-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2018 at 08:42 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `memepartner`
--

-- --------------------------------------------------------

--
-- Table structure for table `dt_abuseprofiles`
--

CREATE TABLE `dt_abuseprofiles` (
  `Id` int(11) NOT NULL,
  `ReportBy` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ProfileId` int(11) NOT NULL DEFAULT '0',
  `Reason` text COLLATE utf8_unicode_ci,
  `ReprotDate` datetime DEFAULT NULL,
  `IsProcess` tinyint(3) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dt_bannedusers`
--

CREATE TABLE `dt_bannedusers` (
  `Id` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `Reason` text COLLATE utf8_unicode_ci NOT NULL,
  `BanedOn` datetime DEFAULT NULL,
  `LiftBanId` int(11) NOT NULL,
  `BannedBy` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dt_blockedusers`
--

CREATE TABLE `dt_blockedusers` (
  `UserID` int(11) NOT NULL,
  `BlockedUserID` int(11) NOT NULL,
  `DateBlock` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dt_bodytypes`
--

CREATE TABLE `dt_bodytypes` (
  `BodyTypeID` smallint(5) UNSIGNED NOT NULL,
  `L1BodyType` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `L2BodyType` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `L3BodyType` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `L4BodyType` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_bodytypes`
--

INSERT INTO `dt_bodytypes` (`BodyTypeID`, `L1BodyType`, `L2BodyType`, `L3BodyType`, `L4BodyType`, `TopSorted`) VALUES
(1, 'Average', 'Average', 'Average', 'Average', 0),
(2, 'Slim', 'Slim', 'Slim', 'Slim', 0),
(3, 'Athletic', 'Athletic', 'Athletic', 'Athletic', 0),
(4, 'Ample', 'Ample', 'Ample', 'Ample', 0),
(6, 'Large', 'Large', 'Large', 'Large', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dt_cards_categories`
--

CREATE TABLE `dt_cards_categories` (
  `Id` int(11) NOT NULL,
  `NameCate` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_cards_categories`
--

INSERT INTO `dt_cards_categories` (`Id`, `NameCate`) VALUES
(1, 'AtWork'),
(2, 'BabyCards'),
(3, 'Birthday'),
(4, 'Congratulation'),
(5, 'Friendship'),
(6, 'Getwell'),
(7, 'Halloween'),
(8, 'Hanukkah'),
(9, 'Invitation'),
(10, 'Love'),
(11, 'Miscellaneous'),
(12, 'NewYear'),
(13, 'Parents'),
(14, 'ReligiousDays'),
(15, 'Sorry'),
(16, 'StPatricksDay'),
(17, 'Thanksgiving'),
(18, 'Thankyou'),
(19, 'Valentine'),
(20, 'Xmas');

-- --------------------------------------------------------

--
-- Table structure for table `dt_chat`
--

CREATE TABLE `dt_chat` (
  `id` int(10) UNSIGNED NOT NULL,
  `from` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `to` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `sent` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `recd` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_chat`
--

INSERT INTO `dt_chat` (`id`, `from`, `to`, `message`, `sent`, `recd`) VALUES
(1, '13', '22', 'hi', '2018-09-19 23:27:11', 0),
(2, '13', '22', 'ako ni bai', '2018-09-20 00:13:47', 0),
(3, '13', '22', 'ggg', '2018-09-20 00:15:17', 0),
(4, '13', '22', 'hey', '2018-09-20 14:01:51', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dt_countries`
--

CREATE TABLE `dt_countries` (
  `CountryID` smallint(5) UNSIGNED NOT NULL,
  `Country` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_countries`
--

INSERT INTO `dt_countries` (`CountryID`, `Country`, `TopSorted`) VALUES
(1, 'Afghanistan', 0),
(2, 'Albania', 0),
(3, 'Algeria', 0),
(4, 'American Samoa', 0),
(5, 'Andorra', 0),
(7, 'Anguilla', 0),
(8, 'Antarctica', 0),
(10, 'Argentina', 0),
(11, 'Armenia', 0),
(12, 'Aruba', 0),
(13, 'Australia', 0),
(14, 'Austria', 0),
(15, 'Azerbaijan', 0),
(17, 'Bahrain', 0),
(18, 'Bangladesh', 0),
(19, 'Barbados', 0),
(20, 'Belarus', 0),
(21, 'Belgium', 0),
(22, 'Belize', 0),
(23, 'Benin', 0),
(24, 'Bermuda', 0),
(25, 'Bhutan', 0),
(26, 'Bolivia', 0),
(27, 'Bosnia', 0),
(28, 'Botswana', 0),
(29, 'Bouvet Island', 0),
(30, 'Brazil', 0),
(32, 'Brunei', 0),
(33, 'Bulgaria', 0),
(34, 'Burkina Faso', 0),
(35, 'Burundi', 0),
(36, 'Cambodia', 0),
(37, 'Cameroon', 0),
(38, 'Canada', 0),
(39, 'Cape Verde', 0),
(40, 'Cayman Islands', 0),
(42, 'Chad', 0),
(43, 'Chile', 0),
(44, 'China', 0),
(49, 'Colombia', 0),
(50, 'Comoros', 0),
(51, 'Congo', 0),
(53, 'Cook Islands', 0),
(54, 'Costa Rica', 0),
(56, 'Croatia', 0),
(57, 'Cuba', 0),
(58, 'Cyprus', 0),
(59, 'Czech Republic', 0),
(60, 'Denmark', 0),
(61, 'Djibouti', 0),
(62, 'Dominica', 0),
(64, 'East Timor', 0),
(65, 'Ecuador', 0),
(66, 'Egypt', 0),
(67, 'El Salvador', 0),
(69, 'Eritrea', 0),
(70, 'Estonia', 0),
(71, 'Ethiopia', 0),
(74, 'Fiji Islands', 0),
(75, 'Finland', 0),
(76, 'France', 0),
(80, 'Gabon', 0),
(82, 'Georgia', 0),
(83, 'Germany', 0),
(84, 'Ghana', 0),
(85, 'Gibraltar', 0),
(86, 'Greece', 0),
(87, 'Greenland', 0),
(88, 'Grenada', 0),
(89, 'Guadeloupe', 0),
(90, 'Guam', 0),
(91, 'Guatemala', 0),
(92, 'Guinea', 0),
(94, 'Guyana', 0),
(95, 'Haiti', 0),
(97, 'Honduras', 0),
(98, 'Hungary', 0),
(99, 'Iceland', 0),
(100, 'India', 0),
(101, 'Indonesia', 0),
(102, 'Iran', 0),
(103, 'Iraq', 0),
(104, 'Ireland', 0),
(105, 'Israel', 0),
(106, 'Italy', 0),
(107, 'Jamaica', 0),
(108, 'Japan', 0),
(109, 'Jordan', 0),
(110, 'Kazakhstan', 0),
(111, 'Kenya', 0),
(112, 'Kiribati', 0),
(113, 'Korea', 0),
(114, 'Korea, North', 0),
(115, 'Kuwait', 0),
(116, 'Kyrgyzstan', 0),
(117, 'Laos', 0),
(118, 'Latvia', 0),
(119, 'Lebanon', 0),
(120, 'Lesotho', 0),
(121, 'Liberia', 0),
(122, 'Libya', 0),
(123, 'Liechtenstein', 0),
(124, 'Lithuania', 0),
(125, 'Luxembourg', 0),
(127, 'Madagascar', 0),
(128, 'Malawi', 0),
(129, 'Malaysia', 0),
(130, 'Maldives', 0),
(131, 'Mali', 0),
(132, 'Malta', 0),
(133, 'Marshall Islands', 0),
(134, 'Martinique', 0),
(135, 'Mauritania', 0),
(136, 'Mauritius', 0),
(137, 'Mayotte', 0),
(138, 'Mexico', 0),
(139, 'Micronesia', 0),
(140, 'Moldova', 0),
(141, 'Monaco', 0),
(142, 'Mongolia', 0),
(143, 'Montserrat', 0),
(144, 'Morocco', 0),
(145, 'Mozambique', 0),
(146, 'Myanmar', 0),
(147, 'Namibia', 0),
(148, 'Nauru', 0),
(149, 'Nepal', 0),
(152, 'New Caledonia', 0),
(153, 'New Zealand', 0),
(154, 'Nicaragua', 0),
(155, 'Niger', 0),
(156, 'Nigeria', 0),
(157, 'Niue', 0),
(158, 'Norfolk Island', 0),
(160, 'Norway', 0),
(161, 'Oman', 0),
(162, 'Pakistan', 0),
(163, 'Palau', 0),
(164, 'Panama', 0),
(166, 'Paraguay', 0),
(167, 'Peru', 0),
(168, 'Philippines', 0),
(169, 'Pitcairn Island', 0),
(170, 'Poland', 0),
(171, 'Portugal', 0),
(172, 'Puerto Rico', 0),
(173, 'Qatar', 0),
(174, 'Reunion', 0),
(175, 'Romania', 0),
(176, 'Russia', 0),
(177, 'Rwanda', 0),
(178, 'Saint Helena', 0),
(180, 'Saint Lucia', 0),
(183, 'Samoa', 0),
(184, 'San Marino', 0),
(186, 'Saudi Arabia', 0),
(187, 'Senegal', 0),
(188, 'Seychelles', 0),
(189, 'Sierra Leone', 0),
(190, 'Singapore', 0),
(191, 'Slovakia', 0),
(192, 'Slovenia', 0),
(193, 'Solomon Islands', 0),
(194, 'Somalia', 0),
(195, 'South Africa', 0),
(197, 'Spain', 0),
(198, 'Sri Lanka', 0),
(199, 'Sudan', 0),
(200, 'Suriname', 0),
(202, 'Swaziland', 0),
(203, 'Sweden', 0),
(204, 'Switzerland', 0),
(205, 'Syria', 0),
(206, 'Taiwan', 0),
(207, 'Tajikistan', 0),
(208, 'Tanzania', 0),
(209, 'Thailand', 0),
(210, 'Togo', 0),
(211, 'Tokelau', 0),
(212, 'Tonga', 0),
(213, 'TrinCountryIDad & Tobago', 0),
(214, 'Tunisia', 0),
(215, 'Turkey', 0),
(216, 'Turkmenistan', 0),
(218, 'Tuvalu', 0),
(219, 'Uganda', 0),
(220, 'Ukraine', 0),
(222, 'United Kingdom', 0),
(223, 'United States', 0),
(225, 'Uruguay', 0),
(226, 'Uzbekistan', 0),
(227, 'Vanuatu', 0),
(229, 'Venezuela', 0),
(230, 'Vietnam', 1),
(234, 'Western Sahara', 0),
(235, 'Yemen', 0),
(236, 'Yugoslavia', 0),
(237, 'Zambia', 0),
(238, 'Zimbabwe', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dt_datinginterest`
--

CREATE TABLE `dt_datinginterest` (
  `DatingInterestID` int(10) UNSIGNED NOT NULL,
  `L1DatingInterest` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `L2DatingInterest` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `L3DatingInterest` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `L4DatingInterest` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_datinginterest`
--

INSERT INTO `dt_datinginterest` (`DatingInterestID`, `L1DatingInterest`, `L2DatingInterest`, `L3DatingInterest`, `L4DatingInterest`, `TopSorted`) VALUES
(1, 'Friendship', 'Friendship', 'Friendship', 'Friendship', 0),
(2, 'Dating', 'Dating', 'Dating', 'Dating', 0),
(3, 'Long-term relationship', 'Long-term relationship', 'Long-term relationship', 'Long-term relationship', 0),
(4, 'Just for Fun', 'Just for Fun', 'Just for Fun', 'Just for Fun', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dt_drinking`
--

CREATE TABLE `dt_drinking` (
  `DrinkingID` smallint(5) UNSIGNED NOT NULL,
  `L1Drinking` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `L2Drinking` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `L3Drinking` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `L4Drinking` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_drinking`
--

INSERT INTO `dt_drinking` (`DrinkingID`, `L1Drinking`, `L2Drinking`, `L3Drinking`, `L4Drinking`, `TopSorted`) VALUES
(1, 'Not drink at all', 'Not drink at all', 'Not drink at all', 'Not drink at all', 0),
(2, 'Light/social drinker', 'Light/social drinker', 'Light/social drinker', 'Light/social drinker', 0),
(3, 'Heavy drinker', 'heavy drinker', 'heavy drinker', 'heavy drinker', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dt_ecards`
--

CREATE TABLE `dt_ecards` (
  `Id` int(11) NOT NULL,
  `SenderId` int(11) NOT NULL DEFAULT '0',
  `RecieverId` int(11) NOT NULL DEFAULT '0',
  `CardId` int(11) NOT NULL DEFAULT '0',
  `CateCardId` int(11) NOT NULL DEFAULT '0',
  `Subjects` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Contents` text COLLATE utf8_unicode_ci,
  `SentDate` datetime DEFAULT NULL,
  `WidthMess` int(11) NOT NULL DEFAULT '0',
  `HeightMess` int(11) NOT NULL DEFAULT '0',
  `LeftMess` int(11) NOT NULL DEFAULT '0',
  `TopMess` int(11) NOT NULL DEFAULT '0',
  `IsReed` tinyint(3) NOT NULL DEFAULT '0',
  `Music` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_ecards`
--

INSERT INTO `dt_ecards` (`Id`, `SenderId`, `RecieverId`, `CardId`, `CateCardId`, `Subjects`, `Contents`, `SentDate`, `WidthMess`, `HeightMess`, `LeftMess`, `TopMess`, `IsReed`, `Music`) VALUES
(1, 13, 18, 96, 16, 'mp3', '', '2018-09-19 16:21:44', 0, 0, 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `dt_educations`
--

CREATE TABLE `dt_educations` (
  `EducationID` smallint(5) UNSIGNED NOT NULL,
  `L1Education` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `L2Education` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `L3Education` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `L4Education` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_educations`
--

INSERT INTO `dt_educations` (`EducationID`, `L1Education`, `L2Education`, `L3Education`, `L4Education`, `TopSorted`) VALUES
(1, 'High School graduate', 'High School graduate', 'High School graduate', 'High School graduate', 0),
(2, 'Some college', 'Some college', 'Some college', 'Some college', 0),
(3, 'Current college student', 'Current college student', 'Current college student', 'Current college student', 0),
(4, 'AA (2 years college)', 'AA (2 years college)', 'AA (2 years college)', 'AA (2 years college)', 0),
(5, 'BA/BS (4 years college)', 'BA/BS (4 years college)', 'BA/BS (4 years college)', 'BA/BS (4 years college)', 0),
(6, 'Current grad school student', 'Current grad school student', 'Current grad school student', 'Current grad school student', 0),
(7, 'MA/MS/MBA', 'MA/MS/MBA', 'MA/MS/MBA', 'MA/MS/MBA', 0),
(8, 'PhD/Post doctorate', 'PhD/Post doctorate', 'PhD/Post doctorate', 'PhD/Post doctorate', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dt_eyescolors`
--

CREATE TABLE `dt_eyescolors` (
  `EyeColorID` int(10) UNSIGNED NOT NULL,
  `L1EyeColor` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `L2EyeColor` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `L3EyeColor` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `L4EyeColor` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_eyescolors`
--

INSERT INTO `dt_eyescolors` (`EyeColorID`, `L1EyeColor`, `L2EyeColor`, `L3EyeColor`, `L4EyeColor`, `TopSorted`) VALUES
(1, 'Black', 'Black', 'Black', 'Black', 0),
(2, 'Blue', 'Blue', 'Blue', 'Blue', 0),
(3, 'Brown', 'Brown', 'Brown', 'Brown', 0),
(4, 'Gray', 'Gray', 'Gray', 'Gray', 0),
(5, 'Green', 'Green', 'Green', 'Green', 0),
(6, 'Hazel', 'Hazel', 'Hazel', 'Hazel', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dt_filteremails`
--

CREATE TABLE `dt_filteremails` (
  `Id` int(11) NOT NULL,
  `EmailAddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BanEmail` tinyint(3) NOT NULL DEFAULT '0',
  `BanDomain` tinyint(3) NOT NULL DEFAULT '0',
  `BanDate` datetime DEFAULT NULL,
  `ReasonBaned` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dt_flirts`
--

CREATE TABLE `dt_flirts` (
  `Id` int(11) NOT NULL,
  `CateId` int(11) NOT NULL DEFAULT '0',
  `FilrtValue` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_flirts`
--

INSERT INTO `dt_flirts` (`Id`, `CateId`, `FilrtValue`) VALUES
(1, 1, 'How is it what have not been snatched up yet ?'),
(2, 1, 'You look and sound adorable. I''d love to learn more.'),
(3, 1, 'I''d travel a milion miles to see your smile'),
(4, 1, 'Candlelight, sunlight, or moonlight'),
(5, 1, 'I''d a shot at sweeping you off your feet.'),
(6, 1, 'Judging your book by its cover. I''d love to curl up and reed the rest.'),
(7, 1, 'I''d canve your name every tree from Los Angeles to New York'),
(8, 2, 'Flirt cate 2.1'),
(9, 2, 'Flirt cate 2.2'),
(10, 2, 'Flirt cate 2.3'),
(11, 3, 'Flirt cate 3.1'),
(12, 3, 'Flirt cate 3.2'),
(13, 3, 'Flirt cate 3.3'),
(14, 4, 'Flirt cate 4.1'),
(15, 4, 'Flirt cate 4.2'),
(16, 4, 'Flirt cate 4.3'),
(17, 5, 'Flirt cate 5.1'),
(18, 5, 'Flirt cate 5.2'),
(19, 5, 'Flirt cate 5.3'),
(20, 6, 'Flirt cate 6.1'),
(21, 6, 'Flirt cate 6.2'),
(22, 6, 'Flirt cate 6.3');

-- --------------------------------------------------------

--
-- Table structure for table `dt_flirt_categories`
--

CREATE TABLE `dt_flirt_categories` (
  `Id` int(11) NOT NULL,
  `NameCate` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_flirt_categories`
--

INSERT INTO `dt_flirt_categories` (`Id`, `NameCate`) VALUES
(1, 'Romantic'),
(2, 'Humorous'),
(3, 'Casual'),
(4, 'Whose line is it anyway'),
(5, 'Holiday / Seasonal'),
(6, 'Juda''isms');

-- --------------------------------------------------------

--
-- Table structure for table `dt_gender`
--

CREATE TABLE `dt_gender` (
  `GenderID` smallint(5) UNSIGNED NOT NULL,
  `L1Gender` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `L2Gender` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `L3Gender` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `L4Gender` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `TopSorted` tinyint(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_gender`
--

INSERT INTO `dt_gender` (`GenderID`, `L1Gender`, `L2Gender`, `L3Gender`, `L4Gender`, `TopSorted`) VALUES
(1, 'Male', 'Male', '', '', NULL),
(2, 'Female', 'Female', '', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dt_greetingcards`
--

CREATE TABLE `dt_greetingcards` (
  `Id` int(11) NOT NULL,
  `CardCate` int(11) NOT NULL DEFAULT '0',
  `CardName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IsText` int(11) NOT NULL DEFAULT '0',
  `ViewFormat` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_greetingcards`
--

INSERT INTO `dt_greetingcards` (`Id`, `CardCate`, `CardName`, `IsText`, `ViewFormat`) VALUES
(1, 1, 'i-AtWork-1@2x.jpg', 0, NULL),
(2, 1, 'i-AtWork-2@2x.jpg', 0, NULL),
(3, 1, 'i-AtWork-3@2x.jpg', 0, NULL),
(4, 1, 'i-AtWork-4@2x.jpg', 0, NULL),
(5, 2, 'i-BabyCards-1@2x.jpg', 0, NULL),
(6, 2, 'i-BabyCards-2@2x.jpg', 0, NULL),
(7, 2, 'i-BabyCards-3@2x.jpg', 0, NULL),
(8, 2, 'i-BabyCards-4@2x.jpg', 0, NULL),
(9, 3, 'i-Birthday-1@2x.jpg', 0, NULL),
(10, 3, 'i-Birthday-2@2x.jpg', 0, NULL),
(11, 3, 'i-Birthday-3@2x.jpg', 0, NULL),
(12, 3, 'i-Birthday-4@2x.jpg', 0, NULL),
(13, 3, 'i-Birthday-5@2x.jpg', 0, NULL),
(14, 3, 'i-Birthday-6@2x.jpg', 0, NULL),
(15, 3, 'i-Birthday-7@2x.jpg', 0, NULL),
(16, 3, 'i-Birthday-8@2x.jpg', 0, NULL),
(17, 3, 'i-Birthday-9@2x.jpg', 0, NULL),
(18, 4, 'i-Congratulation-1@2x.jpg', 0, NULL),
(19, 4, 'i-Congratulation-2@2x.jpg', 0, NULL),
(20, 4, 'i-Congratulation-3@2x.jpg', 0, NULL),
(21, 4, 'i-Congratulation-4@2x.jpg', 0, NULL),
(22, 4, 'i-Congratulation-5@2x.jpg', 0, NULL),
(23, 5, 'i-Friendship-1@2x.jpg', 0, NULL),
(24, 5, 'i-Friendship-2@2x.jpg', 0, NULL),
(25, 5, 'i-Friendship-3@2x.jpg', 0, NULL),
(26, 5, 'i-Friendship-4@2x.jpg', 0, NULL),
(27, 5, 'i-Friendship-5@2x.jpg', 0, NULL),
(28, 6, 'i-Getwell-1@2x.jpg', 0, NULL),
(29, 6, 'i-Getwell-2@2x.jpg', 0, NULL),
(30, 6, 'i-Getwell-3@2x.jpg', 0, NULL),
(31, 6, 'i-Getwell-4@2x.jpg', 0, NULL),
(32, 6, 'i-Getwell-5@2x.jpg', 0, NULL),
(33, 7, 'i-Halloween-1@2x.jpg', 0, NULL),
(34, 7, 'i-Halloween-2@2x.jpg', 0, NULL),
(35, 7, 'i-Halloween-3@2x.jpg', 0, NULL),
(36, 7, 'i-Halloween-4@2x.jpg', 0, NULL),
(37, 7, 'i-Halloween-5@2x.jpg', 0, NULL),
(38, 8, 'i-Hanukkah-1@2x.jpg', 0, NULL),
(39, 8, 'i-Hanukkah-2@2x.jpg', 0, NULL),
(40, 8, 'i-Hanukkah-3@2x.jpg', 0, NULL),
(41, 8, 'i-Hanukkah-4@2x.jpg', 0, NULL),
(42, 8, 'i-Hanukkah-5@2x.jpg', 0, NULL),
(43, 8, 'i-Hanukkah-6@2x.jpg', 0, NULL),
(44, 8, 'i-Hanukkah-7@2x.jpg', 0, NULL),
(45, 8, 'i-Hanukkah-8@2x.jpg', 0, NULL),
(46, 8, 'i-Hanukkah-9@2x.jpg', 0, NULL),
(47, 8, 'i-Hanukkah-10@2x.jpg', 0, NULL),
(48, 8, 'i-Hanukkah-11@2x.jpg', 0, NULL),
(49, 8, 'i-Hanukkah-12@2x.jpg', 0, NULL),
(50, 8, 'i-Hanukkah-13@2x.jpg', 0, NULL),
(51, 8, 'i-Hanukkah-14@2x.jpg', 0, NULL),
(52, 8, 'i-Hanukkah-15@2x.jpg', 0, NULL),
(53, 9, 'i-Invitation-1@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:145px; margin-top:30px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;12&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(54, 9, 'i-Invitation-2@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:145px; margin-top:45px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;12&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(55, 9, 'i-Invitation-3@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:145px; margin-top:45px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;12&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#FFF&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(56, 9, 'i-Invitation-4@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:145px; margin-top:45px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;12&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(57, 9, 'i-Invitation-5@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:145px; margin-top:70px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;10&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(58, 10, 'i-Love-1@2x.jpg', 0, NULL),
(59, 10, 'i-Love-2@2x.jpg', 0, NULL),
(60, 10, 'i-Love-3@2x.jpg', 0, NULL),
(61, 10, 'i-Love-4@2x.jpg', 0, NULL),
(62, 10, 'i-Love-5@2x.jpg', 0, NULL),
(63, 10, 'i-Love-6@2x.jpg', 0, NULL),
(64, 11, 'i-Miscellaneous-1@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:145px; margin-top:40px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;10&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(65, 11, 'i-Miscellaneous-2@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:145px; margin-top:50px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;10&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(66, 11, 'i-Miscellaneous-3@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:145px; margin-top:70px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;10&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(67, 11, 'i-Miscellaneous-4@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:170px; margin-top:30px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;10&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(68, 11, 'i-Miscellaneous-5@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:160px; margin-top:100px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;10&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(69, 11, 'i-Miscellaneous-6@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:160px; margin-top:60px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;10&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(70, 11, 'i-Miscellaneous-7@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:150px; margin-top:70px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;9&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(71, 12, 'i-NewYear-1@2x.jpg', 0, NULL),
(72, 12, 'i-NewYear-2@2x.jpg', 0, NULL),
(73, 12, 'i-NewYear-3@2x.jpg', 0, NULL),
(74, 12, 'i-NewYear-4@2x.jpg', 0, NULL),
(75, 12, 'i-NewYear-5@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:140px; margin-top:60px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;10&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(76, 13, 'i-Parents-1@2x.jpg', 0, NULL),
(77, 13, 'i-Parents-2@2x.jpg', 0, NULL),
(78, 13, 'i-Parents-3@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:140px; margin-top:40px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;13&quot;  style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; text-shadow: -1px 0 white, 0 1px white, 1px 0 white, 0 -1px white;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(79, 13, 'i-Parents-4@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:140px; margin-top:40px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;13&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; text-shadow: -1px 0 white, 0 1px white, 1px 0 white, 0 -1px white;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(80, 13, 'i-Parents-5@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:160px; margin-top:80px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;8&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; text-shadow: -1px 0 white, 0 1px white, 1px 0 white, 0 -1px white;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(81, 14, 'i-ReligiousDays-1@2x.jpg', 0, NULL),
(82, 14, 'i-ReligiousDays-2@2x.jpg', 0, NULL),
(83, 14, 'i-ReligiousDays-3@2x.jpg', 0, NULL),
(84, 14, 'i-ReligiousDays-4@2x.jpg', 0, NULL),
(85, 14, 'i-ReligiousDays-5@2x.jpg', 0, NULL),
(86, 14, 'i-ReligiousDays-6@2x.jpg', 0, NULL),
(87, 14, 'i-ReligiousDays-7@2x.jpg', 0, NULL),
(88, 14, 'i-ReligiousDays-8@2x.jpg', 0, NULL),
(89, 14, 'i-ReligiousDays-9@2x.jpg', 0, NULL),
(90, 15, 'i-Sorry-1@2x.jpg', 0, NULL),
(91, 15, 'i-Sorry-2@2x.jpg', 0, NULL),
(92, 15, 'i-Sorry-3@2x.jpg', 0, NULL),
(93, 15, 'i-Sorry-4@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:130px; margin-top:30px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;18&quot; rows=&quot;7&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(94, 15, 'i-Sorry-5@2x.jpg', 0, NULL),
(95, 16, 'i-StPatricksDay-1@2x.jpg', 0, NULL),
(96, 16, 'i-StPatricksDay-1@2x.jpg', 0, NULL),
(97, 16, 'i-StPatricksDay-3@2x.jpg', 0, NULL),
(98, 16, 'i-StPatricksDay-4@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:130px; margin-top:50px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;18&quot; rows=&quot;7&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(99, 16, 'i-StPatricksDay-5@2x.jpg', 0, NULL),
(100, 16, 'i-StPatricksDay-6@2x.jpg', 0, NULL),
(101, 17, 'i-Thanksgiving-1@2x.jpg', 0, NULL),
(102, 17, 'i-Thanksgiving-2@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:130px; margin-top:50px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;18&quot; rows=&quot;7&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(103, 17, 'i-Thanksgiving-3@2x.jpg', 0, NULL),
(104, 17, 'i-Thanksgiving-4@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:130px; margin-top:50px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;18&quot; rows=&quot;7&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(105, 17, 'i-Thanksgiving-5@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:130px; margin-top:50px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;18&quot; rows=&quot;7&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(106, 18, 'i-Thankyou-1@2x.jpg', 0, NULL),
(107, 18, 'i-Thankyou-2@2x.jpg', 0, NULL),
(108, 18, 'i-Thankyou-3@2x.jpg', 0, NULL),
(109, 18, 'i-Thankyou-4@2x.jpg', 0, NULL),
(110, 18, 'i-Thankyou-5@2x.jpg', 0, NULL),
(111, 19, 'i-Valentine-1@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:140px; margin-top:90px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;16&quot; rows=&quot;9&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(112, 19, 'i-Valentine-2@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:140px; margin-top:100px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;16&quot; rows=&quot;8&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#FFF&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(113, 19, 'i-Valentine-3@2x.jpg', 0, NULL),
(114, 19, 'i-Valentine-4@2x.jpg', 0, NULL),
(115, 19, 'i-Valentine-5@2x.jpg', 0, NULL),
(116, 19, 'i-Valentine-6@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:110px; margin-top:155px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;23&quot; rows=&quot;7&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(117, 19, 'i-Valentine-7@2x.jpg', 0, NULL),
(118, 19, 'i-Valentine-8@2x.jpg', 0, NULL),
(119, 19, 'i-Valentine-9@2x.jpg', 0, NULL),
(120, 19, 'i-Valentine-10@2x.jpg', 0, NULL),
(121, 19, 'i-Valentine-11@2x.jpg', 0, NULL),
(122, 19, 'i-Valentine-12@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:160px; margin-top:70px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;12&quot; rows=&quot;9&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(123, 19, 'i-Valentine-13@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:130px; margin-top:90px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;18&quot; rows=&quot;4&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(124, 19, 'i-Valentine-14@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:140px; margin-top:100px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;17&quot; rows=&quot;5&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(125, 19, 'i-Valentine-15@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:125px; margin-top:100px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;20&quot; rows=&quot;7&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(126, 19, 'i-Valentine-16@2x.jpg', 0, NULL),
(127, 19, 'i-Valentine-17@2x.jpg', 0, NULL),
(128, 19, 'i-Valentine-18@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:125px; margin-top:70px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;20&quot; rows=&quot;7&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#FFF&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(129, 19, 'i-Valentine-19@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:125px; margin-top:30px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;20&quot; rows=&quot;6&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(130, 19, 'i-Valentine-20@2x.jpg', 0, NULL),
(131, 19, 'i-Valentine-21@2x.jpg', 0, NULL),
(132, 19, 'i-Valentine-22@2x.jpg', 0, NULL),
(133, 19, 'i-Valentine-23@2x.jpg', 0, NULL),
(134, 19, 'i-Valentine-24@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:125px; margin-top:200px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;20&quot; rows=&quot;4&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#FFF&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(135, 19, 'i-Valentine-25@2x.jpg', 0, NULL),
(136, 19, 'i-Valentine-26@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:125px; margin-top:55px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;20&quot; rows=&quot;4&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(137, 19, 'i-Valentine-27@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:125px; margin-top:65px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;20&quot; rows=&quot;4&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(138, 19, 'i-Valentine-28@2x.jpg', 0, NULL),
(139, 19, 'i-Valentine-29@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:125px; margin-top:30px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;20&quot; rows=&quot;4&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(140, 19, 'i-Valentine-30@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:125px; margin-top:30px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;20&quot; rows=&quot;5&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(141, 19, 'i-Valentine-31@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:120px; margin-top:25px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;18&quot; rows=&quot;6&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(142, 20, 'i-Xmas-1@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:130px; margin-top:80px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;18&quot; rows=&quot;7&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(143, 20, 'i-Xmas-2@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:150px; margin-top:120px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;14&quot; rows=&quot;5&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(144, 20, 'i-Xmas-3@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:130px; margin-top:40px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;13&quot; rows=&quot;6&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(145, 20, 'i-Xmas-4@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:145px; margin-top:130px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;14&quot; rows=&quot;7&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(146, 20, 'i-Xmas-5@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:150px; margin-top:60px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;14&quot; rows=&quot;6&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(147, 20, 'i-Xmas-6@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:130px; margin-top:90px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;18&quot; rows=&quot;7&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(148, 20, 'i-Xmas-7@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:170px; margin-top:50px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;14&quot; rows=&quot;6&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(149, 20, 'i-Xmas-8@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:135px; margin-top:80px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;17&quot; rows=&quot;8&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(150, 20, 'i-Xmas-9@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:155px; margin-top:60px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;14&quot; rows=&quot;8&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(151, 20, 'i-Xmas-10@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:110px; margin-top:70px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;14&quot; rows=&quot;8&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#FFF&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(152, 20, 'i-Xmas-11@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:110px; margin-top:70px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;16&quot; rows=&quot;8&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#000&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(153, 20, 'i-Xmas-12@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:140px; margin-top:70px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;16&quot; rows=&quot;8&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#00F&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(154, 20, 'i-Xmas-13@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:110px; margin-top:80px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;22&quot; rows=&quot;7&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#00F&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(155, 20, 'i-Xmas-14@2x.jpg', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:110px; margin-top:80px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;22&quot; rows=&quot;7&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#FFF&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(156, 20, 'i-Xmas-15@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:115px; margin-top:100px; background:transparent; text-align:left&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;22&quot; rows=&quot;7&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#00F&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(157, 20, 'i-Xmas-16@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:150px; margin-top:80px; background:transparent; text-align:left;&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;14&quot; rows=&quot;8&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#00F;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(158, 20, 'i-Xmas-17@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:150px; margin-top:125px; background:transparent; text-align:left;&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;14&quot; rows=&quot;5&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#00F;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(159, 20, 'i-Xmas-18@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:120px; margin-top:50px; background:transparent; text-align:left;&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;20&quot; rows=&quot;8&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#00F;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(160, 20, 'i-Xmas-19@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:135px; margin-top:50px; background:transparent; text-align:left;&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;16&quot; rows=&quot;8&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#00F;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(161, 20, 'i-Xmas-20@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:150px; margin-top:65px; background:transparent; text-align:left;&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;14&quot; rows=&quot;5&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#00F;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;&lt;/div&gt;'),
(162, 20, 'i-Xmas-21@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:145px; margin-top:70px; background:transparent; text-align:left;&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;14&quot; rows=&quot;5&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#00F;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;&lt;/div&gt;'),
(163, 20, 'i-Xmas-22@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:120px; margin-top:70px; background:transparent; text-align:left;&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;20&quot; rows=&quot;8&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#00F;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(164, 20, 'i-Xmas-23@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:135px; margin-top:55px; background:transparent; text-align:left;&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;18&quot; rows=&quot;8&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#00F;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(165, 20, 'i-Xmas-24@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:135px; margin-top:65px; background:transparent; text-align:left;&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;17&quot; rows=&quot;10&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#00F;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(166, 20, 'i-Xmas-25@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:142px; margin-top:80px; background:transparent; text-align:left;&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;15&quot; rows=&quot;8&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#00F;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;'),
(167, 20, 'i-Xmas-26@2x.png', 1, '&lt;div style=&quot;width:230px; background-color:#999; height:180px; margin-left:150px; margin-top:85px; background:transparent; text-align:left;&quot; id=&quot;loadtext&quot;&gt;\r\n        	&lt;textarea cols=&quot;13&quot; rows=&quot;4&quot; style=&quot;border:hidden; background:transparent; overflow:hidden; text-align:justify; font-style:italic; color:#00F;&quot; placeholder=&quot;Your message&quot; id=&quot;yourmess&quot;&gt;&lt;/textarea&gt;\r\n        &lt;/div&gt;');

-- --------------------------------------------------------

--
-- Table structure for table `dt_haircolors`
--

CREATE TABLE `dt_haircolors` (
  `HairColorID` int(10) UNSIGNED NOT NULL,
  `L1HairColor` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `L2HairColor` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `L3HairColor` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `L4HairColor` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_haircolors`
--

INSERT INTO `dt_haircolors` (`HairColorID`, `L1HairColor`, `L2HairColor`, `L3HairColor`, `L4HairColor`, `TopSorted`) VALUES
(1, 'Black', 'Black', 'Black', 'Black', 1),
(2, 'Auburn', 'Auburn', 'Auburn', 'Auburn', 0),
(3, 'Blonde', 'Blonde', 'Blonde', 'Blonde', 0),
(4, 'Light Brown', 'Light Brown', 'Light Brown', 'Light Brown', 0),
(5, 'Dark Brown', 'Dark Brown', 'Dark Brown', 'Dark Brown', 0),
(6, 'Red', 'Red', 'Red', 'Red', 0),
(7, 'White/gray', 'White/gray', 'White/gray', 'White/gray', 0),
(8, 'Bald', 'Bald', 'Bald', 'Bald', 0),
(9, 'A little gray', 'A little gray', 'A little gray', 'A little gray', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dt_height`
--

CREATE TABLE `dt_height` (
  `HeightID` smallint(5) UNSIGNED NOT NULL,
  `Height` decimal(3,2) NOT NULL DEFAULT '0.00',
  `HeightDescription` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_height`
--

INSERT INTO `dt_height` (`HeightID`, `Height`, `HeightDescription`, `TopSorted`) VALUES
(349, '4.00', '(122cm)', 0),
(350, '4.10', '(125cm)', 0),
(351, '4.20', '(127cm)', 0),
(352, '4.30', '(129cm)', 0),
(353, '4.40', '(132cm)', 0),
(354, '4.50', '(135cm)', 0),
(355, '4.60', '(137cm)', 0),
(356, '4.70', '(140cm)', 0),
(357, '4.80', '(142cm)', 0),
(358, '4.90', '(145cm)', 0),
(359, '4.10', '(147cm)', 0),
(360, '4.11', '(149cm)', 0),
(361, '5.00', '(152cm)', 0),
(362, '5.10', '(154cm)', 0),
(363, '5.20', '(157cm)', 0),
(364, '5.30', '(160cm)', 0),
(365, '5.40', '(163cm)', 0),
(366, '5.50', '(165cm)', 0),
(367, '5.60', '(168cm)', 0),
(368, '5.70', '(170cm)', 0),
(369, '5.80', '(173cm)', 0),
(370, '5.90', '(175cm)', 0),
(371, '5.10', '(178cm)', 0),
(372, '5.11', '(180cm)', 0),
(373, '6.00', '(183cm)', 0),
(374, '6.10', '(185cm)', 0),
(375, '6.20', '(188cm)', 0),
(376, '6.30', '(190cm)', 0),
(377, '6.40', '(193cm)', 0),
(378, '6.50', '(195cm)', 0),
(379, '6.60', '(198cm)', 0),
(380, '6.70', '(200cm)', 0),
(381, '6.80', '(203cm)', 0),
(382, '6.90', '(205cm)', 0),
(383, '6.10', '(208cm)', 0),
(384, '6.11', '(210cm)', 0),
(385, '7.00', '(213cm)', 0),
(386, '7.10', '(215cm)', 0),
(387, '7.20', '(218cm)', 0),
(388, '7.30', '(220cm)', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dt_hotlists`
--

CREATE TABLE `dt_hotlists` (
  `UserID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `SavedUserID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `SavedDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_hotlists`
--

INSERT INTO `dt_hotlists` (`UserID`, `SavedUserID`, `SavedDate`) VALUES
(13, 18, '2018-09-19 20:44:58'),
(13, 25, '2018-09-19 20:45:46');

-- --------------------------------------------------------

--
-- Table structure for table `dt_liftbaned`
--

CREATE TABLE `dt_liftbaned` (
  `Id` int(11) NOT NULL,
  `L1LiftBan` varchar(255) CHARACTER SET utf8 NOT NULL,
  `L2LiftBan` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_liftbaned`
--

INSERT INTO `dt_liftbaned` (`Id`, `L1LiftBan`, `L2LiftBan`) VALUES
(-1, 'Never', 'Never'),
(1, '1 day', '1 day'),
(2, '2 days', '2 days'),
(3, '3 days', '3 days'),
(4, '4 days', '4 days'),
(5, '5 days', '5 days'),
(6, '6 days', '6 days'),
(7, '1 week', '1 week'),
(14, '2 week', '2 weeks'),
(21, '3 week', '3 weeks'),
(30, '1 month', '1 month'),
(60, '2 months', '2 months'),
(90, '3 months', '3 months'),
(120, '4 months', '4 months'),
(150, '5 months', '5 months'),
(180, '6 months', '6 months'),
(210, '7 months', '7 months'),
(240, '8 months', '8 months'),
(270, '9 months', '9 months'),
(300, '10 months', '10 months'),
(330, '11 months', '11 months'),
(365, '1 year', '1 year');

-- --------------------------------------------------------

--
-- Table structure for table `dt_maritalstatus`
--

CREATE TABLE `dt_maritalstatus` (
  `MaritalStatusID` smallint(5) UNSIGNED NOT NULL,
  `L1MaritalStatus` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `L2MaritalStatus` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `L3MaritalStatus` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `L4MaritalStatus` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_maritalstatus`
--

INSERT INTO `dt_maritalstatus` (`MaritalStatusID`, `L1MaritalStatus`, `L2MaritalStatus`, `L3MaritalStatus`, `L4MaritalStatus`, `TopSorted`) VALUES
(1, 'Single', 'Single', 'Single', 'Single', NULL),
(2, 'In Relationship', 'In Relationship', 'In Relationship', 'In Relationship', NULL),
(3, 'Married', 'Married', 'Married', 'Married', NULL),
(4, 'Widowed', 'Widowed', 'Widowed', 'Widowed', NULL),
(5, 'Separated', 'Separated', 'Separated', 'Separated', NULL),
(6, 'Divorced', 'Divorced', 'Divorced', 'Divorced', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dt_messages`
--

CREATE TABLE `dt_messages` (
  `MessageID` int(10) UNSIGNED NOT NULL,
  `RecieverID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `SenderID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `RecieverStatusID` tinyint(3) UNSIGNED DEFAULT '1',
  `SenderStatusID` tinyint(3) UNSIGNED DEFAULT '1',
  `SentOn` datetime DEFAULT NULL,
  `ReadOn` datetime DEFAULT NULL,
  `ReplyID` int(10) UNSIGNED DEFAULT NULL,
  `AttachmentUID` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AttachmentExtension` varchar(7) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Subject` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Message` text COLLATE utf8_unicode_ci,
  `MessageStatus` tinyint(3) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_messages`
--

INSERT INTO `dt_messages` (`MessageID`, `RecieverID`, `SenderID`, `RecieverStatusID`, `SenderStatusID`, `SentOn`, `ReadOn`, `ReplyID`, `AttachmentUID`, `AttachmentExtension`, `Subject`, `Message`, `MessageStatus`) VALUES
(1, 13, 32, 0, 0, '2018-08-20 16:46:57', '2018-08-30 18:05:15', 0, '', '', 'Can u receive this?', 'Please reply', 1),
(2, 32, 13, 1, 0, '2018-08-22 15:30:53', '2018-08-30 18:08:21', 1, '', '', 're.Can u receive this?', 'Yes I can', 1),
(3, 32, 13, 1, 0, '2018-08-30 18:05:15', '2018-08-30 18:08:08', 1, '', '', 're.Can u receive this?', 'Yes', 1),
(4, 13, 18, 0, 0, '2018-08-30 18:14:43', '2018-08-31 13:17:55', 0, '', '', 'message', 'message', 1),
(5, 13, 18, 0, 0, '2018-08-30 18:14:43', '2018-08-31 13:17:51', 0, '', '', 'message', 'message', 1),
(6, 16, 18, 0, 1, '2018-08-30 18:15:08', '2018-09-21 23:33:07', 0, '', '', 'test message', 'test message', 1),
(7, 13, 32, 0, 0, '2018-08-31 13:19:16', '2018-09-21 22:23:31', 0, '', '', 'message', 'message', 1),
(8, 32, 32, 1, 0, '2018-08-31 13:19:35', '2018-08-31 13:19:38', 0, '', '', 'message', 'message', 1),
(9, 32, 32, 1, 0, '2018-08-31 13:19:50', '2018-08-31 13:19:56', 0, '', '', 'message', 'message', 1),
(10, 32, 32, 0, 0, '2018-08-31 13:20:37', '2018-08-31 13:23:07', 0, '', '', 'message', 'message', 1),
(11, 32, 32, 1, 0, '2018-08-31 13:21:10', '2018-08-31 13:21:12', 0, '', '', ' message', '&nbsp;<span style="white-space:pre">	</span>message', 1),
(12, 32, 32, 0, 0, '2018-08-31 13:21:22', '2018-08-31 13:23:07', 0, '', '', 'message', 'message', 1),
(13, 32, 32, 0, 0, '2018-08-31 13:21:22', '2018-08-31 13:23:07', 0, '', '', 'message', 'message', 1),
(14, 32, 32, 0, 0, '2018-08-31 13:21:28', '2018-08-31 13:23:07', 0, '', '', 'message', 'message', 1),
(15, 32, 32, 0, 0, '2018-08-31 13:21:28', '2018-08-31 13:23:07', 0, '', '', 'message', 'message', 1),
(16, 32, 32, 0, 0, '2018-08-31 13:21:32', '2018-08-31 13:26:03', 0, '', '', 'message', 'message', 1),
(17, 32, 32, 0, 0, '2018-08-31 13:21:32', '2018-08-31 13:23:07', 0, '', '', 'message', 'message', 1),
(18, 32, 32, 0, 0, '2018-08-31 13:21:35', '2018-08-31 13:26:03', 0, '', '', 'message', 'message', 1),
(19, 32, 32, 0, 0, '2018-08-31 13:21:44', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(20, 32, 32, 0, 0, '2018-08-31 13:21:48', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(21, 32, 32, 0, 0, '2018-08-31 13:21:51', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(22, 32, 32, 0, 0, '2018-08-31 13:21:55', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(23, 32, 32, 0, 0, '2018-08-31 13:21:59', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(24, 32, 32, 0, 0, '2018-08-31 13:22:03', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(25, 32, 32, 0, 0, '2018-08-31 13:22:08', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(26, 32, 32, 0, 0, '2018-08-31 13:22:12', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(27, 32, 13, 0, 0, '2018-08-31 13:23:38', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(28, 32, 13, 0, 0, '2018-08-31 13:24:13', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(29, 32, 13, 0, 0, '2018-08-31 13:24:20', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(30, 32, 13, 0, 0, '2018-08-31 13:24:20', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(31, 32, 13, 0, 0, '2018-08-31 13:24:23', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(32, 32, 13, 0, 0, '2018-08-31 13:24:23', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(33, 32, 13, 0, 0, '2018-08-31 13:24:27', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(34, 32, 13, 0, 0, '2018-08-31 13:24:32', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(35, 32, 13, 0, 0, '2018-08-31 13:24:32', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(36, 32, 13, 0, 0, '2018-08-31 13:24:36', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(37, 32, 13, 0, 0, '2018-08-31 13:24:43', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(38, 32, 13, 0, 0, '2018-08-31 13:24:47', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(39, 32, 13, 0, 0, '2018-08-31 13:24:47', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(40, 32, 13, 0, 0, '2018-08-31 13:24:53', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(41, 32, 13, 0, 0, '2018-08-31 13:24:53', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(42, 32, 13, 0, 0, '2018-08-31 13:24:57', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(43, 32, 13, 0, 0, '2018-08-31 13:25:01', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(44, 32, 13, 0, 0, '2018-08-31 13:25:06', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(45, 32, 13, 0, 0, '2018-08-31 13:25:06', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(46, 32, 13, 0, 0, '2018-08-31 13:25:12', '2018-08-31 13:26:03', 0, '', '', 'Antonio Carvajal', 'Antonio Carvajal', 1),
(47, 18, 13, 1, 0, '2018-09-19 15:44:46', '2018-09-19 21:53:20', 0, '0', '', 'Send a flirt', 'Flirt cate 2.2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dt_notifyemail`
--

CREATE TABLE `dt_notifyemail` (
  `Id` int(11) NOT NULL,
  `L1NOTIFY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `L2NOTIFY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_notifyemail`
--

INSERT INTO `dt_notifyemail` (`Id`, `L1NOTIFY`, `L2NOTIFY`) VALUES
(1, 'Daily', 'Daily'),
(2, 'Monthly', 'Monthly'),
(3, 'Instantly', 'Instantly'),
(4, 'Do not email', 'Do not email');

-- --------------------------------------------------------

--
-- Table structure for table `dt_orders`
--

CREATE TABLE `dt_orders` (
  `Id` int(11) NOT NULL,
  `OrderId` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `UserId` int(11) NOT NULL DEFAULT '0',
  `PayDate` datetime DEFAULT NULL,
  `Amounts` int(11) NOT NULL DEFAULT '0',
  `Status` tinyint(1) NOT NULL DEFAULT '0',
  `PaymentId_NL` bigint(20) NOT NULL DEFAULT '0',
  `PaymentType_NL` tinyint(3) NOT NULL DEFAULT '0',
  `PriceId` int(11) NOT NULL DEFAULT '0',
  `ExpireDate` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_orders`
--

INSERT INTO `dt_orders` (`Id`, `OrderId`, `UserId`, `PayDate`, `Amounts`, `Status`, `PaymentId_NL`, `PaymentType_NL`, `PriceId`, `ExpireDate`) VALUES
(1, '', 13, '2018-09-19 15:38:39', 6, 0, 0, 0, 3, NULL),
(2, '', 13, '2018-09-19 15:38:51', 6, 0, 0, 0, 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dt_pages`
--

CREATE TABLE `dt_pages` (
  `Id` int(11) NOT NULL,
  `PageName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PageBody` longtext COLLATE utf8_unicode_ci,
  `LastUpdated` datetime DEFAULT NULL,
  `IsActive` tinyint(3) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_pages`
--

INSERT INTO `dt_pages` (`Id`, `PageName`, `PageBody`, `LastUpdated`, `IsActive`) VALUES
(1, 'Term of use', '<div class="helpcontent">\r\n                	                        <p><b>This site was offline for royal and true, we would be allowed to set up the rules as follows:</b> </p>\r\n\r\n                        <p class="lheight23"><b>1. Images:</b> The \r\nwebsite will censor all images posted on member profile, members can \r\nview their pictures immediately after posting, but others can not see if\r\n the pictures are not censored. The picture below will not be accepted: </p>\r\n    \r\n                        <p class="indentlh23">a. Naked pictures (No shirt or pants) .</p>\r\n                        <p class="indentlh23">b. Character image is sexually or provoke violence (of tongue, hand signs, invasions mark on hand, on his . . .) .</p>\r\n                        <p class="indentlh23">c. Image ad or website name or email address .</p>\r\n                        <p class="indentlh23">d. Figure fruits, plants, \r\ncars, houses, utensils, gold and silver (Generally is not your image). \r\nFigure a political character, or support parties, religious .</p>\r\n                        <p class="indentlh23">e. Figure children or persons under 18 years old .</p>\r\n                        \r\n                        <p><i>Please only post pictures of you find your purpose .</i> </p>\r\n    \r\n                        <p><b>2. Profiles:</b> The website will censor all new documents published or revised and rewritten .</p>\r\n                        <p class="indentlh23">Site only accept \r\napplication for up to find your purpose Tetragonal. Please do not \r\njoking, swearing, or saying to use this service to advertise private \r\nbusinesses .</p>\r\n                        <p class="indentlh23">Please do not post email address or phone number on your profile . </p>\r\n                        <p><i>We would refuse no records to find your purpose or not proper records rules .</i></p>\r\n                        \r\n                        <p><b><i>Sovereignty site please keep the records, photos, scripts have been posted for this site .</i></b></p>\r\n                        \r\n                        <p><b>3. Email:</b> Do not type your phone number, email address in email content .<br>All your email contents must be under the supervision of website .</p>\r\n                        \r\n                        <p class="lheight23">This is family oriented community website .<br>We\r\n reserve the right to remove postings that defame or insult anyone. Our \r\nstaffs will review and approve profiles and photos posted on this site \r\nwithin 24 hours .</p>\r\n                                        </div>', '2013-07-22 16:35:10', 1),
(2, 'Help - User Guide', '<p class="lheight23"><a><b>1. Sign up / Create account </b> -&gt; Simple with 3 steps :</a></p>\r\n                        <span id="faq1">\r\n                            <p class="indentlh23">Step 1:<br>\r\n                                <img src="http://localhost/test/datingsite/imgs/L1step1.jpg" style="margin-left:20px;" border="0">\r\n                            </p>\r\n                            <p style="text-indent:20px; line-height:23px;">Step 2: <br>\r\n                                <img src="http://localhost/test/datingsite/imgs/L1step2.jpg" style="margin-left:20px;" border="0">\r\n                            </p>\r\n                            <p style="text-indent:20px; line-height:23px;">Step 3: <br>\r\n                                <img src="http://localhost/test/datingsite/imgs/L1step3.jpg" style="margin-left:20px;" border="0">\r\n                            </p>\r\n                        </span>\r\n                    \r\n                        <p class="lheight23"><a><b>2. How can I forget my password ?</b></a></p>\r\n                        <span id="faq2">\r\n                            <p class="indentlh23">- At the homepage click on <b><i>Sign-In</i></b></p>\r\n                            <p class="indentlh23">- At the <b><i>Sign-In</i></b> page click on <b><i>Forgot password</i></b></p>\r\n                            <p class="indentlh23">\r\n                                <img src="http://localhost/test/datingsite/imgs/L1forgot.jpg" style="margin-left:20px;" border="0">\r\n                            </p>\r\n                        </span>\r\n                    \r\n                        <p><a><b>3. I want to change my password, what to do ?</b></a></p>\r\n                        <span id="faq3">\r\n                            <p class="indentlh23">- Login to website .</p>\r\n                            <p class="indentlh23">- Select the menu <b><i>ACCOUNT</i></b> -&gt; <b><i>Change password</i></b></p>\r\n                            <p class="indentlh23">\r\n                                <img src="http://localhost/test/datingsite/imgs/L1changepass.jpg" style="margin-left:20px; width:800px" border="0">\r\n                            </p>\r\n                            <p class="indentlh23">- Fill out the information and press <b><i>Save</i></b>, your password has been changed .</p>\r\n                        </span>  \r\n                                      \r\n                        <p><a><b>4. Want to change your personal information to do ?</b></a></p>\r\n                        <span id="faq4">\r\n                            <p class="indentlh23">- Login to website .</p>\r\n                            <p class="indentlh23">- Select the menu <b><i>ACCOUNT</i></b> -&gt; <b><i>Updating personal information</i></b></p>\r\n                            <p class="indentlh23">\r\n                                <img src="http://localhost/test/datingsite/imgs/L1info.jpg" style="margin-left:20px; width:800px" border="0">\r\n                            </p>\r\n                            <p class="indentlh23">- Fill out the information and press <b><i>Save</i></b>, your personal information has been changed .</p>\r\n                        </span>\r\n                    \r\n                        <p><a><b>5. Want to change the information on my potential matches to do ?</b></a></p>\r\n                        <span id="faq5">\r\n                            <p class="indentlh23">- Login to website .</p>\r\n                            <p class="indentlh23">- Select the menu <b><i>ACCOUNT</i></b> -&gt; <b><i>Updating your potential matches</i></b></p>\r\n                            <p class="indentlh23">\r\n                                <img src="http://localhost/test/datingsite/imgs/L1match.jpg" style="margin-left:20px; width:800px" border="0">\r\n                            </p>\r\n                            <p class="indentlh23">- Fill in the information and press <b><i>Save</i></b>, your potential matches has been changed .</p>\r\n                        </span>\r\n                        \r\n                        <p><a><b>6. I can select other members to find / not find my profile</b></a></p>\r\n                        <span id="faq6">\r\n                            <p class="indentlh23">- Login to website .</p>\r\n                            <p class="indentlh23">- Select the menu <b><i>ACCOUNT</i></b> -&gt; <b><i>Hide / Show profile</i></b></p>\r\n                            <p class="indentlh23">\r\n                                <img src="http://localhost/test/datingsite/imgs/L1profile.jpg" style="margin-left:20px; width:800px" border="0">\r\n                            </p>\r\n                            <p class="indentlh23">- If your profile status is: <b>Waiting for approve</b> then you can not Hide / Show profile; You can set the time you want to notify when you have mail sent to you by other members .</p>\r\n                            <p class="indentlh23">- Choose the option you want and press <b><i>Save settings</i></b>, your settings have been changed .</p>\r\n                        </span>\r\n                    \r\n                        <p><a><b>7. Want to upload photos, can I do ?</b></a></p>\r\n                        <span id="faq7">\r\n                            <p class="indentlh23">- Login to website .</p>\r\n                            <p class="indentlh23">- Select the menu <b><i>ACCOUNT</i></b> -&gt; <b><i>Upload photos</i></b></p>\r\n                            <p class="indentlh23">\r\n                                <img src="http://localhost/test/datingsite/imgs/L1upload.jpg" style="margin-left:20px; width:800px" border="0">\r\n                            </p>\r\n                            <p class="indentlh23">- Fill in the information and press <b><i>Upload</i></b>, your pictures will be shown after approve .</p>\r\n                        </span>\r\n                    \r\n                        <p><a><b>8. I want to delete photos uploaded ?</b></a></p>\r\n                        <span id="faq8">\r\n                            <p class="indentlh23">- Login to website .</p>\r\n                            <p class="indentlh23">- Select the menu <b><i>ACCOUNT</i></b> -&gt; <b><i>Remove photos</i></b></p>\r\n                            <p class="indentlh23">\r\n                                <img src="http://localhost/test/datingsite/imgs/L1delimg.jpg" style="margin-left:20px; width:800px" border="0">\r\n                            </p>\r\n                            <p class="indentlh23">- Select the photo that you want to delete by clicking the checkbox and click <b><i>Delete selected</i></b>, your photos have been deleted .</p>\r\n                        </span>\r\n                    \r\n                        <p><a><b>9. Want to change primary photo to do ?</b></a></p>\r\n                        <span id="faq9">\r\n                            <p class="indentlh23">- Login to website .</p>\r\n                            <p class="indentlh23">- Select the menu <b><i>ACCOUNT</i></b> -&gt; <b><i>Set primary photo</i></b></p>\r\n                            <p class="indentlh23">\r\n                                <img src="http://localhost/test/datingsite/imgs/L1primary.jpg" style="margin-left:20px; width:800px" border="0">\r\n                            </p>\r\n                            <p class="indentlh23">- Click on the picture of your choice and press <b><i>Save</i></b>, primary photo has been changed .</p>\r\n                    	</span>\r\n                    \r\n                        <p><a><b>10. For my other activities</b></a></p>\r\n                        <span id="faq10">\r\n                            <p class="indentlh23">- Login to website .</p>\r\n                            <p class="indentlh23">- Select the menu <b><i>ACCOUNT</i></b> -&gt; <b><i>People liked / familiarized with you ,</i></b> to know who have sent a message to make friend with you, please click <b><i>Save</i></b> to save any profile you like because these messages will be automatically deleted after 30 days .</p>\r\n                            <p class="indentlh23">- Select the menu <b><i>ACCOUNT</i></b> -&gt; <b><i>Whom you liked / familiarized with</i></b> to know whom have liked / made friend, please click <b><i>Save</i></b> to save any profile you like because these messages will be automatically deleted after 30 days .</p>\r\n                            <p class="indentlh23">- Select the menu <b><i>ACCOUNT</i></b> -&gt; <b><i>Viewed your profile</i></b> to know members have viewed your profile, please click <b><i>Save</i></b> to save any profile you like because these messages will be automatically deleted after 30 days .</p>\r\n                            <p class="indentlh23">- Select the menu <b><i>ACCOUNT</i></b> -&gt; <b><i>Your potential matches, </i></b> this is a new feature of the website, this will filter the profiles matching your search criteria in the <b><i>Your potential matches</i></b>, you can send email to them or send signal to make friend or save their profile . This information will not be deleted .</p>\r\n                            <p class="indentlh23">- Select the menu <b><i>ACCOUNT</i></b> -&gt; <b><i>Saved profile</i></b> to review profiles that you have previously saved. This information will not be deleted .</p>\r\n                            <p class="indentlh23">- Select the menu <b><i>ACCOUNT</i></b> -&gt; <b><i>Saved search</i></b> to review the results of the search that you previously saved. This information will not be deleted .</p>\r\n                        </span>\r\n                    \r\n                        <p><a><b>11. How do I find profiles that appropriate to my expect ?</b></a></p>\r\n                        <span id="faq11">\r\n                            <p class="indentlh23">- At the main menu of the website .</p>\r\n                            <p class="indentlh23">- Select the menu <b><i>SEARCH</i></b></p>\r\n                            <p class="indentlh23">- Website will give you two ways to search <b><i>Quick Search</i></b> and <b><i>Advanced Search </i></b> by <b><i>Reducing / Extend</i></b> the search criteria; <br>when the search results are given, you can save these results by type in a name you want to save in the <i>"Type a name to save search results"</i> box and then click the <b><i>Save Results </i></b>button .<br>You can also edit the search criteria by clicking on the <b><i>Edit search</i></b> button.</p>\r\n                        </span>\r\n                    \r\n                        <p><a><b>12. How to send a message / Send a signal to someone to make friend or Save a profile ?</b></a></p>\r\n                        <span id="faq12">\r\n                            <p class="indentlh23"><b>a. Send email</b> there are two ways:</p>\r\n                            <p class="indentlh23">- Method 1: Select the menu <b><i>EMAIL</i></b> -&gt; <i>Compose</i></p>\r\n                            <p class="indentlh23">- Method 2: Click the <b><i>Email</i></b> button which you can see in the profile of the members, website will redirect you to send email function .</p>\r\n                            <p class="indentlh23"><b>b. Send a make friend: </b> Click the <b><i>Familiarize</i></b>button which you can see in the profile of the members, website will send your request to members .</p>\r\n                            <p class="indentlh23"><b>c. Save profile: </b> Click the <b><i>Save</i></b> button which you can see in the profile of the members, that profile will be included in the list of your saved profile .</p>\r\n                        </span>\r\n                    \r\n                        <p><a><b>13. Send / Receive email</b></a></p>\r\n                        <span id="faq13">\r\n                            <p class="indentlh23">- Login to website .</p>\r\n                            <p class="indentlh23">- Select the menu <b><i>EMAIL</i></b></p>\r\n                            <p class="indentlh23">- Here you can send \r\nmessages to other members, view others'' messages sent to you, manage \r\nmessages you have sent/ have not sent to someone that sent messages to \r\nyou, and mailbox user guide .</p><p class="indentlh23"><br></p></span>', '2013-07-22 16:04:35', 1),
(3, 'Admin Helps', 'This content help for admin will appear here !!', '2013-07-22 16:59:56', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dt_paymentprovide`
--

CREATE TABLE `dt_paymentprovide` (
  `Id` int(11) NOT NULL,
  `PaymentType` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `APIKey` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `APIPassword` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `APISignature` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `APISucrect` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CurrencyCode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ReturnURL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CancelURL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ButtonImg` text CHARACTER SET utf8,
  `APIMode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IsActive` tinyint(3) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_paymentprovide`
--

INSERT INTO `dt_paymentprovide` (`Id`, `PaymentType`, `APIKey`, `APIPassword`, `APISignature`, `APISucrect`, `CurrencyCode`, `ReturnURL`, `CancelURL`, `ButtonImg`, `APIMode`, `IsActive`) VALUES
(1, 'Paypal', 'YOUR_PP_ID', 'YOUR_PP_PASSWORD', 'YOUR_SIGNATURE', NULL, 'USD', 'members/membership1.php', 'members/membership1.php?a=cancel', '&lt;input type=&quot;image&quot; src=&quot;https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif&quot; border=&quot;0&quot; name=&quot;smagree&quot; alt=&quot;PayPal - The safer, easier way to pay online!&quot;&gt; &lt;img alt=&quot;PayPal - The safer, easier way to pay online!&quot; border=&quot;0&quot; src=&quot;https://www.paypalobjects.com/en_US/i/scr/pixel.gif&quot; width=&quot;1&quot; height=&quot;1&quot;&gt;', 'sandbox', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dt_photos`
--

CREATE TABLE `dt_photos` (
  `PhotoID` int(10) UNSIGNED NOT NULL,
  `UserID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `PhotoExtension` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `PhotoDescription` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `IsApproved` tinyint(4) DEFAULT NULL,
  `PrimaryPhoto` smallint(5) UNSIGNED DEFAULT NULL,
  `InsertDate` date DEFAULT NULL,
  `TotalRating` int(11) DEFAULT NULL,
  `NumberOfVote` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_photos`
--

INSERT INTO `dt_photos` (`PhotoID`, `UserID`, `PhotoExtension`, `PhotoDescription`, `IsApproved`, `PrimaryPhoto`, `InsertDate`, `TotalRating`, `NumberOfVote`) VALUES
(1, 13, 'jpg', 'Sample', 1, 1, '2012-10-11', 23, 5),
(2, 18, 'jpg', '', 1, 1, '2012-10-11', 19, 4),
(3, 20, 'jpg', '', 1, 1, '2012-10-11', 16, 5),
(4, 16, 'jpg', 'Sample', 1, 1, '2012-10-11', 8, 2),
(5, 27, 'jpg', '', 1, 1, '2012-10-11', 11, 2),
(6, 25, 'jpg', '', 1, 1, '2012-10-11', 12, 2),
(7, 25, 'jpg', '', 1, 0, '2013-01-06', 0, 0),
(8, 30, 'jpg', '', 1, 1, '2012-10-11', 10, 2),
(9, 22, 'jpg', 'Sample', 1, 0, '2012-10-20', 0, 0),
(10, 24, 'jpg', '', 1, 1, '2012-12-06', 53, 14),
(11, 28, 'jpg', '', 1, 0, '2013-01-12', 0, 0),
(12, 28, 'jpg', '', 1, 0, '2013-01-12', 0, 0),
(13, 28, 'jpg', 'Sample', 1, 1, '2012-10-24', 0, 0),
(14, 13, 'jpg', '', 1, 0, '2018-08-20', 0, 0),
(15, 18, 'jpg', 'sss', 1, 0, '2018-09-19', 0, 0),
(16, 22, 'jpg', 'asdfa', 1, 0, '2018-09-19', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `dt_posts`
--

CREATE TABLE `dt_posts` (
  `PostID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `DateCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dt_posts`
--

INSERT INTO `dt_posts` (`PostID`, `UserID`, `Description`, `DateCreated`) VALUES
(3, 16, 'dcczc', '2018-09-21 17:43:04'),
(4, 16, 'adsasdasd', '2018-09-21 17:44:36'),
(5, 16, 'Post number 2', '2018-09-21 18:03:59'),
(6, 16, 'Axe', '2018-09-21 18:04:19'),
(7, 16, 'Cobo', '2018-09-21 18:04:39'),
(8, 16, 'Meme', '2018-09-21 18:04:50');

-- --------------------------------------------------------

--
-- Table structure for table `dt_prices`
--

CREATE TABLE `dt_prices` (
  `Id` int(11) NOT NULL,
  `Prices` int(11) NOT NULL DEFAULT '0',
  `NumofEmail` int(11) NOT NULL DEFAULT '0',
  `Block` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_prices`
--

INSERT INTO `dt_prices` (`Id`, `Prices`, `NumofEmail`, `Block`) VALUES
(1, 2, 60, 1),
(2, 4, 120, 2),
(3, 6, 200, 3),
(4, 8, 300, 4),
(5, 10, 2000, 10),
(6, 12, 3000, 20);

-- --------------------------------------------------------

--
-- Table structure for table `dt_profilestatus`
--

CREATE TABLE `dt_profilestatus` (
  `ProfileStatusID` int(11) UNSIGNED NOT NULL,
  `L1ProfileStatus` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `L2ProfileStatus` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `L3ProfileStatus` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `L4ProfileStatus` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_profilestatus`
--

INSERT INTO `dt_profilestatus` (`ProfileStatusID`, `L1ProfileStatus`, `L2ProfileStatus`, `L3ProfileStatus`, `L4ProfileStatus`, `TopSorted`) VALUES
(1, 'Enable', 'Enable', 'Enable', 'Enable', 1),
(2, 'Close / Hide my profile', 'Close / Hide my profile', 'Disable', 'Disable', 2),
(3, 'Remove profile', 'Remove profile', 'Removed', 'Removed', 3),
(9, 'Hide My Profile', 'Hide My Profile', '', '', 0),
(4, 'Wating for approve', 'Wating for approve', '', '', 4),
(5, 'Profile is unacceptable', 'Profile is unacceptable', '', '', 5),
(6, 'User has no intention to seek friends', 'User has no intention to seek friends', '', '', 6),
(7, 'Violate user agreement', 'Violate user agreement', '', '', 7),
(8, 'Disable due to users complains', 'Disable due to users complains', '', '', 8);

-- --------------------------------------------------------

--
-- Table structure for table `dt_religions`
--

CREATE TABLE `dt_religions` (
  `ReligionID` smallint(5) UNSIGNED NOT NULL,
  `L1Religion` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `L2Religion` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `L3Religion` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `L4Religion` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_religions`
--

INSERT INTO `dt_religions` (`ReligionID`, `L1Religion`, `L2Religion`, `L3Religion`, `L4Religion`, `TopSorted`) VALUES
(1, 'No Religion', 'No Religion', 'No Religion', 'No Religion', 0),
(2, 'Agnostic', 'Agnostic', 'Agnostic', 'Agnostic', 0),
(3, 'Alternative', 'Alternative', 'Alternative', 'Alternative', 0),
(4, 'Atheist', 'Atheist', 'Atheist', 'Atheist', 0),
(5, 'Buddhist', 'Buddhist', 'Buddhist', 'Buddhist', 0),
(6, 'Taoist', 'Taoist', 'Taoist', 'Taoist', 0),
(7, 'Catholic', 'Catholic', 'Catholic', 'Catholic', 0),
(8, 'Christian', 'Christian', 'Christian', 'Christian', 0),
(9, 'Hindu', 'Hindu', 'Hindu', 'Hindu', 0),
(10, 'Islamic', 'Islamic', 'Islamic', 'Islamic', 0),
(11, 'Jewish', 'Jewish', 'Jewish', 'Jewish', 0),
(12, 'Protestant', 'Protestant', 'Protestant', 'Protestant', 0),
(13, 'Spiritual', 'Spiritual', 'Spiritual', 'Spiritual', 0),
(14, 'Other', 'Other', 'Other', 'Other', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dt_savedsearch`
--

CREATE TABLE `dt_savedsearch` (
  `SearchID` int(10) UNSIGNED NOT NULL,
  `UserID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `SearchName` varchar(75) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Query` text COLLATE utf8_unicode_ci,
  `SearchValue` text COLLATE utf8_unicode_ci,
  `DateCreated` datetime DEFAULT NULL,
  `DateProcessed` datetime DEFAULT NULL,
  `SubcriptionStatusID` tinyint(3) UNSIGNED DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_savedsearch`
--

INSERT INTO `dt_savedsearch` (`SearchID`, `UserID`, `SearchName`, `Query`, `SearchValue`, `DateCreated`, `DateProcessed`, `SubcriptionStatusID`) VALUES
(1, 18, '', 'fg=2&af=18&at=25&o=0&t=0', 'fg=2&af=18&at=25&o=0&t=0', '2018-09-19 21:58:20', '2018-09-19 21:58:20', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dt_signalme`
--

CREATE TABLE `dt_signalme` (
  `RecieverID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `SenderID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `SignalDate` datetime DEFAULT '0000-00-00 00:00:00',
  `IsViews` tinyint(3) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_signalme`
--

INSERT INTO `dt_signalme` (`RecieverID`, `SenderID`, `SignalDate`, `IsViews`) VALUES
(18, 13, '2018-08-31 16:41:53', 1),
(18, 13, '2018-08-31 17:07:49', 1),
(18, 13, '2018-09-19 20:45:29', 1),
(18, 13, '2018-09-19 22:14:59', 1),
(27, 18, '2018-09-19 22:20:39', 1),
(22, 13, '2018-09-19 22:25:58', 1),
(18, 22, '2018-09-19 22:26:26', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dt_site_settings`
--

CREATE TABLE `dt_site_settings` (
  `Id` int(11) NOT NULL,
  `Variable` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IsRead` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_site_settings`
--

INSERT INTO `dt_site_settings` (`Id`, `Variable`, `Value`, `IsRead`) VALUES
(1, 'totallogin', '5', 0),
(2, 'default_language', 'L1', 0),
(3, 'sitename', 'MemePartner', 0),
(4, 'slogan', 'Get entertained while you search your perfect match', 0),
(5, 'strfoot', 'All right reserved &copy; 2018', 0),
(6, 'currency', '$', 0),
(7, 'numof_record_perpage', '30', 0),
(8, 'filetype', 'gif,jpg', 0),
(9, 'max_size', '2500001111', 0),
(10, 'max_height', '1000001111', 0),
(11, 'max_width', '1000001111', 0),
(12, 'maxemail', '20', 0),
(13, 'uploaddir', 'fuploads', 0),
(14, 'adminemail', 'admin@yourdomain.com', 0),
(15, 'Version', '1.0', 0),
(16, 'logo', 'logo.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dt_smoking`
--

CREATE TABLE `dt_smoking` (
  `SmokingID` smallint(5) UNSIGNED NOT NULL,
  `L1Smoking` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `L2Smoking` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `L3Smoking` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `L4Smoking` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_smoking`
--

INSERT INTO `dt_smoking` (`SmokingID`, `L1Smoking`, `L2Smoking`, `L3Smoking`, `L4Smoking`, `TopSorted`) VALUES
(1, 'Non-smoker', 'Non-smoker', 'Non-smoker', 'Non-smoker', 0),
(2, 'Heavy smoker', 'Heavy smoker', 'Heavy smoker', 'Heavy smoker', 0),
(3, 'Light smoker', 'Light smoker', 'Light smoker', 'Light smoker', 0),
(4, 'Cigar/pipe smoker', 'Cigar/pipe smoker', 'Cigar/pipe smoker', 'Cigar/pipe smoker', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dt_states`
--

CREATE TABLE `dt_states` (
  `StateID` int(11) NOT NULL,
  `State` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CountryID` int(11) NOT NULL DEFAULT '0',
  `TopSorted` tinyint(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_states`
--

INSERT INTO `dt_states` (`StateID`, `State`, `CountryID`, `TopSorted`) VALUES
(236, 'Alabama', 223, 0),
(237, 'Alaska', 223, 0),
(238, 'Alberta', 223, 0),
(239, 'American Samoa', 223, 0),
(240, 'Arizona', 223, 0),
(241, 'Arkansas', 223, 0),
(242, 'Armed Forces', 223, 0),
(243, 'Armed Forces Americas', 223, 0),
(244, 'Armed Forces Pacific', 223, 0),
(245, 'British Columbia', 223, 0),
(246, 'California', 223, 0),
(247, 'Colorado', 223, 0),
(248, 'Connecticut', 223, 0),
(249, 'Delaware', 223, 0),
(250, 'District of Columbia', 223, 0),
(251, 'Federated States of Micronesia', 223, 0),
(252, 'Florida', 223, 0),
(253, 'Georgia', 223, 0),
(254, 'Guam', 223, 0),
(255, 'Hawaii', 223, 0),
(256, 'Idaho', 223, 0),
(257, 'Illinois', 223, 0),
(258, 'Indiana', 223, 0),
(259, 'Iowa', 223, 0),
(260, 'Kansas', 223, 0),
(261, 'Kentucky', 223, 0),
(262, 'Louisiana', 223, 0),
(263, 'Maine', 223, 0),
(264, 'Manitoba', 223, 0),
(265, 'Marshall Islands', 223, 0),
(266, 'Maryland', 223, 0),
(267, 'Massachusetts', 223, 0),
(268, 'Michigan', 223, 0),
(269, 'Minnesota', 223, 0),
(270, 'Mississippi', 223, 0),
(271, 'Missouri', 223, 0),
(272, 'Montana', 223, 0),
(273, 'Nebraska', 223, 0),
(274, 'Nevada', 223, 0),
(275, 'New Brunswick', 223, 0),
(276, 'New Hampshire', 223, 0),
(277, 'New Jersey', 223, 0),
(278, 'New Mexico', 223, 0),
(279, 'New York', 223, 0),
(280, 'Newfoundland', 223, 0),
(281, 'Newfoundland and Labrador', 223, 0),
(282, 'North Carolina', 223, 0),
(283, 'North Dakota', 223, 0),
(284, 'NorthernMariana Islands', 223, 0),
(285, 'Northwest Territories', 223, 0),
(286, 'Nova Scotia', 223, 0),
(287, 'Nunavut', 223, 0),
(288, 'Ohio', 223, 0),
(289, 'Oklahoma', 223, 0),
(290, 'Ontario', 223, 0),
(291, 'Oregon', 223, 0),
(292, 'Palau', 223, 0),
(293, 'Pennsylvania', 223, 0),
(294, 'Prince Edward Island', 223, 0),
(295, 'Puerto Rico', 223, 0),
(296, 'Quebec', 223, 0),
(297, 'Rhode Island', 223, 0),
(298, 'Saskatchewan', 223, 0),
(299, 'South Carolina', 223, 0),
(300, 'South Dakota', 223, 0),
(301, 'Tennessee', 223, 0),
(302, 'Texas', 223, 0),
(303, 'Utah', 223, 0),
(304, 'Vermont', 223, 0),
(305, 'Virgin Islands', 223, 0),
(306, 'Virginia', 223, 0),
(307, 'Washington', 223, 0),
(308, 'West Virginia', 223, 0),
(309, 'Wisconsin', 223, 0),
(310, 'Wyoming', 223, 0),
(311, 'Yukon', 223, 0),
(357, 'Hà Nam', 230, NULL),
(312, 'An Giang', 230, NULL),
(313, 'Afghanistan', 1, NULL),
(314, 'Albania', 2, NULL),
(315, 'Algeria', 3, NULL),
(316, 'American Samoa', 4, NULL),
(317, 'Andorra', 5, NULL),
(318, 'Anguilla', 7, NULL),
(319, 'Antarctica', 8, NULL),
(320, 'Barbuda', 9, NULL),
(321, 'Argentina', 10, NULL),
(322, 'Armenia', 11, NULL),
(323, 'Aruba', 12, NULL),
(324, 'Australia', 13, NULL),
(325, 'Austria', 14, NULL),
(326, 'Azerbaijan', 15, NULL),
(327, 'Bahamas', 16, NULL),
(328, 'Bahrain', 17, NULL),
(329, 'Bangladesh', 18, NULL),
(330, 'Barbados', 19, NULL),
(331, 'Belarus', 20, NULL),
(332, 'Belgium', 21, NULL),
(333, 'Belize', 22, NULL),
(334, 'Benin', 23, NULL),
(335, 'Bermuda', 24, NULL),
(336, 'Vũng Tàu', 230, NULL),
(337, 'Bắc Cạn', 230, NULL),
(338, 'Bắc Giang', 230, NULL),
(339, 'Bạc Liêu', 230, NULL),
(340, 'Bắc Ninh', 230, NULL),
(341, 'Bến Tre', 230, NULL),
(342, 'Bình Dương', 230, NULL),
(343, 'Bình Định', 230, NULL),
(344, 'Bình Phước', 230, NULL),
(345, 'Bình Thuận', 230, NULL),
(346, 'Cà Mau', 230, NULL),
(347, 'Cần Thơ', 230, NULL),
(348, 'Cao Bằng', 230, NULL),
(349, 'Dak Nông', 230, NULL),
(350, 'Đà Nẵng', 230, NULL),
(351, 'Đắc Lắc', 230, NULL),
(352, 'Điện Biên', 230, NULL),
(353, 'Đồng Nai', 230, NULL),
(354, 'Đồng Tháp', 230, NULL),
(355, 'Gia Lai', 230, NULL),
(356, 'Hà Giang', 230, NULL),
(358, 'Hà Nội', 230, NULL),
(359, 'Hà Tỉnh', 230, NULL),
(360, 'Hải Dương', 230, NULL),
(361, 'Hải Phòng', 230, NULL),
(362, 'Hậu Giang', 230, NULL),
(363, 'Hồ Chí Minh', 230, NULL),
(364, 'Hòa Bình', 230, NULL),
(365, 'Hưng Yên', 230, NULL),
(366, 'Khánh Hòa', 230, NULL),
(367, 'Kiên Giang', 230, NULL),
(368, 'Kon Tum', 230, NULL),
(369, 'Lai Châu', 230, NULL),
(370, 'Lâm Đồng', 230, NULL),
(371, 'Lạng Sơn', 230, NULL),
(372, 'Lào Cai', 230, NULL),
(373, 'Long An', 230, NULL),
(374, 'Nam Định', 230, NULL),
(375, 'Nghệ An', 230, NULL),
(376, 'Ninh Bình', 230, NULL),
(377, 'Ninh Thuận', 230, NULL),
(378, 'Phú Thọ', 230, NULL),
(379, 'Phú Yên', 230, NULL),
(380, 'Quảng Bình', 230, NULL),
(381, 'Quảng Nam', 230, NULL),
(382, 'Quãng Ngãi', 230, NULL),
(383, 'Quảng Ninh', 230, NULL),
(384, 'Quảng Trị', 230, NULL),
(385, 'Sóc Trăng', 230, NULL),
(386, 'Sơn La', 230, NULL),
(387, 'Tây Ninh', 230, NULL),
(388, 'Thái Bình', 230, NULL),
(389, 'Thái Nguyên', 230, NULL),
(390, 'Thanh Hóa', 230, NULL),
(391, 'Thừa Thiên - Huế', 230, NULL),
(392, 'Tiền Giang', 230, NULL),
(393, 'Trà Vinh', 230, NULL),
(394, 'Tuyên Quang', 230, NULL),
(395, 'Vĩnh Long', 230, NULL),
(396, 'Vĩnh Phúc', 230, NULL),
(397, 'Yên Bái', 230, NULL),
(398, 'Bhutan', 25, NULL),
(399, 'Bolivia', 26, NULL),
(400, 'Bosinia', 27, NULL),
(401, 'Botswana', 28, NULL),
(402, 'Buouvet', 29, NULL),
(403, 'Brazil', 30, NULL),
(404, 'Brunei', 32, NULL),
(405, 'Bulgaria', 33, NULL),
(406, 'Burkina', 34, NULL),
(407, 'Burundi', 35, NULL),
(408, 'Cambodia', 36, NULL),
(409, 'Cameroon', 37, NULL),
(410, 'Canada', 38, NULL),
(411, 'Capeverde', 39, NULL),
(412, 'Cayman', 40, NULL),
(413, 'Chad', 42, NULL),
(414, 'Chile', 43, NULL),
(415, 'BacKinh', 44, NULL),
(416, 'Hongkong', 45, NULL),
(417, 'Colombia', 49, NULL),
(418, 'Comoros', 50, NULL),
(419, 'Congo', 51, NULL),
(420, 'CookIslands', 53, NULL),
(421, 'Costarica', 54, NULL),
(422, 'Croatia', 56, NULL),
(423, 'Cuba', 57, NULL),
(424, 'Cyprus', 58, NULL),
(425, 'Czech', 59, NULL),
(426, 'Denmark', 60, NULL),
(427, 'Djibouti', 61, NULL),
(428, 'Dominica', 62, NULL),
(429, 'EastTimor', 64, NULL),
(430, 'Ecuador', 65, NULL),
(431, 'Egypt', 66, NULL),
(432, 'Salvador', 67, NULL),
(433, 'Eritrea', 69, NULL),
(434, 'Estonia', 70, NULL),
(435, 'Ethiopia', 71, NULL),
(436, 'Fiji', 74, NULL),
(437, 'Finland', 75, NULL),
(438, 'France', 76, NULL),
(439, 'Gabon', 80, NULL),
(440, 'Georgia', 82, NULL),
(441, 'Germany', 83, NULL),
(442, 'Ghana', 84, NULL),
(443, 'Gibraltar', 85, NULL),
(444, 'Greece', 86, NULL),
(445, 'Greenland', 87, NULL),
(446, 'Grenada', 88, NULL),
(447, 'Guadeloupe', 89, NULL),
(448, 'Guinea', 92, NULL),
(449, 'Guyana', 94, NULL),
(450, 'Guam', 90, NULL),
(451, 'Guatemala', 91, NULL),
(452, 'Haiti', 95, NULL),
(453, 'Honduras', 97, NULL),
(454, 'Hungary', 98, NULL),
(455, 'Iceland', 99, NULL),
(456, 'India', 100, NULL),
(457, 'Jakatta', 101, NULL),
(458, 'Iran', 102, NULL),
(459, 'Iraq', 103, NULL),
(460, 'Ireland', 104, NULL),
(461, 'Israel', 105, NULL),
(462, 'Italy', 106, NULL),
(463, 'Jamaica', 107, NULL),
(464, 'Tokyo', 108, NULL),
(465, 'Jordan', 109, NULL),
(466, 'Kazakhstan', 110, NULL),
(467, 'Kenya', 111, NULL),
(468, 'Kiribati', 112, NULL),
(469, 'Korea', 113, NULL),
(470, 'North Korea', 114, NULL),
(471, 'Kuwait', 115, NULL),
(472, 'Kyrgyzstan', 116, NULL),
(473, 'Lao', 117, NULL),
(474, 'Latvia', 118, NULL),
(475, 'Lebanon', 119, NULL),
(476, 'Lesotho', 120, NULL),
(477, 'Liberia', 121, NULL),
(478, 'Libya', 122, NULL),
(479, 'Liechtenstein', 123, NULL),
(480, 'Lithuania', 124, NULL),
(481, 'Luxembourg', 125, NULL),
(482, 'Madargascar', 127, NULL),
(483, 'Malawi', 128, NULL),
(484, 'Malaysia', 129, NULL),
(485, 'Maldives', 130, NULL),
(486, 'Mali', 131, NULL),
(487, 'Malta', 132, NULL),
(488, 'Marshall', 133, NULL),
(489, 'Martinique', 134, NULL),
(490, 'Mauritania', 135, NULL),
(491, 'Mauritius', 136, NULL),
(492, 'Mayotte', 137, NULL),
(493, 'Mexico', 138, NULL),
(494, 'Micronesia', 139, NULL),
(495, 'Moldova', 140, NULL),
(496, 'Monaco', 141, NULL),
(497, 'Mongolia', 142, NULL),
(498, 'Montserrat', 143, NULL),
(499, 'Morocco', 144, NULL),
(500, 'Mozambique', 145, NULL),
(501, 'Myanmar', 146, NULL),
(502, 'Namibia', 147, NULL),
(503, 'Nauru', 148, NULL),
(504, 'Nepal', 149, NULL),
(505, 'Caledonia', 152, NULL),
(506, 'New Zealand', 153, NULL),
(507, 'Nicaragua', 154, NULL),
(508, 'Niger', 155, NULL),
(509, 'Nigeria', 156, NULL),
(510, 'Niue', 157, NULL),
(511, 'Norfolk', 158, NULL),
(512, 'Norway', 160, NULL),
(513, 'Oman', 161, NULL),
(514, 'Pakistan', 162, NULL),
(515, 'Palau', 163, NULL),
(516, 'Panama', 164, NULL),
(517, 'Paraguay', 166, NULL),
(518, 'Peru', 167, NULL),
(519, 'Philippines', 168, NULL),
(520, 'Pitcairn', 169, NULL),
(521, 'Poland', 170, NULL),
(522, 'Portugal', 171, NULL),
(523, 'Puerto', 172, NULL),
(524, 'Qatar', 173, NULL),
(525, 'Reunion', 174, NULL),
(526, 'Romania', 175, NULL),
(527, 'Russia', 176, NULL),
(528, 'Rwanda', 177, NULL),
(529, 'Helena', 178, NULL),
(530, 'Lucia', 180, NULL),
(531, 'Samoa', 183, NULL),
(532, 'Marino', 184, NULL),
(533, 'Arabia', 186, NULL),
(534, 'Senegal', 187, NULL),
(535, 'Seychelles', 188, NULL),
(536, 'Sierra', 189, NULL),
(537, 'Singapore', 190, NULL),
(538, 'Slovakia', 191, NULL),
(539, 'Slovenia', 192, NULL),
(540, 'Solomon', 193, NULL),
(541, 'Somalia', 194, NULL),
(542, 'South Africa', 195, NULL),
(543, 'Spain', 197, NULL),
(544, 'Srilanka', 198, NULL),
(545, 'Sudan', 199, NULL),
(546, 'Suriname', 200, NULL),
(547, 'Swaziland', 202, NULL),
(548, 'Sweden', 203, NULL),
(549, 'Switzerland', 204, NULL),
(550, 'Syria', 205, NULL),
(551, 'Taiwan', 206, NULL),
(552, 'Tajikistan', 207, NULL),
(553, 'Tanzania', 208, NULL),
(554, 'Thailand', 209, NULL),
(555, 'Togo', 210, NULL),
(556, 'Tokelau', 211, NULL),
(557, 'Tonga', 212, NULL),
(558, 'Tobago', 213, NULL),
(559, 'Tunisia', 214, NULL),
(560, 'Turkey', 215, NULL),
(561, 'Turkmenistan', 216, NULL),
(562, 'Tuvalu', 218, NULL),
(563, 'Uganda', 219, NULL),
(564, 'Ukraine', 220, NULL),
(565, 'London', 222, NULL),
(566, 'Uruguay', 225, NULL),
(567, 'Uzbekistan', 226, NULL),
(568, 'Vanuatu', 227, NULL),
(569, 'Venezuela', 229, NULL),
(570, 'Western', 234, NULL),
(571, 'Yemen', 235, NULL),
(572, 'Yugoslavia', 236, NULL),
(573, 'Zambia', 237, NULL),
(574, 'Zimbabwe', 238, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dt_themes`
--

CREATE TABLE `dt_themes` (
  `Id` int(11) NOT NULL,
  `ThemeName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IsActive` tinyint(3) NOT NULL DEFAULT '1',
  `SourceName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FileView` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_themes`
--

INSERT INTO `dt_themes` (`Id`, `ThemeName`, `IsActive`, `SourceName`, `FileView`) VALUES
(1, 'Default', 1, 'style.css', 'theme_default.jpg'),
(2, 'Theme 1', 1, 'style1.css', 'theme_1.jpg'),
(3, 'Theme 2', 1, 'style2.css', 'theme_2.jpg'),
(4, 'Theme 3', 1, 'style3.css', 'theme_3.jpg'),
(5, 'Theme 4', 1, 'style4.css', 'theme_4.jpg'),
(6, 'Theme 5', 1, 'style5.css', 'theme_5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `dt_users`
--

CREATE TABLE `dt_users` (
  `UserID` int(11) UNSIGNED NOT NULL,
  `MembershipID` smallint(5) UNSIGNED NOT NULL DEFAULT '1',
  `RemainVIPContacts` bigint(20) UNSIGNED DEFAULT '0',
  `SiteID` tinyint(3) UNSIGNED DEFAULT '1',
  `Name` varchar(75) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ProfileName` varchar(75) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AboutMe` text COLLATE utf8_unicode_ci,
  `Interests` text COLLATE utf8_unicode_ci,
  `Goal` text COLLATE utf8_unicode_ci,
  `Email` varchar(75) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(75) COLLATE utf8_unicode_ci NOT NULL,
  `GenderID` smallint(5) UNSIGNED DEFAULT NULL,
  `HeightID` smallint(5) UNSIGNED DEFAULT NULL,
  `Age` smallint(5) UNSIGNED DEFAULT NULL,
  `BodyTypeID` smallint(5) UNSIGNED DEFAULT NULL,
  `HairColorID` smallint(5) UNSIGNED DEFAULT NULL,
  `EyeColorID` smallint(5) UNSIGNED DEFAULT NULL,
  `City` varchar(75) COLLATE utf8_unicode_ci NOT NULL,
  `StateID` int(11) DEFAULT NULL,
  `CountryID` smallint(6) NOT NULL DEFAULT '0',
  `Zipcode` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `IMessagerID` smallint(5) UNSIGNED DEFAULT NULL,
  `IMessager` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ReligionID` smallint(6) DEFAULT NULL,
  `EducationID` smallint(6) DEFAULT NULL,
  `Occupation` varchar(75) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SmokingID` smallint(6) DEFAULT NULL,
  `DrinkingID` smallint(6) DEFAULT NULL,
  `MaritalStatusID` tinyint(3) UNSIGNED DEFAULT NULL,
  `DatingInterestID` smallint(5) UNSIGNED DEFAULT NULL,
  `HaveChildren` smallint(5) UNSIGNED DEFAULT NULL,
  `WantChildren` smallint(5) UNSIGNED DEFAULT NULL,
  `WillingToTravel` decimal(18,0) DEFAULT NULL,
  `IPaddress` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DatePosted` date NOT NULL DEFAULT '0000-00-00',
  `DateUpdate` date NOT NULL DEFAULT '0000-00-00',
  `LastEmailSent` datetime DEFAULT NULL,
  `LastLogon` datetime DEFAULT NULL,
  `ProfileStatusID` smallint(5) UNSIGNED DEFAULT '0',
  `NotificationScheduleID` tinyint(3) UNSIGNED DEFAULT '3',
  `MatchAgeFrom` tinyint(4) DEFAULT NULL,
  `MatchAgeTO` tinyint(4) DEFAULT NULL,
  `MatchGenderID` tinyint(6) DEFAULT NULL,
  `MatchHeightIDFrom` smallint(6) DEFAULT NULL,
  `MatchHeightIDTo` smallint(6) DEFAULT NULL,
  `MatchBodyStyleID` smallint(6) DEFAULT NULL,
  `MatchReligionID` smallint(6) DEFAULT NULL,
  `MatchEducationID` smallint(6) DEFAULT NULL,
  `MatchCareerID` smallint(6) DEFAULT NULL,
  `MatchSmokingID` smallint(6) DEFAULT NULL,
  `MatchDrinkingID` smallint(6) DEFAULT NULL,
  `MatchMaritalStatusID` smallint(6) DEFAULT NULL,
  `MatchNumberofChild` smallint(6) DEFAULT NULL,
  `MatchBeSameLocation` smallint(6) DEFAULT NULL,
  `SubcribeList` smallint(6) DEFAULT NULL,
  `RandomVerifyID` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `AboutMyMatch` text COLLATE utf8_unicode_ci,
  `PrimaryPhotoID` int(11) DEFAULT NULL,
  `GroupID` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `Views` bigint(20) DEFAULT '0',
  `IsOnline` tinyint(3) NOT NULL DEFAULT '0',
  `TotalRating` bigint(20) NOT NULL DEFAULT '0',
  `NumberOfVote` bigint(20) NOT NULL DEFAULT '0',
  `ThemeId` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_users`
--

INSERT INTO `dt_users` (`UserID`, `MembershipID`, `RemainVIPContacts`, `SiteID`, `Name`, `ProfileName`, `AboutMe`, `Interests`, `Goal`, `Email`, `Password`, `GenderID`, `HeightID`, `Age`, `BodyTypeID`, `HairColorID`, `EyeColorID`, `City`, `StateID`, `CountryID`, `Zipcode`, `Phone`, `IMessagerID`, `IMessager`, `ReligionID`, `EducationID`, `Occupation`, `SmokingID`, `DrinkingID`, `MaritalStatusID`, `DatingInterestID`, `HaveChildren`, `WantChildren`, `WillingToTravel`, `IPaddress`, `DatePosted`, `DateUpdate`, `LastEmailSent`, `LastLogon`, `ProfileStatusID`, `NotificationScheduleID`, `MatchAgeFrom`, `MatchAgeTO`, `MatchGenderID`, `MatchHeightIDFrom`, `MatchHeightIDTo`, `MatchBodyStyleID`, `MatchReligionID`, `MatchEducationID`, `MatchCareerID`, `MatchSmokingID`, `MatchDrinkingID`, `MatchMaritalStatusID`, `MatchNumberofChild`, `MatchBeSameLocation`, `SubcribeList`, `RandomVerifyID`, `AboutMyMatch`, `PrimaryPhotoID`, `GroupID`, `Views`, `IsOnline`, `TotalRating`, `NumberOfVote`, `ThemeId`) VALUES
(13, 1, 0, 2, 'User1', 'User01', 'direct, a good girl, calm and not easy to get angry but if someone makes me angry I will remember for a long time', 'love music, love to travel with the person I love, like purple, like to stare out to sea the most', 'Hard working, wish for a peaceful and happy life', 'user1@domain.com', 'user1', 2, 366, 30, 1, 1, 1, 'Sample data', 279, 223, '0084', '', 2, '', 5, 1, 'business', 1, 1, 6, 1, 2, 2, '137', '113.180.97.249', '2012-10-11', '2018-09-19', NULL, '2018-09-22 01:21:01', 4, 3, 34, 46, 1, 365, 349, 1, 0, 5, NULL, 1, 2, 0, NULL, 1, 0, 504189728, 'Direct, gallant, love and take good care of other members in family, hate lying', 14, 0, 2, 0, 0, 0, 1),
(16, 1, 0, 2, 'User4', 'User4', 'My parents are farmers, I am living with my parents in Daknon Province. I do not have any degree or diploma and are unemployed. I want to have a serious relationship, age is not important', 'love cooking and take care of my family, like swimming but I cannot swim', 'Looking for a husband who is caring, warm-hearted and responsible', 'user4@domain.com', 'user4', 2, 364, 20, 1, 1, 1, 'Sample data', 279, 223, '', '', NULL, NULL, 1, 1, 'countryman', 1, 1, 1, 3, 3, 1, '50', '171.255.10.230', '2012-10-11', '2012-10-11', NULL, '2018-09-22 01:23:24', 1, 1, 23, 40, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 345729815, 'A gentle, caring, honest ,thoughtful, responsible man', 4, 0, 3, 0, 0, 0, 1),
(18, 1, 0, 2, 'User2', 'User2', 'was born and grow up in Hanoi. Honest, sharing and good listener !', 'listening to music, cooking, travelling ...', 'Looking for a spouse', 'user2@domain.com', 'user2', 1, 365, 34, 1, 1, 1, 'Sample data', 279, 223, '0084', '', 2, '', 1, 5, 'Office staff', 1, 2, 1, 2, 3, 2, '50', '118.70.170.110', '2012-10-11', '2013-04-16', NULL, '2018-09-19 22:15:13', 1, 3, 24, 31, 2, 362, 364, 0, 0, 0, NULL, 1, 0, 0, NULL, 1, 0, 799971426, 'A nice and graceful woman', 15, 0, 20, 0, 5, 1, 1),
(20, 1, 0, 2, 'User3', 'User3', 'single, stable job and looking for a spouse. Would like to make friends with faithful and honest girls', 'playing and watching sports, reading books and magazines, travelling', 'Be successful in job and  have a happy family with her parents and siblings', 'user3@domain.com', 'user3', 1, 368, 36, 1, 1, 1, 'Sample data', 279, 223, '', '0903551214', 2, '', 1, 5, 'accounting', 1, 2, 1, 3, 3, 2, '50', '115.75.225.195', '2012-10-11', '2012-10-25', NULL, '2013-03-09 01:14:15', 1, 3, 26, 34, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 755687812, 'faithful and honest', 3, 0, 0, 0, 0, 0, 1),
(22, 1, 0, 2, 'User5', 'I am # 5', 'Outgoing, active.>_', 'Love travelling.hehe', 'Looking for an ideal husband. (^_^)', 'user5@domain.com', 'user5', 2, 362, 25, 1, 1, 1, 'Sample data', 279, 223, '', '0909284462', 2, '', 5, 4, 'accounting', 1, 2, 1, 2, 3, 2, '50', '113.172.160.156', '2012-10-11', '2018-09-22', NULL, '2018-09-22 01:28:12', 4, 3, 27, 45, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 85928553, 'thoughtful. Has a stable job and lives in Saigon, (I hope that I will see a good man).', 16, 0, 3, 1, 0, 0, 1),
(24, 1, 0, 2, 'User6', 'User6', 'honest, direct, loyal, hate lying', 'travelling, Watching movies , love Vietnamese traditional music', 'Make friends', 'user6@domain.com', 'user6', 2, 367, 49, 5, 1, 1, 'Sample data', 279, 223, '', '', 2, '', 5, 4, 'MC', 1, 1, 1, 1, 1, 1, '50', '115.72.217.222', '2012-10-11', '2012-10-15', NULL, '2018-09-22 01:23:54', 1, 3, 49, 62, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 125254593, 'I want to make friends with people from all over the world, share happiness and sadness ', 10, 0, 0, 0, 0, 0, 1),
(25, 1, 0, 2, 'User7', 'User7', 'the simpler you make it, the easier life becomes', 'Read fiction and non-fiction books, travel, listen to music, talk to friends.', '"Each day I choose a joy. Choose the flowers and smiles. I take the wind and let you hold it. So i can see you smile...And like that, I enjoy my life each day ..."', 'user7@domain.com', 'user7', 2, 361, 27, 1, 1, 1, 'Sample data', 279, 223, '12345', '', 1, '', 1, 5, 'Teachers', 1, 1, 1, 1, 3, 3, '50', '183.91.30.52', '2012-10-11', '2013-04-28', NULL, '2018-09-21 23:06:38', 1, 3, 27, 33, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 211814461, 'Friends who share same goals and interests.', 6, 0, 1, 1, 0, 0, 1),
(27, 1, 0, 2, 'User8', 'User8', 'Funny honest, direct, hate lying', 'Travel, watch movies, read books and magazines ,go to the pagoda regularly', 'Make friends', 'user8@domain.com', 'user8', 2, 357, 50, 1, 1, 1, 'Sample data', 279, 223, '', '', 2, '', 5, 4, 'Teachers', 1, 1, 1, 1, 1, 1, '50', '115.72.197.228', '2012-10-11', '2012-10-15', NULL, '2018-09-22 01:26:34', 1, 3, 50, 69, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 704317602, 'looking for friends, does not matter where you come from, age is not important , does not care whether you are rich , share sadness and happiness', 5, 0, 3, 0, 0, 0, 1),
(28, 1, 0, 2, 'User9', 'User9', 'height: 1.58m weight: 46 kg, nice, calm, antagonistic, besides these I still have a lot of positive qualities and some negative ones, I believe that no one is perfect, you can understand me better when we are dating. hiiii', 'watch movies, travel', 'looking for a woman who can share happiness and sadness, taking care of each other, building a happy family together.', 'user9@domain.com', 'user9', 1, 363, 32, 1, 1, 1, 'Sample data', 279, 223, '', '886-983478667', 2, '', 5, 1, 'Office staff', 1, 1, 6, 2, 2, 2, '500', '115.82.7.159', '2012-10-11', '2013-04-16', NULL, '2013-04-29 10:36:01', 1, 1, 25, 28, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 266378200, 'take good care of family, share sadness and happiness', 11, 0, 0, 0, 0, 0, 1),
(30, 1, 0, 2, 'User10', 'User10', 'good sense of humor, honest , direct, hate lying', 'traveling, love music and Vietnamese traditional music', 'Make friends', 'user10@domain.com', 'user10', 2, 362, 47, 2, 1, 1, 'Sample data', 279, 223, '', '', 2, '', 5, 4, 'business', 1, 1, 4, 1, 1, 1, '50', '115.72.197.228', '2012-10-11', '2012-10-15', NULL, '2018-09-21 20:33:50', 1, 3, 50, 60, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 431042685, 'Want to make friends with people from different provinces and cities, share happiness and sadness , looking forward to your reply', 8, 0, 6, 1, 11, 3, 1),
(31, 3, 0, 1, 'Antonio Carvajal', 'admin', '', '', '', 'antonio.carvajal.ph@gmail.com', 'happymovie', 1, 349, 18, 1, 1, 1, '', 235, 230, '', '', 2, '', 1, 1, '', 1, 1, 1, 2, 1, 1, '50', '113.162.232.13', '2010-12-16', '2012-10-22', NULL, '2018-08-22 14:56:57', 1, 2, 18, 18, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '', 55471, 5, 27, 0, 0, 0, 1),
(32, 1, 0, 2, '', 'Antonio Carvajal', 'I am a BSIT graduating student at University of Cebu', 'Programming, Surfing the net, Watching movies, Sports', '', 'antonio.carvajal@gmail.com', 'happymovie', 1, 371, 18, 1, 1, 1, 'Cebu', 519, 168, '6000', '0927 733 6999', 0, '', 8, 3, 'Student', 1, 2, 1, 1, 3, 3, '50', '::1', '2018-08-20', '2018-08-20', '0000-00-00 00:00:00', '2018-08-31 13:28:07', 4, 0, 18, 25, 1, 358, 370, 0, 8, 3, 0, 1, 0, 1, 0, 1, 0, 0, 'Fun and Engaging', NULL, 0, 0, 1, 0, 0, 1),
(33, 1, 0, 2, '', 'LayZPH', 'dasdas', 'sdfgsdfgsdfgsdfg', '', 'asdasdfasf@gmail.com', '123123', 1, 366, 18, 6, 9, 3, 'zxcvzxcv', 249, 223, 'zxcvzxcvzc', 'gdsfgdfsg', 0, '', 4, 5, 'sdfgdfs', 2, 1, 1, 1, 2, 2, '50', '::1', '2018-08-30', '2018-08-30', '0000-00-00 00:00:00', '2018-08-30 18:45:53', 4, 0, 18, 25, 1, 365, 364, 3, 2, 5, 0, 4, 2, 6, 0, 1, 0, 0, 'lkajdsflksjaasdfsaf', NULL, 0, 0, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `dt_whoviews`
--

CREATE TABLE `dt_whoviews` (
  `Id` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `ViewUserId` int(11) NOT NULL,
  `ViewDate` datetime NOT NULL,
  `IsView` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dt_whoviews`
--

INSERT INTO `dt_whoviews` (`Id`, `UserId`, `ViewUserId`, `ViewDate`, `IsView`) VALUES
(1, 32, 27, '2018-08-20 16:38:40', 0),
(2, 13, 30, '2018-08-30 18:02:17', 0),
(3, 18, 25, '2018-08-30 18:17:38', 0),
(4, 13, 16, '2018-08-30 18:20:52', 0),
(5, 13, 18, '2018-08-30 18:26:05', 0),
(6, 13, 27, '2018-08-30 18:36:55', 0),
(7, 13, 22, '2018-08-30 18:37:55', 0),
(8, 18, 27, '2018-09-19 21:30:08', 0),
(9, 22, 30, '2018-09-21 21:59:53', 0),
(10, 22, 18, '2018-09-21 22:01:15', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dt_abuseprofiles`
--
ALTER TABLE `dt_abuseprofiles`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dt_bannedusers`
--
ALTER TABLE `dt_bannedusers`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dt_bodytypes`
--
ALTER TABLE `dt_bodytypes`
  ADD PRIMARY KEY (`BodyTypeID`);

--
-- Indexes for table `dt_cards_categories`
--
ALTER TABLE `dt_cards_categories`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dt_chat`
--
ALTER TABLE `dt_chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dt_countries`
--
ALTER TABLE `dt_countries`
  ADD PRIMARY KEY (`CountryID`);

--
-- Indexes for table `dt_datinginterest`
--
ALTER TABLE `dt_datinginterest`
  ADD PRIMARY KEY (`DatingInterestID`);

--
-- Indexes for table `dt_drinking`
--
ALTER TABLE `dt_drinking`
  ADD PRIMARY KEY (`DrinkingID`);

--
-- Indexes for table `dt_ecards`
--
ALTER TABLE `dt_ecards`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dt_educations`
--
ALTER TABLE `dt_educations`
  ADD PRIMARY KEY (`EducationID`);

--
-- Indexes for table `dt_eyescolors`
--
ALTER TABLE `dt_eyescolors`
  ADD PRIMARY KEY (`EyeColorID`);

--
-- Indexes for table `dt_filteremails`
--
ALTER TABLE `dt_filteremails`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dt_flirts`
--
ALTER TABLE `dt_flirts`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dt_flirt_categories`
--
ALTER TABLE `dt_flirt_categories`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dt_gender`
--
ALTER TABLE `dt_gender`
  ADD PRIMARY KEY (`GenderID`);

--
-- Indexes for table `dt_greetingcards`
--
ALTER TABLE `dt_greetingcards`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dt_haircolors`
--
ALTER TABLE `dt_haircolors`
  ADD PRIMARY KEY (`HairColorID`);

--
-- Indexes for table `dt_height`
--
ALTER TABLE `dt_height`
  ADD PRIMARY KEY (`HeightID`);

--
-- Indexes for table `dt_hotlists`
--
ALTER TABLE `dt_hotlists`
  ADD KEY `IdxtblDHotListsUserID` (`UserID`);

--
-- Indexes for table `dt_liftbaned`
--
ALTER TABLE `dt_liftbaned`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dt_maritalstatus`
--
ALTER TABLE `dt_maritalstatus`
  ADD PRIMARY KEY (`MaritalStatusID`);

--
-- Indexes for table `dt_messages`
--
ALTER TABLE `dt_messages`
  ADD PRIMARY KEY (`MessageID`),
  ADD KEY `tblDMessageRecieverID` (`RecieverID`),
  ADD KEY `tblDMessageSenderID` (`SenderID`);

--
-- Indexes for table `dt_notifyemail`
--
ALTER TABLE `dt_notifyemail`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dt_orders`
--
ALTER TABLE `dt_orders`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dt_pages`
--
ALTER TABLE `dt_pages`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dt_paymentprovide`
--
ALTER TABLE `dt_paymentprovide`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dt_photos`
--
ALTER TABLE `dt_photos`
  ADD PRIMARY KEY (`PhotoID`);

--
-- Indexes for table `dt_posts`
--
ALTER TABLE `dt_posts`
  ADD PRIMARY KEY (`PostID`);

--
-- Indexes for table `dt_prices`
--
ALTER TABLE `dt_prices`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dt_profilestatus`
--
ALTER TABLE `dt_profilestatus`
  ADD PRIMARY KEY (`ProfileStatusID`);

--
-- Indexes for table `dt_religions`
--
ALTER TABLE `dt_religions`
  ADD PRIMARY KEY (`ReligionID`);

--
-- Indexes for table `dt_savedsearch`
--
ALTER TABLE `dt_savedsearch`
  ADD PRIMARY KEY (`SearchID`),
  ADD KEY `tblDSavedSearchUserID` (`UserID`);

--
-- Indexes for table `dt_signalme`
--
ALTER TABLE `dt_signalme`
  ADD KEY `tblDSignalMeRecieverID` (`RecieverID`);

--
-- Indexes for table `dt_site_settings`
--
ALTER TABLE `dt_site_settings`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dt_smoking`
--
ALTER TABLE `dt_smoking`
  ADD PRIMARY KEY (`SmokingID`);

--
-- Indexes for table `dt_states`
--
ALTER TABLE `dt_states`
  ADD PRIMARY KEY (`StateID`);

--
-- Indexes for table `dt_themes`
--
ALTER TABLE `dt_themes`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dt_users`
--
ALTER TABLE `dt_users`
  ADD PRIMARY KEY (`UserID`),
  ADD KEY `tblDtblDUsersProfileStatusID` (`ProfileStatusID`),
  ADD KEY `tblDUserIndexOnEmail` (`Email`);

--
-- Indexes for table `dt_whoviews`
--
ALTER TABLE `dt_whoviews`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dt_abuseprofiles`
--
ALTER TABLE `dt_abuseprofiles`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dt_bannedusers`
--
ALTER TABLE `dt_bannedusers`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dt_bodytypes`
--
ALTER TABLE `dt_bodytypes`
  MODIFY `BodyTypeID` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `dt_cards_categories`
--
ALTER TABLE `dt_cards_categories`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `dt_chat`
--
ALTER TABLE `dt_chat`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `dt_countries`
--
ALTER TABLE `dt_countries`
  MODIFY `CountryID` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=239;
--
-- AUTO_INCREMENT for table `dt_datinginterest`
--
ALTER TABLE `dt_datinginterest`
  MODIFY `DatingInterestID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `dt_drinking`
--
ALTER TABLE `dt_drinking`
  MODIFY `DrinkingID` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `dt_ecards`
--
ALTER TABLE `dt_ecards`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `dt_educations`
--
ALTER TABLE `dt_educations`
  MODIFY `EducationID` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `dt_eyescolors`
--
ALTER TABLE `dt_eyescolors`
  MODIFY `EyeColorID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `dt_filteremails`
--
ALTER TABLE `dt_filteremails`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dt_flirts`
--
ALTER TABLE `dt_flirts`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `dt_flirt_categories`
--
ALTER TABLE `dt_flirt_categories`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `dt_gender`
--
ALTER TABLE `dt_gender`
  MODIFY `GenderID` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `dt_greetingcards`
--
ALTER TABLE `dt_greetingcards`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=168;
--
-- AUTO_INCREMENT for table `dt_haircolors`
--
ALTER TABLE `dt_haircolors`
  MODIFY `HairColorID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `dt_height`
--
ALTER TABLE `dt_height`
  MODIFY `HeightID` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=390;
--
-- AUTO_INCREMENT for table `dt_liftbaned`
--
ALTER TABLE `dt_liftbaned`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=367;
--
-- AUTO_INCREMENT for table `dt_maritalstatus`
--
ALTER TABLE `dt_maritalstatus`
  MODIFY `MaritalStatusID` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `dt_messages`
--
ALTER TABLE `dt_messages`
  MODIFY `MessageID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `dt_notifyemail`
--
ALTER TABLE `dt_notifyemail`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `dt_orders`
--
ALTER TABLE `dt_orders`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `dt_pages`
--
ALTER TABLE `dt_pages`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `dt_paymentprovide`
--
ALTER TABLE `dt_paymentprovide`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `dt_photos`
--
ALTER TABLE `dt_photos`
  MODIFY `PhotoID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `dt_posts`
--
ALTER TABLE `dt_posts`
  MODIFY `PostID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `dt_prices`
--
ALTER TABLE `dt_prices`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `dt_profilestatus`
--
ALTER TABLE `dt_profilestatus`
  MODIFY `ProfileStatusID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `dt_religions`
--
ALTER TABLE `dt_religions`
  MODIFY `ReligionID` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `dt_savedsearch`
--
ALTER TABLE `dt_savedsearch`
  MODIFY `SearchID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `dt_site_settings`
--
ALTER TABLE `dt_site_settings`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `dt_smoking`
--
ALTER TABLE `dt_smoking`
  MODIFY `SmokingID` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `dt_states`
--
ALTER TABLE `dt_states`
  MODIFY `StateID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=575;
--
-- AUTO_INCREMENT for table `dt_themes`
--
ALTER TABLE `dt_themes`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `dt_users`
--
ALTER TABLE `dt_users`
  MODIFY `UserID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `dt_whoviews`
--
ALTER TABLE `dt_whoviews`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
