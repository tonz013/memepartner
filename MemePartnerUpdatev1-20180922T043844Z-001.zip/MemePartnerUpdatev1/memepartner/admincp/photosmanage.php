<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/photosmanage.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smrmvimgs'])){
	if(count($_POST['imgs'])>0){
		$ptdel = getPhotosUnlink($_POST['imgs']);
	if(!delImages($_POST['imgs']))
		$error = $errordata;
	else{
		$_SESSION['succ'] = 'You have been deleted <b><i>'.count($_POST['imgs']).'</i></b> photo(s) !';
		foreach($ptdel as $hval)
			unlink(dirname(dirname(__FILE__)).'/'.$uploaddir.'/'.$hval);
		mysql_close();
		$returnurl = (!empty($_SERVER['QUERY_STRING']))?'?'.$_SERVER['QUERY_STRING']:'';
		header('Location: '.$base_url.'admincp/photosmanage.php'.$returnurl);
		exit();
		}}
	else $error = 'Please select file to delete !';
	}
$purl = '';
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smfind'])){
	$str = '';
	if(!empty($_POST['txtname']))
		$str .= 'k='.urlencode($_POST['txtname']).'&';
	if(intval($_POST['txtday'])>0)
		$str .= 'd='.$_POST['txtday'].'&';
	if(intval($_POST['txtmonth'])>0)
		$str .= 'm='.$_POST['txtmonth'].'&';
	if(intval($_POST['txtyear'])>0)
		$str .= 'y='.$_POST['txtyear'].'&';
	$str = substr($str, 0, -1);
	mysql_close();
	header('Location: '.$base_url.'admincp/photosmanage.php?'.$str);
	exit();
	}
$strsearch = '';
if(isset($_GET['k']) && !empty($_GET['k'])){
	$strsearch .= "u.ProfileName like '%".mysql_real_escape_string(urldecode($_GET['k']))."%' and ";
	$purl .= 'k='.$_GET['k'].'&'; 
	}
if(isset($_GET['d']) && intval($_GET['d'])>0){
	$strsearch .= "date_format(InsertDate, '%d') = '".date('d', strtotime($_GET['d'].'-1-2013'))."' and ";
	$purl .= 'd='.$_GET['d'].'&'; 
	}
if(isset($_GET['m']) && intval($_GET['m'])>0){
	$strsearch .= "date_format(InsertDate, '%m') = '".date('m', strtotime('1-'.$_GET['m'].'-2013'))."' and ";
	$purl .= 'm='.$_GET['m'].'&'; 
	}
if(isset($_GET['y']) && intval($_GET['y'])>0){
	$strsearch .= "date_format(InsertDate, '%Y') = '".date('Y', strtotime('1-1-'.$_GET['y']))."' and ";
	$purl .= 'y='.$_GET['y'].'&'; 
	}
$purl = (!empty($purl))?'?'.substr($purl, 0, -1):'';
$title = 'AdminCP - Photos Management';
require_once 'include/header.php';
?>
<script language="javascript" type="text/javascript">
function cfmDel(){
	if(document.getElementById('hdddel').value==1){
	if(confirm('Are you sure you want to delete ?'))
		return true;
	return false;}
	return true;
	}
</script>
<div class="admincontent">
	<p class="contentop">Photos Management</p>
    <div class="contenbody">
    	<form action="" method="post">
        	<p align="center"><i><input type="text" name="txtname" style="width:265px; font-style:italic" placeholder="Enter the name to find" value="<?php echo (isset($_GET['k']) && !empty($_GET['k']))?urldecode($_GET['k']):'';?>" /><span style="margin-left:30px;">Uploaded on date: </span>
            <select name="txtday" style="font-style:italic">
            	<option value="0">Day</option>
                <?php
				$dval = (isset($_GET['d']) && intval($_GET['d'])>0)?intval($_GET['d']):0;
				for($k=1; $k<32; $k++){
					$sel = ($k==$dval)?' selected="selected"':'';
					echo '<option value="'.$k.'" '.$sel.'>'.$k.'</option>';
					}
				?>
            </select> / 
            <select name="txtmonth" style="font-style:italic">
            	<option value="0">Month</option>
                <?php
				$mval = (isset($_GET['m']) && intval($_GET['m'])>0)?intval($_GET['m']):0;
				for($k=1; $k<13; $k++){
					$sel = ($k==$mval)?' selected="selected"':'';
					echo '<option value="'.$k.'" '.$sel.'>'.$k.'</option>';
					}
				?>
            </select> / 
            <select name="txtyear" style="font-style:italic">
            	<option value="0">Year</option>
                <?php
				$yval = (isset($_GET['y']) && intval($_GET['y'])>0)?intval($_GET['y']):0;
				for($k=2000; $k<date('Y')+1; $k++){
					$sel = ($k==$yval)?' selected="selected"':'';
					echo '<option value="'.$k.'" '.$sel.'>'.$k.'</option>';
					}
				?>
            </select>
            <input type="submit" name="smfind" value="Search" style="margin-left:20px;" class="massbutton"/></i>
            </p>
         </form>
    	<?php
		$config['showeachside'] = 4;
		$config['per_page'] = 30;
		$config['js_numrows_page'] = countPhotosManage($strsearch, '');
		$config['curpage'] = empty($_GET['p'])?1:$_GET['p'];
		$config['rs_start'] = ($config['curpage']*$config['per_page'])-$config['per_page'];
		if($config['js_numrows_page'] < $config['per_page'])
			$config['per_page'] = $config['js_numrows_page'];
		$config['cururl'] = $base_url.'admincp/photosmanage.php'.$purl;
		$rs_maxpage = $config['js_numrows_page']>0?ceil($config['js_numrows_page']/$config['per_page']):0;
		$paging = Pagination($config);
		if(isset($error) && !empty($error))
			echo '<p style="margin:0px; padding:10px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
		if(isset($_SESSION['succ']) && !empty($_SESSION['succ'])){
			echo '<p style="margin:0px; padding:10px"><font color="#009933">'.$_SESSION['succ'].'</font></p>';
			unset($_SESSION['succ']);
			}
		$list = getPhotosManage($strsearch, " limit ".$config['rs_start'].", ".$config['per_page']);
		if(count($list)>0){
		?>
        <form action="" method="post" onsubmit="return cfmDel()"><input type="hidden" id="hdddel" value="1" />
        <p><span style="padding:0px 0px 0px 10px; float:left"><i>Have <b><?php echo $config['js_numrows_page'];?></b> record(s)</i></span><span style="padding:0px 0px 0px 10px; float:right"><i>Display <b><?php echo $config['curpage'];?></b> of <b><?php echo $rs_maxpage;?></b> pages&nbsp;&nbsp;</i></span></p>
        <p style="clear:both; height:0px">&nbsp;</p>
        <table width="100%" border="0" cellpadding="0" cellspacing="0">
        	<tr bgcolor="#f2f2f2">
            	<td width="15%" class="headrows1" colspan="6" style="border-top:1px solid #d6d8e5">&nbsp;</td>
            </tr>
            <?php
			for($i=0; $i<count($list['PhotoID']); $i+=6){
				?>
                <tr>
                    <td width="15%" class="headrows3" valign="top" style="text-align:left">
                    	<p><input type="checkbox" style="margin-left:0px; padding-left:0px" value="<?php echo $list['PhotoID'][$i];?>" name="imgs[]" />
						<?php echo $list['ProfileName'][$i];
							$extend = ($list['PrimaryPhotoID'][$i]==$list['PhotoID'][$i])?'Primary':date('m-d-Y', strtotime($list['InsertDate'][$i]));
							echo ' <i>('.$extend.')</i>';
						
						?></p>
                    	<img src="<?php echo $base_url.$uploaddir.'/'.$list['UserID'][$i].'u'.$list['PhotoID'][$i].'.'.$list['PhotoExtension'][$i];?>" border="0" width='170' />
                    </td>
                    <td width="15%" class="headrows4" valign="top" align="left">
                    	<p><input type="checkbox" style="margin-left:0px; padding-left:0px" value="<?php echo $list['PhotoID'][$i+1];?>" name="imgs[]"  />
						<?php echo $list['ProfileName'][$i+1];
							$extend = ($list['PrimaryPhotoID'][$i+1]==$list['PhotoID'][$i+1])?'Primary':date('m-d-Y', strtotime($list['InsertDate'][$i+1]));
							echo ' <i>('.$extend.')</i>';?></p>
                    	<img src="<?php echo $base_url.$uploaddir.'/'.$list['UserID'][$i+1].'u'.$list['PhotoID'][$i+1].'.'.$list['PhotoExtension'][$i+1];?>" border="0" width='170' />
                    </td>
                    <td width="15%" class="headrows4" valign="top" align="left">
                    	<p><input type="checkbox" style="margin-left:0px; padding-left:0px" value="<?php echo $list['PhotoID'][$i+2];?>" name="imgs[]"  />
						<?php echo $list['ProfileName'][$i+2];
							$extend = ($list['PrimaryPhotoID'][$i+2]==$list['PhotoID'][$i+2])?'Primary':date('m-d-Y', strtotime($list['InsertDate'][$i+2]));
							echo ' <i>('.$extend.')</i>';?></p>
                   		<img src="<?php echo $base_url.$uploaddir.'/'.$list['UserID'][$i+2].'u'.$list['PhotoID'][$i+2].'.'.$list['PhotoExtension'][$i+2];?>" border="0" width='170' />
                    </td>
                    <td width="15%" class="headrows4" valign="top" align="left">
                    	<p><input type="checkbox" style="margin-left:0px; padding-left:0px" value="<?php echo $list['PhotoID'][$i+3];?>" name="imgs[]"  />
						<?php echo $list['ProfileName'][$i+3];
							$extend = ($list['PrimaryPhotoID'][$i+3]==$list['PhotoID'][$i+3])?'Primary':date('m-d-Y', strtotime($list['InsertDate'][$i+3]));
							echo ' <i>('.$extend.')</i>';?></p>
                    	<img src="<?php echo $base_url.$uploaddir.'/'.$list['UserID'][$i+3].'u'.$list['PhotoID'][$i+3].'.'.$list['PhotoExtension'][$i+3];?>" border="0" width='170' />
                    </td>
                    <td width="15%" class="headrows4" valign="top" align="left">
                    	<p><input type="checkbox" style="margin-left:0px; padding-left:0px" value="<?php echo $list['PhotoID'][$i+4];?>" name="imgs[]"  />
						<?php echo $list['ProfileName'][$i+4];
							$extend = ($list['PrimaryPhotoID'][$i+4]==$list['PhotoID'][$i+4])?'Primary':date('m-d-Y', strtotime($list['InsertDate'][$i+4]));
							echo ' <i>('.$extend.')</i>';?></p>
                    	<img src="<?php echo $base_url.$uploaddir.'/'.$list['UserID'][$i+4].'u'.$list['PhotoID'][$i+4].'.'.$list['PhotoExtension'][$i+4];?>" border="0" width='170' />
                    </td>
                    <td width="15%" class="headrows4" valign="top" align="left">
                    	<p><input type="checkbox" style="margin-left:0px; padding-left:0px" value="<?php echo $list['PhotoID'][$i+5];?>" name="imgs[]"  />
						<?php echo $list['ProfileName'][$i+5];
							$extend = ($list['PrimaryPhotoID'][$i+5]==$list['PhotoID'][$i+5])?'Primary':date('m-d-Y', strtotime($list['InsertDate'][$i+5]));
							echo ' <i>('.$extend.')</i>';?></p>
                    	<img src="<?php echo $base_url.$uploaddir.'/'.$list['UserID'][$i+5].'u'.$list['PhotoID'][$i+5].'.'.$list['PhotoExtension'][$i+5];?>" border="0" width='170' />
                    </td>
                </tr>
                <?php
				}
			?>
            
            <tr>
            	<td width="20%" style="padding:20px" colspan="7" align="center"><input type="submit" name="smrmvimgs" class="massbutton" /><input type="hidden" value="<?php echo $i;?>" name="total" /></td>
            </tr>
        </table>
        <p id="paging" style="clear:both; margin-right:0px; text-align:center"><?php echo $paging;?></p>
        <?php  }
		else echo '<p style="padding:10px;">There are no messages !</p>';
		?>
        </form>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>