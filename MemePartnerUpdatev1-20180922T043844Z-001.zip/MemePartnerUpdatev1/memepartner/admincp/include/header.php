<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $title;?></title>
<link href="<?php echo $base_url;?>css/style.css" type="text/css" rel="stylesheet" />
<link href="<?php echo $base_url;?>imgs/dtlogo.gif" rel="shortcut icon" type="image/x-icon" />
<script language="javascript" type="text/javascript" src="<?php echo $base_url;?>jss/jquery.min.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo $base_url;?>jss/styles.js"></script>
<link href="<?php echo $base_url;?>css/admincss.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <div id="contentbody" style="margin-top:0px; padding-top:0px">
<?php $_SESSION['lang'] = 'L1';