<?php
if ( ! function_exists('valid_email')){
	function valid_email($address){
		return ( ! preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $address)) ? FALSE : TRUE;
		}
	}
if(!function_exists('dropdownlist')){
	function dropdownlist($sql='', $val=0){
		$query = mysql_query($sql);
		if(!$query)
			echo '<option value="-1">- Error data -</option>';
		else{
			while($rows=mysql_fetch_array($query)){
				$sel = ($rows['Id']==$val)?' selected="selected"':'';
				echo '<option value="'.$rows['Id'].'" '.$sel.'>'.$rows['LName'].'</option>';
				}
			}
		}
	}
if(!function_exists('adminLogin')){
	function adminLogin($info=array()){
		$sql = "select UserID from ".$GLOBALS['table_prefix']."users where Email = '".$info[0]."' and Password = '".$info[1]."' and MembershipID = 3";
		$query = mysql_query($sql);
		if(!$query)
			return 0;
		elseif(mysql_num_rows($query)>0){
			$row=mysql_fetch_array($query);
			return $row['UserID'];
			}
		else return -1;
		}
	}
if(!function_exists('getProfilesApprove')){
	function getProfilesApprove($limit){
		$result = array();
		$sql = "select u.UserID, ProfileName, AboutMe, City, AboutMyMatch, Goal, LastLogon, State, Country, ".$_SESSION['lang']."Gender as LGender, PhotoExtension, PrimaryPhotoID, Interests from ".$GLOBALS['table_prefix']."users as u  left join ".$GLOBALS['table_prefix']."states as s on u.StateID = s.StateID left join ".$GLOBALS['table_prefix']."countries as c on u.CountryID = c.CountryID left join ".$GLOBALS['table_prefix']."gender as g on u.GenderID = g.GenderID left join ".$GLOBALS['table_prefix']."photos as p on u.PrimaryPhotoID = p.PhotoID where u.ProfileStatusID = 4 order by LastLogon desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return $result;
		elseif(mysql_num_rows($query)>0){
			while($rows=mysql_fetch_array($query)){
				$result['UserID'][] = $rows['UserID'];
				$result['ProfileName'][] = $rows['ProfileName'];
				$result['AboutMe'][] = $rows['AboutMe'];
				$result['City'][] = $rows['City'];
				$result['AboutMyMatch'][] = $rows['AboutMyMatch'];
				$result['Goal'][] = $rows['Goal'];
				$result['LastLogon'][] = $rows['LastLogon'];
				$result['State'][] = $rows['State'];
				$result['Country'][] = $rows['Country'];
				$result['LGender'][] = $rows['LGender'];
				$result['PhotoExtension'][] = $rows['PhotoExtension'];
				$result['PrimaryPhotoID'][] = $rows['PrimaryPhotoID'];
				$result['Interests'][] = $rows['Interests'];
				}
			return $result;
			}
		else return $result;
		}
	}
if(!function_exists('updateProfile')){
	function updateProfile($userid=0, $val=0){
		$sql = "update ".$GLOBALS['table_prefix']."users set ProfileStatusID = ".$val." where UserID = ".$userid;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('approveImages')){
	function approveImages($data=array(), $userid=0){
		$sql = "update ".$GLOBALS['table_prefix']."photos set IsApproved = 1 where PhotoID in (".implode(',',$data).") and UserID = ".$userid;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('removeImages')){
	function removeImages($data=array(), $userid=0){
		$sql = "delete from ".$GLOBALS['table_prefix']."photos where PhotoID in (".implode(',',$data).") and UserID = ".$userid;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('removeProfiles')){
	function removeProfiles($profile=0){
		$sql = "delete from ".$GLOBALS['table_prefix']."users where UserID = ".$profile;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else{
			$img = getUserImgs($profile);
			if(count($img)>0)
				removeImages($img, $profile);
			$mess = getMessagesUsers($profile);
			if(count($mess)>0)
				delMessagesUsers($mess, $profile);
			$ban = getBannedUsers($profile);
			if(count($ban)>0)
				delBannedUsers($ban, $profile);
			$saved = getSavedSearchUsers($profile);
			if(count($saved)>0)
				delSavedSearchUsers($saved, $profile);
			delSignalsUsers($profile);
			delBlockUsers($profile);
			delHotlistUsers($profile);
			return true;
			}
		}
	}
if(!function_exists('getUserImgs')){
	function getUserImgs($userid=0){
		$result = array();
		$sql = "select PhotoID from ".$GLOBALS['table_prefix']."photos where UserID = ".$userid;
		$query = mysql_query($sql);
		if(!$query)
			return $result;
		elseif(mysql_num_rows($query)>0){
			while($rows=mysql_fetch_array($query))
				array_push($result, $rows['PhotoID']);
			return $result;
			}
		else return $result;
		}
	}
if(!function_exists('getMessagesUsers')){
	function getMessagesUsers($userid=0){
		$result = array();
		$sql = "select DISTINCT MessageID from ".$GLOBALS['table_prefix']."messages where RecieverID = ".$userid." or SenderID = ".$userid;
		$query = mysql_query($sql);
		if(!$query)
			return $result;
		elseif(mysql_num_rows($query)>0){
			while($rows=mysql_fetch_array($query))
				array_push($result, $rows['MessageID']);
			return $result;
			}
		else return $result;
		}
	}
if(!function_exists('delMessagesUsers')){
	function delMessagesUsers($data=array(), $userid=0){
		$sql = "delete from ".$GLOBALS['table_prefix']."messages where MessageID in (".implode(',', $data).")";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('getBannedUsers')){
	function getBannedUsers($userid=0){
		$result = array();
		$sql = "select DISTINCT Id from ".$GLOBALS['table_prefix']."bannedusers where UserId = ".$userid;
		$query = mysql_query($sql);
		if(!$query)
			return $result;
		elseif(mysql_num_rows($query)>0){
			while($rows=mysql_fetch_array($query))
				array_push($result, $rows['Id']);
			return $result;
			}
		else return $result;
		}
	}
if(!function_exists('delBannedUsers')){
	function delBannedUsers($data=array(), $userid=0){
		$sql = "delete from ".$GLOBALS['table_prefix']."bannedusers where Id in (".implode(',', $data).")";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('getSavedSearchUsers')){
	function getSavedSearchUsers($userid=0){
		$result = array();
		$sql = "select DISTINCT SearchID from ".$GLOBALS['table_prefix']."savedsearch where UserID = ".$userid;
		$query = mysql_query($sql);
		if(!$query)
			return $result;
		elseif(mysql_num_rows($query)>0){
			while($rows=mysql_fetch_array($query))
				array_push($result, $rows['SearchID']);
			return $result;
			}
		else return $result;
		}
	}
if(!function_exists('delSavedSearchUsers')){
	function delSavedSearchUsers($data=array(), $userid=0){
		$sql = "delete from ".$GLOBALS['table_prefix']."savedsearch where SearchID in (".implode(',', $data).")";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('delSignalsUsers')){
	function delSignalsUsers($userid=0){
		$sql = "delete from ".$GLOBALS['table_prefix']."signalme where RecieverID = ".$userid." or SenderID = ".$userid;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('delBlockUsers')){
	function delBlockUsers($userid=0){
		$sql = "delete from ".$GLOBALS['table_prefix']."blockedusers where UserID = ".$userid." or BlockedUserID = ".$userid;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('delHotlistUsers')){
	function delHotlistUsers($userid=0){
		$sql = "delete from ".$GLOBALS['table_prefix']."hotlists where UserID = ".$userid." or SavedUserID = ".$userid;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('getProfilesImgs')){
	function getProfilesImgs($limit=''){
		$result = array();
		$sql = "select PhotoID, PhotoExtension, p.UserID, ProfileName, City, InsertDate, State, Country, ".$_SESSION['lang']."Gender as LGender, Email from ".$GLOBALS['table_prefix']."photos as p left join ".$GLOBALS['table_prefix']."users as u on p.UserID = u.UserID and IsApproved = 0 left join ".$GLOBALS['table_prefix']."states as s on u.StateID = s.StateID left join ".$GLOBALS['table_prefix']."countries as c on u.CountryID = c.CountryID left join ".$GLOBALS['table_prefix']."gender as g on u.GenderID = g.GenderID where u.ProfileStatusID = 1 order by InsertDate desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return $result;
		elseif(mysql_num_rows($query)>0){
			while($rows=mysql_fetch_array($query)){
				$result['UserID'][] = $rows['UserID'];
				$result['ProfileName'][] = $rows['ProfileName'];
				$result['AboutMe'][] = $rows['AboutMe'];
				$result['City'][] = $rows['City'];
				$result['InsertDate'][] = $rows['InsertDate'];
				$result['State'][] = $rows['State'];
				$result['Country'][] = $rows['Country'];
				$result['LGender'][] = $rows['LGender'];
				$result['PhotoExtension'][] = $rows['PhotoExtension'];
				$result['PhotoID'][] = $rows['PhotoID'];
				$result['Email'][] = $rows['Email'];
				}
			return $result;
			}
		else return $result;
		}
	}
if(!function_exists('getMessagesApprpve')){
	function getMessagesApprpve($limit=''){
		$result = array();
		$sql = "select MessageID, SentOn, Subject, Message, u1.ProfileName as sender, u2.ProfileName as receiver from ".$GLOBALS['table_prefix']."messages as m left join ".$GLOBALS['table_prefix']."users as u1 on m.SenderID = u1.UserID left join ".$GLOBALS['table_prefix']."users as u2 on m.RecieverID = u2.UserID where MessageStatus = 0 order by SentOn desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return $result;
		elseif(mysql_num_rows($query)>0){
			while($rows=mysql_fetch_array($query)){
				$result['MessageID'][] = $rows['MessageID'];
				$result['SentOn'][] = $rows['SentOn'];
				$result['Subject'][] = $rows['Subject'];
				$result['Message'][] = $rows['Message'];
				$result['sender'][] = $rows['sender'];
				$result['State'][] = $rows['State'];
				$result['receiver'][] = $rows['receiver'];
				}
			return $result;
			}
		else return $result;
		}
	}
if(!function_exists('approveMessages')){
	function approveMessages($data=array()){
		$sql = "update ".$GLOBALS['table_prefix']."messages set MessageStatus = 1 where MessageID in (".implode(',',$data).")";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('delMessages')){
	function delMessages($data=array()){
		$sql = "delete from ".$GLOBALS['table_prefix']."messages where MessageID in (".implode(',',$data).")";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('getEmailSender')){
	function getEmailSender($mess=0){
		$sql = "select Email from ".$GLOBALS['table_prefix']."messages as m inner join ".$GLOBALS['table_prefix']."users as u on m.SenderID = u.UserID where MessageID = ".$mess;
		$query = mysql_query($sql);
		if(!$query)
			return '';
		elseif(mysql_num_rows($query)>0){
			$row = mysql_fetch_array($query);
			return $row['Email'];
			}
		else return '';
		}
	}
if(!function_exists('getEmailReceiver')){
	function getEmailReceiver($mess=0){
		$sql = "select Email from ".$GLOBALS['table_prefix']."messages as m inner join ".$GLOBALS['table_prefix']."users as u on m.RecieverID = u.UserID where MessageID = ".$mess;
		$query = mysql_query($sql);
		if(!$query)
			return '';
		elseif(mysql_num_rows($query)>0){
			$row = mysql_fetch_array($query);
			return $row['Email'];
			}
		else return '';
		}
	}
if(!function_exists('getPhotosManage')){
	function getPhotosManage($strsearch='', $limit=''){
		$result = array();
		$sql = "select PhotoID, p.UserID, PhotoExtension, u.ProfileName, InsertDate, PrimaryPhotoID from ".$GLOBALS['table_prefix']."photos as p inner join ".$GLOBALS['table_prefix']."users as u on u.UserID = p.UserID where ".$strsearch." IsApproved = 1 order by InsertDate desc, p.UserID desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return $result;
		elseif(mysql_num_rows($query)>0){
			while($rows=mysql_fetch_array($query)){
				$result['PhotoID'][] = $rows['PhotoID'];
				$result['UserID'][] = $rows['UserID'];
				$result['PhotoExtension'][] = $rows['PhotoExtension'];
				$result['ProfileName'][] = $rows['ProfileName'];
				$result['InsertDate'][] = $rows['InsertDate'];
				$result['PrimaryPhotoID'][] = $rows['PrimaryPhotoID'];
				}
			return $result;
			}
		else return $result;
		}
	}
if(!function_exists('countPhotosManage')){
	function countPhotosManage($strsearch='', $limit=''){
		$sql = "select PhotoID, p.UserID, PhotoExtension, u.ProfileName from ".$GLOBALS['table_prefix']."photos as p inner join ".$GLOBALS['table_prefix']."users as u on u.UserID = p.UserID where ".$strsearch." IsApproved = 1 order by InsertDate desc, p.UserID desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return 0;
		else return mysql_num_rows($query);
		}
	}
if(!function_exists('Pagination')){
	function Pagination($config=array()){
		$firstpage = 'First';
		$lastpage = 'Last';
		$output = '';
		$rs_maxpage = ($config['js_numrows_page']>0)?ceil($config['js_numrows_page']/$config['per_page']):0;
		$eitherside = ($config['showeachside'] * $config['per_page']);
		$paga = (strpos($config['cururl'], '?')!==false)?'&p=':'?p=';
		if($rs_maxpage>1){
			if($config['rs_start']+1 > $eitherside){
				$page = $config['curpage'] - 1;
				$output .= '<a href="'.$config['cururl'].'"><i>'.$firstpage.'</i></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$config['cururl'].$paga.$page.'"><i><<</i></a> . . . ';
				}
				$pg=1;
			for($y=0; $y<$config['js_numrows_page']; $y+=$config['per_page']){
				if(($y > ($config['rs_start'] - $eitherside)) && ($y < ($config['rs_start'] + $eitherside)))
					$output .= ($pg==$config['curpage'])?'<b> &nbsp;'.$pg.'</b>':' &nbsp;<a href="'.$config['cururl'].$paga.$pg.'">'.$pg.'</a>';
				$pg++;
				}
			if(($config['rs_start']+$eitherside)<$config['js_numrows_page']){
				$page = $config['curpage'] + 1;
				$output .=  ' . . . <a href="'.$config['cururl'].$paga.$page.'"><i>>></i></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$config['cururl'].$paga.$rs_maxpage.'"><i>'.$lastpage.'</i></a>';
				}
			}
		return $output;
		}
	}
if(!function_exists('delImages')){
	function delImages($data=array()){
		$sql = "delete from ".$GLOBALS['table_prefix']."photos where PhotoID in (".implode(',',$data).")";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('getPhotosUnlink')){
	function getPhotosUnlink($imgs=array()){
		$result = array();
		$sql = "select PhotoID, UserID, PhotoExtension from ".$GLOBALS['table_prefix']."photos where PhotoID in (".implode(',', $imgs).")";
		$query = mysql_query($sql);
		if(!$query)
			return $result;
		elseif(mysql_num_rows($query)>0){
			while($rows=mysql_fetch_array($query)){
				$result[] = $rows['UserID'].'u'.$rows['PhotoID'].'.'.$rows['PhotoExtension'];
				}
			return $result;
			}
		else return $result;
		}
	}
if(!function_exists('countAllUsers')){
	function countAllUsers($strsearch='', $limit=''){
		$sql = "select count(UserID) as totalu from ".$GLOBALS['table_prefix']."users as u where ".$strsearch." ProfileStatusID <> 0 and u.UserID not in (select UserId from ".$GLOBALS['table_prefix']."bannedusers) order by u.UserID desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return 0;
		else{
			$ttu = mysql_fetch_array($query);
			return $ttu['totalu'];
			}
		}
	}
if(!function_exists('getUsersManage')){
	function getUsersManage($strsearch='', $limit=''){
		$sql = "select u.UserID, ProfileName, Age, City, State, Country, GenderID, Email from ".$GLOBALS['table_prefix']."users as u left join ".$GLOBALS['table_prefix']."states as s on u.StateID = s.StateID left join ".$GLOBALS['table_prefix']."countries as c on u.CountryID = c.CountryID where ".$strsearch." ProfileStatusID <> 0 and u.UserID not in (select UserId from ".$GLOBALS['table_prefix']."bannedusers) order by u.UserID desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return array();
		else return $query;
		}
	}
if(!function_exists('countPhotosOfUser')){
	function countPhotosOfUser($user=0){
		$sql = "select count(PhotoID) as total from ".$GLOBALS['table_prefix']."photos where UserID = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return 0;
		else{
			$tt = mysql_fetch_array($query);
			return $tt['total'];
			}
		}
	}
if(!function_exists('countMessOfUser')){
	function countMessOfUser($user=0){
		$result = array();
		$sql = "select count(MessageID) as totals from ".$GLOBALS['table_prefix']."messages where SenderID = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return $result;
		else{
			$tts = mysql_fetch_array($query);
			$result['sent'] = $tts['totals'];
			}
		$sqln = "select count(MessageID) as totalr from ".$GLOBALS['table_prefix']."messages where RecieverID = ".$user;
		$queryn = mysql_query($sqln);
		if(!$queryn)
			return $result;
		else{
			$ttr = mysql_fetch_array($queryn);
			$result['rece'] = $ttr['totalr'];
			}
		return $result;
		}
	}
if(!function_exists('getInfoUsersBan')){
	function getInfoUsersBan($user=0){
		$result = array();
		$sql = "select ProfileName, Email from ".$GLOBALS['table_prefix']."users where UserID = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return $result;
		elseif(mysql_num_rows($query)>0){
			$rows=mysql_fetch_array($query);
			$result['ProfileName'] = $rows['ProfileName'];
			$result['Email'] = $rows['Email'];
			return $result;
			}
		else return $result;
		}
	}
if(!function_exists('BanUsers')){
	function BanUsers($data=array()){
		$sql = "insert into ".$GLOBALS['table_prefix']."bannedusers (UserId, Reason, BanedOn, LiftBanId, BannedBy) values (".$data[0].", '".$data[1]."', '".date('Y-m-d h:i:s')."', ".$data[2].", 'Admin')";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('getFullInfoUser')){
	function getFullInfoUser($user=0){
		$sql = "select * from ".$GLOBALS['table_prefix']."users where UserID = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return array();
		else return mysql_fetch_array($query);
		}
	}
if(!function_exists('updateUser')){
	function updateUser($data=array(),$user=0){
		$sql = "update ".$GLOBALS['table_prefix']."users set Name = '".$data[0]."', ProfileName = '".$data[1]."', GenderID = ".$data[2].", HeightID = ".$data[3].", Age = ".$data[4].", BodyTypeID = ".$data[5].", HairColorID = ".$data[6].", EyeColorID = ".$data[7].", City = '".$data[8]."', StateID = ".$data[9].", CountryID = ".$data[10].", Phone = '".$data[11]."', ReligionID = ".$data[12].", EducationID = ".$data[13].", Occupation = '".$data[14]."', SmokingID = ".$data[15].", DrinkingID = ".$data[16].", MaritalStatusID = ".$data[17].", DatingInterestID = ".$data[18].", HaveChildren = ".$data[19].", WantChildren = ".$data[20].", WillingToTravel = ".$data[21].", MatchAgeFrom = ".$data[22].", MatchAgeTO = ".$data[23].", MatchGenderID = ".$data[24].", MatchHeightIDFrom = ".$data[25].", MatchHeightIDTo = ".$data[26].", MatchBodyStyleID = ".$data[27].", MatchReligionID = ".$data[28].", MatchEducationID = ".$data[29].", MatchSmokingID = ".$data[30].", MatchDrinkingID = ".$data[31].", MatchMaritalStatusID = ".$data[32].", MatchBeSameLocation = ".$data[33].", Interests = '".$data[34]."', AboutMe = '".$data[35]."', AboutMyMatch = '".$data[36]."' where UserID = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('getRegToday')){
	function getRegToday($curdate=''){
		$sql = "SELECT COUNT(*) AS Total, DATE_FORMAT(DatePosted,'%l %p') AS TheDate FROM ".$GLOBALS['table_prefix']."users WHERE DATE_FORMAT( DatePosted,'%Y-%m-%d')>'".$curdate."' GROUP BY DATE_FORMAT(DatePosted,'%l %p') ORDER BY DatePosted DESC";
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('getLoginToday')){
	function getLoginToday($curdate=''){
		$sql = "SELECT COUNT(*) AS Total, DATE_FORMAT( LastLogon,'%l %p') AS TheDate FROM ".$GLOBALS['table_prefix']."users WHERE DATE_FORMAT( LastLogon,'%Y-%m-%d')>'".$curdate."' GROUP BY DATE_FORMAT(LastLogon,'%l %p') ORDER BY LastLogon DESC";
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('getSentMessToday')){
	function getSentMessToday($curdate=''){
		$sql = "SELECT COUNT(*) AS Total, DATE_FORMAT(SentOn,'%l %p') AS TheDate FROM ".$GLOBALS['table_prefix']."messages WHERE DATE_FORMAT( SentOn,'%Y-%m-%d')>'".$curdate."' GROUP BY DATE_FORMAT(SentOn,'%l %p') ORDER BY SentOn DESC";
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('getSignalToday')){
	function getSignalToday($curdate=''){
		$sql = "SELECT COUNT(*) AS Total, DATE_FORMAT(SignalDate,'%l %p') AS TheDate FROM ".$GLOBALS['table_prefix']."signalme WHERE DATE_FORMAT( SignalDate,'%Y-%m-%d')>'".$curdate."' GROUP BY DATE_FORMAT(SignalDate,'%l %p') ORDER BY SignalDate DESC";
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('getPhotosToday')){
	function getPhotosToday($curdate=''){
		$sql = "SELECT COUNT(*) AS Total, DATE_FORMAT(InsertDate,'%l %p') AS TheDate FROM ".$GLOBALS['table_prefix']."photos WHERE DATE_FORMAT( InsertDate,'%Y-%m-%d')>'".$curdate."' GROUP BY DATE_FORMAT(InsertDate,'%l %p') ORDER BY InsertDate DESC";
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('getRegSite')){
	function getRegSite($curdate=''){
		$sql = "SELECT COUNT(*) AS Total, DATE_FORMAT(DatePosted,'%Y-%d-%m') AS TheDate FROM ".$GLOBALS['table_prefix']."users WHERE DATE_FORMAT( DatePosted,'%Y-%m-%d') <= '".$curdate."' GROUP BY DATE_FORMAT(DatePosted,'%Y-%d-%m') ORDER BY DatePosted DESC limit 30";
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('getLoginSite')){
	function getLoginSite($curdate=''){
		$sql = "SELECT COUNT(*) AS Total, DATE_FORMAT( LastLogon,'%Y-%d-%m') AS TheDate FROM ".$GLOBALS['table_prefix']."users WHERE DATE_FORMAT( LastLogon,'%Y-%m-%d')<='".$curdate."' GROUP BY DATE_FORMAT(LastLogon,'%Y-%d-%m') ORDER BY LastLogon DESC limit 30";
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('getSentMessSite')){
	function getSentMessSite($curdate=''){
		$sql = "SELECT COUNT(*) AS Total, DATE_FORMAT(SentOn, '%Y-%d-%m') AS TheDate FROM ".$GLOBALS['table_prefix']."messages WHERE DATE_FORMAT( SentOn,'%Y-%m-%d') <= '".$curdate."' GROUP BY DATE_FORMAT(SentOn, '%Y-%d-%m') ORDER BY SentOn DESC limit 30";
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('getSignalSite')){
	function getSignalSite($curdate=''){
		$sql = "SELECT COUNT(*) AS Total, DATE_FORMAT(SignalDate, '%Y-%d-%m') AS TheDate FROM ".$GLOBALS['table_prefix']."signalme WHERE DATE_FORMAT( SignalDate,'%Y-%m-%d') <= '".$curdate."' GROUP BY DATE_FORMAT(SignalDate, '%Y-%d-%m') ORDER BY SignalDate DESC limit 30";
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('getPhotosSite')){
	function getPhotosSite($curdate=''){
		$sql = "SELECT COUNT(*) AS Total, DATE_FORMAT(InsertDate, '%Y-%d-%m') AS TheDate FROM ".$GLOBALS['table_prefix']."photos WHERE DATE_FORMAT( InsertDate,'%Y-%m-%d') <= '".$curdate."' GROUP BY DATE_FORMAT(InsertDate, '%Y-%d-%m') ORDER BY InsertDate DESC limit 30";
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('countUsersSite')){
	function countUsersSite(){
		$sql = "SELECT COUNT(UserID) AS Total FROM ".$GLOBALS['table_prefix']."users";
		$query = mysql_query($sql);
		if(!$query)
			return 0;
		else{
			$row = mysql_fetch_array($query);
			return $row['Total'];
			}
		}
	}
if(!function_exists('countUsersCountry')){
	function countUsersCountry($country=0){
		$sql = "SELECT COUNT(UserID) AS Total FROM ".$GLOBALS['table_prefix']."users where CountryID = ".$country;
		$query = mysql_query($sql);
		if(!$query)
			return 0;
		else{
			$row = mysql_fetch_array($query);
			return $row['Total'];
			}
		}
	}
if(!function_exists('getAllCountries')){
	function getAllCountries(){
		$sql = "SELECT b.Country, Count(UserID) AS Total FROM ".$GLOBALS['table_prefix']."users AS a LEFT JOIN ".$GLOBALS['table_prefix']."countries AS b ON a.CountryID = b.CountryID GROUP BY b.Country ORDER BY Total desc";
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('getAgeGroups')){
	function getAgeGroups(){
		$sql = "SELECT Age, COUNT(UserID) AS Total FROM ".$GLOBALS['table_prefix']."users GROUP BY Age ORDER BY Total desc";
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('getEducationGroups')){
	function getEducationGroups(){
		$sql = "SELECT b.".$_SESSION['lang']."Education as LEducation, Count(UserID) AS Total FROM ".$GLOBALS['table_prefix']."users AS a LEFT JOIN ".$GLOBALS['table_prefix']."educations AS b ON a.EducationID = b.EducationID GROUP BY a.EducationID ORDER BY Total desc";
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('getGenderGroups')){
	function getGenderGroups(){
		$sql = "SELECT b.".$_SESSION['lang']."Gender as LGender, Count(UserID) AS Total FROM ".$GLOBALS['table_prefix']."users AS a LEFT JOIN ".$GLOBALS['table_prefix']."gender AS b ON a.GenderID = b.GenderID GROUP BY a.GenderID ORDER BY Total desc";
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('removeOldMess')){
	function removeOldMess($curdate=''){
		$sql = "delete from ".$GLOBALS['table_prefix']."messages where DATE_FORMAT( SentOn,'%Y-%m-%d') <= '".$curdate."'";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('removeOldSignals')){
	function removeOldSignals($curdate=''){
		$sql = "delete from ".$GLOBALS['table_prefix']."signalme where DATE_FORMAT( SignalDate,'%Y-%m-%d') <= '".$curdate."'";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('removeInactiveUsers')){
	function removeInactiveUsers($curdate=''){
		$arrayid=array();
		$idsql = "select UserID from ".$GLOBALS['table_prefix']."users where ProfileStatusID = 3 and DATE_FORMAT( LastLogon,'%Y-%m-%d') <= '".$curdate."'";
		$idqry = mysql_query($idsql);
		if(!$idqry)
			return false;
		elseif(mysql_num_rows($idqry)>0){
			while($rows=mysql_fetch_array($idqry))
				array_push($arrayid, $rows['UserID']);
			}
		if(count($arrayid)>0){
			foreach($arrayid as $varrayid)
				removeProfiles($varrayid);
			}
		return true;
		}
	}
if(!function_exists('getInactiveImgs')){
	function getInactiveImgs($curdate=''){
		$result = array();
		$sql = "select PhotoID, UserID, PhotoExtension from ".$GLOBALS['table_prefix']."photos where UserID in (select UserID from ".$GLOBALS['table_prefix']."users where ProfileStatusID = 3 DATE_FORMAT( LastLogon,'%Y-%m-%d') <= '".$curdate."')";
		$query = mysql_query($sql);
		if(!$query)
			return $result;
		elseif(mysql_num_rows($query)>0){
			while($rows=mysql_fetch_array($query)){
				$result[] = $rows['UserID'].'u'.$rows['PhotoID'].'.'.$rows['PhotoExtension'];
				}
			return $result;
			}
		else return $result;
		}
	}
if(!function_exists('removeMessDeleted')){
	function removeMessDeleted(){
		$sql = "delete from ".$GLOBALS['table_prefix']."messages where RecieverStatusID = 1 and SenderStatusID = 1";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('get_browser_')){
	function get_browser_($user_agent){
		return $_SERVER['HTTP_USER_AGENT'];
		}
	}
if(!function_exists('getListBanned')){
	function getListBanned(){
		$sql = "SELECT ba.Id, Reason, BanedOn, ".$_SESSION['lang']."LiftBan as LLiftBan, ProfileName, Email, LastLogon FROM ".$GLOBALS['table_prefix']."bannedusers as ba left join ".$GLOBALS['table_prefix']."liftbaned as lb on ba.LiftBanId = lb.Id left join ".$GLOBALS['table_prefix']."users AS a on ba.UserId = a.UserID ORDER BY BanedOn desc";
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('unBanned')){
	function unBanned($data=array()){
		$sql = "delete from ".$GLOBALS['table_prefix']."bannedusers where Id in (".implode(',', $data).")";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('addNewValue')){
	function addNewValue($data=array(),$table=''){
		$field = '';
		$vals = '';
		foreach($data as $name => $val){
			$field .= $name.', ';
			$vals .= $val.', ';
			}
		$sql = "insert into ".$table." ( ".substr($field, 0, -2)." ) values (".substr($vals, 0, -2).")";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('updValues')){
	function updValues($data=array(), $table='', $con=''){
		$set = '';
		foreach($data as $name => $val)
			$set .= $name.' = '.$val.', ';
		$sql = "update ".$table." set ".substr($set, 0, -2)." where ".$con;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('delValue')){
	function delValue($data='', $table=''){
		$sql = "delete from ".$table." where ".$data;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('getListed')){
	function getListed($field=array(), $table=array()){
		$sel = '';
		foreach($field as $field => $val)
			$sel .= $field.' as '.$val.', ';
		$sql = "select ".substr($sel, 0, -2)." from ".$table[0]." order by ".$table[1]." desc";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return $query;
		}
	}
if(!function_exists('getListCountries')){
	function getListCountries($str='', $limit=''){
		$sql = "SELECT CountryID as Id, Country as L1Value from ".$GLOBALS['table_prefix']."countries ".$str." order by CountryID desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('getListState')){
	function getListState($str='', $limit=''){
		$sql = "SELECT StateID as Id, State as L1Value, s.CountryID as L3Value, Country as L4Value from ".$GLOBALS['table_prefix']."states as s inner join ".$GLOBALS['table_prefix']."countries as c on c.CountryID = s.CountryID ".$str." order by StateID desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('removeAccountNoComplete')){
	function removeAccountNoComplete($curdate=''){
		$sql = "delete from ".$GLOBALS['table_prefix']."users where ProfileStatusID = 0 and date_format(DatePosted, '%Y-%m-%d') <= '".$curdate."'";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('getUserID')){
	function getUserID(){
		$sql = "select UserID from ".$GLOBALS['table_prefix']."users where ProfileStatusID = 1";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return $query;
		}
	}
if(!function_exists('getInfoMatch')){
	function getInfoMatch($userid=0){
		$sql = "select Email, MatchAgeFrom, MatchAgeTO, MatchGenderID, MatchHeightIDFrom, MatchHeightIDTo, MatchBodyStyleID, MatchReligionID, MatchEducationID, MatchSmokingID, MatchDrinkingID, MatchMaritalStatusID, MatchBeSameLocation, CountryID, DatingInterestID from ".$GLOBALS['table_prefix']."users where UserID = ".$userid;
		$query = mysql_query($sql);
		return mysql_fetch_array($query);
		}
	}
if(!function_exists('countMatchProfile')){
	function countMatchProfile($userid=0, $str=''){
		$sql = "select UserID from ".$GLOBALS['table_prefix']."users as u where ".$str." ProfileStatusID = 1";
		$query = mysql_query($sql);
		if(!$query)
			return 0;
		elseif(mysql_num_rows($query)>0){
			$row = mysql_fetch_array($query);
			return $row['Total'];
			}
		else return 0;
		}
	}
if(!function_exists('getAllPages')){
	function getAllPages(){
		$sql = "SELECT Id, PageName, PageBody, LastUpdated, IsActive from ".$GLOBALS['table_prefix']."pages";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return $query;
		}
	}
if(!function_exists('FillterEmail')){
	function FillterEmail($data=array()){
		$sql = "insert into ".$GLOBALS['table_prefix']."filteremails (EmailAddress, BanEmail, BanDomain, BanDate, ReasonBaned) values ('".$data[0]."', ".$data[1].", ".$data[2].", '".$data[3]."', '".$data[4]."')";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('getListCrads')){
	function getListCrads($str='', $limit=''){
		$sql = "SELECT s.Id, CardName, IsText, ViewFormat, NameCate, CardCate from ".$GLOBALS['table_prefix']."greetingcards as s inner join ".$GLOBALS['table_prefix']."cards_categories as c on c.Id = s.CardCate ".$str." order by s.Id desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return $query;
		}
	}
if(!function_exists('getListAbuse')){
	function getListAbuse($str='', $limit=''){
		$sql = "select DISTINCT ProfileId, ProfileName, Email, LastLogon from ".$GLOBALS['table_prefix']."abuseprofiles as a inner join ".$GLOBALS['table_prefix']."users as u on a.ProfileId = u.UserID where IsProcess = 0 order by ReprotDate desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return $query;
		}
	}
if(!function_exists('getReportBy')){
	function getReportBy($user=0){
		$str = '';
		$sql = "select ReportBy from ".$GLOBALS['table_prefix']."abuseprofiles where ProfileId = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		elseif(mysql_num_rows($query)>0){
			while($row=mysql_fetch_array($query))
				$str .= $row['ReportBy'].'<br>';
			}
		return $str;
		}
	}
if(!function_exists('getReportDate')){
	function getReportDate($user=0){
		$str = '';
		$sql = "select ReprotDate from ".$GLOBALS['table_prefix']."abuseprofiles where ProfileId = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		elseif(mysql_num_rows($query)>0){
			while($row=mysql_fetch_array($query))
				$str .= $row['ReprotDate'].'<br>';
			}
		return $str;
		}
	}
if(!function_exists('getReportReason')){
	function getReportReason($user=0){
		$str = '';
		$sql = "select Reason from ".$GLOBALS['table_prefix']."abuseprofiles where ProfileId = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		elseif(mysql_num_rows($query)>0){
			while($row=mysql_fetch_array($query))
				$str .= '+ '.$row['Reason'].'<br>';
			}
		return $str;
		}
	}
if(!function_exists('unReport')){
	function unReport($data=array()){
		$sql = "delete from ".$GLOBALS['table_prefix']."abuseprofiles where ProfileId in(".implode(',', $data).")";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('getListFlirt')){
	function getListFlirt($str='', $limit=''){
		$sql = "SELECT f.Id, FilrtValue as L1Value, f.CateId as L3Value, NameCate as L4Value from ".$GLOBALS['table_prefix']."flirts as f inner join ".$GLOBALS['table_prefix']."flirt_categories as c on c.Id = f.CateId ".$str." order by f.Id desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}
if(!function_exists('getThemes')){
	function getThemes($id=0){
		if($id>0)
			$sql = "select t.Id, count(ThemeId) as numof, ThemeName, FileView, SourceName, IsActive from ".$GLOBALS['table_prefix']."themes as t left join ".$GLOBALS['table_prefix']."users as u on t.Id = u.ThemeId where Id = ".$id;
		else $sql = "select Id, (select count(UserID) from ".$GLOBALS['table_prefix']."users where ThemeId = ".$GLOBALS['table_prefix']."themes.Id) as numof, ThemeName, FileView, SourceName, IsActive from ".$GLOBALS['table_prefix']."themes order by numof desc";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return $query;
		}
	}
if(!function_exists('getListPrices')){
	function getListPrices($str='', $limit=''){
		$sql = "SELECT Id, Prices as L1Value, Block as L2Value from ".$GLOBALS['table_prefix']."prices order by Id desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return '';
		else return $query;
		}
	}