<?php
require_once "../../includes/config.php";
require_once "../../includes/database.php";
?>
<html>
<head>
<title>HTML Frames Example - Menu 1</title>
<style type="text/css">
a{
	text-decoration:none; color:#3b5998;
	}
body {
    background: -webkit-linear-gradient(#3b5998, #FFFFFF);
    background: -moz-linear-gradient(#3b5998, #FFFFFF);
    background: -ms-linear-gradient(#3b5998, #FFFFFF);
    background: -o-linear-gradient(#3b5998, #FFFFFF);
    background: linear-gradient(#3b5998, #FFFFFF);
	background-repeat:no-repeat;
	}
.maintitle{
	margin-left:5px; padding:3px 0px 3px 20px; width:190px; margin-bottom:0px; border:1px solid #CCC; background:url(../../imgs/arrowd.png) #546ea5 no-repeat 3px 5px; color:#FFF; cursor:pointer
	}
.maintitleclose{
	margin-left:5px; padding:3px 0px 3px 20px; width:190px; margin-bottom:0px; border:1px solid #CCC; background:url(../../imgs/arrowo.png) #546ea5 no-repeat 3px 5px; color:#FFF; cursor:pointer
	}
ul{
	margin:0px; padding:0px;
	}
ul li{
	list-style-type:none; width:190px; padding:2px 0px 2px 20px; margin-left:5px; border-left:1px solid #CCC; border-right:1px solid #CCC; border-bottom:1px solid #CCC; background:#FFF;
	}
ul li:hover, ul li.current{
	list-style-type:none; width:190px; padding:2px 0px 2px 20px; margin-left:5px; border-left:1px solid #CCC; border-right:1px solid #CCC; border-bottom:1px solid #CCC; background:url(../../imgs/b.png) #ebeef4 no-repeat 100% 7px;
	}
</style>
<script language="javascript" type="text/javascript">
function closemenu(str1,str2,str3,intval){
	if(intval==1){
		document.getElementById(str1).style.display = 'block';
		document.getElementById(str2).style.display = 'none';
		document.getElementById(str3).style.display = 'block';
		}
	else if(intval==0){
		document.getElementById(str1).style.display = 'none';
		document.getElementById(str2).style.display = 'block';
		document.getElementById(str3).style.display = 'none';
		}
	}
function chgClass(str1){
	var temparr = str1.split('_');
	for(var j=1; j<document.getElementsByTagName('li').length + 1; j++){
		if(j==temparr[1])
			document.getElementById('link_'+j).className = 'current';
		else document.getElementById('link_'+j).className = '';
		}
	}
</script>
</head>
<body>
<p align="center"><a href="../" target="_top">
	<img src="../../<?php echo 'fuploads/'.$logo;?>" border="0" style="width:284px; height:64px;"></a>
</p>
<h4 class="maintitle" id="maintitle1" onClick="closemenu('maintitle1', 'maintitleclose1', 'submenu1', 0)" style="display:none">Report</h4>
<h4 class="maintitleclose" id="maintitleclose1" onClick="closemenu('maintitle1', 'maintitleclose1', 'submenu1', 1)" title="expand group">Report</h4>
<ul id="submenu1" style="display:none">
	<a href="../todaytraffic.php" target="content"><li id="link_1" onClick="chgClass('link_1')">Today Traffic</li></a>
    <a href="../sitetraffic.php" target="content"><li id="link_2" onClick="chgClass('link_2')">Site Statistics</li></a>
    <a href="../abuse.php" target="content"><li onClick="chgClass('link_3')" id="link_3">Users abuse</li></a>
</ul>
<h4 class="maintitle" id="maintitle2" onClick="closemenu('maintitle2', 'maintitleclose2', 'submenu2', 0)" style="display:none">Utilities</h4>
<h4 class="maintitleclose" id="maintitleclose2" onClick="closemenu('maintitle2', 'maintitleclose2', 'submenu2', 1)" title="expand group">Utilities</h4>
<ul id="submenu2" style="display:none">
	<a href="../listbanned.php" target="content"><li id="link_4" onClick="chgClass('link_4')">Banned users</li></a>
    <a href="../cleanup.php" target="content"><li id="link_5" onClick="chgClass('link_5')">Clean up</li></a>
    <a href="../backupdb.php" target="content"><li id="link_6" onClick="chgClass('link_6')">Backup database</li></a>
    <a href="../emailmatches.php" target="content"><li id="link_7" onClick="chgClass('link_7')">Email potential matches</li></a>
</ul>
<h4 class="maintitle" id="maintitle3" onClick="closemenu('maintitle3', 'maintitleclose3', 'submenu3', 0)" style="display:none">User Admin</h4>
<h4 class="maintitleclose" id="maintitleclose3" onClick="closemenu('maintitle3', 'maintitleclose3', 'submenu3', 1)" title="expand group">User Admin</h4>
<ul id="submenu3" style="display:none">
    <a href="../approveprofile.php" target="content"><li id="link_8" onClick="chgClass('link_8')">Approve profiles</li></a>
    <a href="../approvephotos.php" target="content"><li id="link_9" onClick="chgClass('link_9')">Approve photos</li></a>
    <a href="../approvemessages.php" target="content"><li id="link_10" onClick="chgClass('link_10')">Approve messages</li></a>
    <a href="../photosmanage.php" target="content"><li id="link_11" onClick="chgClass('link_11')">Photos management</li></a>
    <a href="../usersmanage.php" target="content"><li id="link_12" onClick="chgClass('link_12')">Users management</li></a>
</ul>
<h4 class="maintitle" id="maintitle4" onClick="closemenu('maintitle4', 'maintitleclose4', 'submenu4', 0)" style="display:none">Options</h4>
<h4 class="maintitleclose" id="maintitleclose4" onClick="closemenu('maintitle4', 'maintitleclose4', 'submenu4', 1)" title="expand group">Options</h4>
<ul id="submenu4" style="display:none">
	<a href="../bodytypes.php" target="content"><li id="link_13" onClick="chgClass('link_13')">Body types</li></a>
    <a href="../country.php" target="content"><li id="link_14" onClick="chgClass('link_14')">Countries</li></a>
    <a href="../datinginterest.php" target="content"><li id="link_15" onClick="chgClass('link_15')">Dating interest</li></a>
    <a href="../drinking.php" target="content"><li id="link_16" onClick="chgClass('link_16')">Drinking</li></a>
    <a href="../educations.php" target="content"><li id="link_17" onClick="chgClass('link_17')">Educations</li></a>
    <a href="../eyescolors.php" target="content"><li id="link_18" onClick="chgClass('link_18')">Eyes colors</li></a>
    <a href="../gender.php" target="content"><li id="link_19" onClick="chgClass('link_19')">Genders</li></a>
    <a href="../haircolors.php" target="content"><li id="link_20" onClick="chgClass('link_20')">Hair colors</li></a>
    <a href="../height.php" target="content"><li id="link_21" onClick="chgClass('link_21')">Height</li></a>
    <a href="../liftbaned.php" target="content"><li id="link_22" onClick="chgClass('link_22')">Lift ban</li></a>
    <a href="../maritalstatus.php" target="content"><li id="link_23" onClick="chgClass('link_23')">Marital status</li></a>
    <a href="../notifyemail.php" target="content"><li id="link_24" onClick="chgClass('link_24')">Notify email</li></a>
    <a href="../profilestatus.php" target="content"><li id="link_25" onClick="chgClass('link_25')">Profile status</li></a>
    <a href="../religions.php" target="content"><li id="link_26" onClick="chgClass('link_26')">Religions</li></a>
    <a href="../smoking.php" target="content"><li id="link_27" onClick="chgClass('link_27')">Smoking</li></a>
    <a href="../states.php" target="content"><li id="link_28" onClick="chgClass('link_28')">States</li></a>
    <a href="../flirtcate.php" target="content"><li id="link_29" onClick="chgClass('link_29')">Flirt categories</li></a>
    <a href="../flirt.php" target="content"><li id="link_30" onClick="chgClass('link_30')">Flirts</li></a>
    <a href="../catecard.php" target="content"><li id="link_31" onClick="chgClass('link_31')">Categories ecard</li></a>
    <a href="../greetingcard.php" target="content"><li id="link_32" onClick="chgClass('link_32')">Greeting cards</li></a>
    <a href="../editprice.php" target="content"><li id="link_33" onClick="chgClass('link_33')">Price service</li></a>
</ul>
<h4 class="maintitle" id="maintitle5" onClick="closemenu('maintitle5', 'maintitleclose5', 'submenu5', 0)" style="display:none">Pages</h4>
<h4 class="maintitleclose" id="maintitleclose5" onClick="closemenu('maintitle5', 'maintitleclose5', 'submenu5', 1)" title="expand group">Pages</h4>
<ul id="submenu5" style="display:none">
	<a href="../managepage.php" target="content"><li id="link_34" onClick="chgClass('link_34')">Manage pages</li></a>
    <a href="../managetheme.php" target="content"><li id="link_35" onClick="chgClass('link_35')">Manage themes</li></a>
</ul>
<h4 class="maintitle" id="maintitle6" onClick="closemenu('maintitle6', 'maintitleclose6', 'submenu6', 0)" style="display:none">Settings</h4>
<h4 class="maintitleclose" id="maintitleclose6" onClick="closemenu('maintitle6', 'maintitleclose6', 'submenu6', 1)" title="expand group">Settings</h4>
<ul id="submenu6" style="display:none">
	<a href="../changepass.php" target="content"><li id="link_36" onClick="chgClass('link_36')">Account settings</li></a>
    <a href="../siteseting.php" target="content"><li id="link_37" onClick="chgClass('link_37')">Site settings</li></a>
    <a href="../paymentseting.php" target="content"><li id="link_38" onClick="chgClass('link_38')">Payment settings</li></a>
</ul>
<a target="_top" href="../signout.php"><h4 class="maintitleclose" id="maintitleclose7" title="Sign out">Sign Out</h4></a>
<br>&nbsp;
</body>
</html>