<p class="linehead">&nbsp;</p>
   </div>
   <div id="footer">
   		<p style="margin-bottom:3px"><?php echo stripslashes(html_entity_decode($strfoot)); mysql_close();?></p>
   </div>
</body>
</html>