<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/todaytraffic.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
$title = 'AdminCP - Today Traffic';
require_once 'include/header.php';
$date = date('y-m-d');
$newdate = strtotime ( '-1 day' , strtotime ( $date ) ) ;
$newdate = date ( 'Y-m-d' , $newdate );
?>
<div class="admincontent">
	<p class="contentop">Today Traffic</p>
    <div class="contenbody">
    	<form action="" method="post">
        <div style="width:20%; float:left;">
        	<h4 align="center" style="margin-bottom:3px; padding-bottom:3px">Daily Registration</h4>
            <table width="99%" border="0" cellpadding="0" cellspacing="0">
            	<tr bgcolor="#f2f2f2">
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Time</td>
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center"><b>Total</b></td>
                </tr>
                <?php
				$reg = getRegToday($newdate);
				if(mysql_num_rows($reg)>0){
					while($rows=mysql_fetch_array($reg)){
						?>
                        <tr>
                            <td width="50%" style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['TheDate'];?></td>
                            <td width="50%" style="border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['Total'];?></td>
                        </tr>
                        <?php
						}
					}
				else echo '<tr><td style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:1px 0px" align="center" colspan="2">0</td></tr>';
				?>
            </table>
        </div>
        <div style="width:20%; float:left">
        	<h4 align="center" style="margin-bottom:3px; padding-bottom:3px">Today's Login</h4>
            <table width="99%" border="0" cellpadding="0" cellspacing="0">
            	<tr bgcolor="#f2f2f2">
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Time</td>
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Total</td>
                </tr>
                <?php
				$log = getLoginToday($newdate);
				if(mysql_num_rows($log)>0){
					while($rows=mysql_fetch_array($log)){
						?>
                        <tr>
                            <td width="50%" style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['TheDate'];?></td>
                            <td width="50%" style="border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['Total'];?></td>
                        </tr>
                        <?php
						}
					}
				else echo '<tr><td style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:1px 0px" align="center" colspan="2">0</td></tr>';
				?>
            </table>
        </div>
        <div style="width:20%; float:left">
        	<h4 align="center" style="margin-bottom:3px; padding-bottom:3px">Total Messages Posted</h4>
            <table width="99%" border="0" cellpadding="0" cellspacing="0">
            	<tr bgcolor="#f2f2f2">
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Time</td>
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Total</td>
                </tr>
                <?php
				$sent = getSentMessToday($newdate);
				if(mysql_num_rows($sent)>0){
					while($rows=mysql_fetch_array($sent)){
						?>
                        <tr>
                            <td width="50%" style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['TheDate'];?></td>
                            <td width="50%" style="border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['Total'];?></td>
                        </tr>
                        <?php
						}
					}
				else echo '<tr><td style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:1px 0px" align="center" colspan="2">0</td></tr>';
				?>
            </table>
        </div>
        <div style="width:20%; float:left">
        	<h4 align="center" style="margin-bottom:3px; padding-bottom:3px">Total Signals Sent</h4>
            <table width="99%" border="0" cellpadding="0" cellspacing="0">
            	<tr bgcolor="#f2f2f2">
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Time</td>
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Total</td>
                </tr>
                <?php
				$sig = getSignalToday($newdate);
				if(mysql_num_rows($sig)>0){
					while($rows=mysql_fetch_array($sig)){
						?>
                        <tr>
                            <td width="50%" style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['TheDate'];?></td>
                            <td width="50%" style="border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['Total'];?></td>
                        </tr>
                        <?php
						}
					}
				else echo '<tr><td style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:1px 0px" align="center" colspan="2">0</td></tr>';
				?>
            </table>
        </div>
        <div style="width:20%; float:left">
        	<h4 align="center" style="margin-bottom:3px; padding-bottom:3px">Total Photos Posted</h4>
            <table width="99%" border="0" cellpadding="0" cellspacing="0">
            	<tr bgcolor="#f2f2f2">
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Time</td>
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Total</td>
                </tr>
                <?php
				$pho = getPhotosToday($newdate);
				if(mysql_num_rows($pho)>0){
					while($rows=mysql_fetch_array($pho)){
						?>
                        <tr>
                            <td width="50%" style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['TheDate'];?></td>
                            <td width="50%" style="border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['Total'];?></td>
                        </tr>
                        <?php
						}
					}
				else echo '<tr><td style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:1px 0px" align="center" colspan="2">0</td></tr>';	
				?>
            </table>
        </div>
        <p style="clear:both">&nbsp;</p>
        </form>
    </div><p style="clear:both">&nbsp;</p>
</div>