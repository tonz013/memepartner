<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/managepage.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
$dipadd = 'style="display:none"';
$dipedit = 'style="display:none"';
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smcancel'])){
	mysql_close();
	header('Location: '.$base_url.'admincp/managepage.php');
	exit();
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smadd'])){
	if(empty($_POST['pagename'])){
		$err_e = 'Please enter page name';
		$dipadd = '';
		$dipedit = 'style="display:none"';
		}
	elseif(empty($_POST['bodyadd'])){
		$err_v = 'Please enter content page';
		$dipadd = '';
		$dipedit = 'style="display:none"';
		}
	else{
		$isactive = $_POST['isactive']=='on'?1:0;
		if(!addNewValue(array('PageName' => "'".mysql_real_escape_string($_POST['pagename'])."'", 'PageBody' => "'".mysql_real_escape_string($_POST['bodyadd'])."'", 'LastUpdated'=>"'".date('Y-m-d H:i:s')."'", 'IsActive'=>$isactive), $table_prefix.'pages')){
			$error = $errordata;
			$dipadd = '';
			$dipedit = 'style="display:none"';
			}
		else{
			mysql_close();
			header('Location: '.$base_url.'admincp/managepage.php');
			exit();
			}
		}
	}
if(isset($_GET['id']) && intval($_GET['id'])>0 && isset($_GET['a']) && $_GET['a']=='d'){
	if(!delValue('BodyTypeID = '.intval($_GET['id']), $table_prefix.'bodytypes'))
		$error = $errordata;
	else{
		mysql_close();
		header('Location: '.$base_url.'admincp/managepage.php');
		exit();
		}
	}
$title = 'AdminCP - Manage pages';
require_once 'include/header.php';
?>
<link rel="stylesheet" href="ext/jquery.wysiwyg.css" type="text/css" />
  <script type="text/javascript" src="ext/jquery-1.3.2.js"></script>
  <script type="text/javascript" src="ext/jquery.wysiwyg.js"></script>
  <script type="text/javascript">
  $(function()
  {
      $('#bodyadd').wysiwyg();
  });
  function editPage(valchange){
	document.getElementById('frmnew').style.display='none';
	document.getElementById('frmEdit').style.display='';
	$('#frmEdit').load('editpage.php?pi=' + valchange);
	}
  </script>
<div class="admincontent">
	<p class="contentop">Manage pages</p>
    <div class="contenbody">
    	<div style="width:40%; float:left">
    	
    	<?php
		if(isset($error) && !empty($error))
			echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
		$list = getAllPages();
		?>
        <table width="100%" border="0" cellpadding="0" cellspacing="0">
        	<tr bgcolor="#f2f2f2">
            	<td width="2%" class="headrows1" style="border-top:1px solid #d6d8e5">No.</td>
                <td width="53%" class="headrows2" style="border-top:1px solid #d6d8e5">Page Name</td>
                <td width="33%" class="headrows2" style="border-top:1px solid #d6d8e5">Last updated</td>
                <td width="12%" class="headrows2" style="border-top:1px solid #d6d8e5; border-right:1px solid #d6d8e5">Actions</td>
            </tr>
            <?php
			if(mysql_num_rows($list)>0){
				$i=1;
				while($rows=mysql_fetch_array($list)){
					?>
					<tr>
						<td width="2%" class="headrows3" valign="top"><?php echo $i;?></td>
						<td width="43%" class="headrows4" align="left"><?php echo $rows['PageName'];?></td>
						<td width="43%" class="headrows4" align="left"><?php echo $rows['LastUpdated'];?></td>
						<td width="12%" class="headrows4" align="center" style="border-right:1px solid #d6d8e5"><a href="editpage.php?pi=<?php echo $rows['Id'];?>"><i>Edit</i></a></td>
					</tr>
					<?php
					$i++;
					}
				}
			else echo '<tr><td width="20%" colspan="5" align="left"><p>'.$norecord.' !!</p></td></tr>';
			?>
            <tr>
            	<td width="20%" style="padding:20px" colspan="4" align="center"><input type="button" name="smadnew" class="massbutton" value="Add new" onclick="adclkActions(0,'','',2)" /></td>
            </tr>
        </table>
        </div>
        <div style="width:58%; float:right">
        	<span id="frmEdit" <?php echo $dipedit;?>>
            </span>
            <span id="frmnew" <?php echo $dipadd;?>>
        	<h4>Add New Page</h4>
            <form action="" method="post">
            <table width="100%" cellpadding="3" cellspacing="3">
            	<tr>
                	<td width="15%" align="right" valign="top">Page name:</td>
                    <td width="85%" align="left"><input type="text" size="40" id="pagename" name="pagename" value="<?php echo isset($_POST['pagename'])?$_POST['pagename']:'';?>" />
                    <?php
					if(isset($err_e) && !empty($err_e))
						echo '<br><small><font color="#FF0000"><i>'.$err_e.'</i></font></small>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="15%" align="right" valign="top">Page body:</td>
                    <td width="85%" align="left"><textarea cols="65" rows="15" id="bodyadd" name="bodyadd"><?php echo isset($_POST['bodyadd'])?$_POST['bodyadd']:'';?></textarea>
                    <?php
					if(isset($err_v) && !empty($err_v))
						echo '<br><small><font color="#FF0000"><i>'.$err_v.'</i></font></small>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="15%" align="right" valign="top">&nbsp;</td>
                    <td width="85%" align="left"><input type="checkbox" style="margin-left:0px; padding-left:0px;" name="isactive"/>Active</td>
                </tr>
                <tr>
                	<td width="15%" align="right">&nbsp;</td>
                    <td width="85%" align="left"><input type="submit" name="smadd" class="massbutton" value="Add" />&nbsp;<input type="submit" name="smcancel" class="massbutton" value="Cancel" /></td>
                </tr>
            </table>
            </form>
            </span>
        </div>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>