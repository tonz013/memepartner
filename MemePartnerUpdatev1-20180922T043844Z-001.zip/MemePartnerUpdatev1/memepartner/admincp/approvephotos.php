<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/approvephotos.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smappimgs'])){
	$app = false;
	$rmv = array();
	for($j=0; $j<$_POST['total']; $j++){
		if($_POST['proapp'.$j]==3){// accept images <=> accept profile + accept images
			$app = true;
			if(!approveImages(array($_POST['img'.$j]), $_POST['newm'.$j])){
				$error = $errordata;
				$app = false;
				break;
				}
			}
		elseif($_POST['proapp'.$j]==4){// remove images <=> accept profile + remove images
			if(!removeImages(array($_POST['img'.$j]), $_POST['newm'.$j])){
				$error = $errordata;
				break;
				}
			else{ 
				$app = true;
				array_push($rmv, $_POST['newm'.$j].'u'.$_POST['img'.$j].'.'.$_POST['ext'.$j]);
				$subj = 'Upload photos '.$sitename;
				$mess = 'Hi <i>'.$_POST['mail'.$j].'</i> ,<br>Your picture has been removed for violating the rules posted on '.$sitename.'<br><br>Rules posted image:<br><p>'.$rulesupload1.'</p><p>'.$rulesupload2.'</p><p>'.$rulesupload3.'</p><p>'.$rulesupload4.'</p>';
				if(!mail($_POST['mail'.$j], '=?UTF-8?B?'.base64_encode($subj).'?=', $mess, "Content-Type: text/html; charset=utf-8\r\n"."From: ".$sitename)){
					$error = 'Can not send email !';
					$app = false;
					}
				}
			}
		}
	if(count($rmv)>0){
		foreach($rmv as $vrmv)
			unlink(dirname(dirname(__FILE__)).'/'.$uploaddir.'/'.$vrmv);
		}
	if($app){
		mysql_close();
		header('Location: '.$base_url.'admincp/approvephotos.php');
		exit();
		}
	}
$title = 'AdminCP - Approve Photos';
require_once 'include/header.php';
?>
<div class="admincontent">
	<p class="contentop">Approve Photos</p>
    <div class="contenbody">
    	<form action="" method="post">
    	<?php
		if(isset($error) && !empty($error))
			echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
		$list = getProfilesImgs('limit 20');
		if(count($list)>0){
		?>
        <table width="100%" border="0" cellpadding="0" cellspacing="0">
        	<tr bgcolor="#f2f2f2">
            	<td width="20%" class="headrows1">Photo</td>
                <td width="44%" class="headrows2">Profile</td>
                <td width="4%" class="headrows2" align="center">IsVIP</td>
                <td width="8%" class="headrows2" align="center">App Photo</td>
                <td width="8%" class="headrows2" align="center">Del Photo</td>
                <td width="8%" class="headrows2" align="center">App Profile</td>
                <td width="8%" class="headrows2" align="center">Del Profile</td>
            </tr>
            <?php
			$i=0;
			foreach($list['UserID'] as $vlist){
				$img = '<img src="'.$base_url.$uploaddir.'/'.$vlist.'u'.$list['PhotoID'][$i].'.'.$list['PhotoExtension'][$i].'" border="0" style="width:210px; height:260px;"/>';
				$acity = (empty($list['City'][$i]))?$list['State'][$i].', '.$list['Country'][$i]:$list['City'][$i].', '.$list['State'][$i].', '.$list['Country'][$i];
				?>
                <tr>
                    <td width="20%" class="headrows3" valign="top"><?php echo $img;?></td>
                    <td width="44%" class="headrows4" valign="top">
                        <p class="frstop"><b>Profile name:</b> <?php echo $list['ProfileName'][$i];?></p>
                        <p><b>Gender:</b> <?php echo $list['LGender'][$i];?></p>
                        <p><b>Address:</b> <?php echo $acity;?></p>
                        <p><b>Email:</b> <?php echo $list['Email'][$i];?></p>
                        <input type="hidden" value="<?php echo $vlist;?>" name="newm<?php echo $i;?>" />
                        <input type="hidden" value="<?php echo $list['PhotoID'][$i];?>" name="img<?php echo $i;?>" />
                        <input type="hidden" value="<?php echo $list['PhotoExtension'][$i];?>" name="ext<?php echo $i;?>" />
                        <input type="hidden" value="<?php echo $list['Email'][$i];?>" name="mail<?php echo $i;?>" />
                    </td>
                    <td width="4%" class="headrows4" align="center"><input type="checkbox" disabled="disabled" /></td>
                    <td width="8%" class="headrows4" align="center">
                    	<?php if(!empty($img)) echo '<input type="radio" name="proapp'.$i.'" value="3"/>';?>
                    </td>
                    <td width="8%" class="headrows4" align="center"><?php if(!empty($img)) echo '<input type="radio" name="proapp'.$i.'" value="4"/>';?></td>
                    <td width="8%" class="headrows4" align="center">&nbsp;</td>
                    <td width="8%" class="headrows4" align="center">&nbsp;</td>
                </tr>
                <?php
				$i++;
				}
			?>
            <tr>
            	<td width="20%" style="padding:20px" colspan="7" align="center"><input type="submit" name="smappimgs" class="massbutton" /><input type="hidden" value="<?php echo $i;?>" name="total" /></td>
            </tr>
        </table>
        <?php }
		else echo '<p style="padding:10px;">There are no photos !</p>';
		?>
        </form>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>