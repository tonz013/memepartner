<?php
set_time_limit(0);
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smsentmail'])){
	$listuser = getUserID();
	if(!$listuser)
		$error = 'Data error !';
	elseif(mysql_num_rows($listuser)>0){
		while($rows=mysql_fetch_array($listuser)){
			$match = getInfoMatch($rows['UserID']);
			$strsql = '';
			if($match['MatchAgeTO']>$match['MatchAgeFrom'])
				$strsql .= 'Age >= '.$match['MatchAgeFrom'].' and Age <= '.$match['MatchAgeTO'].' and ';
			else $strsql .= 'Age >= '.$match['MatchAgeFrom'].' and ';
			if($match['MatchGenderID']>0)
				$strsql .= 'u.GenderID = '.$match['MatchGenderID'].' and ';
			if($match['MatchHeightIDTo']>$match['MatchHeightIDFrom'])
				$strsql .= '(HeightID >= '.$match['MatchHeightIDFrom'].' and HeightID <= '.$match['MatchHeightIDTo'].') and ';
			else $strsql .= 'HeightID >= '.$match['MatchHeightIDFrom'].' and ';
			if($match['MatchBodyStyleID']>0)
				$strsql .= 'u.BodyTypeID = '.$match['MatchBodyStyleID'].' and ';
			if($match['MatchReligionID']>0)
				$strsql .= 'u.ReligionID = '.$match['MatchReligionID'].' and ';
			if($match['MatchEducationID']>0)
				$strsql .= 'u.EducationID = '.$match['MatchEducationID'].' and ';
			if($match['MatchSmokingID']>0)
				$strsql .= 'u.SmokingID = '.$match['MatchSmokingID'].' and ';
			if($match['MatchDrinkingID']>0)
				$strsql .= 'u.DrinkingID = '.$match['MatchDrinkingID'].' and ';
			if($match['MatchMaritalStatusID']>0)
				$strsql .= 'u.MaritalStatusID = '.$match['MatchMaritalStatusID'].' and ';
			if($match['MatchBeSameLocation']==1)
				$strsql .= 'u.CountryID = '.$match['CountryID'].' and ';
			$total = countMatchProfile($rows['UserID'], $strsql);
			if($total>0){
				$smess = '<p>Please <a href="'.$base_url.'members/myaccount.php"><b>click here</b></a> to see all your matches !</p>';
				mail($match['Email'], '=?UTF-8?B?'.base64_encode($total.' profiles matches today').'?=', $smess, "Content-Type: text/html; charset=utf-8\r\n"."From: ".$sitename);
				}
			}
		}
	}
$listuser = getUserID();
require_once 'include/header.php';
?>
<div class="admincontent">
	<p class="contentop">Send email to user about them matchs</p>
    <div class="contenbody"><br /><form action="" method="post">
    	<p align="center">Total <b><?php echo mysql_num_rows($listuser);?></b> users need send email</p>
        
        <p align="center"><input type="submit" class="massbutton" name="smsentmail" value="Send Email"/></p></form>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>