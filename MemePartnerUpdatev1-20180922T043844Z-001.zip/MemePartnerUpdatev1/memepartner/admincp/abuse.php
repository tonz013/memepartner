<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/abuse.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smprocess'])){
	$unrp = array();
	for($j=1; $j<$_POST['hddtotal']; $j++){
		if($_POST['actions'.$j]==1){
			if(!BanUsers(array(intval($_POST['hddpro'.$j]), mysql_real_escape_string('Report abuse by other user !'), 7))){
				$error = $errordata.' 1';
				break;
				}
			else array_push($unrp, $_POST['hddpro'.$j]);
			}
		elseif($_POST['actions'.$j]==2){
			array_push($unrp, $_POST['hddpro'.$j]);
			}
		}
	if(count($unrp)>0){
		if(!unReport($unrp))
			$error = $errordata.' 2';
		else{
			mysql_close();
			header('Location: '.$base_url.'admincp/abuse.php');
			exit();
			}
		}
	}
require_once 'include/header.php';
?>
<div class="admincontent">
	<p class="contentop">Users abuse</p>
    <div class="contenbody">
    	<form action="" method="post">
    	<?php
		if(isset($error) && !empty($error))
			echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
		$config['showeachside'] = 4;
		$config['per_page'] = 20;
		$config['js_numrows_page'] = mysql_num_rows(getListAbuse('', ''));
		$config['curpage'] = empty($_GET['p'])?1:$_GET['p'];
		$config['rs_start'] = ($config['curpage']*$config['per_page'])-$config['per_page'];
		if($config['js_numrows_page'] < $config['per_page'])
			$config['per_page'] = $config['js_numrows_page'];
		$page = (isset($_GET['p']) && intval($_GET['p'])>0)?'&p='.$_GET['p']:'';
		$config['cururl'] = $base_url.'admincp/abuse.php'.$pstr;
		$rs_maxpage = ceil($config['js_numrows_page']/$config['per_page']);
		$paging = Pagination($config);
		$list = getListAbuse(''," limit ".$config['rs_start'].", ".$config['per_page']);
		if(mysql_num_rows($list)>0){
		?>
        <table width="100%" border="0" cellpadding="0" cellspacing="0">
        	<tr bgcolor="#f2f2f2">
            	<td width="3%" class="headrows1" style="border-top:1px solid #d6d8e5">No.</td>
                <td width="20%" class="headrows2" style="border-top:1px solid #d6d8e5">Profile / Email</td>
                <td width="17%" class="headrows2" style="border-top:1px solid #d6d8e5">Report by</td>
                <td width="13%" class="headrows2" align="center" style="border-top:1px solid #d6d8e5">Report date</td>
                <td width="24%" class="headrows2" align="center" style="border-top:1px solid #d6d8e5">Reason</td>
                <td width="13%" class="headrows2" align="center" style="border-top:1px solid #d6d8e5">Last Logon</td>
                <td width="4%" class="headrows2" align="center" style="border-top:1px solid #d6d8e5">Ban</td>
                <td width="6%" class="headrows2" align="center" style="border-top:1px solid #d6d8e5">UnReport</td>
            </tr>
            <?php
			$i=1;
			while($rows=mysql_fetch_array($list)){
				?>
                <tr>
                    <td width="3%" class="headrows3" valign="top"><?php echo $i;?></td>
                    <td width="20%" class="headrows4" valign="top"><?php echo '<a href="../viewprofile.php?id='.$rows['ProfileId'].'" target="_blank">'.$rows['ProfileName'].'</a><br>'.$rows['Email'];?></td>
                    <td width="17%" class="headrows4" align="left"><?php echo getReportBy($rows['ProfileId']);?></td>
                    <td width="13%" class="headrows4" align="center"><?php echo getReportDate($rows['ProfileId']);?></td>
                    <td width="24%" class="headrows4" align="left"><?php echo getReportReason($rows['ProfileId']);?></td>
                    <td width="13%" class="headrows4" align="center"><?php echo $rows['LastLogon'];?></td>
                    <td width="4%" class="headrows4" align="center"><input type="radio" name="actions<?php echo $i;?>" value="1" /><input type="hidden" name="hddpro<?php echo $i;?>" value="<?php echo $rows['ProfileId'];?>" /></td>
                    <td width="6%" class="headrows4" align="center"><input type="radio" name="actions<?php echo $i;?>" value="2" /></td>
                </tr>
                <?php
				$i++;
				}
			?><input type="hidden" name="hddtotal" value="<?php echo $i;?>" />
            <tr>
            	<td width="20%" style="padding:20px" colspan="7" align="center"><input type="submit" name="smprocess" class="massbutton" /></td>
            </tr>
        </table>
        <?php 
			if(isset($paging) && !empty($paging))
				echo '<p id="paging" style="clear:both; margin-right:0px; text-align:center">'.$paging.'</p>';
			}
		else echo '<p style="padding:10px;">'.$norecord.'</p>';
		?>
        </form>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>