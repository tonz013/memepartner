<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/managetheme.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
$dipadd = 'style="display:none"';
$dipedit = 'style="display:none"';
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smcancel'])){
	mysql_close();
	header('Location: '.$base_url.'admincp/managetheme.php');
	exit();
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smadd'])){
	$arrname = array();
	$file1 = fopen("../css/test.txt","w+");
	fwrite($file1,"test");
	fclose($file1);
	if(!$file1){
		$err = 1;
		array_push($arrname,'css');
		}
	else unlink(dirname(dirname(__FILE__))."/css/test.txt");
	$file2 = fopen("../imgs/test.txt","w+");
	fwrite($file2,"test");
	fclose($file2);
	if(!$file2){
		$err = 1;
		array_push($arrname,'imgs');
		}
	else unlink(dirname(dirname(__FILE__))."/imgs/test.txt");
	if(intval($err)==0){
		if(empty($_POST['themename'])){
			$err_n = 'Please enter the name theme';
			$dipadd = '';
			$dipedit = 'style="display:none"';
			}
		elseif(empty($_FILES['cssfile']['name'])){
			$err_c = 'Please select css file';
			$dipadd = '';
			$dipedit = 'style="display:none"';
			}
		elseif(empty($_FILES['imgfile']['name'])){
			$err_i = 'Please image to view';
			$dipadd = '';
			$dipedit = 'style="display:none"';
			}
		else{
			$active = ($_POST['chkactive']=='on')?1:0;
			$cssfile = $_FILES['cssfile']['name'];
			$imgview = $_FILES['imgfile']['name'];
			$extcss = pathinfo($_FILES['cssfile']['name']);
			$extcss = $extcss['extension'];
			$extview = pathinfo($_FILES['imgfile']['name']);
			$extview = $extview['extension'];
			if(strtolower($extcss)!='css'){
				$err_c = 'File invalid ! File type is .css';
				$dipadd = '';
				$dipedit = 'style="display:none"';
				}
			elseif(!in_array(strtolower($extview), $filetype)){
				$err_i = $filetypeinvalid.'. File format: '.implode(', ', $filetype);
				$dipadd = '';
				$dipedit = 'style="display:none"';
				}
			elseif(file_exists('../css/'.$_FILES['cssfile']['name'])){
				$err_c = 'File name is already in use';
				$dipadd = '';
				$dipedit = 'style="display:none"';
				}
			elseif(file_exists('../imgs/'.$_FILES['imgfile']['name'])){
				$err_i = 'File name is already in use';
				$dipadd = '';
				$dipedit = 'style="display:none"';
				}
			elseif(!move_uploaded_file($_FILES['cssfile']['tmp_name'],dirname(dirname(__FILE__)).'/css/'.$_FILES['cssfile']['name'])){
				$err_c = 'Error while uploading !!';
				$dipadd = '';
				$dipedit = 'style="display:none"';
				}
			elseif(!move_uploaded_file($_FILES['imgfile']['tmp_name'],dirname(dirname(__FILE__)).'/imgs/'.$_FILES['imgfile']['name'])){
				$err_i = 'Error while uploading !!';
				$dipadd = '';
				$dipedit = 'style="display:none"';
				}
			elseif(!addNewValue(array('ThemeName' => "'".mysql_real_escape_string($_POST['themename'])."'", 'IsActive' => $active, 'SourceName' => "'".$cssfile."'", 'FileView' => "'".$imgview."'"), $table_prefix.'themes')){
				$error = $errordata;
				$dipadd = '';
				$dipedit = 'style="display:none"';
				}
			else{
				mysql_close();
				header('Location: '.$base_url.'admincp/managetheme.php');
				exit();
				}
			}
		}
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smupdate'])){
	if(empty($_POST['themename'])){
		$err_n = 'Please enter the name theme';
		$dipedit = '';
		$dipadd = 'style="display:none"';
		}
	else{
		$arrname = array();
		$file1 = fopen("../css/test.txt","w+");
		fwrite($file1,"test");
		fclose($file1);
		if(!$file1){
			$err = 1;
			array_push($arrname,'css');
			}
		else unlink(dirname(dirname(__FILE__))."/css/test.txt");
		$file2 = fopen("../imgs/test.txt","w+");
		fwrite($file2,"test");
		fclose($file2);
		if(!$file2){
			$err = 1;
			array_push($arrname,'imgs');
			}
		else unlink(dirname(dirname(__FILE__))."/imgs/test.txt");
		if(intval($err)==0){
			$cssfile = '';
			$imgview = '';
			$err_c = '';
			$err_i = '';
			if(!empty($_FILES['cssfile']['name'])){
				$extcss = pathinfo($_FILES['cssfile']['name']);
				$extcss = $extcss['extension'];
				if(strtolower($extcss)!='css'){
					$err_c = 'File invalid ! File type is .css';
					$dipedit = '';
					$dipadd = 'style="display:none"';
					}
				elseif(!move_uploaded_file($_FILES['cssfile']['tmp_name'],dirname(dirname(__FILE__)).'/css/'.$_FILES['cssfile']['name'])){
					$err_c = 'Error while uploading !!';
					$dipedit = '';
					$dipadd = 'style="display:none"';
					}
				else $cssfile = $_FILES['cssfile']['name'];
				}
			if(!empty($_FILES['imgfile']['name'])){
				$extview = pathinfo($_FILES['imgfile']['name']);
				$extview = $extview['extension'];
				if(!in_array(strtolower($extview), $filetype)){
					$err_i = $filetypeinvalid.'. File format: '.implode(', ', $filetype);
					$dipedit = '';
					$dipadd = 'style="display:none"';
					}
				elseif(!move_uploaded_file($_FILES['imgfile']['tmp_name'],dirname(dirname(__FILE__)).'/imgs/'.$_FILES['imgfile']['name'])){
					$err_i = 'Error while uploading !!';
					$dipedit = '';
					$dipadd = 'style="display:none"';
					}
				else $imgview = $_FILES['imgfile']['name'];
				}
			if(empty($err_c) && empty($err_i)){
				if(empty($imgview) && empty($cssfile))
					$temp = array('ThemeName' => "'".mysql_real_escape_string($_POST['themename'])."'");
				elseif(!empty($imgview) && empty($cssfile))
					$temp = array('ThemeName' => "'".mysql_real_escape_string($_POST['themename'])."'", 'FileView' => "'".$imgview."'");
				elseif(empty($imgview) && !empty($cssfile))
					$temp = array('ThemeName' => "'".mysql_real_escape_string($_POST['themename'])."'", 'SourceName' => "'".$cssfile."'");
				else $temp = array('ThemeName' => "'".mysql_real_escape_string($_POST['themename'])."'", 'SourceName' => "'".$cssfile."'", 'FileView' => "'".$imgview."'");
				if(!updValues($temp, $table_prefix.'themes', 'Id = '.intval($_POST['hddid']))){
					$error = $errordata;
					$dipedit = '';
					$dipadd = 'style="display:none"';
					}
				else{
					mysql_close();
					header('Location: '.$base_url.'admincp/managetheme.php');
					exit();
					}
				}
			}
		}
	}
if(isset($_GET['id']) && intval($_GET['id'])>0 && isset($_GET['a']) && $_GET['a']=='d'){
	$dell = mysql_fetch_array(getThemes(intval($_GET['id'])));
	unlink(dirname(dirname(__FILE__)).'/css/'.$dell['SourceName']);
	unlink(dirname(dirname(__FILE__)).'/imgs/'.$dell['FileView']);
	if(!delValue('Id = '.intval($_GET['id']), $table_prefix.'themes'))
		$error = $errordata;
	else{
		mysql_close();
		header('Location: '.$base_url.'admincp/managetheme.php');
		exit();
		}
	}
$title = 'AdminCP - Manage Themes';
require_once 'include/header.php';
?>
<script language="javascript">
function editSate(valchange,str1,str2,str3,intval){
	document.getElementById('frmnew').style.display='none';
	document.getElementById('frmEdit').style.display='';
	document.getElementById('themename').focus();
	document.getElementById('themename').value = str1;
	document.getElementById('hddid').value = valchange;
	document.getElementById('cssfile').innerHTML = str3;
	document.getElementById('imgfile').innerHTML = str2;
	if(intval==1)
		document.getElementById('chkactive').checked = true;
	}
function chkfrm(){
	if(document.getElementById('vnvalue').value==''){
		alert('Enter the name state');
		return false;
		}
	return true;
	}
</script>
<div class="admincontent">
	<p class="contentop">Manage Themes</p>
    <div class="contenbody">
    	<div style="width:50%; float:left"><br />
        <form action="" method="post" enctype="multipart/form-data">
    	<?php
		$str = '';
		$pstr = '';
		if(isset($error) && !empty($error))
			echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
		if(intval($err)==1){
			echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>';
			for($i=0; $i<count($arrname); $i++){
				echo $i+1 .'. '.$arrname[$i].' folder is read-only. Please assign Read/Write permission and try again.<br>';
				}
			echo '</i></small></font></p>';
			}
		$list = getThemes(0);
		if(mysql_num_rows($list)>0){
		?>
        <table width="100%" border="0" cellpadding="0" cellspacing="0">
        	<tr bgcolor="#f2f2f2">
            	<td width="2%" class="headrows1" style="border-top:1px solid #d6d8e5">No.</td>
                <td width="30%" class="headrows2" style="border-top:1px solid #d6d8e5">Theme Name</td>
                <td width="50%" class="headrows2" style="border-top:1px solid #d6d8e5">Photos</td>
                <td width="6%" class="headrows2" style="border-top:1px solid #d6d8e5">Used</td>
                <td width="12%" class="headrows2" colspan="2" style="border-top:1px solid #d6d8e5; border-right:1px solid #d6d8e5">Actions</td>
            </tr>
            <?php
			$i=1;
			while($rows=mysql_fetch_array($list)){
				?>
                <tr>
                    <td width="2%" class="headrows3" ><?php echo $i;?></td>
                    <td width="30%" class="headrows4" align="left"><?php echo $rows['ThemeName'];?></td>
                    <td width="50%" class="headrows4" align="left"><img src="../imgs/<?php echo $rows['FileView'];?>" border="0" style="width:100px;" /></td>
                    <td width="6%" class="headrows4" align="center"><?php echo $rows['numof'];?></td>
                    <td width="6%" class="headrows4" align="center"><a href="javascript:void(0)" onclick="editSate(<?php echo $rows['Id'];?>,'<?php echo $rows['ThemeName'];?>','<?php echo $rows['FileView'];?>','<?php echo $rows['SourceName'];?>',<?php echo $rows['IsActive'];?>)"><i>Edit</i></a></td>
                    <td width="6%" class="headrows4" align="center" style="border-right:1px solid #d6d8e5"><a href="javascript:void(0)" onclick="confirmDel('<?php echo $base_url.'admincp/managetheme.php?id='.$rows['Id'].'&a=d';?>', 'Do you want to delete ?')"><i>Del</i></a></td>
                </tr>
                <?php
				$i++;
				}
			?>
            <tr>
            	<td width="20%" style="padding:20px" colspan="7" align="center"><input type="button" name="smadnew" class="massbutton" value="Add new" onclick="adclkActions(0,'','',2)" /></td>
            </tr>
        </table></form>
        <p id="paging" style="clear:both; margin-right:0px; text-align:center"><?php echo $paging;?></p>
        <?php }
		else echo '<p style="padding:10px;">'.$norecord.'</p>';
		?>
        
        </div>
        <div style="width:48%; float:right">
        	<span id="frmEdit" <?php echo $dipedit;?>>
            <h4>Update Value</h4>
            <form action="" method="post" enctype="multipart/form-data">
            <table width="100%" cellpadding="3" cellspacing="3">
            	<tr>
                	<td width="30%" align="right" valign="top"><font color="#FF0000">* </font>Theme name:</td>
                    <td width="70%" align="left"><input type="text" size="40" id="themename" name="themename" value="<?php echo isset($_POST['themename'])?$_POST['themename']:'';?>" /></select>
                    <?php
					if(isset($err_n) && !empty($err_n))
						echo '<br><small><font color="#FF0000"><i>'.$err_n.'</i></font></small>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="30%" align="right" valign="top">CSS File:</td>
                    <td width="70%" align="left"><label id="cssfile"></label><br /><input type="file" size="30" name="cssfile" />
                    <?php
					if(isset($err_c) && !empty($err_c))
						echo '<br><small><font color="#FF0000"><i>'.$err_c.'</i></font></small>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="30%" align="right" valign="top">View image:</td>
                    <td width="70%" align="left"><label id="imgfile"></label><br /><input type="file" size="30" name="imgfile" />
                    <?php
					if(isset($err_i) && !empty($err_i))
						echo '<br><small><font color="#FF0000"><i>'.$err_i.'</i></font></small>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="30%" align="right" valign="top">&nbsp;</td>
                    <td width="70%" align="left"><input type="checkbox" checked="checked" name="chkactive" id="chkactive" />Is Active</td>
                </tr>
                <tr>
                	<td width="30%" align="right">&nbsp;</td>
                    <td width="70%" align="left"><input type="submit" name="smupdate" class="massbutton" value="Save" />&nbsp;<input type="submit" name="smcancel" class="massbutton" value="Cancel" /></td>
                </tr>
            </table><input type="hidden" name="hddid" id="hddid" />
            </form>
            </span>
            <span id="frmnew" <?php echo $dipadd;?>>
        	<h4>Add New Value</h4>
            <form action="" method="post" enctype="multipart/form-data">
            <table width="100%" cellpadding="3" cellspacing="3">
            	<tr>
                	<td width="30%" align="right" valign="top"><font color="#FF0000">* </font>Theme name:</td>
                    <td width="70%" align="left"><input type="text" size="40" id="themename" name="themename" value="<?php echo isset($_POST['themename'])?$_POST['themename']:'';?>" /></select>
                    <?php
					if(isset($err_n) && !empty($err_n))
						echo '<br><small><font color="#FF0000"><i>'.$err_n.'</i></font></small>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="30%" align="right" valign="top"><font color="#FF0000">* </font>CSS File:</td>
                    <td width="70%" align="left"><input type="file" size="30" name="cssfile" />
                    <?php
					if(isset($err_c) && !empty($err_c))
						echo '<br><small><font color="#FF0000"><i>'.$err_c.'</i></font></small>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="30%" align="right" valign="top"><font color="#FF0000">* </font>View image:</td>
                    <td width="70%" align="left"><input type="file" size="30" name="imgfile" />
                    <?php
					if(isset($err_i) && !empty($err_i))
						echo '<br><small><font color="#FF0000"><i>'.$err_i.'</i></font></small>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="30%" align="right" valign="top">&nbsp;</td>
                    <td width="70%" align="left"><input type="checkbox" checked="checked" name="chkactive" />Is Active</td>
                </tr>
                <tr>
                	<td width="30%" align="right">&nbsp;</td>
                    <td width="70%" align="left"><input type="submit" name="smadd" class="massbutton" value="Add" />&nbsp;<input type="submit" name="smcancel" class="massbutton" value="Cancel" /></td>
                </tr>
            </table>
            </form>
            </span>
        </div>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>