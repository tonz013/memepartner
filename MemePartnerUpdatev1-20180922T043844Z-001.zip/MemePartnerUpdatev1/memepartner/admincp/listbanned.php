<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/listbanned.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smunban'])){
	if(count($_POST['unbaned'])>0){
		if(!unBanned($_POST['unbaned']))
			$error = $errordata;
		else{
			mysql_close();
			header('Location: '.$base_url.'admincp/listbanned.php');
			exit();
			}
		}
	else $error = 'Select data to unban';
	}
$title = 'AdminCP - List banned';
require_once 'include/header.php';
?>
<div class="admincontent">
	<p class="contentop">List banned</p>
    <div class="contenbody">
    	<form action="" method="post">
    	<?php
		if(isset($error) && !empty($error))
			echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
		$list = getListBanned();
		if(mysql_num_rows($list)>0){
		?>
        <table width="100%" border="0" cellpadding="0" cellspacing="0">
        	<tr bgcolor="#f2f2f2">
            	<td width="3%" class="headrows1" style="border-top:1px solid #d6d8e5">No.</td>
                <td width="20%" class="headrows2" style="border-top:1px solid #d6d8e5">Email</td>
                <td width="17%" class="headrows2" style="border-top:1px solid #d6d8e5">Profile</td>
                <td width="13%" class="headrows2" align="center" style="border-top:1px solid #d6d8e5">BannedOn</td>
                <td width="20%" class="headrows2" align="center" style="border-top:1px solid #d6d8e5">Reason</td>
                <td width="10%" class="headrows2" align="center" style="border-top:1px solid #d6d8e5">LiftBan</td>
                <td width="13%" class="headrows2" align="center" style="border-top:1px solid #d6d8e5">Last Logon</td>
                <td width="4%" class="headrows2" align="center" style="border-top:1px solid #d6d8e5">Unban</td>
            </tr>
            <?php
			$i=1;
			while($rows=mysql_fetch_array($list)){
				?>
                <tr>
                    <td width="3%" class="headrows3" valign="top"><?php echo $i;?></td>
                    <td width="20%" class="headrows4" valign="top"><?php echo $rows['Email'];?></td>
                    <td width="17%" class="headrows4" align="left"><?php echo $rows['ProfileName'];?></td>
                    <td width="13%" class="headrows4" align="center"><?php echo $rows['BanedOn'];?></td>
                    <td width="20%" class="headrows4" align="left"><?php echo $rows['Reason'];?></td>
                    <td width="10%" class="headrows4" align="left"><?php echo $rows['LLiftBan'];?></td>
                    <td width="13%" class="headrows4" align="center"><?php echo $rows['LastLogon'];?></td>
                    <td width="4%" class="headrows4" align="center"><input type="checkbox" name="unbaned[]" value="<?php echo $rows['Id'];?>" /></td>
                </tr>
                <?php
				$i++;
				}
			?>
            <tr>
            	<td width="20%" style="padding:20px" colspan="7" align="center"><input type="submit" name="smunban" class="massbutton" /></td>
            </tr>
        </table>
        <?php }
		else echo '<p style="padding:10px;">'.$norecord.'</p>';
		?>
        </form>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>