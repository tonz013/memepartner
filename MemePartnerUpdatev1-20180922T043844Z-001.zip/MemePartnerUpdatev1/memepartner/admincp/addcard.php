<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/addcard.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smcancel'])){
	mysql_close();
	header('Location: '.$base_url.'admincp/greetingcard.php');
	exit();
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smadd'])){
	if(empty($_POST['vnvalue'])){
		$err_v = 'Please enter the name state';
		$dipadd = '';
		$dipedit = 'style="display:none"';
		}
	elseif(!addNewValue(array('State' => "'".mysql_real_escape_string($_POST['vnvalue'])."'", 'CountryID' => intval($_POST['newval'])), $table_prefix.'states')){
		$error = $errordata;
		$dipadd = '';
		$dipedit = 'style="display:none"';
		}
	else{
		mysql_close();
		header('Location: '.$base_url.'admincp/greetingcard.php');
		exit();
		}
	}
$title = 'AdminCP - Add card';
require_once 'include/header.php';
?>
<script type="text/javascript" src="<?php echo $base_url;?>admincp/ext/jquery.form.js"></script> 
 <script> 
        $(document).ready(function() { 
		var submitbutton 	= $("#SubmitButton");
		var myform 			= $("#UploadForm");
		var output 			= $("#output");
		var completed 		= '0%';
		
				$(myform).ajaxForm({
					beforeSend: function() { //brfore sending form
						submitbutton.attr('disabled', ''); // disable upload button
						$("#errcate").empty();
						$("#errfile").empty();
					},
					uploadProgress: function(event, position, total, percentComplete) { //on progress
						complete;
						},
					complete: function(response) { // on complete
						var text = response.responseText;
						if(text.substring(0,1)==1){
							$("#errcate").html('<br>'+text.substring(1));
							return;
							}
						else if(text.substring(0,1)==2){
							$("#errfile").html('<br>'+text.substring(1));
							return;
							}
						else if(text.substring(0,1)==3){
							$("#errfile").html('<br>'+text.substring(1));
							return;
							}
						else if(text.substring(0,1)==4){
							window.location.href='<?php echo $base_url.'admincp/greetingcard.php';?>';
							return;
							}
						else{
							output.html(response.responseText);
							return;
							}
					}
			});
        }); 

    </script> 
<div class="admincontent">
	<p class="contentop">Add Card</p>
    <div class="contenbody">
    	<div style="width:80%; float:left; min-height:600px;">
        <form action="<?php echo $base_url;?>admincp/processupload.php" method="post" enctype="multipart/form-data" id="UploadForm">
        	<table width="100%" cellpadding="3" cellspacing="3">
            	<tr>
                	<td width="35%" align="right" valign="top">Card category:</td>
                    <td width="65%" align="left"><select name="slcardcate">
                        <option value="0">- - Select - -</option>
                        <?php
                        $sel = isset($_GET['c'])?$_GET['c']:0;
                        $sqlcountry = 'select Id, NameCate as LName from '.$table_prefix.'cards_categories order by LName asc';
                        dropdownlist($sqlcountry, $sel);
                        ?>
                    </select>
                    <label id="errcate" style="color:#F00; font-size:12px; font-style:italic"></label>
                    </td>
                </tr>
                <tr>
                	<td width="35%" align="right" valign="top">Card image:</td>
                    <td width="65%" align="left"><input type="file" name="ImageFile" />
                    <label id="errfile" style="color:#F00; font-size:12px; font-style:italic"></label>
                    </td>
                </tr>
                <tr>
                	<td width="35%" align="right">&nbsp;</td>
                    <td width="65%" align="left"><input type="checkbox" style="margin-left:0px; padding-left:0px;" name="istext"/>Is Message</td>
                </tr>
                <tr>
                	<td width="35%" align="right">Format Text (HTML Code):</td>
                    <td width="65%" align="left">
                    	<textarea cols="60" rows="7" name="formatcode" placeholder="<div><textarea></textarea></div>"></textarea>
                    </td>
                </tr>
                <tr>
                	<td width="35%" align="right">&nbsp;</td>
                    <td width="65%" align="left">
                    	<input type="submit" value="Add" class="massbutton" name="smadd" id="SubmitButton"/>&nbsp;<input type="submit" value="Review" class="massbutton" name="review"/>&nbsp;<input type="submit" value="Cancel" class="massbutton" name="smcancel"/>
                    </td>
                </tr>
        	</table>
            <div id="output" style="clear:both"></div>
        </form>
        </div>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>