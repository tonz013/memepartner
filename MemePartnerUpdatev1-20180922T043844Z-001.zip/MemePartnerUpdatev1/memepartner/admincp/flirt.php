<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/flirt.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['searchct'])){
	header('Location: '.$base_url.'admincp/flirt.php?c='.intval($_POST['slcountry']));
	exit();
	}
$dipadd = 'style="display:none"';
$dipedit = 'style="display:none"';
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smcancel'])){
	mysql_close();
	header('Location: '.$base_url.'admincp/flirt.php');
	exit();
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smadd'])){
	if(empty($_POST['vnvalue'])){
		$err_v = 'Please enter the flirt value';
		$dipadd = '';
		$dipedit = 'style="display:none"';
		}
	elseif(!addNewValue(array('FilrtValue' => "'".mysql_real_escape_string($_POST['vnvalue'])."'", 'CateId' => intval($_POST['newval'])), $table_prefix.'flirts')){
		$error = $errordata;
		$dipadd = '';
		$dipedit = 'style="display:none"';
		}
	else{
		mysql_close();
		header('Location: '.$base_url.'admincp/flirt.php');
		exit();
		}
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smupdate'])){
	if(!updValues(array('FilrtValue' => "'".mysql_real_escape_string($_POST['vnvalue'])."'", 'CateId' => intval($_POST['newval'])), $table_prefix.'flirts', 'Id = '.intval($_POST['hddid']))){
		$error = $errordata;
		$dipedit = '';
		$dipadd = 'style="display:none"';
		}
	else{
		mysql_close();
		header('Location: '.$base_url.'admincp/flirt.php');
		exit();
		}
	}
if(isset($_GET['id']) && intval($_GET['id'])>0 && isset($_GET['a']) && $_GET['a']=='d'){
	if(!delValue('Id = '.intval($_GET['id']), $table_prefix.'flirts'))
		$error = $errordata;
	else{
		mysql_close();
		header('Location: '.$base_url.'admincp/flirt.php');
		exit();
		}
	}
$title = 'AdminCP - Update Flirts';
require_once 'include/header.php';
?>
<script language="javascript">
function editSate(valchange){
	document.getElementById('frmnew').style.display='none';
	document.getElementById('frmEdit').style.display='';
	$('#frmEdit').load('editflirt.php?st=' + valchange);
	}
function chkfrm(){
	if(document.getElementById('vnvalue').value==''){
		alert('Enter the flirt value');
		return false;
		}
	return true;
	}
</script>
<div class="admincontent">
	<p class="contentop">Update Flirts</p>
    <div class="contenbody">
    	<div style="width:50%; float:left">
        <form action="" method="post">
    	<p>&nbsp;<i>Search for category name:</i>&nbsp;
        <select name="slcountry">
        	<option value="0">- - All - -</option>
            <?php
			$sel = isset($_GET['c'])?$_GET['c']:0;
			$sqlcountry = 'select Id, NameCate as LName from '.$table_prefix.'flirt_categories order by LName asc';
			dropdownlist($sqlcountry, $sel);
			?>
        </select>
        <input type="submit" value="Search" class="massbutton" style="margin-left:10px" name="searchct"/></p>
    	<?php
		$str = '';
		$pstr = '';
		if(isset($_GET['c'])){
			if(intval($_GET['c'])>0){
				$str = " where f.CateId = ".intval($_GET['c']);
				$pstr = '?c='.intval($_GET['c']);
				}
			else{ $str = "";
				$pstr = '?c='.intval($_GET['c']);
				}
			}
			
		if(isset($error) && !empty($error))
			echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
		$config['showeachside'] = 4;
		$config['per_page'] = 20;
		$config['js_numrows_page'] = mysql_num_rows(getListFlirt($str, ''));
		$config['curpage'] = empty($_GET['p'])?1:$_GET['p'];
		$config['rs_start'] = ($config['curpage']*$config['per_page'])-$config['per_page'];
		if($config['js_numrows_page'] < $config['per_page'])
			$config['per_page'] = $config['js_numrows_page'];
		$page = (isset($_GET['p']) && intval($_GET['p'])>0)?'&p='.$_GET['p']:'';
		$config['cururl'] = $base_url.'admincp/flirt.php'.$pstr;
		$rs_maxpage = ceil($config['js_numrows_page']/$config['per_page']);
		$paging = Pagination($config);
		$list = getListFlirt($str, " limit ".$config['rs_start'].", ".$config['per_page']);
		if(mysql_num_rows($list)>0){
		?>
        <table width="100%" border="0" cellpadding="0" cellspacing="0">
        	<tr bgcolor="#f2f2f2">
            	<td width="2%" class="headrows1" style="border-top:1px solid #d6d8e5">No.</td>
                <td width="43%" class="headrows2" style="border-top:1px solid #d6d8e5">Flirt content</td>
                <td width="43%" class="headrows2" style="border-top:1px solid #d6d8e5">Category</td>
                <td width="12%" class="headrows2" colspan="2" style="border-top:1px solid #d6d8e5; border-right:1px solid #d6d8e5">Actions</td>
            </tr>
            <?php
			$i=1;
			while($rows=mysql_fetch_array($list)){
				?>
                <tr>
                    <td width="2%" class="headrows3" valign="top"><?php echo $i;?></td>
                    <td width="43%" class="headrows4" align="left"><?php echo $rows['L1Value'];?></td>
                    <td width="43%" class="headrows4" align="left"><?php echo $rows['L4Value'];?></td>
                    <td width="6%" class="headrows4" align="center"><a href="javascript:void(0)" onclick="editSate(<?php echo $rows['Id'];?>)"><i>Edit</i></a></td>
                    <td width="6%" class="headrows4" align="center" style="border-right:1px solid #d6d8e5"><a href="javascript:void(0)" onclick="confirmDel('<?php echo $base_url.'admincp/flirt.php?id='.$rows['Id'].'&a=d';?>', 'Do you want to delete ?')"><i>Del</i></a></td>
                </tr>
                <?php
				$i++;
				}
			?>
            <tr>
            	<td width="20%" style="padding:20px" colspan="7" align="center"><input type="button" name="smadnew" class="massbutton" value="Add new" onclick="adclkActions(0,'','',2)" /></td>
            </tr>
        </table></form>
        <p id="paging" style="clear:both; margin-right:0px; text-align:center"><?php echo $paging;?></p>
        <?php }
		else echo '<p style="padding:10px;">'.$norecord.'</p>';
		?>
        
        </div>
        <div style="width:48%; float:right">
        	<span id="frmEdit" <?php echo $dipedit;?>>
            </span>
            <span id="frmnew" <?php echo $dipadd;?>>
        	<h4>Add New Value</h4>
            <form action="" method="post">
            <table width="100%" cellpadding="3" cellspacing="3">
            	<tr>
                	<td width="30%" align="right" valign="top">Select category:</td>
                    <td width="70%" align="left">
                    <select name="newval" >
                        <?php
                        $sel = isset($_POST['newval'])?$_POST['newval']:0;
                        $sqlcountry = 'select Id, NameCate as LName from '.$table_prefix.'flirt_categories order by LName asc';
                        dropdownlist($sqlcountry, $sel);
                        ?>
                    </select>
                    
                    <?php
					if(isset($err_e) && !empty($err_e))
						echo '<br><small><font color="#FF0000"><i>'.$err_e.'</i></font></small>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="30%" align="right" valign="top">Name category:</td>
                    <td width="70%" align="left"><input type="text" size="40" id="vnvalue" name="vnvalue" value="<?php echo isset($_POST['vnvalue'])?$_POST['vnvalue']:'';?>" />
                    <?php
					if(isset($err_v) && !empty($err_v))
						echo '<br><small><font color="#FF0000"><i>'.$err_v.'</i></font></small>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="30%" align="right">&nbsp;</td>
                    <td width="70%" align="left"><input type="submit" name="smadd" class="massbutton" value="Add" />&nbsp;<input type="submit" name="smcancel" class="massbutton" value="Cancel" /></td>
                </tr>
            </table>
            </form>
            </span>
        </div>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>