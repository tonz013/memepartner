<?php
require_once "../includes/config.php";
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smsignin'])){
	if(empty($_POST['email']))
		$errore = 'Please enter admin email address';
	elseif(empty($_POST['codeimg']) || trim($_POST['codeimg'])=='')
		$errorp = 'Please enter verification code';
	elseif(trim($_POST['codeimg'])!=$_SESSION['encoded_captcha'])
		$errorp = 'Verification code not match';
	else{
		$sql = "select UserID, Password from ".$table_prefix."users where Email = '".mysql_real_escape_string(trim($_POST['email']))."' and MembershipID = 3";
		$qry = mysql_query($sql);
		if($qry && mysql_num_rows($qry)>0){
			$row=mysql_fetch_array($qry);
			$str = '';
			$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
			$size = strlen( $chars );
			for( $i = 0; $i < 8; $i++ ) {
				$str .= $chars[ rand( 0, $size - 1 ) ];
				}
			$re = "update ".$table_prefix."users set Password = '".$str."' where Email = '".$_POST['email']."' and MembershipID = 3";
			$qryre = mysql_query($re);
			if(!$qryre)
				$error = 'Error occurred check member, please try again !';
			else{
				$mess = 'Dear <i>'.$_POST['email'].',</i><br>';
				$mess = 'You asked for password recovery.<br><br>';
				$mess .= 'Your password: '.$str.'<br><br>';
				$mess .= 'To signin website, <a href="'.$base_url.'admincp">click here.</a><br>';
				if(!mail($_POST['email'], '=?UTF-8?B?'.base64_encode('Recovery password').'?=', $mess, "Content-Type: text/html; charset=utf-8\r\n"."From: Web support"))
					$error = 'Can not send email !';
				else $succ = "An email containing your password has been sent to <b>".$_POST['email']."</b>";
				}
			}
		else $error = 'Email incorrect';
		}
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smsavepass'])){
	if(empty($_POST['newpass']) || trim($_POST['newpass'])=='')
		$errornp = 'Please enter new password';
	elseif(empty($_POST['renewpass']) || trim($_POST['renewpass'])=='')
		$errorrn = 'Please verify new password';
	elseif(trim($_POST['newpass'])!=trim($_POST['renewpass']))
		$errorrn = 'New password not match';
	else{
		$sql = "update ".$table_prefix."users set Password = '".md5(mysql_real_escape_string(trim($_POST['newpass'])))."' where UserId = ".intval($_POST['adminid'])." and Password = '".mysql_real_escape_string(substr(trim($_GET['str']), 0, -6))."'";
		$qry = mysql_query($sql);
		if($qry)
			$success = '<p>Your password updated successfull.<br>Please login <a href="'.$base_url.'admincp">here</a></p>';
		else $error = '<p>Can not update your password.</p>';
		}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Recovery password for admin</title>
</head><a href=""></a>
<body>
	<div style="width:500px; margin:0px auto; border: 1px #CCC solid; margin-top:15%">
    	<form action="<?php echo !empty($_SERVER['QUERY_STRING'])?'?'.$_SERVER['QUERY_STRING']:'';?>" method="post">
        <?php
		if(isset($_GET['str']) && !empty($_GET['str'])){
			$sql = "select UserId from ".$table_prefix."users where Password = '".mysql_real_escape_string(substr(trim($_GET['str']), 0, -6))."'";
			$qry = mysql_query($sql);
			if($qry && mysql_num_rows($qry)>0){
				$row=mysql_fetch_array($qry);
				?>
                <h3 style="color:#FFFFFF; background:#273c67; margin:0px 0px 20px 0px; padding:5px 0px 5px 10px">Recovery admin password</h3>
                <?php
				if(isset($success) && !empty($success))
					echo $success;
				if(isset($error) && !empty($error))
					echo '<br><font color="#FF0000" style="margin-left:31%"><small>'.$error.'</small></font>';
				?>
                <table width="100%" cellpadding="3" cellspacing="3" border="0">
                    <tr>
                        <td width="35%" align="right" valign="top">New password :</td>
                        <td width="65%" align="left"><input type="password" style="width:250px;" name="newpass" value="<?php echo (isset($_POST['newpass']) && !empty($_POST['newpass']))?$_POST['newpass']:'';?>"/>
                            <?php
                            if(isset($errornp) && !empty($errornp))
                                echo '<br><font color="#FF0000"><small>'.$errornp.'</small></font>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td width="35%" align="right" valign="top">Verify new password :</td>
                        <td width="65%" align="left">
                            <input type="password" style="width:250px;" name="renewpass" value=""/>
                            <?php
                            if(isset($errorrn) && !empty($errorrn))
                                echo '<br><font color="#FF0000"><small>'.$errorrn.'</small></font>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td width="35%" align="right">&nbsp;<input type="hidden" name="adminid" value="<?php echo $row['UserId'];?>" /></td>
                        <td width="65%" align="left"><input type="submit" value="Update" name="smsavepass" /></td>
                    </tr>
                </table>
                <?php
				}
			else echo '<font color="#FF0000"><small>Your bad URL !!</small></font>';
			}
		else{
		?>
        <h3 style="color:#FFFFFF; background:#273c67; margin:0px 0px 20px 0px; padding:5px 0px 5px 10px">Admin forgot password</h3>
        <?php
		if(isset($success) && !empty($success))
			echo $success;
		if(isset($error) && !empty($error))
			echo '<br><font color="#FF0000" style="margin-left:31%"><small>'.$error.'</small></font>';
		?>
    	<table width="100%" cellpadding="3" cellspacing="3" border="0">
        	<tr>
            	<td width="30%" align="right" valign="top">Admin email :</td>
                <td width="70%" align="left"><input type="text" style="width:250px;" name="email" value="<?php echo isset($_POST['email'])?$_POST['email']:'';?>"/>
                	<?php
					if(isset($errore) && !empty($errore))
						echo '<br><font color="#FF0000"><small>'.$errore.'</small></font>';
					?>
                </td>
            </tr>
            <tr>
            	<td width="30%" align="right" valign="top">Verify :</td>
                <td width="70%" align="left">
                	<img src="<?php echo $base_url;?>includes/capcha.php" border="0"/><br />
                    <input type="text" style="margin-top:5px" name="codeimg" size="10" maxlength="6" />
                    <?php
					if(isset($errorp) && !empty($errorp))
						echo '<br><font color="#FF0000"><small>'.$errorp.'</small></font>';
					?>
                </td>
            </tr>
            <tr>
            	<td width="30%" align="right">&nbsp;</td>
                <td width="70%" align="left"><input type="submit" value="Request" name="smsignin" /></td>
            </tr>
            <tr>
            	<td width="30%" align="right">&nbsp;</td>
                <td width="70%" align="left"><i><a href="login.php">Or sign-in here !</a><br />&nbsp;</i></td>
            </tr>
        </table>
        <?php } ?>
        </form>
    </div>
</body>
</html>
<?php
mysql_close();