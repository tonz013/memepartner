<?php
set_time_limit(600);
ini_set("mysql.connect_timeout",24*24*60);
ini_set("max_execution_time",24*24*60);
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/backupdb.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smbackup'])){
	if( 'SQL' == $_REQUEST['output_format'] ){
        $print_form=0;
		$filname = $_REQUEST['SeltTable']."_".date('YmdHis').'.sql';
        header('Content-type: text/plain');
        header("Content-Disposition: attachment; filename=$filname");
	echo "/*mysqldump.php */\n";
       _mysqldump_table_data($_REQUEST['SeltTable']);
        }
	exit();
	}
function _mysqldump_table_data($table)
    {
	$limit = "";
	echo "/* Table structure for table `$table` */\n";
    if( isset($_REQUEST['sql_drop_table']))
        echo "DROP TABLE IF EXISTS `$table`;\n\n";
		
	if( isset($_REQUEST['sql_create_table'])){
        $sql="show create table `$table`; ";
        $result=mysql_query($sql);
        if( $result)
        	{
            if($row= mysql_fetch_assoc($result))
            	{
                echo $row['Create Table'].";\n\n";
                }
            }
        }
    $sqlm="select * from `$table`";
    $res=mysql_query($sqlm);
    if( $res)
    	{
        $num_rows= mysql_num_rows($res);
        $num_fields= mysql_num_fields($res);
        if( $num_rows> 0)
        	{
            echo "/* dumping data for table `$table` */\n";
		echo "LOCK TABLES `$table` WRITE;\n\t";
            $field_type=array();
            $i=0;
            while( $i <$num_fields)
            	{
                $meta= mysql_fetch_field($res, $i);
                array_push($field_type, $meta->type);
                $i++;
                }
                  //print_r( $field_type);
            $index=0;
            while( $row= mysql_fetch_row($res))
            	{
				echo "insert into `$table` values ";
                echo "(";
                for( $i=0; $i <$num_fields; $i++)
                	{
                    if( is_null( $row[$i]))
                    	echo "null";
                    else
                    	{
                        switch( $field_type[$i])
                        	{
                            case 'int':
                            	echo $row[$i];
                            break;
                            case 'string':
                            case 'blob' :
                            default:
                            echo "'".mysql_real_escape_string($row[$i])."'";
                            }
                       	}
               		if( $i <$num_fields-1)
                        echo ",";
                    }
             	echo ");";
                echo "\n";
                $index++;
              }
           }
        }
	echo "UNLOCK TABLES;";
    mysql_free_result($res);
    echo "\n";
	}
$title = 'AdminCP - Backup database';
require_once 'include/header.php';
$sql="show tables like '".$table_prefix."%';";
$result= mysql_query($sql);
?>
<div class="admincontent">
	<p class="contentop">Backup database</p>
    <div class="contenbody"><bR />
    	<form action="" method="post">
        <table width="100%" cellpadding="3" cellspacing="3">
        	<tr>
            	<td width="100%" align="left" colspan="2"><input type="checkbox" name="sql_drop_table" <?php if(isset($_REQUEST['action']) && ! isset($_REQUEST['sql_drop_table'])) ; else echo 'checked' ?> /> Drop before create .</td>
            </tr>
            <tr><td width="100%" align="left" colspan="2"><input type="checkbox" name="sql_create_table" <?php if(isset($_REQUEST['action']) && ! isset($_REQUEST['sql_create_table'])) ; else echo 'checked' ?> /> Save the table structure .</td>
            </tr>
            <tr><td width="100%" align="left" colspan="2"><input type="checkbox" name="sql_table_data" <?php if(isset($_REQUEST['action']) && ! isset($_REQUEST['sql_table_data'])) ; else echo 'checked' ?> /> Save the table data .</td>
            </tr>
            <tr><td width="100%" align="left" colspan="2"><input type="radio" name="output_format" value="SQL" <?php if( isset($_REQUEST['output_format']) && 'SQL' == $_REQUEST['output_format']) echo "selected";?> checked="checked">Compress the file with *.sql</td>
            </tr>
            <tr><td width="14%" align="left">You have [ <b><?php echo mysql_num_rows($result);?></b> ] table(s) : </td><td width="86%"><select name="SeltTable">
				<?php
				while( $row= mysql_fetch_row($result))
					echo '<option value="'.$row[0].'">'.$row[0].'</option>';
				?>
			</select></td>
            </tr>
            <tr>
                <td width="100%" align="left" colspan="2"><br /><input type="submit" class="massbutton" name="smbackup"/></td>
            </tr>
        </table><br />
        </form>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>