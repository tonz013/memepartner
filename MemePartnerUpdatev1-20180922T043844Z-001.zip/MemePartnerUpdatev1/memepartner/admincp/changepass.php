<?php
require_once "../includes/config.php";
require_once "../includes/database.php";
require_once "include/functions.php";
if(intval($_SESSION['admincp'])==0 || !$_SESSION['admincp']){
	header('Location: login.php');
	exit();
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smsave'])){
	$update = false;
	$umail = false;
	$upass = false;
	if(!empty($_POST['email'])){
		if(!valid_email(trim($_POST['email'])))
			$err_e = 'Your email invalid !';
		else{
			$update = true;
			$umail = true;
			}
		}
	if(!empty($_POST['password'])){
		if(strlen(trim($_POST['password']))<6)
			$err_p = 'Password min is 6 characters';
		else{
			$update = true;
			$upass = true;
			}
		}
	if($update==true && $umail==true && $upass==true){
		$sql = "update ".$table_prefix."users set Password = '".mysql_real_escape_string(trim($_POST['password']))."', Email = '".trim($_POST['email'])."' where UserID = ".intval($_SESSION['admincp'])." and MembershipID = 3";
		$qry = mysql_query($sql);
		if($qry)
			$success = 'Your account updated successfull.';
		else $error = 'Can not update your account';
		}
	elseif($update==true && $umail==true){
		$sql = "update ".$table_prefix."users set Email = '".trim($_POST['email'])."' where UserID = ".intval($_SESSION['admincp'])." and MembershipID = 3";
		$qry = mysql_query($sql);
		if($qry)
			$success = 'Your email updated successfull.';
		else $error = 'Can not update your email';
		}
	elseif($update==true && $upass==true){
		$sql = "update ".$table_prefix."users set Password = '".mysql_real_escape_string(trim($_POST['password']))."' where UserId = ".intval($_SESSION['admincp'])." and MembershipID = 3";
		$qry = mysql_query($sql);
		if($qry)
			$success = 'Your password updated successfull.';
		else $error = 'Can not update your password';
		}
	}
$mmenu=5;
$title = 'Update account admin';
?>
<link href="../css/admincss.css" type="text/css" rel="stylesheet" />
<div class="admincontent">
	<p class="contentop"><?php echo $title;?></p>
    <div class="contenbody">
    	<form action="" method="post">
            <?php
			if(isset($error) && !empty($error))
				echo '<br><font color="#FF0000" style="text-align:left"><small>'.$error.'</small></font><br>';
			if(isset($success) && !empty($success))
				echo '<br><font color="#009933" style="text-align:left"><small>'.$success.'</small></font><br>';
			?>
        	<table width="100%" cellpadding="3" cellspacing="3" border="0">
            	<tr>
                	<td width="30%" align="right" valign="top">Email admin : </td>
                    <td width="70%" align="left">
                        <?php
						$sql = 'select Email from '.$table_prefix.'users where UserID = '.$_SESSION['admincp'];
						$qury = mysql_query($sql);
						if($qury && mysql_num_rows($qury)>0){
							$rows=mysql_fetch_array($qury);
							echo $rows['Email'];
							}
						else echo 'Error data';
						?>
                    </td>
                </tr>
                <tr>
                	<td width="30%" align="right" valign="top">Password : </td>
                    <td width="70%" align="left">**************</td>
                </tr>
            </table>
            <hr width="80%" color="#CCCCCC" size="1" />
            <table width="100%" cellpadding="3" cellspacing="3" border="0">
            	<tr>
                	<td width="30%" align="right" valign="top"><font color="#FF0000">* </font>New admin email : </td>
                    <td width="70%" align="left">
                    <input type="text" style="width:250px;" maxlength="255" name="email" value="<?php echo isset($_POST['email'])?$_POST['email']:'';?>"/>
                    <?php
					if(isset($err_e) && !empty($err_e))
						echo '<br><font color="#FF0000"><small><i>'.$err_e.'</i></small></font>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="30%" align="right" valign="top"><font color="#FF0000">* </font>New password : </td>
                    <td width="70%" align="left"><input type="password" style="width:250px;" maxlength="32" name="password"/>
                    <?php
					if(isset($err_p) && !empty($err_p))
						echo '<br><font color="#FF0000"><small><i>'.$err_p.'</i></small></font>';
					?></td>
                </tr>
                <tr>
                	<td width="30%" align="right">&nbsp;</td>
                    <td width="70%" align="left"><input type="submit" name="smsave" value="Save change"/>&nbsp;</td>
                </tr>
            </table>
            </form>
    <p style="clear:both">&nbsp;</p>
    </div><p style="clear:both">&nbsp;</p>
</div>
<?php
mysql_close();