<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/adminhelp.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
$page1 = "select PageName, PageBody, IsActive, LastUpdated from ".$table_prefix."pages where Id = 3";
$qrypa = mysql_query($page1);
if($qrypa!=false && mysql_num_rows($qrypa)>0){
	$row=mysql_fetch_array($qrypa);
	$title = 'AdminCP - '.$row['PageName'];
	}
else $title = 'Page error';
require_once 'include/header.php';
?>
<link rel="stylesheet" href="<?php echo $base_url;?>admincp/ext/jquery.wysiwyg.css" type="text/css" />
  <script type="text/javascript" src="<?php echo $base_url;?>admincp/ext/jquery-1.3.2.js"></script>
  <script type="text/javascript" src="<?php echo $base_url;?>admincp/ext/jquery.wysiwyg.js"></script>
  <script type="text/javascript">
  $(function()
  {
      $('#bodyadd').wysiwyg();
  });
  </script>
<div class="admincontent">
	<p class="contentop"><?php echo (isset($row['PageName']) && !empty($row['PageName']))?$row['PageName']:$title;?></p>
    <div class="contenbody">
    	<div style="width:100%; float:left; padding:10px; min-height:500px">
        	<?php
    		echo (isset($row['PageBody']) && !empty($row['PageBody']))?$row['PageBody']:'<p>'.$norecord.' !!</p>';
			?>
        </div>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>