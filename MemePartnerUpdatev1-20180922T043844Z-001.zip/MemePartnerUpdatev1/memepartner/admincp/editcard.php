<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/editcatd.php?'.$_SERVER['QUERY_STRING'];
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
$dipadd = 'style="display:none"';
$dipedit = 'style="display:none"';
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smcancel'])){
	mysql_close();
	header('Location: '.$base_url.'admincp/greetingcard.php');
	exit();
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smupdate'])){
	if(!updValues(array('State' => "'".mysql_real_escape_string($_POST['vnvalue'])."'", 'CountryID' => intval($_POST['newval'])), $table_prefix.'states', 'StateID = '.intval($_POST['hddid']))){
		$error = $errordata;
		$dipedit = '';
		$dipadd = 'style="display:none"';
		}
	else{
		mysql_close();
		header('Location: '.$base_url.'admincp/greetingcard.php');
		exit();
		}
	}
$where = ' where s.Id = '.intval($_GET['id']);
$detail = getListCrads($where,'');
if(!$detail)
	$title = 'AdminCP - Edit card - Your bad url !!';
else{
	$row = mysql_fetch_array($detail);
	$title = 'AdminCP - Edit card - '.$row['CardName'];
	}
require_once 'include/header.php';
?>
<script type="text/javascript" src="<?php echo $base_url;?>admincp/ext/jquery.form.js"></script> 
 <script> 
        $(document).ready(function() { 
		//elements
		////var progressbox 	= $('#progressbox');
		///var progressbar 	= $('#progressbar');
		//var statustxt 		= $('#statustxt');
		var submitbutton 	= $("#SubmitButton");
		var myform 			= $("#UploadForm");
		var output 			= $("#output");
		var completed 		= '0%';
		
				$(myform).ajaxForm({
					beforeSend: function() { //brfore sending form
						submitbutton.attr('disabled', ''); // disable upload button
						$("#errcate").empty();
						$("#errfile").empty();
						//statustxt.empty();
						//progressbox.show(); //show progressbar
						//progressbar.width(completed); //initial value 0% of progressbar
						//statustxt.html(completed); //set status text
						//statustxt.css('color','#000'); //initial color of status text
					},
					uploadProgress: function(event, position, total, percentComplete) { //on progress
						/*progressbar.width(percentComplete + '%') //update progressbar percent complete
						statustxt.html(percentComplete + '%'); //update status text
						if(percentComplete>50)
							{
								statustxt.css('color','#fff'); //change status text to white after 50%
							}*/
						complete;
						},
					complete: function(response) { // on complete
						var text = response.responseText;
						if(text.substring(0,1)==1){
							$("#errcate").html('<br>'+text.substring(1));
							return;
							}
						else if(text.substring(0,1)==2){
							$("#errfile").html('<br>'+text.substring(1));
							return;
							}
						else if(text.substring(0,1)==3){
							$("#errfile").html('<br>'+text.substring(1));
							return;
							}
						else if(text.substring(0,1)==4){
							window.location.href='<?php echo $base_url.'admincp/greetingcard.php';?>';
							return;
							}
						else{
							output.html(response.responseText);
							return;
							}
						/*output.html(response.responseText); //update element with received data
						//myform.resetForm();  // reset form
						submitbutton.removeAttr('disabled'); //enable submit button
						//progressbox.hide(); // hide progressbar*/
					}
			});
        }); 

    </script> 
<div class="admincontent">
	<p class="contentop">Edit Card</p>
    <div class="contenbody">
    	<div style="width:80%; float:left; min-height:900px;">
        <?php
		if(!$row || $row['Id']==0) echo 'p>Your bad url !!</p>';
		else{
		?>
        <form action="<?php echo $base_url;?>admincp/editupload.php?<?php echo $_SERVER['QUERY_STRING'];?>" method="post" enctype="multipart/form-data" id="UploadForm">
        	<table width="100%" cellpadding="3" cellspacing="3">
            	<tr>
                	<td width="35%" align="right" valign="top">Card category:</td>
                    <td width="65%" align="left"><select name="slcardcate">
                        <option value="0">- - Select - -</option>
                        <?php
                        $sel = isset($_GET['c'])?$_GET['c']:$row['CardCate'];
                        $sqlcountry = 'select Id, NameCate as LName from '.$table_prefix.'cards_categories order by LName asc';
                        dropdownlist($sqlcountry, $sel);
                        ?>
                    </select>
                    <label id="errcate" style="color:#F00; font-size:12px; font-style:italic"></label>
                    </td>
                </tr>
                <tr>
                	<td width="35%" align="right" valign="top">Card image:</td>
                    <td width="65%" align="left">
                    <?php
					$chk = $row['IsText']==1?' checked="checked"':'';
					if(!empty($row['CardName']))
					?><img src="../ecards/<?php echo $row['CardName'];?>" border="0" /><br />
                    <input type="file" name="ImageFile" />
                    <label id="errfile" style="color:#F00; font-size:12px; font-style:italic"></label>
                    </td>
                </tr>
                <tr>
                	<td width="35%" align="right">&nbsp;</td>
                    <td width="65%" align="left"><input type="checkbox" style="margin-left:0px; padding-left:0px;" name="istext" <?php echo $chk;?>/>Is Message</td>
                </tr>
                <tr>
                	<td width="35%" align="right">Format Text (HTML Code):</td>
                    <td width="65%" align="left">
                    	<textarea cols="60" rows="7" name="formatcode"><?php echo html_entity_decode(htmlentities($row['ViewFormat']));?></textarea>
                    </td>
                </tr>
                <tr>
                	<td width="35%" align="right">&nbsp;</td>
                    <td width="65%" align="left">
                    	<input type="submit" value="Save" class="massbutton" name="smupdate" id="SubmitButton"/>&nbsp;<input type="submit" value="Review" class="massbutton" name="review"/>&nbsp;<input type="submit" value="Cancel" class="massbutton" name="smcancel"/>
                    </td>
                </tr>
        	</table>
            <div id="output" style="clear:both"><input type="hidden" name="hddfile" value="<?php echo $row['CardName'];?>"/></div>
        </form>
        <?php }?>
        </div>
        
    </div>
</div>
<?php
require_once 'include/footer.php';
?>