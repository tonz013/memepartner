<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/banuser.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smbanuser'])){
	if(empty($_POST['reason']))
		$error = 'Please enter the reason to ban this user';
	elseif(!BanUsers(array(intval($_GET['uid']), mysql_real_escape_string($_POST['reason']), intval($_POST['valban']))))
		$error = $errordata;
	else{
		if($_POST['spamemail']=='on' && $_POST['spamdomain']=='on'){
			$spammail = 1;
			$spamdomain = 1;
			FillterEmail(array(mysql_real_escape_string($_POST['hddemail']), $spammail, $spamdomain, date('Y-m-d H:i:s'), mysql_real_escape_string($_POST['reason'])));
			}
		elseif($_POST['spamdomain']=='on'){
			$spammail = 0;
			$spamdomain = 1;
			FillterEmail(array(mysql_real_escape_string($_POST['hddemail']), $spammail, $spamdomain, date('Y-m-d H:i:s'), mysql_real_escape_string($_POST['reason'])));
			}
		elseif($_POST['spamemail']=='on'){
			$spammail = 1;
			$spamdomain = 0;
			FillterEmail(array(mysql_real_escape_string($_POST['hddemail']), $spammail, $spamdomain, date('Y-m-d H:i:s'), mysql_real_escape_string($_POST['reason'])));
			}
		mysql_close();
		header('Location: '.$base_url.'admincp/usersmanage.php');
		exit();
		}
	}
$title = 'AdminCP - Ban user';
require_once 'include/header.php';
?>
<div class="admincontent">
	<p class="contentop">Banned user</p>
    <div class="contenbody">
    	<?php
		if(intval($_GET['uid'])>0){
			$list = getInfoUsersBan(intval($_GET['uid']));
			if(count($list)>0){
			?><br />
            <form action="?<?php echo $_SERVER['QUERY_STRING'];?>" method="post">
			<table width="100%" border="0" cellpadding="3" cellspacing="3">
				<tr>
					<td width="30%" align="right">Profile name : </td>
					<td width="70%" align="left"><?php echo $list['ProfileName'];?></td>
				</tr>
				<tr>
					<td width="30%" align="right">Email : </td>
					<td width="70%" align="left"><?php echo $list['Email'];?></td>
				</tr>
				<tr>
					<td width="30%" align="right">Banlift : </td>
					<td width="70%" align="left">
					<select name="valban">
						<?php
						$sel = isset($_POST['valban'])?$_POST['valban']:-1;
						$sqlban = 'select Id as Id, '.$_SESSION['lang'].'LiftBan as LName from '.$table_prefix.'liftbaned order by Id asc';
						dropdownlist($sqlban, $sel);
						?>
					</select></td>
				</tr>
				<tr>
					<td width="30%" align="right"><font color="#FF0000">* </font>Reason : </td>
					<td width="70%" align="left"><textarea style="width:350px;" rows="4" name="reason"><?php echo (isset($_POST['reason']))?$_POST['reason']:'';?></textarea>
                    <?php
					if(isset($error) && !empty($error))
						echo '<br><font color="#FF0000"><small><i>'.$error.'</i></small></font>';
					?>
                    </td>
				</tr>
                <tr>
					<td width="30%" align="right">&nbsp;</td>
					<td width="70%" align="left"><input type="checkbox" style="margin-left:0px; padding-left:0px;" name="spamemail"/>Add this email to list spam email<br />
                    <input type="checkbox" style="margin-left:0px; padding-left:0px;" name="spamdomain"/>Add this domain to list spam domain.
                    </td>
				</tr>
				<tr>
					<td width="30%" align="right">&nbsp;</td>
					<td width="70%" align="left"><input type="submit" name="smbanuser" class="massbutton" /><input type="hidden" name="hddemail" value="<?php echo $list['Email'];?>" /></td>
				</tr>
			</table></form><br />
			<?php  }
			else echo '<p style="padding:10px;">'.$norecord.'</p>';
			}
		else echo '<p style="padding:10px;">Data incorrect !</p>';
		?>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>