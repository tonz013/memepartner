<?php
require_once "../includes/config.php";
require_once "../includes/database.php";
require_once "include/functions.php";
if(isset($_POST))
{
	if(!isset($_POST['slcardcate']) || $_POST['slcardcate']==0){
		echo '1Please select category card !';
		exit();
		}
	else{
		$ThumbSquareSize 		= 200; //Thumbnail will be 200x200
		$BigImageMaxSize 		= 280; //Image Maximum height or width
		$ThumbPrefix			= "thumb_"; //Normal thumb Prefix
		$DestinationDirectory	= '../ecards/'; //Upload Directory ends with / (slash)
		$Quality 				= 90;
		if(isset($_POST['review'])){
			if(!isset($_POST['hddview']) && empty($_POST['hddview'])){
				if(!empty($_FILES['ImageFile']['name'])){
					if(!isset($_FILES['ImageFile']) || !is_uploaded_file($_FILES['ImageFile']['tmp_name'])){
						die('Something went wrong with Upload!');
						}
					$RandomNumber 	= rand(0, 9999999999); 
					$ImageName 		= str_replace(' ','-',strtolower($_FILES['ImageFile']['name'])); 
					$ImageSize 		= $_FILES['ImageFile']['size']; 
					$TempSrc	 	= $_FILES['ImageFile']['tmp_name']; 
					$ImageType	 	= $_FILES['ImageFile']['type']; 
					switch(strtolower($ImageType)){
						case 'image/png':
							$CreatedImage =  imagecreatefrompng($_FILES['ImageFile']['tmp_name']);
							break;
						case 'image/gif':
							$CreatedImage =  imagecreatefromgif($_FILES['ImageFile']['tmp_name']);
							break;			
						case 'image/jpeg':
						case 'image/pjpeg':
							$CreatedImage = imagecreatefromjpeg($_FILES['ImageFile']['tmp_name']);
							break;
						default:
							die('Unsupported File!');
						}
					list($CurWidth,$CurHeight)=getimagesize($TempSrc);
					$ImageExt = substr($ImageName, strrpos($ImageName, '.'));
					$ImageExt = str_replace('.','',$ImageExt);
					
					$ImageName 		= preg_replace("/\\.[^.\\s]{3,4}$/", "", $ImageName); 
					
					$NewImageName = $ImageName.'-'.$RandomNumber.'.'.$ImageExt;
					$DestRandImageName 			= $DestinationDirectory.$NewImageName;
					if(resizeImage($CurWidth,$CurHeight,$BigImageMaxSize,$DestRandImageName,$CreatedImage,$Quality,$ImageType)){
						list($ResizedWidth,$ResizedHeight)=getimagesize($DestRandImageName);
						echo '<table width="100%" border="0" cellpadding="4" cellspacing="0">';
						echo '<tr>';
						echo '<td align="center" width="100%"><input type="hidden" name="hddfile" value="'.$NewImageName.'"/><input type="hidden" name="hddview" value="1" /><div style="width:330px; background:url(../ecards/'.$NewImageName.') no-repeat 100px 10px; height:307px; position:absolute">'.$_POST['formatcode'].'</div></td>';
						echo '</tr>';
						echo '</table>';
						}
					else die('Resize Error');
					}
				else{
					echo '<table width="100%" border="0" cellpadding="4" cellspacing="0">';
					echo '<tr>';
					echo '<td align="center" width="100%"><input type="hidden" name="hddfile" value="'.$_POST['hddfile'].'"/><input type="hidden" name="hddview" value="1" /><div style="width:330px; background:url(../ecards/'.$_POST['hddfile'].') no-repeat 100px 10px; height:307px; position:absolute">'.$_POST['formatcode'].'</div></td>';
					echo '</tr>';
					echo '</table>';
					}
				}
			else{
				if(!empty($_FILES['ImageFile']['name'])){
					if(!isset($_FILES['ImageFile']) || !is_uploaded_file($_FILES['ImageFile']['tmp_name'])){
						die('Something went wrong with Upload!');
						}
					$RandomNumber 	= rand(0, 9999999999); 
					$ImageName 		= str_replace(' ','-',strtolower($_FILES['ImageFile']['name'])); 
					$ImageSize 		= $_FILES['ImageFile']['size']; 
					$TempSrc	 	= $_FILES['ImageFile']['tmp_name']; 
					$ImageType	 	= $_FILES['ImageFile']['type']; 
					switch(strtolower($ImageType)){
						case 'image/png':
							$CreatedImage =  imagecreatefrompng($_FILES['ImageFile']['tmp_name']);
							break;
						case 'image/gif':
							$CreatedImage =  imagecreatefromgif($_FILES['ImageFile']['tmp_name']);
							break;			
						case 'image/jpeg':
						case 'image/pjpeg':
							$CreatedImage = imagecreatefromjpeg($_FILES['ImageFile']['tmp_name']);
							break;
						default:
							die('Unsupported File!');
						}
					list($CurWidth,$CurHeight)=getimagesize($TempSrc);
					$ImageExt = substr($ImageName, strrpos($ImageName, '.'));
					$ImageExt = str_replace('.','',$ImageExt);
					
					$ImageName 		= preg_replace("/\\.[^.\\s]{3,4}$/", "", $ImageName); 
					
					$NewImageName = $ImageName.'-'.$RandomNumber.'.'.$ImageExt;
					$DestRandImageName 			= $DestinationDirectory.$NewImageName;
					if(resizeImage($CurWidth,$CurHeight,$BigImageMaxSize,$DestRandImageName,$CreatedImage,$Quality,$ImageType)){
						list($ResizedWidth,$ResizedHeight)=getimagesize($DestRandImageName);
						echo '<table width="100%" border="0" cellpadding="4" cellspacing="0">';
						echo '<tr>';
						echo '<td align="center" width="100%"><input type="hidden" name="hddfile" value="'.$NewImageName.'"/><input type="hidden" name="hddview" value="1" /><div style="width:330px; background:url(../ecards/'.$NewImageName.') no-repeat 100px 10px; height:307px; position:absolute">'.$_POST['formatcode'].'</div></td>';
						echo '</tr>';
						echo '</table>';
						}
					else die('Resize Error');
					}
				else{
					echo '<table width="100%" border="0" cellpadding="4" cellspacing="0">';
					echo '<tr>';
					echo '<td align="center" width="100%"><input type="hidden" name="hddfile" value="'.$_POST['hddfile'].'"/><input type="hidden" name="hddview" value="1" /><div style="width:330px; background:url(../ecards/'.$_POST['hddfile'].') no-repeat 100px 10px; height:307px; position:absolute">'.$_POST['formatcode'].'</div></td>';
					echo '</tr>';
					echo '</table>';
					}
				}
			}
		elseif(isset($_POST['smupdate'])){
			if(isset($_POST['hddview']) && !empty($_POST['hddview'])){
				$istext = $_POST['istext']=='on'?1:0;
				$sql = "update ".$table_prefix."greetingcards set CardCate = ".intval($_POST['slcardcate']).", CardName = '".mysql_real_escape_string(trim($_POST['hddfile']))."', IsText = ".$istext.", ViewFormat = '".mysql_real_escape_string(trim(htmlspecialchars($_POST['formatcode'])))."' where Id = ".intval($_GET['id']);
				$qry = mysql_query($sql);
				if(!$qry) die('3An error occurred, please try again !');
				else die('4a');
				}
			elseif(!empty($_FILES['ImageFile'])){
				if(!isset($_FILES['ImageFile']) || !is_uploaded_file($_FILES['ImageFile']['tmp_name'])){
					die('2Something went wrong with Upload!');
					}
				$RandomNumber 	= rand(0, 9999999999); 
				$ImageName 		= str_replace(' ','-',strtolower($_FILES['ImageFile']['name'])); 
				$ImageSize 		= $_FILES['ImageFile']['size']; 
				$TempSrc	 	= $_FILES['ImageFile']['tmp_name']; 
				$ImageType	 	= $_FILES['ImageFile']['type']; 
				switch(strtolower($ImageType)){
					case 'image/png':
						$CreatedImage =  imagecreatefrompng($_FILES['ImageFile']['tmp_name']);
						break;
					case 'image/gif':
						$CreatedImage =  imagecreatefromgif($_FILES['ImageFile']['tmp_name']);
						break;			
					case 'image/jpeg':
					case 'image/pjpeg':
						$CreatedImage = imagecreatefromjpeg($_FILES['ImageFile']['tmp_name']);
						break;
					default:
						die('2Unsupported File!');
					}
				list($CurWidth,$CurHeight)=getimagesize($TempSrc);
				$ImageExt = substr($ImageName, strrpos($ImageName, '.'));
				$ImageExt = str_replace('.','',$ImageExt);
				
				$ImageName 		= preg_replace("/\\.[^.\\s]{3,4}$/", "", $ImageName); 
				
				$NewImageName = $ImageName.'-'.$RandomNumber.'.'.$ImageExt;
				$DestRandImageName 			= $DestinationDirectory.$NewImageName;
				if(resizeImage($CurWidth,$CurHeight,$BigImageMaxSize,$DestRandImageName,$CreatedImage,$Quality,$ImageType)){
					if($_POST['istext']=='on'){
						$istext = 1;
						$isformat = mysql_real_escape_string(trim(htmlspecialchars($_POST['formatcode'])));
						}
					else{
						$istext = 0;
						$isformat = '';
						}
					$istext = $_POST['istext']=='on'?1:0;
					$sql = "update ".$table_prefix."greetingcards set CardCate = ".intval($_POST['slcardcate']).", CardName = '".$NewImageName."', IsText = ".$istext.", ViewFormat = '".$isformat."' where Id = ".intval($_GET['id']);
					$qry = mysql_query($sql);
					if(!$qry) die('3An error occurred, please try again !');
					else die('4a');
					}
				else die('2Resize Error');
				}
			else{
				if($_POST['istext']=='on'){
					$istext = 1;
					$isformat = mysql_real_escape_string(trim(htmlspecialchars($_POST['formatcode'])));
					}
				else{
					$istext = 0;
					$isformat = '';
					}
				$sql = "update ".$table_prefix."greetingcards set CardCate = ".intval($_POST['slcardcate']).", CardName = '".mysql_real_escape_string(trim($_POST['hddfile']))."', IsText = ".$istext.", ViewFormat = '".$isformat."' where Id = ".intval($_GET['id']);
				$qry = mysql_query($sql);
				if(!$qry) die('3An error occurred, please try again !');
				else die('4a');
				}
			}
		}
	}


// This function will proportionally resize image 
function resizeImage($CurWidth,$CurHeight,$MaxSize,$DestFolder,$SrcImage,$Quality,$ImageType)
{
	//Check Image size is not 0
	if($CurWidth <= 0 || $CurHeight <= 0) 
	{
		return false;
	}
	
	//Construct a proportional size of new image
	$ImageScale      	= min($MaxSize/$CurWidth, $MaxSize/$CurHeight); 
	$NewWidth  			= ceil($ImageScale*$CurWidth);
	$NewHeight 			= ceil($ImageScale*$CurHeight);
	
	if($CurWidth < $NewWidth || $CurHeight < $NewHeight)
	{
		$NewWidth = $CurWidth;
		$NewHeight = $CurHeight;
	}
	$NewCanves 	= imagecreatetruecolor($NewWidth, $NewHeight);
	// Resize Image
	if(imagecopyresampled($NewCanves, $SrcImage,0, 0, 0, 0, $NewWidth, $NewHeight, $CurWidth, $CurHeight))
	{
		switch(strtolower($ImageType))
		{
			case 'image/png':
				imagepng($NewCanves,$DestFolder);
				break;
			case 'image/gif':
				imagegif($NewCanves,$DestFolder);
				break;			
			case 'image/jpeg':
			case 'image/pjpeg':
				imagejpeg($NewCanves,$DestFolder,$Quality);
				break;
			default:
				return false;
		}
	//Destroy image, frees up memory	
	if(is_resource($NewCanves)) {imagedestroy($NewCanves);} 
	return true;
	}

}
