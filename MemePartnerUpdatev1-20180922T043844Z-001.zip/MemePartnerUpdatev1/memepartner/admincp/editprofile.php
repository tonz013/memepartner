<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/editprofile.php?'.$_SERVER['QUERY_STRING'];
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smupdate'])){
	if(empty($_POST['profilename']))
		$error = $err_p = $profilenull;
	elseif(strlen($_POST['profilename'])<6)
		$error = $err_p = $datashort;
	elseif(empty($_POST['abloutme']))
		$error = $err_a = $aboutnull;
	elseif(strlen($_POST['abloutme'])<6)
		$error = $err_a = $datashort;
	elseif(intval($_POST['slcountry'])==0)
		$error = $err_co = $countrynull;
	elseif(intval($_POST['slcity'])==0)
		$error = $err_ci = $statenull;
	elseif(empty($_POST['txtinterests']))
		$error = $err_i = $interestnull;
	elseif(strlen($_POST['txtinterests'])<6)
		$error = $err_i = $datashort;
	elseif(empty($_POST['abouth']))
		$err_h = $aboutherorhis;
	elseif(strlen($_POST['abouth'])<6)
		$err_h = $datashort;
	else{
		$match = ($_POST['matchsame']=='on')?1:0;
		$data = array(mysql_real_escape_string($_POST['fullname']), mysql_real_escape_string($_POST['profilename']), $_POST['rdgender'], $_POST['slHeight'], $_POST['slage'], $_POST['slBodyType'], $_POST['slHairColor'], $_POST['slEyeColor'], mysql_real_escape_string($_POST['txtstate']), $_POST['slcity'], $_POST['slcountry'], mysql_real_escape_string($_POST['phone']), $_POST['slReligion'], $_POST['slEducation'], mysql_real_escape_string($_POST['opcupation']), $_POST['slSmoking'], $_POST['slDrinking'], $_POST['slMarital'], $_POST['slDatingInterest'], $_POST['rdhave'], $_POST['rdwant'], $_POST['sltravel'], $_POST['slagefrom'], $_POST['slageto'], $_POST['mdgender'], $_POST['mslHeightfrom'], $_POST['mslHeightto'], $_POST['mslBodyType'], $_POST['mslReligion'], $_POST['mslEducation'], $_POST['mslSmoking'], $_POST['mslDrinking'], $_POST['mslMarital'], $match, mysql_real_escape_string($_POST['txtinterests']), mysql_real_escape_string($_POST['abloutme']), mysql_real_escape_string($_POST['abouth']));
		if(!updateUser($data, intval($_GET['uid'])))
			$error = 'An error occurred, please try again !';
		else $succ = 'Successfully updated !';
		}
	}
$title = 'AdminCP - Edit user';
require_once 'include/header.php';
?>
<script language="javascript">
$(document).ready(function(){
		$('#slcountry').change(function() {
			var valchange = this.value;
	  		$('#slcity').load('<?php echo $base_url;?>includes/loadcities.php?countryId=' + valchange);
	  		});
		});
</script>
<div class="admincontent">
	<p class="contentop">Edit user</p>
    <div class="contenbody">
    	<?php
		if(isset($error) && !empty($error))
            echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
		if(isset($succ) && !empty($succ))
			echo '<p style="margin:0px; padding:5px 20px"><font color="#009933"><i>'.$succ.'</i></font></p>';
		if(intval($_GET['uid'])>0){
			$list = getFullInfoUser(intval($_GET['uid']));
			if(count($list)>0){
			?>
            <form action="?<?php echo $_SERVER['QUERY_STRING'];?>" method="post">
            <div style="width:50%; float:left; padding-left:10px;">
            	<h3 style="margin-bottom:3px; padding-bottom:3px">Personal Informations</h3>
                <table width="100%" cellpadding="3" cellspacing="3" border="0">
                	<tr>
                    	<td width="30%" align="right" valign="top"><b>Email : </b></td>
                        <td width="70%" align="left"><b><?php echo $list['Email'];?></b></td>
                    </tr>
                	<tr>
                    	<td width="30%" align="right" valign="top"><font color="#FF0000">* </font>Profile name : </td>
                        <td width="70%" align="left"><input type="text" style="width:265px;" name="profilename" value="<?php echo isset($_POST['profilename'])?$_POST['profilename']:$list['ProfileName'];?>" />
                        <?php
						if(isset($err_p) && !empty($err_p))
                            echo '<br><font color="#FF0000"><small><i>'.$err_p.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Full name : </td>
                        <td width="70%" align="left"><input type="text" style="width:265px;" name="fullname" value="<?php echo isset($_POST['fullname'])?$_POST['fullname']:$list['Name'];?>" /></td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Phone : </td>
                        <td width="70%" align="left"><input type="text" style="width:265px;" name="phone" value="<?php echo isset($_POST['phone'])?$_POST['phone']:$list['Phone'];?>"/></td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><font color="#FF0000">* </font>About me : </td>
                        <td width="70%" align="left"><textarea style="width:265px;" rows="4" name="abloutme"><?php echo isset($_POST['abloutme'])?$_POST['abloutme']:$list['AboutMe'];?></textarea>
                        <?php
                        if(isset($err_a) && !empty($err_a))
                           echo '<br><font color="#FF0000"><small><i>'.$err_a.'</i></small></font>';
                        ?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><font color="#FF0000">* </font>Interest : </td>
                        <td width="70%" align="left"><textarea style="width:265px;" rows="4" name="txtinterests"><?php echo isset($_POST['txtinterests'])?$_POST['txtinterests']:$list['Interests'];?></textarea>
                        <?php
                                if(isset($err_i) && !empty($err_i))
                                    echo '<br><font color="#FF0000"><small><i>'.$err_i.'</i></small></font>';
                                ?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Age : </td>
                        <td width="70%" align="left"><select name="slage">
                        	<?php
							$val = isset($_POST['slage'])?$_POST['slage']:$list['Age'];
							for($i=18; $i<76; $i++){
								$sel = ($val==$i)?' selected="selected"':'';
								echo '<option value="'.$i.'" '.$sel.'>'.$i.'</option>';
								}
							?>
                        </select></td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Gender : </td>
                        <td width="70%" align="left">
                        <?php
						if(isset($_POST['rdgender'])){
							if($_POST['rdgender']==1){
								$gen1 = ' checked="checked"';
								$gen2 = '';
								}
							elseif($_POST['rdgender']==2){
								$gen1 = '';
								$gen2 = ' checked="checked"';
								}
							}
						elseif($list['GenderID']==1){
							$gen1 = ' checked="checked"';
							$gen2 = '';
							}
						elseif($list['GenderID']==2){
							$gen1 = '';
							$gen2 = ' checked="checked"';
							}
						?>
                        <input type="radio" value="1" style="margin-left:0px; padding-left:0px;" <?php echo $gen1;?> name="rdgender"/>&nbsp;Male<input type="radio" value="2" style="margin-left:40px; padding-left:0px;" name="rdgender" <?php echo $gen2;?>/>&nbsp;Female</td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><font color="#FF0000">* </font>Country : </td>
                        <td width="70%" align="left"><select name="slcountry" id="slcountry">
                        	<?php
							$sel = isset($_POST['slcountry'])?$_POST['slcountry']:$list['CountryID'];
							$sqlcountry = 'select CountryID as Id, Country as LName from '.$table_prefix.'countries order by TopSorted desc, LName asc';
							dropdownlist($sqlcountry, $sel);
							?>
                        </select></td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><font color="#FF0000">* </font>State : </td>
                        <td width="70%" align="left"><select name="slcity" id="slcity">
                        	<?php
							$ctval = isset($_POST['slcountry'])?$_POST['slcountry']:$list['CountryID'];
							$cval = isset($_POST['slcity'])?$_POST['slcity']:$list['StateID'];
							$sql = 'select StateID as Id, State as LName from '.$table_prefix.'states where CountryID = '.intval($ctval).' order by TopSorted desc, LName asc';
							dropdownlist($sql, $cval);
							?>
                        </select></td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">City : </td>
                        <td width="70%" align="left"><input type="text" style="width:265px;" name="txtstate" value="<?php echo isset($_POST['txtstate'])?$_POST['txtstate']:'';?>" maxlength="255"/></td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Educations : </td>
                        <td width="70%" align="left"><select name="slEducation">
                        	<?php
							$sel = isset($_POST['slEducation'])?$_POST['slEducation']:$list['EducationID'];
							$sql = 'select EducationID as Id, '.$_SESSION['lang'].'Education as LName from '.$table_prefix.'educations order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select></td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Opcupation : </td>
                        <td width="70%" align="left"><input type="text" style="width:265px;" name="opcupation" value="<?php echo isset($_POST['opcupation'])?$_POST['opcupation']:'';?>" maxlength="255" /></td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Marital status : </td>
                        <td width="70%" align="left"><select name="slMarital">
                        	<?php
							$sel = isset($_POST['slMarital'])?$_POST['slMarital']:$list['MaritalStatusID'];
							$sql = 'select MaritalStatusID as Id, '.$_SESSION['lang'].'MaritalStatus as LName from '.$table_prefix.'maritalstatus order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select></td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Height : </td>
                        <td width="70%" align="left"><select name="slHeight">
                        	<?php
							$sel = isset($_POST['slHeight'])?$_POST['slHeight']:$list['HeightID'];
							$sql = 'select HeightID as Id, HeightDescription as LName from '.$table_prefix.'height order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select></td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Hair color : </td>
                        <td width="70%" align="left"><select name="slHairColor">
                        	<?php
							$sel = isset($_POST['slHairColor'])?$_POST['slHairColor']:$list['HairColorID'];
							$sql = 'select HairColorID as Id, '.$_SESSION['lang'].'HairColor as LName from '.$table_prefix.'haircolors order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select></td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Eyes color : </td>
                        <td width="70%" align="left"><select name="slEyeColor">
                        	<?php
							$sel = isset($_POST['slEyeColor'])?$_POST['slEyeColor']:$list['EyeColorID'];
							$sql = 'select EyeColorID as Id, '.$_SESSION['lang'].'EyeColor as LName from '.$table_prefix.'eyescolors order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select></td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Body type : </td>
                        <td width="70%" align="left"><select name="slBodyType">
                        	<?php
							$sel = isset($_POST['slBodyType'])?$_POST['slBodyType']:$list['BodyTypeID'];
							$sql = 'select BodyTypeID as Id, '.$_SESSION['lang'].'BodyType as LName from '.$table_prefix.'bodytypes order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select></td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Religion : </td>
                        <td width="70%" align="left"><select name="slReligion">
                        	<?php
							$sel = isset($_POST['slReligion'])?$_POST['slReligion']:$list['ReligionID'];
							$sql = 'select ReligionID as Id, '.$_SESSION['lang'].'Religion as LName from '.$table_prefix.'religions order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select></td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Smkoing : </td>
                        <td width="70%" align="left"><select name="slSmoking">
                        	<?php
							$sel = isset($_POST['slSmoking'])?$_POST['slSmoking']:$list['SmokingID'];
							$sql = 'select SmokingID as Id, '.$_SESSION['lang'].'Smoking as LName from '.$table_prefix.'smoking order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select></td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Drinking : </td>
                        <td width="70%" align="left"><select name="slDrinking">
                        	<?php
							$sel = isset($_POST['slDrinking'])?$_POST['slDrinking']:$list['DrinkingID'];
							$sql = 'select DrinkingID as Id, '.$_SESSION['lang'].'Drinking as LName from '.$table_prefix.'drinking order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select></td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Have Children : </td>
                        <td width="70%" align="left">
                        	<?php
							if(isset($_POST['rdhave'])){
								if($_POST['rdhave']==2){
									$rdhave1 = ' checked="checked"';
									$rdhave2 = '';
									}
								elseif($_POST['rdhave']==3){
									$rdhave1 = '';
									$rdhave2 = ' checked="checked"';
									}
								}
							elseif($list['HaveChildren']==2){
								$rdhave1 = ' checked="checked"';
								$rdhave2 = '';
								}
							elseif($list['HaveChildren']==3){
								$rdhave1 = '';
								$rdhave2 = ' checked="checked"';
								}
							?>
							<input type="radio" value="2" style="margin-left:0px; padding-left:0px;" <?php echo $rdhave1;?> name="rdhave"/>&nbsp;Yes<input type="radio" value="3" style="margin-left:40px; padding-left:0px;" name="rdhave" <?php echo $rdhave2;?>/>&nbsp;No
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Want Children : </td>
                        <td width="70%" align="left">
                        	<?php
							if(isset($_POST['rdwant'])){
								if($_POST['rdwant']==2){
									$rdwant1 = ' checked="checked"';
									$rdwant2 = '';
									}
								elseif($_POST['rdwant']==3){
									$rdwant1 = '';
									$rdwant2 = ' checked="checked"';
									}
								}
							elseif($list['WantChildren']==2){
								$rdwant1 = ' checked="checked"';
								$rdwant2 = '';
								}
							elseif($list['WantChildren']==3){
								$rdwant1 = '';
								$rdwant2 = ' checked="checked"';
								}
							?>
							<input type="radio" value="2" style="margin-left:0px; padding-left:0px;" name="rdwant" <?php echo $rdwant1;?>/>&nbsp;Yes<input type="radio" value="3" style="margin-left:40px; padding-left:0px;" name="rdwant" <?php echo $rdwant2;?>/>&nbsp;No
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">Willing To Travel : </td>
                        <td width="70%" align="left"><select name="sltravel">
                        	<?php
							$tval = isset($_POST['sltravel'])?$_POST['sltravel']:$list['WillingToTravel'];
							for($i=50; $i<501; $i++){
								$sel = ($tval==$i)?'selected="selected"':'';
								echo '<option value="'.$i.'" '.$sel.'>'.$i.'</option>';
								}
							?>
                        </select> kilomets</td>
                    </tr>
                </table>
            </div>
            <div style="width:49%; float:right">
            	<h3 style="margin-bottom:3px; padding-bottom:3px">Potential Matches</h3>
                <table width="100%" cellpadding="3" cellspacing="3" border="0">
                    <tr>
                    	<td width="27%" align="right" valign="top"><font color="#FF0000">* </font>About my match : </td>
                        <td width="73%" align="left"><textarea style="width:265px;" rows="4" name="abouth"><?php echo isset($_POST['abouth'])?$_POST['abouth']:$list['AboutMyMatch'];?></textarea></td>
                    </tr>
                    <tr>
                    	<td width="27%" align="right" valign="top">Match gender : </td>
                        <td width="73%" align="left"><?php
                                 if($_POST['mdgender']==1 || intval($list['MatchGenderID'])==1){
                                     $gen1 = ' checked="checked"';
                                     $gen2 = '';
                                     $gen3 = '';
                                     }
                                 elseif($_POST['mdgender']==2 || intval($list['MatchGenderID'])==2){
                                     $gen1 = '';
                                     $gen2 = ' checked="checked"';
                                     $gen3 = '';
                                     }
                                 elseif($_POST['mdgender']==0 || intval($list['MatchGenderID'])==0){
                                     $gen1 = '';
                                     $gen2 = '';
                                     $gen3 = ' checked="checked"';
                                     }
                                ?>
                                <input type="radio" value="1" style="margin-left:0px; padding-left:0px;" <?php echo $gen1;?> name="mdgender"/> Male<input type="radio" value="2" style="margin-left:40px; padding-left:0px;" name="mdgender" <?php echo $gen2;?>/> Female<input type="radio" value="0" style="margin-left:40px; padding-left:0px;" name="mdgender" <?php echo $gen3;?>/> All</td>
                    </tr>
                    <tr>
                                <td width="27%" align="right" valign="top">Match age : </td>
                                <td width="73%" align="left">
                                <select name="slagefrom">
                                    <?php
                                    for($i=18; $i<76; $i++){
                                        $val = isset($_POST['slagefrom'])?$_POST['slagefrom']:$list['MatchAgeFrom'];
                                        $sel = ($val==$i)?' selected="selected"':'';
                                        echo '<option value="'.$i.'" '.$sel.'>'.$i.'</option>';
                                        }
                                    ?>
                                </select><span style="margin-left:10px; margin-right:10px;"> to </span><select name="slageto">
                                    <?php
                                    for($i=18; $i<76; $i++){
                                        $val = isset($_POST['slageto'])?$_POST['slageto']:$list['MatchAgeTO'];
                                        $sel = ($val==$i)?' selected="selected"':'';
                                        echo '<option value="'.$i.'" '.$sel.'>'.$i.'</option>';
                                        }
                                    ?>
                                </select>
                                </td>
                            </tr>
                    <tr>
                    	<td width="27%" align="right" valign="top">Purpose to : </td>
                        <td width="73%" align="left"><select name="slDatingInterest">
                        	<?php
                                    $sel = isset($_POST['slDatingInterest'])?$_POST['slDatingInterest']:$list['DatingInterestID'];
                                    $sql = 'select DatingInterestID as Id, '.$_SESSION['lang'].'DatingInterest as LName from '.$table_prefix.'datinginterest order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
                                    ?>
                        </select></td>
                    </tr>
                    <tr>
                    	<td width="27%" align="right" valign="top">Match education : </td>
                        <td width="73%" align="left"><select name="mslEducation">
                        	<?php
                                    $sel = isset($_POST['mslEducation'])?$_POST['mslEducation']:$list['MatchEducationID'];
                                    $sql = 'select EducationID as Id, '.$_SESSION['lang'].'Education as LName from '.$table_prefix.'educations order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
                                    ?>
                        </select></td>
                    </tr>
                    <tr>
                    	<td width="27%" align="right" valign="top">Match marital : </td>
                        <td width="73%" align="left"><select name="mslMarital">
                        	<?php
                                    $sel = isset($_POST['mslMarital'])?$_POST['mslMarital']:$list['MatchMaritalStatusID'];
                                    $sql = 'select MaritalStatusID as Id, '.$_SESSION['lang'].'MaritalStatus as LName from '.$table_prefix.'maritalstatus order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
                                    ?>
                        </select></td>
                    </tr>
                    <tr>
                    	<td width="27%" align="right" valign="top">Match height : </td>
                        <td width="73%" align="left">
                        	<select name="mslHeightfrom">
                                    <?php
                                    $sel = isset($_POST['mslHeightfrom'])?$_POST['mslHeightfrom']:$list['MatchHeightIDFrom'];
                                    $sql = 'select HeightID as Id, HeightDescription as LName from '.$table_prefix.'height order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
                                    ?>
                                </select><span style="margin-left:10px; margin-right:10px;"><?php echo $to;?></span>
                                <select name="mslHeightto">
                                    <?php
                                    $sel = isset($_POST['mslHeightto'])?$_POST['mslHeightto']:$list['MatchHeightIDTo'];
                                    $sql = 'select HeightID as Id, HeightDescription as LName from '.$table_prefix.'height order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
                                    ?>
                                </select>
                        </td>
                    </tr>
                    <tr>
                    	<td width="27%" align="right" valign="top">Match body type : </td>
                        <td width="73%" align="left">
                        	<select name="mslBodyType">
                                    <?php
                                    $sel = isset($_POST['mslBodyType'])?$_POST['mslBodyType']:$list['MatchBodyStyleID'];
                                    $sql = 'select BodyTypeID as Id, '.$_SESSION['lang'].'BodyType as LName from '.$table_prefix.'bodytypes order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
                                    ?>
                                </select>
                        </td>
                    </tr>
                    <tr>
                    	<td width="27%" align="right" valign="top">Match regilion : </td>
                        <td width="73%" align="left">
                        	<select name="mslReligion">
                                    <?php
                                    $sel = isset($_POST['mslReligion'])?$_POST['mslReligion']:$list['MatchReligionID'];
                                    $sql = 'select ReligionID as Id, '.$_SESSION['lang'].'Religion as LName from '.$table_prefix.'religions order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
                                    ?>
                                </select>
                        </td>
                    </tr>
                    <tr>
                    	<td width="27%" align="right" valign="top">Match Smoking : </td>
                        <td width="73%" align="left">
                        	<select name="mslSmoking">
                                    <?php
                                    $sel = isset($_POST['mslSmoking'])?$_POST['mslSmoking']:$list['MatchSmokingID'];
                                    $sql = 'select SmokingID as Id, '.$_SESSION['lang'].'Smoking as LName from '.$table_prefix.'smoking order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
                                    ?>
                                </select>
                        </td>
                    </tr>
                    <tr>
                    	<td width="27%" align="right" valign="top">Match drinking : </td>
                        <td width="73%" align="left">
                        	<select name="mslDrinking">
                                    <?php
                                    $sel = isset($_POST['mslDrinking'])?$_POST['mslDrinking']:$list['MatchDrinkingID'];
                                    $sql = 'select DrinkingID as Id, '.$_SESSION['lang'].'Drinking as LName from '.$table_prefix.'drinking order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
									$chk = ($list['MatchBeSameLocation']==1)?' checked="checked"':'';
                                    ?>
                                </select>
                        </td>
                    </tr>
                    <tr>
                                <td width="27%" align="right" valign="top">&nbsp;</td>
                                <td width="73%" align="left">
                                <input type="checkbox" style="margin-left:0px; padding-left:0px;" name="matchsame" <?php echo $chk;?>/>&nbsp;<i>Match the same hometown</i>
                                <?php
                                if(isset($err_t) && !empty($err_t))
                                    echo '<br><font color="#FF0000"><small><i>'.$err_t.'</i></small></font>';
                                ?>
                                </td>
                            </tr>
                </table>
            </div>
            <p style="clear:both"></p>
			<table width="100%" border="0" cellpadding="3" cellspacing="3">
				<tr>
					<td width="50%" align="right">&nbsp;</td>
					<td width="50%" align="left"><input type="submit" name="smupdate" class="massbutton" value="Save Changes"/></td>
				</tr>
			</table></form><br />
			<?php  }
			else echo '<p style="padding:10px;">'.$norecord.'</p>';
			}
		else echo '<p style="padding:10px;">Data incorrect !</p>';
		?>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>