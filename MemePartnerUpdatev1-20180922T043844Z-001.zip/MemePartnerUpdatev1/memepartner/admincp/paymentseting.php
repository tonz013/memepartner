<?php
require_once "../includes/config.php";
require_once "../includes/database.php";
require_once "include/functions.php";
if(intval($_SESSION['admincp'])==0 || !$_SESSION['admincp']){
	header('Location: login.php');
	exit();
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smsave'])){
	if(empty($_POST['PaymentType']) || trim($_POST['PaymentType'])=='')
		$err_s = 'Please enter payment name';
	elseif(empty($_POST['APIKey']) || trim($_POST['APIKey'])=='')
		$err_1s = 'Please enter API key';
	elseif(empty($_POST['APIPassword']) || trim($_POST['APIPassword'])=='')
		$err_d = 'Please enter API password';
	elseif(empty($_POST['APISignature']) || trim($_POST['APISignature'])=='')
		$err_f = 'Please enter API signature';
	else{
		$upimage = !empty($_POST['ButtonImg'])?", ButtonImg = '".mysql_real_escape_string(htmlentities(trim($_POST['ButtonImg'])))."'":'';
		$sqlu = 'update '.$table_prefix."paymentprovide set PaymentType = '".mysql_real_escape_string(htmlentities(trim($_POST['PaymentType'])))."', APIKey = '".mysql_real_escape_string(htmlentities(trim($_POST['APIKey'])))."', APIPassword = '".mysql_real_escape_string(htmlentities(trim($_POST['APIPassword'])))."', APISignature = '".mysql_real_escape_string(htmlentities(trim($_POST['APISignature'])))."' ".$upimage.", APIMode = '".mysql_real_escape_string(htmlentities(trim($_POST['APIMode'])))."' where Id = 1";
		$qryu = mysql_query($sqlu) or die(mysql_error());
		if(!$qryu)
			$error = 'Can not save your setting';
		else $success = 'Your settings saved successfull.';
		}
	}
$mmenu=5;
$title = 'Payment settings';
?>
<link href="../css/admincss.css" type="text/css" rel="stylesheet" />
<div class="admincontent">
	<p class="contentop"><?php echo $title;?></p>
    <div class="contenbody">
    	<form action="" method="post">
            <?php
			if(isset($error) && !empty($error))
				echo '<br><font color="#FF0000" style="text-align:left"><small>'.$error.'</small></font><br>';
			if(isset($success) && !empty($success))
				echo '<br><font color="#009933" style="text-align:left"><small>'.$success.'</small></font><br>';
			$sqls = 'select PaymentType, APIKey, APIPassword, APISignature, APISucrect, CurrencyCode, ReturnURL, CancelURL, ButtonImg, APIMode from '.$table_prefix.'paymentprovide where Id = 1';
			$qrys = mysql_query($sqls);
			if(!$qrys)
				echo '<p>Can not load payment method</p>';
			elseif(mysql_num_rows($qrys)>0){
				$rows=mysql_fetch_array($qrys);
			?><br />
        	<table width="100%" cellpadding="3" cellspacing="3" border="0">
                    <tr>
                        <td width="30%" align="right" valign="top"><font color="#FF0000">*</font> Payment name : </td>
                        <td width="70%" align="left"><input type="text" size="40" maxlength="255" name="PaymentType" value="<?php echo isset($_POST['PaymentType'])?$_POST['PaymentType']:$rows['PaymentType'];?>" />
                        <?php
						if(isset($err_s) && !empty($err_s))
							echo '<br><font color="#FF0000"><small><i>'.$err_s.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                        <td width="30%" align="right" valign="top"><font color="#FF0000">* </font>API Key/Username : </td>
                        <td width="70%" align="left"><input type="text" size="40" maxlength="255" name="APIKey" value="<?php echo isset($_POST['APIKey'])?$_POST['APIKey']:$rows['APIKey'];?>" />
                        <?php
						if(isset($err_1s) && !empty($err_1s))
							echo '<br><font color="#FF0000"><small><i>'.$err_1s.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                        <td width="30%" align="right" valign="top"><font color="#FF0000">* </font>API Password : </td>
                        <td width="70%" align="left"><input type="text" size="40" maxlength="255" name="APIPassword" value="<?php echo isset($_POST['APIPassword'])?$_POST['APIPassword']:$rows['APIPassword'];?>" />
                        <?php
						if(isset($err_d) && !empty($err_d))
							echo '<br><font color="#FF0000"><small><i>'.$err_d.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                        <td width="30%" align="right" valign="top"><font color="#FF0000">* </font>API Signature : </td>
                        <td width="70%" align="left"><input type="text" size="100" name="APISignature" value="<?php echo isset($_POST['APISignature'])?$_POST['APISignature']:$rows['APISignature'];?>" />
                        <?php
						if(isset($err_f) && !empty($err_f))
							echo '<br><font color="#FF0000"><small><i>'.$err_f.'</i></small></font>';
						?></td>
                    </tr>
                    <tr>
                        <td width="30%" align="right" valign="top">API Sucrect : </td>
                        <td width="70%" align="left"><input type="text" size="40" name="APISucrect" value="<?php echo isset($_POST['APISucrect'])?$_POST['APISucrect']:$rows['APISucrect'];?>" />
                        </td>
                    </tr>
                    <tr>
                        <td width="30%" align="right" valign="top">Curency Code : </td>
                        <td width="70%" align="left"><select name="CurrencyCode">
                            	<option value="USD" <?php echo ($curu=='USD')?' selected="selected"':'';?>>USD</option>
                                <option value="VND"<?php echo ($curu=='VND')?' selected="selected"':'';?>>VND</option>
                                <option value="CAD"<?php echo ($curu=='CAD')?' selected="selected"':'';?>>CAD</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td width="30%" align="right" valign="top">Return URL : </td>
                        <td width="70%" align="left"><input type="text" size="40" maxlength="255" name="ReturnURL" value="<?php echo isset($_POST['ReturnURL'])?$_POST['ReturnURL']:$rows['ReturnURL'];?>" disabled="disabled" />
                        </td>
                    </tr>
                    <tr>
                        <td width="30%" align="right" valign="top">Cancel URL : </td>
                        <td width="70%" align="left"><input type="text" size="40" maxlength="255" name="CancelURL" value="<?php echo isset($_POST['CancelURL'])?$_POST['CancelURL']:$rows['CancelURL'];?>" disabled="disabled" />
                       </td>
                    </tr>
                    <tr>
                        <td width="30%" align="right" valign="top">Button Image : </td>
                        <td width="70%" align="left">
                        <?php echo isset($_POST['ButtonImg'])?$_POST['ButtonImg']:html_entity_decode($rows['ButtonImg']);?><br />
                        <input type="text" size="100" name="ButtonImg" value=""/>
                        <?php
						if(isset($err_e) && !empty($err_e))
							echo '<br><font color="#FF0000"><small><i>'.$err_e.'</i></small></font>';
						?></td>
                    </tr>
                    <tr>
                        <td width="30%" align="right" valign="top">API Mode : </td>
                        <td width="70%" align="left"><input type="text" size="10" maxlength="255" name="APIMode" value="<?php echo isset($_POST['APIMode'])?$_POST['APIMode']:$rows['APIMode'];?>" />
                        </td>
                    </tr>
                    <tr>
                        <td width="30%" align="right">&nbsp;</td>
                        <td width="70%" align="left"><input type="submit" name="smsave" value="Save setting"/>&nbsp;</td>
                    </tr>
                </table>
                <?php
				}
			?>
            </form>
    <p style="clear:both">&nbsp;</p>
    </div><p style="clear:both">&nbsp;</p>
</div>
<?php
mysql_close();