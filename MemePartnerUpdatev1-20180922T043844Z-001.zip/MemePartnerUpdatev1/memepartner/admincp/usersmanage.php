<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/usersmanage.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
if(isset($_GET['uid']) && intval($_GET['uid'])>0 && isset($_GET['a']) && $_GET['a']=='d'){
	$str = '';
	if(!empty($_SERVER['QUERY_STRING'])){
		foreach($_GET as $gname => $vgname){
			if($gname!='uid' && $gname!='a')
				$str .= $gname.'='.$vgname.'&';
			}
		}
	$str = !empty($str)?'?'.substr($str,0,-1):'';
	$ptdel = getPhotosUnlink(getUserImgs($_GET['uid']));
	if(!removeProfiles(intval($_GET['uid'])))
		$error = $errordata;
	else{
		if(count($ptdel)>0)
			foreach($ptdel as $vptdel)
				unlink(dirname(dirname(__FILE__)).'/'.$uploaddir.'/'.$vptdel);
		mysql_close();
		header('Location: '.$base_url.'admincp/usersmanage.php'.$str);
		exit();
		}
	}
$purl = '';
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smfind'])){
	if(empty($_POST['txtname']) || intval($_POST['txtoptions'])==0)
		$error = 'Please enter the key and select one of these options to find !';
	else{
		$str = '';
		if(!empty($_POST['txtname']))
			$str .= 'k='.urlencode($_POST['txtname']).'&';
		if(intval($_POST['txtoptions'])>0)
			$str .= 'o='.$_POST['txtoptions'].'&';
		$str = substr($str, 0, -1);
		mysql_close();
		header('Location: '.$base_url.'admincp/usersmanage.php?'.$str);
		exit();
		}
	}
$strsearch = '';
if(isset($_GET['o']) && intval($_GET['o'])>0 && isset($_GET['k']) && !empty($_GET['k'])){
	if(intval($_GET['o'])==1) $strsearch .= 'u.Age = '.intval($_GET['k'])." and ";
	if(intval($_GET['o'])==2) $strsearch .= "u.City like '%".mysql_real_escape_string(urldecode($_GET['k']))."%' and ";
	if(intval($_GET['o'])==3) $strsearch .= "u.Email like '%".mysql_real_escape_string(urldecode($_GET['k']))."%' and ";
	if(intval($_GET['o'])==4) $strsearch .= "u.ProfileName like '%".mysql_real_escape_string(urldecode($_GET['k']))."%' and ";
	$purl .= 'k='.$_GET['k'].'&o='.$_GET['o'].'&'; 
	}
$purl = (!empty($purl))?'?'.substr($purl, 0, -1):'';
$title = 'AdminCP - Users Management';
require_once 'include/header.php';
?>
<script language="javascript" type="text/javascript">
function cfmDel(str){
	if(confirm('Are you sure you want to delete ?'))
		window.location.href = str;
	return;
	}
</script>
<div class="admincontent">
	<p class="contentop">Users Management</p>
    <div class="contenbody">
    	<form action="" method="post">
        	<p align="center"><i><input type="text" name="txtname" style="width:265px; font-style:italic" placeholder="Search for" value="<?php echo (isset($_GET['k']) && !empty($_GET['k']))?urldecode($_GET['k']):'';?>" /><span style="margin-left:30px;">By option: </span>
            <select name="txtoptions" style="font-style:italic">
            	<option value="0">- - All - -</option>
            	<option value="1" <?php echo (intval($_GET['o'])==1)?' selected="selected"':'';?>>Age</option>
                <option value="2" <?php echo (intval($_GET['o'])==2)?' selected="selected"':'';?>>City</option>
                <option value="3" <?php echo (intval($_GET['o'])==3)?' selected="selected"':'';?>>Email</option>
                <option value="4" <?php echo (intval($_GET['o'])==4)?' selected="selected"':'';?>>Profile name</option>
            </select>
            <input type="submit" name="smfind" value="Search" style="margin-left:20px;" class="massbutton"/></i>
            </p>
    	<?php
		$config['showeachside'] = 4;
		$config['per_page'] = 30;
		$config['js_numrows_page'] = countAllUsers($strsearch, '');
		$config['curpage'] = empty($_GET['p'])?1:$_GET['p'];
		$config['rs_start'] = ($config['curpage']*$config['per_page'])-$config['per_page'];
		if($config['js_numrows_page'] < $config['per_page'])
			$config['per_page'] = $config['js_numrows_page'];
		$config['cururl'] = $base_url.'admincp/usersmanage.php'.$purl;
		$rs_maxpage = ceil($config['js_numrows_page']/$config['per_page']);
		$paging = Pagination($config);
		if(isset($error) && !empty($error))
			echo '<p style="margin:0px; padding:10px"><font color="#FF0000"><i>'.$error.'</i></font></p>';
		if(isset($succ) && !empty($succ))
			echo '<p style="margin:0px; padding:10px"><font color="#009933">'.$succ.'</font></p>';
		$list = getUsersManage($strsearch, " limit ".$config['rs_start'].", ".$config['per_page']);
		if(mysql_num_rows($list)>0){
		?>
        <p><span style="padding:0px 0px 0px 10px; float:left"><i>Have <b><?php echo $config['js_numrows_page'];?></b> record(s)</i></span><span style="padding:0px 0px 0px 10px; float:right"><i>Display <b><?php echo $config['curpage'];?></b> of <b><?php echo $rs_maxpage;?></b> pages&nbsp;&nbsp;</i></span></p>
        <p style="clear:both; height:0px">&nbsp;</p>
        <table width="100%" border="0" cellpadding="0" cellspacing="0">
        	<tr bgcolor="#f2f2f2">
            	<td width="5%" class="headrows1" style="border-top:1px solid #d6d8e5" align="center">Gender</td>
                <td width="16%" class="headrows2" style="border-top:1px solid #d6d8e5" align="left">Profile name</td>
                <td width="22%" class="headrows2" style="border-top:1px solid #d6d8e5" align="left">Email</td>
                <td width="4%" class="headrows2" style="border-top:1px solid #d6d8e5" align="center">IsVIP</td>
                <td width="4%" class="headrows2" style="border-top:1px solid #d6d8e5" align="center">Age</td>
                <td width="25%" class="headrows2" style="border-top:1px solid #d6d8e5" align="left">Address</td>
                <td width="4%" class="headrows2" style="border-top:1px solid #d6d8e5" align="center">Photo</td>
                <td width="5%" class="headrows2" style="border-top:1px solid #d6d8e5" align="center">Message</td>
                <td width="12%" class="headrows2" colspan="3" style="border-top:1px solid #d6d8e5" align="center">Actions</td>
            </tr>
            <?php
			$i=0;
			$rturl = (!empty($_SERVER['QUERY_STRING']))?'?'.$_SERVER['QUERY_STRING'].'&':'?';
			while($rows = mysql_fetch_array($list)){
				$gender = ($rows['GenderID']==1)?'male_icon.gif':'female_icon.gif';
				$uadd = (!empty($rows['City']))?$rows['City'].', '.$rows['State'].', '.$rows['Country']:$rows['State'].', '.$rows['Country'];
				$ofmess = countMessOfUser($rows['UserID']);
				?>
                <tr>
                    <td width="5%" class="headrows3" valign="top" style="text-align:center"><img src="<?php echo $base_url.'imgs/'.$gender;?>" border="0" /></td>
                    <td width="16%" class="headrows4" valign="top" align="left"><a href="editprofile.php?uid=<?php echo $rows['UserID'];?>"><?php echo $rows['ProfileName'];?></a></td>
                    <td width="22%" class="headrows4" valign="top" align="left"><a href="sendmail.php<?php echo $rturl.'uid='.$rows['UserID'];?>"><?php echo $rows['Email'];?></a></td>
                    <td width="4%" class="headrows4" valign="top" align="center"><input type="checkbox" disabled="disabled" value="<?php echo $vlist;?>"/></td>
                    <td width="4%" class="headrows4" valign="top" align="center"><?php echo $rows['Age'];?></td>
                    <td width="25" class="headrows4" valign="top" align="left"><?php echo $uadd;?></td>
                    <td width="4%" class="headrows4" valign="top" align="center"><?php echo countPhotosOfUser($rows['UserID']);?></td>
                    <td width="5%" class="headrows4" valign="top" align="center"><?php echo $ofmess['sent'].'/'.$ofmess['rece'];?></td>
                    <td width="4%" class="headrows4" valign="top" align="center"><a href="banuser.php?uid=<?php echo $rows['UserID'];?>">Ban</a></td>
                    <td width="4%" class="headrows4" valign="top" align="center"><a href="editprofile.php?uid=<?php echo $rows['UserID'];?>">Edit</a></td>
                    <td width="4%" class="headrows4" valign="top" align="center"><a href="javascript:cfmDel('<?php echo $rturl.'uid='.$rows['UserID'].'&a=d';?>')">Del</a></td>
                </tr>
                <?php
				$i++;
				}
			?>
        </table>
        <p id="paging" style="clear:both; margin-right:0px; text-align:center"><?php echo $paging;?></p>
        <?php  }
		else echo '<p style="padding:10px;">'.$norecord.'</p>';
		?>
        </form>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>