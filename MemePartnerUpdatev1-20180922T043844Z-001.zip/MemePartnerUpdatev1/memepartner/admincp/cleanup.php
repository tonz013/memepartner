<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/cleanup.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smcleanup'])){
	$date = date('y-m-d');
	if(intval($_POST['rmvmess'])>0){
		$newdate = strtotime ( '-'.$_POST['rmvmess'].' day' , strtotime ( $date ) ) ;
		$newdate = date ( 'Y-m-d' , $newdate );
		if(!removeOldMess($newdate))
			$error = $errordata.' oldmess';
		}
	if(intval($_POST['rmvsignal'])>0){
		$newdate = strtotime ( '-'.$_POST['rmvsignal'].' day' , strtotime ( $date ) ) ;
		$newdate = date ( 'Y-m-d' , $newdate );
		if(!removeOldSignals($newdate))
			$error = $errordata.' old signal';
		}
	if(intval($_POST['rmvinacc'])>0){
		$newdate = strtotime ( '-'.$_POST['rmvinacc'].' day' , strtotime ( $date ) ) ;
		$newdate = date ( 'Y-m-d' , $newdate );
		if(!removeInactiveUsers($newdate))
			$error = $errordata.' user';
		else{
			$unlink = getInactiveImgs($newdate);
			if(count($unlink)>0){
				foreach($unlink as $hval)
					unlink(dirname(dirname(__FILE__)).'/'.$uploaddir.'/'.$hval);
				}
			}
		}
	if($_POST['rmvdelete']=='on'){
		if(!removeMessDeleted())
			$error = $errordata;
		}
	if($_POST['rmvnotcomp']=='on'){
		$newdate = strtotime ( '-1 day' , strtotime ( $date ) ) ;
		$newdate = date ( 'Y-m-d' , $newdate );
		if(!removeAccountNoComplete($newdate))
			$error = $errordata;
		}
	}
$title = 'AdminCP - Clean Up';
require_once 'include/header.php';
?>
<div class="admincontent">
	<p class="contentop">Clean Up: Messages, Signals, Inactive users</p>
    <div class="contenbody"><bR />
    <?php
	if(isset($error) && !empty($error))
		echo '<p style="margin:0px; padding:5px 10px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
	?>
    	<form action="" method="post">
        <table width="100%" cellpadding="3" cellspacing="3">
        	<tr>
            	<td width="30%" align="right">Delete messages that are</td>
                <td width="70%" align="left"><input type="text" size="10" style="text-align:center" value="365" name="rmvmess" /> days old.</td>
            </tr>
            <tr>
            	<td width="30%" align="right">Delete Signals that are</td>
                <td width="70%" align="left"><input type="text" size="10" style="text-align:center" value="30" name="rmvsignal" /> days old.</td>
            </tr>
            <tr>
            	<td width="30%" align="right">Delete closed accounts that have been closed for</td>
                <td width="70%" align="left"><input type="text" size="10" style="text-align:center" value="365" name="rmvinacc" /> days old.</td>
            </tr>
            <tr>
            	<td width="30%" align="right">&nbsp;</td>
                <td width="70%" align="left"><input type="checkbox" style="margin-left:0px; padding-left:0px" checked="checked" name="rmvdelete" /> Remove messages have been deleted by memebers</td>
            </tr>
            <tr>
            	<td width="30%" align="right">&nbsp;</td>
                <td width="70%" align="left"><input type="checkbox" style="margin-left:0px; padding-left:0px" checked="checked" name="rmvnotcomp" /> Remove accounts not complete register</td>
            </tr>
            <tr>
            	<td width="30%" align="right">&nbsp;</td>
                <td width="70%" align="left"><input type="submit" class="massbutton" name="smcleanup"/></td>
            </tr>
        </table><br />
        </form>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>