<?php
require_once "../includes/config.php";
require_once "../includes/database.php";
require_once "include/functions.php";
$sqls = "select Prices, Block from ".$table_prefix."prices where Id = ".$_GET['st'];
$myrs = mysql_query($sqls);
$myrow = mysql_fetch_array($myrs);
?>
<h4>Update Value</h4>
            <form action="" method="post">
            <table width="100%" cellpadding="3" cellspacing="3">
            	<tr>
                	<td width="30%" align="right" valign="top">Price of service:</td>
                    <td width="70%" align="left"><input type="text" size="10" id="newval" name="newval" value="<?php echo $myrow['Prices'];?>" maxlength="4" /> <?php echo $currency;?></td>
                </tr>
                <tr>
                	<td width="30%" align="right" valign="top">Duration:</td>
                    <td width="70%" align="left"><input type="text" size="10" id="vnvalue" name="vnvalue" value="<?php echo $myrow['Block'];?>" maxlength="3" /> month.</td>
                </tr>
                <tr>
                	<td width="30%" align="right">&nbsp;</td>
                    <td width="70%" align="left"><input type="submit" name="smupdate" class="massbutton" value="Save" />&nbsp;<input type="submit" name="smcancel" class="massbutton" value="Cancel" /></td>
                </tr>
            </table><input type="hidden" id="hddid" name="hddid" value="<?php echo $_GET['st'];?>" /></form>