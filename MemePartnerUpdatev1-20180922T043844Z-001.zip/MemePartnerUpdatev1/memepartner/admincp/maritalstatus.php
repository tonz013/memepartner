<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/maritalstatus.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
$dipadd = 'style="display:none"';
$dipedit = 'style="display:none"';
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smcancel'])){
	mysql_close();
	header('Location: '.$base_url.'admincp/maritalstatus.php');
	exit();
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smadd'])){
	if(empty($_POST['envalue'])){
		$err_e = 'Please enter English value';
		$dipadd = '';
		$dipedit = 'style="display:none"';
		}
	elseif(!addNewValue(array('L1MaritalStatus' => "'".mysql_real_escape_string($_POST['envalue'])."'", 'L2MaritalStatus' => "'".mysql_real_escape_string($_POST['vnvalue'])."'", 'L3MaritalStatus'=>"''", 'L4MaritalStatus'=>"''", 'TopSorted'=>0), $table_prefix.'maritalstatus')){
		$error = $errordata;
		$dipadd = '';
		$dipedit = 'style="display:none"';
		}
	else{
		mysql_close();
		header('Location: '.$base_url.'admincp/maritalstatus.php');
		exit();
		}
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smupdate'])){
	if(empty($_POST['envalue'])){
		$err_e = 'Please enter English value';
		$dipedit = '';
		$dipadd = 'style="display:none"';
		}
	elseif(!updValues(array('L1MaritalStatus' => "'".mysql_real_escape_string($_POST['envalue'])."'", 'L2MaritalStatus' => "'".mysql_real_escape_string($_POST['vnvalue'])."'"), $table_prefix.'maritalstatus', 'MaritalStatusID = '.intval($_POST['hddid']))){
		$error = $errordata;
		$dipedit = '';
		$dipadd = 'style="display:none"';
		}
	else{
		mysql_close();
		header('Location: '.$base_url.'admincp/maritalstatus.php');
		exit();
		}
	}
if(isset($_GET['id']) && intval($_GET['id'])>0 && isset($_GET['a']) && $_GET['a']=='d'){
	if(!delValue('MaritalStatusID = '.intval($_GET['id']), $table_prefix.'maritalstatus'))
		$error = $errordata;
	else{
		mysql_close();
		header('Location: '.$base_url.'admincp/maritalstatus.php');
		exit();
		}
	}
$title = 'AdminCP - Update Marital status';
require_once 'include/header.php';
?>
<div class="admincontent">
	<p class="contentop">Update Marital status</p>
    <div class="contenbody">
    	<div style="width:50%; float:left">
    	
    	<?php
		if(isset($error) && !empty($error))
			echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
		$list = getListed(array('MaritalStatusID' => 'Id', 'L1MaritalStatus' => 'L1Value', 'L2MaritalStatus' => 'L2Value'), array($table_prefix.'maritalstatus', 'Id'));
		if(count($list)>0){
		?>
        <table width="100%" border="0" cellpadding="0" cellspacing="0">
        	<tr bgcolor="#f2f2f2">
            	<td width="2%" class="headrows1" style="border-top:1px solid #d6d8e5">No.</td>
                <td width="86%" class="headrows2" style="border-top:1px solid #d6d8e5">EN Values</td>
                <td width="12%" class="headrows2" colspan="2" style="border-top:1px solid #d6d8e5; border-right:1px solid #d6d8e5">Actions</td>
            </tr>
            <?php
			$i=1;
			while($rows=mysql_fetch_array($list)){
				?>
                <tr>
                    <td width="2%" class="headrows3" valign="top"><?php echo $i;?></td>
                    <td width="86%" class="headrows4" align="left"><?php echo $rows['L1Value'];?></td>
                    <td width="6%" class="headrows4" align="center"><a href="javascript:void(0)" onclick="adclkActions(<?php echo $rows['Id'];?>,'<?php echo $rows['L1Value'];?>','<?php echo $rows['L2Value'];?>',1)"><i>Edit</i></a></td>
                    <td width="6%" class="headrows4" align="center" style="border-right:1px solid #d6d8e5"><a href="javascript:void(0)" onclick="confirmDel('<?php echo $base_url.'admincp/maritalstatus.php?id='.$rows['Id'].'&a=d';?>', 'Do you want to delete ?')"><i>Del</i></a></td>
                </tr>
                <?php
				$i++;
				}
			?>
            <tr>
            	<td width="20%" style="padding:20px" colspan="7" align="center"><input type="button" name="smadnew" class="massbutton" value="Add new" onclick="adclkActions(0,'','',2)" /></td>
            </tr>
        </table>
        <?php }
		else echo '<p style="padding:10px;">'.$norecord.'</p>';
		?>
        
        </div>
        <div style="width:48%; float:right">
        	<span id="frmEdit" <?php echo $dipedit;?>>
        	<h4>Update Value</h4>
            <form action="" method="post">
            <table width="100%" cellpadding="3" cellspacing="3">
            	<tr>
                	<td width="30%" align="right" valign="top">English value:</td>
                    <td width="70%" align="left"><input type="text" size="40" id="envalue" name="envalue" value="<?php echo isset($_POST['envalue'])?$_POST['envalue']:'';?>" />
                    <?php
					if(isset($err_e) && !empty($err_e))
						echo '<br><small><font color="#FF0000"><i>'.$err_e.'</i></font></small>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="30%" align="right">&nbsp;</td>
                    <td width="70%" align="left"><input type="submit" name="smupdate" class="massbutton" value="Save" />&nbsp;<input type="submit" name="smcancel" class="massbutton" value="Cancel" /></td>
                </tr>
            </table><input type="hidden" id="hddid" name="hddid" />
            </form>
            </span>
            <span id="frmnew" <?php echo $dipadd;?>>
        	<h4>Add New Value</h4>
            <form action="" method="post">
            <table width="100%" cellpadding="3" cellspacing="3">
            	<tr>
                	<td width="30%" align="right" valign="top">English value:</td>
                    <td width="70%" align="left"><input type="text" size="40" id="envalue" name="envalue" value="<?php echo isset($_POST['envalue'])?$_POST['envalue']:'';?>" />
                    <?php
					if(isset($err_e) && !empty($err_e))
						echo '<br><small><font color="#FF0000"><i>'.$err_e.'</i></font></small>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="30%" align="right">&nbsp;</td>
                    <td width="70%" align="left"><input type="submit" name="smadd" class="massbutton" value="Add" />&nbsp;<input type="submit" name="smcancel" class="massbutton" value="Cancel" /></td>
                </tr>
            </table>
            </form>
            </span>
        </div>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>