<?php
require_once "../includes/config.php";
require_once "../includes/database.php";
require_once "include/functions.php";
if(intval($_SESSION['admincp'])==0 || !$_SESSION['admincp']){
	header('Location: login.php');
	exit();
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smsave'])){
	$eror = false;
	$filename = '';
	if(!empty($_FILES['logo']['name'])){
		list($width, $height, $type, $w) = getimagesize($_FILES['logo']['tmp_name']);
		if($width>300){
			$error = 'Max width is 300px';
			$eror = true;
			}
		elseif($height!=64){
			$error = 'Logo height is 64px';
			$eror = true;
			}
		elseif(file_exists('../fuploads/'.$_FILES['logo']['name'])){
			$rand_string='';
			$pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
			for ($i=0; $i < 8; $i++)
				$rand_string .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
			$extension = pathinfo($_FILES['logo']['name']);
			$extension = $extension['extension'];
			$filename = $rand_string.'.'.$extension;
			if(!move_uploaded_file($_FILES['logo']['tmp_name'],dirname(dirname(__FILE__)).'/fuploads/'.$filename)){
				$error = 'Can not upload file';
				$eror = true;
				}
			}
		elseif(!move_uploaded_file($_FILES['logo']['tmp_name'],dirname(dirname(__FILE__)).'/fuploads/'.$_FILES['logo']['name'])){
			$error = 'Can not upload file';
			$eror = true;
			}
		else $filename = $_FILES['logo']['name'];
		}
	if($eror==false && !empty($filename)){
		$sqlu = 'update '.$table_prefix."site_settings set Value = '".$filename."' where Variable = 'logo'";
		$qryu = mysql_query($sqlu);
		if(!$qryu){
			$eror = true;
			$error = 'Can not update logo';
			}
		}
	if($eror==false){
		if(empty($_POST['sitename']) || trim($_POST['sitename'])=='')
			$err_s = 'Please enter site name';
		elseif(empty($_POST['slogan']) || trim($_POST['slogan'])=='')
			$err_1s = 'Please enter slogan of website';
		elseif(empty($_POST['totallogin']) || intval($_POST['totallogin'])==0)
			$err_d = 'Please enter num of login failed, it\'s a number interger';
		elseif(empty($_POST['filetype']) || trim($_POST['filetype'])=='')
			$err_f = 'Please enter types file upload';
		elseif(empty($_POST['max_size']) || intval($_POST['max_size'])==0)
			$err_ms = 'Please enter max file size alow upload, it\'s a number interger';
		elseif(empty($_POST['max_height']) || intval($_POST['max_height'])==0)
			$err_mh = 'Please enter max height of image upload, it\'s a number interger';
		elseif(empty($_POST['max_width']) || intval($_POST['max_width'])==0)
			$err_mw = 'Please enter max width of image upload, it\'s a number interger';
		elseif(empty($_POST['strfoot']) || trim($_POST['strfoot'])=='')
			$err_c = 'Please enter copyright text';
		elseif(empty($_POST['adminemail']) || trim($_POST['adminemail'])=='')
			$err_e = 'Please enter admin emai';
		elseif(!valid_email(trim($_POST['adminemail'])))
			$err_e = 'Email address invalid';
		elseif(empty($_POST['maxemail']) || intval($_POST['maxemail'])==0)
			$err_ses = 'Please enter max email send/received per day, it\'s a number interger';
		elseif(empty($_POST['numof_record_perpage']) || intval($_POST['numof_record_perpage'])==0)
			$err_p = 'Please enter num of record per page, it\'s a number interger';
		else{
			foreach($_POST as $pkey => $pval){
				if($pkey!='smsave'){
					$sqlu = 'update '.$table_prefix."site_settings set Value = '".mysql_real_escape_string(htmlentities(trim($pval)))."' where Variable = '".$pkey."'";
					$qryu = mysql_query($sqlu);
					if(!$qryu)
						$err = 1;
					}
				if($err==1){
					$error = 'Can not update setting value';
					break;
					}
				}
			if($err!=1)
				$success = 'Your settings saved successfull.';
			}
		}
	}
$mmenu=5;
$title = 'Site settings';
?>
<link href="../css/admincss.css" type="text/css" rel="stylesheet" />
<div class="admincontent">
	<p class="contentop"><?php echo $title;?></p>
    <div class="contenbody">
    	<form action="" method="post" enctype="multipart/form-data">
            <?php
			if(isset($error) && !empty($error))
				echo '<br><font color="#FF0000" style="text-align:left"><small>'.$error.'</small></font><br>';
			if(isset($success) && !empty($success))
				echo '<br><font color="#009933" style="text-align:left"><small>'.$success.'</small></font><br>';
			$sqls = 'select Variable, Value from '.$table_prefix.'site_settings where IsRead = 0';
			$qrys = mysql_query($sqls);
			if(!$qrys)
				echo '<p>Can not load config data</p>';
			elseif(mysql_num_rows($qrys)>0){
				while($rows=mysql_fetch_array($qrys)){
					$setting[$rows['Variable']] = $rows['Value'];
					}
				$curu = isset($_POST['unit'])?$_POST['unit']:$setting['unit'];
			?><br />
        	<table width="100%" cellpadding="3" cellspacing="3" border="0">
            		<tr>
                        <td width="40%" align="right" valign="middle">Logo : </td>
                        <td width="60%" align="left">
                        <img src="../<?php echo 'fuploads/'.$logo;?>" border="0" /><br />
                        <input type="file" size="40" name="logo"/>
                        <?php
						if(isset($err_s) && !empty($err_s))
							echo '<br><font color="#FF0000"><small><i>'.$err_s.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                        <td width="40%" align="right" valign="top"><font color="#FF0000">*</font> Site name : </td>
                        <td width="60%" align="left"><input type="text" size="40" maxlength="255" name="sitename" value="<?php echo isset($_POST['sitename'])?$_POST['sitename']:$setting['sitename'];?>" />
                        <?php
						if(isset($err_s) && !empty($err_s))
							echo '<br><font color="#FF0000"><small><i>'.$err_s.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                        <td width="40%" align="right" valign="top"><font color="#FF0000">* </font>Slogan website : </td>
                        <td width="60%" align="left"><input type="text" size="40" maxlength="255" name="slogan" value="<?php echo isset($_POST['slogan'])?$_POST['slogan']:$setting['slogan'];?>" />
                        <?php
						if(isset($err_1s) && !empty($err_1s))
							echo '<br><font color="#FF0000"><small><i>'.$err_1s.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                        <td width="40%" align="right" valign="top">Curency : </td>
                        <td width="60%" align="left">
                        	<select name="unit">
                            	<option value="$" <?php echo ($curu=='$')?' selected="selected"':'';?>>USD</option>
                                <option value="VND"<?php echo ($curu=='VND')?' selected="selected"':'';?>>VND</option>
                                <option value="CAD"<?php echo ($curu=='CAD')?' selected="selected"':'';?>>CAD</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td width="40%" align="right" valign="top"><font color="#FF0000">* </font>Num of login failed : </td>
                        <td width="60%" align="left"><input type="text" size="10" maxlength="2" name="totallogin" value="<?php echo isset($_POST['totallogin'])?$_POST['totallogin']:$setting['totallogin'];?>" />
                        <?php
						if(isset($err_d) && !empty($err_d))
							echo '<br><font color="#FF0000"><small><i>'.$err_d.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                        <td width="40%" align="right" valign="top"><font color="#FF0000">* </font>File types alow upload : </td>
                        <td width="60%" align="left"><input type="text" size="40" maxlength="255" name="filetype" value="<?php echo isset($_POST['filetype'])?$_POST['filetype']:$setting['filetype'];?>" />
                        <?php
						if(isset($err_f) && !empty($err_f))
							echo '<br><font color="#FF0000"><small><i>'.$err_f.'</i></small></font>';
						?></td>
                    </tr>
                    <tr>
                        <td width="40%" align="right" valign="top"><font color="#FF0000">* </font>Max file size upload : </td>
                        <td width="60%" align="left"><input type="text" size="10" maxlength="10" name="max_size" value="<?php echo isset($_POST['max_size'])?$_POST['max_size']:$setting['max_size'];?>" /> KB
                        <?php
						if(isset($err_ms) && !empty($err_ms))
							echo '<br><font color="#FF0000"><small><i>'.$err_ms.'</i></small></font>';
						?></td>
                    </tr>
                    <tr>
                        <td width="40%" align="right" valign="top"><font color="#FF0000">* </font>Max height image upload : </td>
                        <td width="60%" align="left"><input type="text" size="10" maxlength="10" name="max_height" value="<?php echo isset($_POST['max_height'])?$_POST['max_height']:$setting['max_height'];?>" /> pixel
                        <?php
						if(isset($err_mh) && !empty($err_mh))
							echo '<br><font color="#FF0000"><small><i>'.$err_mh.'</i></small></font>';
						?></td>
                    </tr>
                    <tr>
                        <td width="40%" align="right" valign="top"><font color="#FF0000">* </font>Max width image upload : </td>
                        <td width="60%" align="left"><input type="text" size="10" maxlength="10" name="max_width" value="<?php echo isset($_POST['max_width'])?$_POST['max_width']:$setting['max_width'];?>" /> pixel
                        <?php
						if(isset($err_mw) && !empty($err_mw))
							echo '<br><font color="#FF0000"><small><i>'.$err_mw.'</i></small></font>';
						?></td>
                    </tr>
                    <tr>
                        <td width="40%" align="right" valign="top"><font color="#FF0000">* </font>Copyright text : </td>
                        <td width="60%" align="left"><input type="text" size="40" maxlength="255" name="strfoot" value="<?php echo isset($_POST['strfoot'])?$_POST['strfoot']:$setting['strfoot'];?>" />
                        <?php
						if(isset($err_c) && !empty($err_c))
							echo '<br><font color="#FF0000"><small><i>'.$err_c.'</i></small></font>';
						?></td>
                    </tr>
                    <tr>
                        <td width="40%" align="right" valign="top"><font color="#FF0000">* </font>Admin email : </td>
                        <td width="60%" align="left"><input type="text" size="40" maxlength="255" name="adminemail" value="<?php echo isset($_POST['adminemail'])?$_POST['adminemail']:$setting['adminemail'];?>" />
                        <?php
						if(isset($err_e) && !empty($err_e))
							echo '<br><font color="#FF0000"><small><i>'.$err_e.'</i></small></font>';
						?></td>
                    </tr>
                    <tr>
                        <td width="40%" align="right" valign="top"><font color="#FF0000">* </font>Max email send/received per day : </td>
                        <td width="60%" align="left"><input type="text" size="10" maxlength="1" name="maxemail" value="<?php echo isset($_POST['maxemail'])?$_POST['maxemail']:$setting['maxemail'];?>" />
                        <?php
						if(isset($err_ses) && !empty($err_ses))
							echo '<br><font color="#FF0000"><small><i>'.$err_ses.'</i></small></font>';
						?></td>
                    </tr>
                    <tr>
                        <td width="40%" align="right" valign="top"><font color="#FF0000">* </font>Show num of record per page : </td>
                        <td width="60%" align="left"><input type="text" size="10" maxlength="2" name="numof_record_perpage" value="<?php echo isset($_POST['numof_record_perpage'])?$_POST['numof_record_perpage']:$setting['numof_record_perpage'];?>" />
                        <?php
						if(isset($err_p) && !empty($err_p))
							echo '<br><font color="#FF0000"><small><i>'.$err_p.'</i></small></font>';
						?></td>
                    </tr>
                    <tr>
                        <td width="40%" align="right">&nbsp;</td>
                        <td width="60%" align="left"><input type="submit" name="smsave" value="Save setting"/>&nbsp;</td>
                    </tr>
                </table>
                <?php
				}
			?>
            </form>
    <p style="clear:both">&nbsp;</p>
    </div><p style="clear:both">&nbsp;</p>
</div>
<?php
mysql_close();