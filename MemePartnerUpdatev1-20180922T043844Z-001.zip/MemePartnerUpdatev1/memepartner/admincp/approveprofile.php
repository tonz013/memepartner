<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/approveprofile.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smapp'])){
	$app = false;
	for($j=0; $j<$_POST['total']; $j++){
		if($_POST['proapp'.$j]==1){// accept images <=> accept profile + accept images
			$app = true;
			if(!updateProfile($_POST['newm'.$j], 1)){
				$error = $errordata;
				break;
				}
			}
		elseif($_POST['proapp'.$j]==2){// remove images <=> accept profile + remove images
			$app = true;
			if(!removeProfiles($_POST['newm'.$j])){
				$error = $errordata;
				break;
				}
			}
		}
	}
$title = 'AdminCP - Approve profiles';
require_once 'include/header.php';
?>
<div class="admincontent">
	<p class="contentop">Approve profiles</p>
    <div class="contenbody">
    	<form action="" method="post">
    	<?php
		if(isset($error) && !empty($error))
			echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
		$list = getProfilesApprove('limit 20');
		if(count($list)>0){
		?>
        <table width="100%" border="0" cellpadding="0" cellspacing="0">
        	<tr bgcolor="#f2f2f2">
            	<td width="20%" class="headrows1">Photo</td>
                <td width="44%" class="headrows2">Profile</td>
                <td width="4%" class="headrows2" align="center">IsVIP</td>
                <td width="8%" class="headrows2" align="center">App Photo</td>
                <td width="8%" class="headrows2" align="center">Del Photo</td>
                <td width="8%" class="headrows2" align="center">App Profile</td>
                <td width="8%" class="headrows2" align="center">Del Profile</td>
            </tr>
            <?php
			$i=0;
			foreach($list['UserID'] as $vlist){
				$img = ($list['PrimaryPhotoID'][$i]==0)?'':'<img src="'.$base_url.$uploaddir.'/'.$vlist.'u'.$list['PrimaryPhotoID'][$i].'.'.$list['PhotoExtension'][$i].'" border="0" style="width:210px; height:260px;"/>';
				$acity = (empty($list['City'][$i]))?$list['State'][$i].', '.$list['Country'][$i]:$list['City'][$i].', '.$list['State'][$i].', '.$list['Country'][$i];
				?>
                <tr>
                    <td width="20%" class="headrows3" valign="top"><?php echo $img;?></td>
                    <td width="44%" class="headrows4" valign="top">
                        <p class="frstop"><b>Profile name:</b> <?php echo $list['ProfileName'][$i];?></p>
                        <p><b>Gender:</b> <?php echo $list['LGender'][$i];?></p>
                        <p><b>Address:</b> <?php echo $acity;?></p>
                        <p><b>About me:</b> <?php echo $list['AboutMe'][$i];?></p>
                        <p><b>Interest:</b> <?php echo $list['Interests'][$i];?></p>
                        <p><b>Goal:</b> <?php echo $list['Goal'][$i];?></p>
                        <p><b>My match:</b> <?php echo $list['AboutMyMatch'][$i];?></p>
                        <input type="hidden" value="<?php echo $vlist;?>" name="newm<?php echo $i;?>" />
                        <input type="hidden" value="<?php echo $list['PrimaryPhotoID'][$i];?>" name="img<?php echo $i;?>" />
                    </td>
                    <td width="4%" class="headrows4" align="center"><input type="checkbox" disabled="disabled" /></td>
                    <td width="8%" class="headrows4" align="center">
                    	<?php if(!empty($img)) echo '<input type="radio" name="proapp'.$i.'" value="3"/>';?>
                    </td>
                    <td width="8%" class="headrows4" align="center"><?php if(!empty($img)) echo '<input type="radio" name="proapp'.$i.'" value="4"/>';?></td>
                    <td width="8%" class="headrows4" align="center"><input type="radio" name="proapp<?php echo $i;?>" value="1"/></td>
                    <td width="8%" class="headrows4" align="center"><input type="radio" name="proapp<?php echo $i;?>" value="2"/></td>
                </tr>
                <?php
				$i++;
				}
			?>
            <tr>
            	<td width="20%" style="padding:20px" colspan="7" align="center"><input type="submit" name="smapp" class="massbutton" /><input type="hidden" value="<?php echo $i;?>" name="total" /></td>
            </tr>
        </table>
        <?php }
		else echo '<p style="padding:10px;">There are no profiles !</p>';
		?>
        </form>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>