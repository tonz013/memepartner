<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/usersmanage.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smsend'])){
	if(empty($_POST['email']) || trim($_POST['email'])=='')
		$erre = 'Please enter email address';
	elseif(!valid_email(trim($_POST['email'])))
		$erre = 'Email address invalid';
	elseif(empty($_POST['subject']) || trim($_POST['subject'])=='')
		$errs = 'Please enter subject email';
	elseif(empty($_POST['bodyemail']) || trim($_POST['bodyemail'])=='')
		$errb = 'Please enter body email';
	elseif(!mail($_POST['email'], '=?UTF-8?B?'.base64_encode($_POST['subject']).'?=', $_POST['bodyemail'], "Content-Type: text/html; charset=utf-8\r\n"."From: ".$adminemail))
		$error = 'Can not send email !';
	else $succ = 'Email has sent successfull !';
	}
$sql = 'select Email from '.$table_prefix.'users where UserID = '.intval($_GET['uid']);
$qry = mysql_query($sql);
if(!$qry)
	$isemail = '';
else{
	$row = mysql_fetch_array($qry);
	$isemail = $row['Email'];
	}
$title = 'AdminCP - Send email to user';
require_once 'include/header.php';
?>
<div class="admincontent">
	<p class="contentop">Send email to user</p>
    <div class="contenbody"><br />
    	<form action="?<?php echo $_SERVER['QUERY_STRING'];?>" method="post">
        	<?php
			if(isset($succ) || !empty($succ)){
				$str = '';
				foreach($_GET as $key => $val){
					if($key != 'uid'){
						$str .= $key.'='.$val.'&';
						}
					}
				$str = !empty($str)?'?'.substr($str, 0, -1):'';
				echo '<p style="height:200px;"><font color="#009933">'.$succ.'</font></p>';
				echo '<meta http-equiv="Refresh" content="3; url='.$base_url.'admincp/usersmanage.php'.$str.'">';
				}
			else{
				if(isset($error) || !empty($error))
					echo '<font color="#FF0000">'.$error.'</font>';
			?>
        	<table width="100%" border="0" cellpadding="3" cellspacing="3">
            	<tr>
                	<td width="25%" align="right" valign="top">Email: </td>
                    <td width="75%" align="left"><input type="text" size="40" name="email" value="<?php echo isset($_POST['email'])?$_POST['email']:$isemail;?>"/>
                    <?php
					if(isset($erre) && !empty($erre))
						echo '<br /><font color="#FF0000"><small><i>'.$erre.'</i></small></font>';
					?> 
                    </td>
                </tr>
                <tr>
                	<td width="25%" align="right" valign="top">Subject: </td>
                    <td width="75%" align="left"><input type="text" size="40" name="subject" value="<?php echo isset($_POST['subject'])?$_POST['subject']:'';?>"/>
                    <?php
					if(isset($errs) && !empty($errs))
						echo '<br /><font color="#FF0000"><small><i>'.$errs.'</i></small></font>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="25%" align="right">Message: </td>
                    <td width="75%" align="left">
                    	<textarea name="bodyemail" rows="5" cols="60"><?php echo isset($_POST['bodyemail'])?$_POST['bodyemail']:'';?></textarea>
                    <?php
					if(isset($errb) && !empty($errb))
						echo '<br /><font color="#FF0000"><small><i>'.$errb.'</i></small></font>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="25%" align="right">&nbsp;</td>
                    <td width="75%" align="left">
                    	<input type="submit" name="smsend" value="Send email" />
                    </td>
                </tr>
            </table><br />&nbsp;
            <?php }?>
        </form>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>