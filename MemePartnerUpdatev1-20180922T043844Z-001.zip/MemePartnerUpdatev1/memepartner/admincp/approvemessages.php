<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/approvemessages.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smappimgs'])){
	$app = false;
	$rmv = array();
	for($j=0; $j<$_POST['total']; $j++){
		if($_POST['proapp'.$j]==1){// accept messages
			if(!approveMessages(array($_POST['mess'.$j]))){
				$error = $errordata;
				break;
				}
			else{
				$app = true;
				$mail = getEmailReceiver($_POST['mess'.$j]);
				if(!empty($mail)){
					$subj = 'Send email form '.$sitename;
					$mess = 'Hi '.$mail.'<br><br>, <b><i>'.$_POST['sender'.$j].'</i></b> has a leter from '.$sitename.'<br><br><a href="'.$base_url.'members/mail.php">View email</a>';
					if(!mail($mail, '=?UTF-8?B?'.base64_encode($subj).'?=', $mess, "Content-Type: text/html; charset=utf-8\r\n"."From: ".$sitename)){
						$error = 'Can not send email !';	
						$app = false;
						}
					}
				}
			}
		elseif($_POST['proapp'.$j]==2){// remove message
			$mail = getEmailSender($_POST['mess'.$j]);
			if(!delMessages(array($_POST['mess'.$j]))){
				$error = $errordata;
				break;
				}
			else{
				$app = true;
				if(!empty($mail)){
					$subj = 'Send email form '.$sitename;
					$mess = 'Hi '.$mail.'<br><br>Your leter send to <b><i>'.$_POST['receiver'.$j].'</i></b> has been deleted .<br>Reason: Content include email address or phone number or website address';
					if(!mail($mail, '=?UTF-8?B?'.base64_encode($subj).'?=', $mess, "Content-Type: text/html; charset=utf-8\r\n"."From: ".$sitename)){
						$error = 'Can not send email !';	
						$app = false;
						}
					}
				}
			}
		}
	if($app){
		mysql_close();
		header('Location: '.$base_url.'admincp/approvemessages.php');
		exit();
		}
	}
$title = 'AdminCP - Approve Messages';
require_once 'include/header.php';
?>
<div class="admincontent">
	<p class="contentop">Approve Messages</p>
    <div class="contenbody">
    	<form action="" method="post">
    	<?php
		if(isset($error) && !empty($error))
			echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
		$list = getMessagesApprpve('limit 20');
		if(count($list)>0){
		?>
        <table width="100%" border="0" cellpadding="0" cellspacing="0">
        	<tr bgcolor="#f2f2f2">
            	<td width="10%" class="headrows1">Senders</td>
                <td width="10%" class="headrows2">Receiver</td>
                <td width="20%" class="headrows2" align="center">Subjects</td>
                <td width="36%" class="headrows2" align="center">Messages</td>
                <td width="10%" class="headrows2" align="center">Sent date</td>
                <td width="7%" class="headrows2" align="center">App Mess</td>
                <td width="7%" class="headrows2" align="center">Del Mess</td>
            </tr>
            <?php
			$i=0;
			foreach($list['MessageID'] as $vlist){
				?>
                <tr>
                    <td width="10%" class="headrows3" valign="top" style="text-align:left"><?php echo $list['sender'][$i];?>
                    <input type="hidden" value="<?php echo $list['MessageID'][$i];?>" name="mess<?php echo $i;?>" />
                    <input type="hidden" value="<?php echo $list['sender'][$i];?>" name="sender<?php echo $i;?>" />
                    <input type="hidden" value="<?php echo $list['receiver'][$i];?>" name="receiver<?php echo $i;?>" />
                    </td>
                    <td width="10%" class="headrows4" valign="top" align="left"><?php echo $list['receiver'][$i];?></td>
                    <td width="20%" class="headrows4" align="left"><?php echo $list['Subject'][$i];?></td>
                    <td width="36%" class="headrows4" align="left"><?php echo $list['Message'][$i];?></td>
                    <td width="10%" class="headrows4" align="center"><?php echo date('d-m-Y', strtotime($list['SentOn'][$i]));?></td>
                    <td width="7%" class="headrows4" align="center"><input type="radio" name="proapp<?php echo $i;?>" value="1"/></td>
                    <td width="7%" class="headrows4" align="center"><input type="radio" name="proapp<?php echo $i;?>" value="2"/></td>
                </tr>
                <?php
				$i++;
				}
			?>
            <tr>
            	<td width="20%" style="padding:20px" colspan="7" align="center"><input type="submit" name="smappimgs" class="massbutton" /><input type="hidden" value="<?php echo $i;?>" name="total" /></td>
            </tr>
        </table>
        <?php }
		else echo '<p style="padding:10px;">There are no messages !</p>';
		?>
        </form>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>