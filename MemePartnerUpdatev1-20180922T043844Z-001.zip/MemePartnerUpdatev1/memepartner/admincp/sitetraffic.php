<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/sitetraffic.php';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
require_once 'include/header.php';
$date = gmdate("Y-m-d", time()+7*3600);
//$newdate = strtotime ( '-1 month' , strtotime ( $date ) ) ;
$newdate = strtotime ( '-1 day' , strtotime ( $date ) ) ;
$newdate = date ( 'Y-m-d' , $newdate );
$total = countUsersSite();
?>
<div class="admincontent">
	<p class="contentop">Site Traffic</p>
    <div class="contenbody">
    	<form action="" method="post">
        <div style="width:20%; float:left;">
        	<h4 align="center" style="margin-bottom:3px; padding-bottom:3px">Daily Registration</h4>
            <table width="99%" border="0" cellpadding="0" cellspacing="0">
            	<tr bgcolor="#f2f2f2">
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Time</td>
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center"><b>Total</b></td>
                </tr>
                <?php
				$reg = getRegSite($newdate);
				if(mysql_num_rows($reg)>0){
					while($rows=mysql_fetch_array($reg)){
						?>
                        <tr>
                            <td width="50%" style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['TheDate'];?></td>
                            <td width="50%" style="border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['Total'];?></td>
                        </tr>
                        <?php
						}
					}
				else echo '<tr><td style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:1px 0px" align="center" colspan="2">0</td></tr>';
				?>
            </table>
        </div>
        <div style="width:20%; float:left">
        	<h4 align="center" style="margin-bottom:3px; padding-bottom:3px">Today's Login</h4>
            <table width="99%" border="0" cellpadding="0" cellspacing="0">
            	<tr bgcolor="#f2f2f2">
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Time</td>
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Total</td>
                </tr>
                <?php
				$log = getLoginSite($newdate);
				if(mysql_num_rows($log)>0){
					while($rows=mysql_fetch_array($log)){
						?>
                        <tr>
                            <td width="50%" style="border-left:1px solid #d6d8e5; border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['TheDate'];?></td>
                            <td width="50%" style="border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['Total'];?></td>
                        </tr>
                        <?php
						}
					}
				else echo '<tr><td style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:1px 0px" align="center" colspan="2">0</td></tr>';
				?>
            </table>
        </div>
        <div style="width:20%; float:left">
        	<h4 align="center" style="margin-bottom:3px; padding-bottom:3px">Total Messages Posted</h4>
            <table width="99%" border="0" cellpadding="0" cellspacing="0">
            	<tr bgcolor="#f2f2f2">
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Time</td>
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Total</td>
                </tr>
                <?php
				$sent = getSentMessSite($newdate);
				if(mysql_num_rows($sent)>0){
					while($rows=mysql_fetch_array($sent)){
						?>
                        <tr>
                            <td width="50%" style="border-left:1px solid #d6d8e5; border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['TheDate'];?></td>
                            <td width="50%" style="border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['Total'];?></td>
                        </tr>
                        <?php
						}
					}
				else echo '<tr><td style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:1px 0px" align="center" colspan="2">0</td></tr>';
				?>
            </table>
        </div>
        <div style="width:20%; float:left">
        	<h4 align="center" style="margin-bottom:3px; padding-bottom:3px">Total Signals Sent</h4>
            <table width="99%" border="0" cellpadding="0" cellspacing="0">
            	<tr bgcolor="#f2f2f2">
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Time</td>
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Total</td>
                </tr>
                <?php
				$sig = getSignalSite($newdate);
				if(mysql_num_rows($sig)>0){
					while($rows=mysql_fetch_array($sig)){
						?>
                        <tr>
                            <td width="50%" style="border-left:1px solid #d6d8e5; border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['TheDate'];?></td>
                            <td width="50%" style="border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['Total'];?></td>
                        </tr>
                        <?php
						}
					}
				else echo '<tr><td style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:1px 0px" align="center" colspan="2">0</td></tr>';
				?>
            </table>
        </div>
        <div style="width:20%; float:left">
        	<h4 align="center" style="margin-bottom:3px; padding-bottom:3px">Total Photos Posted</h4>
            <table width="99%" border="0" cellpadding="0" cellspacing="0">
            	<tr bgcolor="#f2f2f2">
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Time</td>
                    <td width="50%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Total</td>
                </tr>
                <?php
				$pho = getPhotosSite($newdate);
				if(mysql_num_rows($pho)>0){
					while($rows=mysql_fetch_array($pho)){
						?>
                        <tr>
                            <td width="50%" style="border-left:1px solid #d6d8e5; border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['TheDate'];?></td>
                            <td width="50%" style="border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['Total'];?></td>
                        </tr>
                        <?php
						}
					}
				else echo '<tr><td style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; border-left:1px solid #d6d8e5; padding:1px 0px" align="center" colspan="2">0</td></tr>';	
				?>
            </table>
        </div>
        <p style="clear:both; height:5px;">&nbsp;</p>
        </form>
    </div>
   <p style="clear:both; height:0px;">&nbsp;</p> 
   <p class="contentop">Country infomation</p>
   <div class="contenbody">
   		<table width="100%" border="0" cellpadding="0" cellspacing="0">
            <tr bgcolor="#f2f2f2">
                <td width="33%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Country</td>
                <td width="33%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Number of users</td>
                <td width="34%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Percentage</td>
            </tr>
            <?php
			$usercountry = getAllCountries();
			if(mysql_num_rows($usercountry)>0){
				while($rows = mysql_fetch_array($usercountry)){
					?>
                    <tr>
                            <td width="33%" style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['Country'];?></td>
                            <td width="33%" style="border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['Total'];?></td>
                            <td width="34%" style="border-bottom:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo round(($rows['Total']*100)/$total, 2);?> %</td>
                        </tr>
                    <?php
					}
				}
			?>
        </table><p style="clear:both; height:5px;">&nbsp;</p>
   </div>
   <p style="clear:both; height:0px;">&nbsp;</p> 
   <p class="contentop">Age groups</p>
   <div class="contenbody">
   		<table width="100%" border="0" cellpadding="0" cellspacing="0">
            <tr bgcolor="#f2f2f2">
                <td width="33%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Age</td>
                <td width="33%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Number of users</td>
                <td width="34%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Percentage</td>
            </tr>
            <?php
			$result = getAgeGroups();
			if(mysql_num_rows($result)>0){
				while($rows = mysql_fetch_array($result)){
					?>
                    <tr>
                            <td width="33%" style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['Age'];?></td>
                            <td width="33%" style="border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['Total'];?></td>
                            <td width="34%" style="border-bottom:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo round(($rows['Total']*100)/$total, 2);?> %</td>
                        </tr>
                    <?php
					}
				}
			?>
        </table><p style="clear:both; height:5px;">&nbsp;</p>
   </div>
   <p style="clear:both; height:0px;">&nbsp;</p> 
   <p class="contentop">Gender groups</p>
   <div class="contenbody">
   		<table width="100%" border="0" cellpadding="0" cellspacing="0">
            <tr bgcolor="#f2f2f2">
                <td width="33%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Gender</td>
                <td width="33%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Number of users</td>
                <td width="34%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Percentage</td>
            </tr>
            <?php
			$result = getGenderGroups();
			if(mysql_num_rows($result)>0){
				while($rows = mysql_fetch_array($result)){
					?>
                    <tr>
                            <td width="33%" style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['LGender'];?></td>
                            <td width="33%" style="border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['Total'];?></td>
                            <td width="34%" style="border-bottom:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo round(($rows['Total']*100)/$total, 2);?> %</td>
                        </tr>
                    <?php
					}
				}
			?>
        </table><p style="clear:both; height:5px;">&nbsp;</p>
   </div>
   <p style="clear:both; height:0px;">&nbsp;</p> 
   <p class="contentop">Educations</p>
   <div class="contenbody">
   		<table width="100%" border="0" cellpadding="0" cellspacing="0">
            <tr bgcolor="#f2f2f2">
                <td width="33%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Education</td>
                <td width="33%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Number of users</td>
                <td width="34%" style="border-top:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:3px 0px; color:#3b5998; font-weight:bold" align="center">Percentage</td>
            </tr>
            <?php
			$result = getEducationGroups();
			if(mysql_num_rows($result)>0){
				while($rows = mysql_fetch_array($result)){
					?>
                    <tr>
                            <td width="33%" style="border-right:1px solid #d6d8e5; border-bottom:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['LEducation'];?></td>
                            <td width="33%" style="border-bottom:1px solid #d6d8e5; border-right:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo $rows['Total'];?></td>
                            <td width="34%" style="border-bottom:1px solid #d6d8e5; padding:1px 0px" align="center"><?php echo round(($rows['Total']*100)/$total, 2);?> %</td>
                        </tr>
                    <?php
					}
				}
			?>
        </table><p style="clear:both; height:5px;">&nbsp;</p>
   </div>
</div>
<?php
require_once 'include/footer.php';
?>