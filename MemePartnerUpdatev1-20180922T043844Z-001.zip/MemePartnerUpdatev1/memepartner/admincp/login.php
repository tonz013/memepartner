<?php
require_once "../includes/config.php";
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smadlogin'])){
	if(empty($_POST['email']))
		$err_e = $emailnull;
	elseif(!valid_email(trim($_POST['email'])))
		$err_e = $emailinvalid;
	elseif(empty($_POST['password']))
		$err_p = $passnull;
	else{
		$data = array(mysql_real_escape_string(trim($_POST['email'])), mysql_real_escape_string(trim($_POST['password'])));
		$result = adminLogin($data);
		if($result==0)
			$error = $errordata;
		elseif($result==-1)
			$error = $mailpassnotmatch;
		else{
			mysql_close();
			$_SESSION['admincp'] = $result;
			$_SESSION['adcpmail'] = $_POST['email'];
			$direct = $_SESSION['direct']?$_SESSION['direct']:$base_url.'admincp';
			unset($_SESSION['direct']);
			header('Location: '.$direct);
			exit();
			}
		}
	}
$title = 'Administrator login';
require_once 'include/header.php';
//require_once 'includes/adminmenu.php';
?>
       <div class="maincontent"><br />
       		<div class="signup" style="margin-top:20%; margin-bottom:20%">
            	<form action="" method="post" target="_top">
            	<p class="styletop"><?php echo $title;?></p>
                <?php
				if(isset($error) && !empty($error))
					echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
				?>
                <br />
                <table width="100%" cellpadding="3" cellspacing="3">
                	<tr>
                    	<td width="30%" align="right" valign="top">Email: </td>
                        <td width="70%" align="left"><input type="text" name="email" value="<?php echo isset($_POST['email'])?$_POST['email']:'';?>" style="width:265px;"/><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_e) && !empty($err_e))
							echo '<br><font color="#FF0000"><small><i>'.$err_e.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $mypassword;?>: </td>
                        <td width="70%" align="left"><input type="password" style="width:265px;" name="password" /><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_p) && !empty($err_p))
							echo '<br><font color="#FF0000"><small><i>'.$err_p.'</i></small></font>';
						?>
                        <p style="margin-top:5px"><a href="forgot.php"><i>Forgot password ?</i></a></p>
                        </td>
                    </tr>
                </table><br />
                <div class="stylebott" align="center">
                    	<p style="margin:0px; padding:7px 0px;"><input type="submit" value="<?php echo $signin;?>" class="massbutton" name="smadlogin"/>&nbsp;<input type="reset" value="<?php echo $cancel;?>" class="massbutton"/></p>
                </div>
                </form>
            </div>
            <p class="linespace"><br />&nbsp;</p><br />
       </div>
<?php
require_once 'include/footer.php';
?>