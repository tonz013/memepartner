<?php
require_once "../includes/config.php";
require_once "../includes/database.php";
require_once "include/functions.php";
$sqls = "select CateId, FilrtValue from ".$table_prefix."flirts where Id = ".$_GET['st'];
$myrs = mysql_query($sqls);
$myrow = mysql_fetch_array($myrs);
?>
<h4>Update Value</h4>
            <form action="" method="post" onsubmit="return chkfrm();">
            <table width="100%" cellpadding="3" cellspacing="3">
            	<tr>
                	<td width="30%" align="right" valign="top">Category:</td>
                    <td width="70%" align="left">
                    
                    <select name="newval" >
                        <?php
                        $sel = isset($_POST['newval'])?$_POST['newval']:$myrow['CateId'];
                        $sqlcountry = 'select Id, NameCate as LName from '.$table_prefix.'flirt_categories order by LName asc';
                        dropdownlist($sqlcountry, $sel);
                        ?>
                    </select>
                    <?php
					if(isset($err_e) && !empty($err_e))
						echo '<br><small><font color="#FF0000"><i>'.$err_e.'</i></font></small>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="30%" align="right" valign="top">Value:</td>
                    <td width="70%" align="left"><input type="text" size="40" id="vnvalue" name="vnvalue" value="<?php echo isset($_POST['vnvalue'])?$_POST['vnvalue']:$myrow['FilrtValue'];?>" />
                    <?php
					if(isset($err_v) && !empty($err_v))
						echo '<br><small><font color="#FF0000"><i>'.$err_v.'</i></font></small>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="30%" align="right">&nbsp;</td>
                    <td width="70%" align="left"><input type="submit" name="smupdate" class="massbutton" value="Save" />&nbsp;<input type="submit" name="smcancel" class="massbutton" value="Cancel" /></td>
                </tr>
            </table><input type="hidden" id="hddid" name="hddid" value="<?php echo $_GET['st'];?>" /></form>