<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp';
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
require_once "../includes/database.php";
require_once "include/functions.php";
?>
<html>
<head>
<title>Administrator control panel</title>
<link href="<?php echo $base_url;?>css/admincss.css" type="text/css" rel="stylesheet" />
<script language="javascript" type="text/javascript" src="<?php echo $base_url;?>jss/styles.js"></script>
</head>
<frameset cols="240,*" frameborder="0" border="0" framespacing="0">
	<frame name="menu" src="include/menu.php" marginheight="0" marginwidth="0" scrolling="auto" noresize>
<frameset rows="35,*" frameborder="0" border="0" framespacing="0">
	<frame name="topNav" src="top_nav.php" scrolling="no">
	<frame name="content" src="content.php" marginheight="0" marginwidth="0" scrolling="auto" noresize>
</frameset>

<noframes>
<p>This section (everything between the 'noframes' tags) will only be displayed if the users' browser doesn't support frames. You can provide a link to a non-frames version of the website here. Feel free to use HTML tags within this section.</p>
</noframes>

</frameset>
<?php
require_once 'include/footer.php';
?>