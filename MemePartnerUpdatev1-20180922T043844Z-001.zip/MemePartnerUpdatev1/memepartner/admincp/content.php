<?php
require_once "../includes/config.php";
require_once "../includes/database.php";
require_once "include/functions.php";
?><br />
<script language="javascript" type="text/javascript" src="<?php echo $base_url;?>jss/styles.js"></script>
<table width="100%" cellpadding="3" cellspacing="3">
        	<tr>
				<td style="text-align:right" width="40%">Server Type:</td>
				<td style="text-align:left"><?php echo php_uname('s');?></td>
			</tr>
            <tr>
				<td style="text-align:right" valign="top">Web Server:</td>
				<td style="text-align:left"><?php echo $_SERVER['SERVER_SOFTWARE'];?></td>
			</tr>
            <tr>
				<td style="text-align:right">Server Protocol:</td>
				<td style="text-align:left"><?php echo $_SERVER['SERVER_PROTOCOL'];?></td>
			</tr>
            <tr>
				<td style="text-align:right">Server Port:</td>
				<td style="text-align:left"><?php echo $_SERVER['SERVER_PORT'];?></td>
			</tr>
			<tr>
				<td style="text-align:right">PHP Version:</td>
				<td style="text-align:left"><?php echo phpversion();?></td>
			</tr>
			<tr>
				<td style="text-align:right">PHP Max Post Size:</td>
				<td style="text-align:left"><?php echo (int)(ini_get('post_max_size'))." MB";?></td>
			</tr>
			<tr>
				<td style="text-align:right">PHP Maximum Upload Size:</td>
				<td style="text-align:left"><?php echo (int)(ini_get('upload_max_filesize'))." MB";?></td>
			</tr>
			<tr>
				<td style="text-align:right">PHP Memory Limit:</td>
				<td style="text-align:left"><?php echo (int)(ini_get('memory_limit'))." MB";?></td>
			</tr>
			<tr>
				<td style="text-align:right">PHP Session Time Out:</td>
				<td style="text-align:left"><?php echo ini_get('session.gc_maxlifetime');?></td>
			</tr>
			<tr>
				<td style="text-align:right">MySQL Version:</td>
				<td style="text-align:left"><?php echo mysql_get_server_info();?></td>
			</tr>
			<tr>
				<td style="text-align:right">MySQL Time Out:</td>
				<td style="text-align:left"><?php echo ini_get('max_execution_time');?></td>
			</tr>
			<tr>
				<td style="text-align:right">MySQL Port:</td>
				<td style="text-align:left"><?php echo ini_get('mysql.default_port');?></td>
			</tr>
			<tr>
				<td style="text-align:right">Browser:</td>
				<td style="text-align:left"><?php echo get_browser_($_SERVER['HTTP_USER_AGENT']);?></td>
			</tr>
			<tr>
				<td style="text-align:right">SMTP Port:</td>
				<td style="text-align:left"><?php echo ini_get('smtp_port');?></td>
			</tr>
			<tr>
				<td style="text-align:right">SMTP:</td>
				<td style="text-align:left"><?php echo ini_get('SMTP');?></td>
			</tr>
			<tr>
				<td style="text-align:right">Useful links:</td>
				<td style="text-align:left">
					<select onchange="opennewwindow(this.value)">
						<option value="">- - Useful links - -</option>
						<optgroup label="PHP">
							<option value="http://www.php.net/">Home page (php.net)</option>	
							<option value="http://www.php.net/manual/en/index.php">Reference manual</option>
							<option value="http://www.php.net/downloads.php">Download latest version</option>					
						</optgroup>
						<optgroup label="MySQL">
							<option value="http://www.mysql.com/">Home page (php.net)</option>	
							<option value="http://www.mysql.com/documentation/">Reference manual</option>
							<option value="http://www.mysql.com/downloads/">Download latest version</option>					
						</optgroup>
						<optgroup label="Apache">
							<option value="http://httpd.apache.org/">Home page (php.net)</option>	
							<option value="http://httpd.apache.org/docs/">Reference manual</option>
							<option value="http://httpd.apache.org/download.cgi">Download latest version</option>					
						</optgroup>
					</select>
				</td>
			</tr>
        </table>