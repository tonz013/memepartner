<?php
require_once "../includes/config.php";
if(!$_SESSION['admincp']){
	$_SESSION['direct'] = $base_url.'admincp/editpage.php?'.$_SERVER['QUERY_STRING'];
	header('Location: '.$base_url.'admincp/login.php');
	exit();
	}
$dipadd = 'style="display:none"';
$dipedit = 'style="display:none"';
require_once "../includes/database.php";
require_once "include/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smcancel'])){
	mysql_close();
	header('Location: '.$base_url.'admincp/managepage.php');
	exit();
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smupdate'])){
	if(empty($_POST['pagename'])){
		$err_e = 'Please enter page name';
		$dipedit = '';
		$dipadd = 'style="display:none"';
		}
	elseif(empty($_POST['bodyadd'])){
		$err_v = 'Please enter content page';
		$dipedit = '';
		$dipadd = 'style="display:none"';
		}
	else{
		$isactive = $_POST['isactive']=='on'?1:0;
		if(!updValues(array('PageName' => "'".mysql_real_escape_string($_POST['pagename'])."'", 'PageBody' => "'".mysql_real_escape_string($_POST['bodyadd'])."'", 'LastUpdated'=>"'".date('Y-m-d H:i:s')."'", 'IsActive'=>$isactive), $table_prefix.'pages', 'Id = '.intval($_GET['pi']))){
			$error = $errordata;
			$dipedit = '';
			$dipadd = 'style="display:none"';
			}
		else{
			mysql_close();
			header('Location: '.$base_url.'admincp/managepage.php');
			exit();
			}
		}
	}
$title = 'AdminCP - Edit page';
require_once 'include/header.php';
?>
<link rel="stylesheet" href="ext/jquery.wysiwyg.css" type="text/css" />
  <script type="text/javascript" src="ext/jquery-1.3.2.js"></script>
  <script type="text/javascript" src="ext/jquery.wysiwyg.js"></script>
  <script type="text/javascript">
  $(function()
  {
      $('#bodyadd').wysiwyg();
  });
  </script>
<div class="admincontent">
	<p class="contentop">Edit page</p>
    <div class="contenbody">
    	<div style="width:100%; float:left">
    	
    	<?php
		if(isset($error) && !empty($error))
			echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
		$page1 = "select PageName, PageBody, IsActive, LastUpdated from ".$table_prefix."pages where Id = ".intval($_GET['pi']);
		$qrypa = mysql_query($page1);
		if($qrypa!=false && mysql_num_rows($qrypa)>0){
			$rowp = mysql_fetch_array($qrypa);
		?>
        <form action="?<?php echo $_SERVER['QUERY_STRING'];?>" method="post">
            <table width="100%" cellpadding="3" cellspacing="3">
            	<tr>
                	<td width="15%" align="right" valign="top">Page name:</td>
                    <td width="85%" align="left"><input type="text" size="40" id="pagename" name="pagename" value="<?php echo isset($_POST['pagename'])?$_POST['pagename']:$rowp['PageName'];?>" />
                    <?php
					if(isset($err_e) && !empty($err_e))
						echo '<br><small><font color="#FF0000"><i>'.$err_e.'</i></font></small>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="15%" align="right" valign="top">Page body:</td>
                    <td width="85%" align="left"><textarea cols="100" rows="30" id="bodyadd" name="bodyadd"><?php echo isset($_POST['bodyadd'])?$_POST['bodyadd']:$rowp['PageBody'];?></textarea>
                    <?php
					if(isset($err_v) && !empty($err_v))
						echo '<small><font color="#FF0000"><i>'.$err_v.'</i></font></small>';
					?>
                    </td>
                </tr>
                <tr>
                	<td width="15%" align="right" valign="top">&nbsp;</td>
                    <td width="85%" align="left"><input type="checkbox" style="margin-left:0px; padding-left:0px;" name="isactive" <?php echo $rowp['IsActive']==1?'checked="checked"':'';?>/>Active</td>
                </tr>
                <tr>
                	<td width="15%" align="right" valign="top">Last update:</td>
                    <td width="85%" align="left"><?php echo $rowp['LastUpdated'];?></td>
                </tr>
                <tr>
                	<td width="15%" align="right">&nbsp;</td>
                    <td width="85%" align="left"><input type="submit" name="smupdate" class="massbutton" value="Save change" />&nbsp;<input type="submit" name="smcancel" class="massbutton" value="Cancel" /><br />&nbsp;</td>
                </tr>
            </table>
            </form>
            <?php
			}
		else echo '<p>'.$norecord.' !!</p>';
			?>
        </div>
    </div>
</div>
<?php
require_once 'include/footer.php';
?>