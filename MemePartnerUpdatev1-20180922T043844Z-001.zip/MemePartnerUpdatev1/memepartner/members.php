<?php
require_once "includes/config.php";
require_once "includes/database.php";
require_once "includes/functions.php";
$title = $sitename.' - '.$slogan;
$ismenu = 5;
$sqlsearch = '';
if(isset($_GET['t']) && intval($_GET['t'])>0){
	switch($_GET['t']){
		case 1:
			$order = ', u.Views desc';
			$sqlsearch = '';
		break;
		case 2:
			$sqlsearch = 'u.IsOnline = 1 and ';
			$order = '';
		break;
		case 3:
			$order = ', toprate desc';
			$sqlsearch = '';
		break;
		default:
			$order = ', u.DatePosted desc';
			$sqlsearch = '';
		break;
		}
	}
else $order = ', u.DatePosted desc';
require_once 'includes/header.php';
require_once 'includes/menus.php';
require_once 'includes/menumem.php';
if(isset($_SESSION['memberid']) && intval($_SESSION['memberid'])>0)
	$sqlsearch .= 'u.UserID <> '.$_SESSION['memberid'].' and ';
$config['showeachside'] = 4;
$config['per_page'] = $numof_record_perpage;
$config['js_numrows_page'] = FillListMembers($sqlsearch);
$config['curpage'] = empty($_GET['p'])?1:$_GET['p'];
$config['rs_start'] = ($config['curpage']*$config['per_page'])-$config['per_page'];
if($config['js_numrows_page'] < $config['per_page'])
	$config['per_page'] = $config['js_numrows_page'];
$t = isset($_GET['t'])?intval($_GET['t']):0;
$config['cururl'] = $base_url.'members.php?t='.intval($_GET['t']);
$paging = Pagination($config);
?>
       <div class="maincontent">
       		<?php
			$sql = "select u.UserID, LOWER(SUBSTRING_INDEX(ProfileName, ' ', 4)) as ProfileName, Age, REPLACE(REPLACE(AboutMe, '.', '. '), ',', ', ') as AboutMe, SUBSTRING_INDEX(REPLACE(REPLACE(REPLACE(AboutMe, '-', ' - '), '.', '. '), ',', ', '),' ', 4) as subAboutMe, City, MatchAgeFrom, MatchAgeTO, LastLogon, PrimaryPhotoID, ".$_SESSION['lang']."MaritalStatus as LMaritalStatus, State, Country, ".$_SESSION['lang']."Gender as LGender, PhotoExtension, RemainVIPContacts, IsOnline, u.TotalRating/u.NumberOfVote as toprate from ".$table_prefix."users as u left join ".$table_prefix."maritalstatus as m on u.MaritalStatusID = m.MaritalStatusID left join ".$table_prefix."states as s on u.StateID = s.StateID left join ".$table_prefix."countries as c on u.CountryID = c.CountryID left join ".$table_prefix."gender as g on u.MatchGenderID = g.GenderID left join ".$table_prefix."photos as p on u.PrimaryPhotoID = p.PhotoID where ".$sqlsearch." u.ProfileStatusID = 1 and u.GenderID IS NOT NULL and MembershipID <> 3 order by RemainVIPContacts desc".$order;
			$sql = $sql." limit ".$config['rs_start'].", ".$config['per_page'];
			$qry = mysql_query($sql);
			if(!$qry)
				exit($errordata);
			elseif(mysql_num_rows($qry)>0){
				$i=1;
				$j=1;
				while($rows = mysql_fetch_array($qry)){
					$mvip = ($rows['RemainVIPContacts']==1)?'memvip':'';
					$city = '';
					if(!empty($rows['State'])) $city .= $rows['State'].', ';
					$city .= $rows['Country'];
					$aboutme = (strlen($rows['AboutMe'])>22)?str_replace('....', ' ', $rows['subAboutMe']).' ...':$rows['AboutMe'];
					if(strpos($rows['ProfileName'], ' ')===false && strlen($rows['ProfileName'])>20){
						$prof = substr($rows['ProfileName'], 0, 16).' ...';
						}
					else{
						$prof = (strlen($rows['ProfileName'])>20)?substr(strip_tags($rows['ProfileName']), 0, 25).' ...':strip_tags($rows['ProfileName']);
						}
					if($rows['IsOnline']==1 && $_SESSION['memberid'] > 0){
						$_SESSION['chatuser'] = $_SESSION['memberid'];
						$_SESSION['chatuser_name'] = $_SESSION['memberemail'];
						$onclick = 'onclick="javascript:chatWith(\''.$rows['UserID'].'\',\''.$prof.'\')"';
						$label = 'Chat';
						}
					else{
						$label = $signal;
						$onclick = 'onclick="redirect(\''.$base_url.'alerts.php?ty=2&pr='.$rows['UserID'].'\', 0)"';
						}
					if($rows['PrimaryPhotoID']>0 && file_exists('fuploads/'.$rows['UserID'].'u'.$rows['PrimaryPhotoID'].'.'.$rows['PhotoExtension']))
						$ispt = 'fuploads/'.$rows['UserID'].'u'.$rows['PrimaryPhotoID'].'.'.$rows['PhotoExtension'];
					else $ispt = 'imgs/noimage.jpg';
					if(is_int($j/2)){
					?>
                    	<div class="memcnter <?php echo $mvip;?>">
                            <p class="tbltop"><b><a href="viewprofile.php?id=<?php echo $rows['UserID'];?>"><?php echo $prof.' ('.$rows['Age'].') / '.$rows['LMaritalStatus'];?></a></b></p>
                            <table width="100%" cellpadding="3" cellspacing="3">
                                <tr>
                                    <td width="35%"><a href="viewprofile.php?id=<?php echo $rows['UserID'];?>"><img src="<?php echo $ispt;?>" border="0"/></a></td>
                                    <td width="65%" valign="top" align="left">
                                        <p class="desc"><?php echo preg_replace('/(\w+) (\w+) (\w+),(\w+)/i', '${1} 1 2, $3', $aboutme);?></p>
                                        <p style="padding-top:15px;"><?php echo $city;?></p>
                                        <p><b><?php echo $wantfind;?>:</b> <?php echo $rows['LGender'].' '.$rows['MatchAgeFrom'].' - '.$rows['MatchAgeTO'];?></p><p><small><i><b><?php echo $signin;?>:</b> <?php echo date('H:i:s d-m-Y', strtotime($rows['LastLogon']));?></i></small></p><br />
                                        <p><input type="button" value="Email" class="massbutton" onclick="redirect('<?php echo $base_url.'members/compose.php?pr='.$rows['UserID'];?>', 0)"/>&nbsp;<input type="button" value="<?php echo $label;?>" class="massbutton" <?php echo $onclick;?>/>&nbsp;<input type="button" value="<?php echo $saveit;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'alerts.php?ty=3&pr='.$rows['UserID'];?>', 0)"/></p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    <?php
                    	}
					elseif(is_int($j/3)){
					?>
                    	<div class="memright <?php echo $mvip;?>">
                            <p class="tbltop"><b><a href="viewprofile.php?id=<?php echo $rows['UserID'];?>"><?php echo $prof.' ('.$rows['Age'].') / '.$rows['LMaritalStatus'];?></a></b></p>
                            <table width="100%" cellpadding="3" cellspacing="3">
                                <tr>
                                    <td width="35%"><a href="viewprofile.php?id=<?php echo $rows['UserID'];?>"><img src="<?php echo $ispt;?>" border="0"/></a></td>
                                    <td width="65%" valign="top" align="left">
                                        <p class="desc"><?php echo $aboutme;?></p>
                                        <p style="padding-top:15px;"><?php echo $city;?></p>
                                        <p><b><?php echo $wantfind;?>:</b> <?php echo $rows['LGender'].' '.$rows['MatchAgeFrom'].' - '.$rows['MatchAgeTO'];?></p><p><small><i><b><?php echo $signin;?>:</b> <?php echo date('H:i:s d-m-Y', strtotime($rows['LastLogon']));?></i></small></p><br />
                                        <p><input type="button" value="Email" class="massbutton" onclick="redirect('<?php echo $base_url.'members/compose.php?pr='.$rows['UserID'];?>', 0)"/>&nbsp;<input type="button" value="<?php echo $label;?>" class="massbutton" <?php echo $onclick;?>/>&nbsp;<input type="button" value="<?php echo $saveit;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'alerts.php?ty=3&pr='.$rows['UserID'];?>', 0)"/></p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    <?php
                    	}
					else{
						?>
                        <div class="memleft <?php echo $mvip;?>">
                            <p class="tbltop"><b><a href="viewprofile.php?id=<?php echo $rows['UserID'];?>"><?php echo $prof.' ('.$rows['Age'].') / '.$rows['LMaritalStatus'];?></a></b></p>
                            <table width="100%" cellpadding="3" cellspacing="3">
                                <tr>
                                    <td width="35%"><a href="viewprofile.php?id=<?php echo $rows['UserID'];?>"><img src="<?php echo $ispt;?>" border="0"/></a></td>
                                    <td width="65%" valign="top" align="left">
                                        <p class="desc"><?php echo str_replace(',', ', ', $aboutme);?></p>
                                        <p style="padding-top:15px;"><?php echo $city;?></p>
                                        <p><b><?php echo $wantfind;?>:</b> <?php echo $rows['LGender'].' '.$rows['MatchAgeFrom'].' - '.$rows['MatchAgeTO'];?></p><p><small><i><b><?php echo $signin;?>:</b> <?php echo date('H:i:s d-m-Y', strtotime($rows['LastLogon']));?></i></small></p><br />
                                        <p><input type="button" value="Email" class="massbutton" onclick="redirect('<?php echo $base_url.'members/compose.php?pr='.$rows['UserID'];?>', 0)"/>&nbsp;<input type="button" value="<?php echo $label;?>" class="massbutton" <?php echo $onclick;?>/>&nbsp;<input type="button" value="<?php echo $saveit;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'alerts.php?ty=3&pr='.$rows['UserID'];?>', 0)"/></p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <?php
						}
					if($j==3)
						$j=0;
					$j++;
					$i++;
					}
				}
			else echo '<p style="height:300px">There are no profile !!</p>';
			?>
            <p id="paging" style="clear:both; margin-right:0px; text-align:center"><?php echo $paging;?></p>
       </div>
       
<?php
mysql_close();
$_SESSION['process'] = true;
require_once 'includes/footer.php';
?>