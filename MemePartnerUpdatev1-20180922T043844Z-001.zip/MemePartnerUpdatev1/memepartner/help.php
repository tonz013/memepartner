<?php
require_once "includes/config.php";
require_once "includes/database.php";
require_once "includes/functions.php";
$sql1 = "select PageName, PageBody from ".$table_prefix."pages where Id = 2";
$qry1 = mysql_query($sql1);
if(!$qry && mysql_num_rows($qry1)>0){
	$row = mysql_fetch_array($qry1);
	$title = $row['PageName'];					
	}
else $title = $helpuse.'. '.$norecord;
require_once 'includes/header.php';
require_once 'includes/menus.php';
require_once 'includes/filters.php';
?>
       <div class="maincontent"><br />
       <form action="" method="post">
       		<div id="browsemail">
                <div class="titletop">
                	<div class="lefttitletop" style="width:100%">
                    	<h3><?php echo $title;?></h3>
                    </div>
                    <p class="linespace">&nbsp;</p>
                </div>
                <div class="helpcontent">
                	<?php
					echo htmlspecialchars_decode($row['PageBody']);
					?>
                </div>
                <p class="linespace"><br />&nbsp;</p><br />&nbsp;<input type="hidden" id="hdval" value="14" /><input type="hidden" id="currdis" />
            </div>
            <p class="linespace">&nbsp;</p></form>
       </div>
<?php
mysql_close();
require_once 'includes/footer.php';
?>