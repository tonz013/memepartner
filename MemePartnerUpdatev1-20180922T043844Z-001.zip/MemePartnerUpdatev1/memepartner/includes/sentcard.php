<?php
require_once "config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0)
	$val = -1;
else{
	require_once "database.php";
	$sql = "insert into ".$table_prefix."ecards (SenderId, RecieverId, CardId, CateCardId, Subjects, Contents, SentDate, WidthMess, HeightMess, LeftMess, TopMess, IsReed) values (".$_SESSION['memberid'].", ".intval($_GET['id']).", ".intval($_GET['c']).", ".intval($_GET['o']).", '".mysql_real_escape_string(urldecode($_GET['s']))."', '".mysql_real_escape_string(urldecode($_GET['m']))."', '".date('Y-m-d H:i:s')."', ".intval($_GET['w']).", ".intval($_GET['h']).", ".intval($_GET['l']).", ".intval($_GET['t']).", 0)";
	$qry = mysql_query($sql);
	if(!$qry)
		$val = -2;
	else $val = 1;
	mysql_close();
	}
echo json_encode(array("jval"=>$val));