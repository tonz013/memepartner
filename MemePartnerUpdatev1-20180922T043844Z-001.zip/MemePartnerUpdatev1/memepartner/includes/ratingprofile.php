<?php
require_once "config.php";
if(!isset($_GET['val']) || !isset($_GET['pr']) || intval($_GET['val'])==0 || intval($_GET['pr'])==0)
	$val = -2;
else{
	require_once "database.php";
	$sqli = "update ".$table_prefix."users set TotalRating = TotalRating + ".intval($_GET['val']).", NumberOfVote = NumberOfVote + 1 where UserID = ".intval($_GET['pr']);
	$qryi = mysql_query($sqli);
	if(!$qryi)
		$val = -2;
	else $val = 1;
	mysql_close();
	}
echo json_encode(array("jval"=>$val));