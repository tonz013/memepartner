<?php
require_once "config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0)
	$val = -1;
else{
	require_once "database.php";
	$sqls = "select FilrtValue from ".$table_prefix."flirts where Id = ".intval($_GET['val']);
	$qrys = mysql_query($sqls);
	if($qrys && mysql_num_rows($qrys)){
		$rss = mysql_fetch_array($qrys);
		$subj = 'Send a flirt';
		$sqli = "insert into ".$table_prefix."messages (RecieverID, SenderID, RecieverStatusID, SenderStatusID, SentOn, ReadOn, ReplyID, AttachmentUID, AttachmentExtension, Subject, Message, MessageStatus) values (".intval($_GET['id']).", ".$_SESSION['memberid'].", 0, 0, '".date('Y-m-d H:i:s')."', NULL, 0, 0, '', '".$subj."', '".mysql_real_escape_string($rss['FilrtValue'])."', 1)";
		$qryi = mysql_query($sqli);
		if(!$qryi)
			$val = -2;
		else $val = 1;
		}
	else $val = -2;
	mysql_close();
	}
echo json_encode(array("jval"=>$val));