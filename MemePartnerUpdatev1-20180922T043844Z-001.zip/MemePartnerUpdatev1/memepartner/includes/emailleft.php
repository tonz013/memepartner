<?php
switch($mailmn){
	case 1:
		$mailmn1 = 'class="composemail"';
		$mailmn2 = '';
		$mailmn3 = '';
		$mailmn4 = '';
		$mailmn5 = '';
		$mailmn6 = '';
	break;
	case 2:
		$mailmn1 = 'class="newmail"';
		$mailmn2 = 'class="mailactv"';
		$mailmn3 = '';
		$mailmn4 = '';
		$mailmn5 = '';
		$mailmn6 = '';
	break;
	case 3:
		$mailmn1 = 'class="newmail"';
		$mailmn2 = '';
		$mailmn3 = 'class="mailactv"';
		$mailmn4 = '';
		$mailmn5 = '';
		$mailmn6 = '';
	break;
	case 4:
		$mailmn1 = 'class="newmail"';
		$mailmn2 = '';
		$mailmn3 = '';
		$mailmn4 = 'class="mailactv"';
		$mailmn5 = '';
		$mailmn6 = '';
	break;
	case 5:
		$mailmn1 = 'class="newmail"';
		$mailmn2 = '';
		$mailmn3 = '';
		$mailmn4 = '';
		$mailmn5 = 'class="mailactv"';
		$mailmn6 = '';
	break;
	case 6:
		$mailmn1 = 'class="newmail"';
		$mailmn2 = '';
		$mailmn3 = '';
		$mailmn4 = '';
		$mailmn5 = '';
		$mailmn6 = 'class="mailactv"';
	break;
	}
$mninbox = countNewEmail($_SESSION['memberid']);
$strinbox = ($mninbox>0)?'<b>'.$inbox.' ('.$mninbox.')</b>':$inbox;
?>
<div class="mailfelft">
                	<p align="center"><input type="button" value="<?php echo $newmess;?>" <?php echo $mailmn1;?> onclick="window.location.href='<?php echo $base_url;?>members/compose.php'"/></p>
                    <ul>
                    	<a href="mail.php"><li <?php echo $mailmn2;?>><p class="normenu"><?php echo $strinbox;?></p></li></a>
                        <a href="sentmail.php"><li <?php echo $mailmn3;?>><p class="normenu"><?php echo $sentmail;?></p></li></a>
                        <a href="trashmail.php"><li <?php echo $mailmn4;?>><p class="normenu"><?php echo $trashmail;?></p></li></a>
                        <a href="blacklist.php"><li <?php echo $mailmn5;?>><p class="normenu"><?php echo $blacklist;?></p></li></a>
                        <a href="helpmail.php"><li <?php echo $mailmn6;?>><p class="lastmenu"><?php echo $helpmail;?></p></li></a>
                    </ul>
                </div>