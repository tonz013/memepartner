<?php
require_once "config.php";
if(!isset($_GET['val']) || !isset($_GET['pr']) || intval($_GET['val'])==0 || intval($_GET['pr'])==0)
	echo 'Your bad URL !!';
else{
	require_once "database.php";
	require_once "functions.php";
	$person = getFullPersonal(intval($_GET['pr']));
	if(empty($person['ProfileName']))
		echo 'There are no record !';
	else{
		$ispixel = ($person['NumberOfVote']>0)?round(($person['TotalRating']*100)/($person['NumberOfVote']*5)).'px':'0px';
		?>
        <span style="float:left;" class="rates_cont"><small><i><?php echo $yourrate.':';?></i></small><br />
        	<?php
			for($i=1; $i<6; $i++){
				$isclass = ($i<=intval($_GET['val']))?' class="active"':'';
				echo '<a href="javascript:void(0)" id="rate'.$i.'" '.$isclass.'>&nbsp;</a>';
				}
			?>
        </span>
        <span style="float:right; text-align:left"><small><i><?php echo $totalrate.':';?> <?php echo ($person['NumberOfVote']>0)?round($person['TotalRating']/$person['NumberOfVote'], 2):0;?> (<?php echo $person['NumberOfVote'].' '.$vote;?>)</i></small><br />
        <div style="width:100px;margin:0 auto;"><div class="active_rate_list"><div class="inactive_rate_list" style="width:<?php echo $ispixel;?>;"></div></div></div>
        </span>
        <?php
		}
	mysql_close();
	}