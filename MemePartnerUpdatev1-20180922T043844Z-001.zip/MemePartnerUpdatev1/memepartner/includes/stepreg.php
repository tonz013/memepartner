<?php
switch($isstep){
	case 1:
		$step1 = 'actvsteps';
		$step2 = 'noactvsteps';
		$step3 = 'noactvsteps';
	break;
	case 2:
		$step1 = 'noactvsteps';
		$step2 = 'actvsteps';
		$step3 = 'noactvsteps';
	break;
	case 3:
		$step1 = 'noactvsteps';
		$step2 = 'noactvsteps';
		$step3 = 'actvsteps';
	break;
	default:
		$step1 = 'actvsteps';
		$step2 = 'noactvsteps';
		$step3 = 'noactvsteps';
	break;
	}
?>
<br /><div id="stepreg">
	<p class="intro"><?php echo $stepprofile;?></p>
    <ul>
    	<li class="dwidth30"><p class="steps <?php echo $step1;?>">1. <?php echo $createaccount;?></p></li>
        <li class="dwidth35"><p class="steps <?php echo $step2;?>">2. <?php echo $aboutme;?></p></li>
        <li class="dwidth35"><p class="steps <?php echo $step3;?>">3. <?php echo $yourmatch;?></p></li>
    </ul>
    <p class="linespace">&nbsp;</p>
</div>