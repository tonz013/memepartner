<?php
if(isset($ismenu)){
	switch($ismenu){
		case 1:
			$mnact1 = 'actv';
			$mnact2 = 'notactv';
			$mnact3 = 'notactv';
			$mnact4 = 'notactv';
			$mnact5 = 'notactv';
			$mnact6 = 'notactv';
			$mnact7 = 'notactv';
		break;
		case 2:
			$mnact1 = 'fnotactv';
			$mnact2 = 'actv';
			$mnact3 = 'notactv';
			$mnact4 = 'notactv';
			$mnact5 = 'notactv';
			$mnact6 = 'notactv';
			$mnact7 = 'notactv';
		break;
		case 3:
			$mnact1 = 'fnotactv';
			$mnact2 = 'fnotactv';
			$mnact3 = 'actv';
			$mnact4 = 'notactv';
			$mnact5 = 'notactv';
			$mnact6 = 'notactv';
			$mnact7 = 'notactv';
		break;
		case 4:
			$mnact1 = 'fnotactv';
			$mnact2 = 'notactv';
			$mnact3 = 'fnotactv';
			$mnact4 = 'actv';
			$mnact5 = 'notactv';
			$mnact6 = 'notactv';
			$mnact7 = 'notactv';
		break;
		case 5:
			$mnact1 = 'fnotactv';
			$mnact2 = 'notactv';
			$mnact3 = 'notactv';
			$mnact4 = 'fnotactv';
			$mnact5 = 'actv';
			$mnact6 = 'notactv';
			$mnact7 = 'notactv';
		break;
		case 6:
			$mnact1 = 'fnotactv';
			$mnact2 = 'notactv';
			$mnact3 = 'notactv';
			$mnact4 = 'notactv';
			$mnact5 = 'fnotactv';
			$mnact6 = 'actv';
			$mnact7 = 'notactv';
		break;
		case 7:
			$mnact1 = 'fnotactv';
			$mnact2 = 'notactv';
			$mnact3 = 'notactv';
			$mnact4 = 'notactv';
			$mnact5 = 'notactv';
			$mnact6 = 'notactv';
			$mnact7 = 'actv';
		break;
		default:
			$mnact1 = 'fnotactv';
			$mnact2 = 'notactv';
			$mnact3 = 'notactv';
			$mnact4 = 'notactv';
			$mnact5 = 'notactv';
			$mnact6 = 'notactv';
		break;
		}
	}
else{
	$mnact1 = 'notactv';
	$mnact2 = 'notactv';
	$mnact3 = 'notactv';
	$mnact4 = 'notactv';
	$mnact5 = 'notactv';
	$mnact6 = 'notactv';
	$mnact6 = 'notactv';
	}
$str = '';
$str .= isset($_COOKIE['g'])?'g='.$_COOKIE['g'].'&':'g=0&';
$str .= isset($_COOKIE['a'])?'a='.$_COOKIE['a'].'&':'a=0&';
$str .= isset($_COOKIE['c'])?'c='.$_COOKIE['c']:'c=0';
if((!isset($_COOKIE['g']) && !isset($_COOKIE['a']) && !isset($_COOKIE['c'])) || ($_COOKIE['g']==0 && $_COOKIE['a']==0 && $_COOKIE['c']==0))
	$str = '';
if(!empty($str))
	$str = 'index.php?'.$str;
?>
<div id="menus">
            <ul>
                <li class="<?php echo $mnact1;?>"><b><a href="<?php echo $base_url.$str;?>"><?php echo $home;?></a></b></li>
                <li class="<?php echo $mnact2;?>"><b><a href="<?php echo $base_url;?>members/myaccount.php"><?php echo $account;?></a></b></li>
                <li class="<?php echo $mnact3;?>"><b><a href="<?php echo $base_url;?>search.php"><?php echo 'FIND MATCH';?></a></b></li>
                <li class="<?php echo $mnact4;?>"><b><a href="<?php echo $base_url;?>members/mail.php"><?php echo $checkmail;?></a></b></li>
                <!-- <li class="<?php echo $mnact5;?>"><b><a href="<?php echo $base_url;?>browse.php"><?php echo $browse;?></a></b></li> -->
                <li class="<?php echo $mnact5;?>"><b><a href="<?php echo $base_url;?>members.php"><?php echo 'members';?></a></b></li>
                <!--<li class="<?php echo $mnact6;?>"><b><a href="<?php echo $base_url;?>contact.php"><?php echo $contact;?></a></b></li>-->
                <li class="<?php echo $mnact7;?>"><b><a href="<?php echo $base_url;?>memes.php"><?php echo 'Memes';?></a></b></li>
            </ul>
            <p class="linespace">&nbsp;</p>
       </div>