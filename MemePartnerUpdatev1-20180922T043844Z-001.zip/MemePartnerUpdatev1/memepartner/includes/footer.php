<p>&nbsp;</p>
   </div>
   <div id="footer">
   		<p style="margin:10px 0px 2px 0px; padding:10px 0px 2px 0px"><a href="<?php echo $base_url;?>termofuse.php"><?php echo $termofofuse;?></a><span class="justspan">|</span><a href="<?php echo $base_url;?>contact.php"><?php echo $contact;?></a><span class="justspan">|</span><a href="<?php echo $base_url;?>help.php"><?php echo $help;?></a></p>
   		<p style="padding:0px 0px 0px 0px; margin:0px 0px 0px 0px"><?php echo stripslashes(html_entity_decode($strfoot));?></p>
   </div>
</body>
</html>