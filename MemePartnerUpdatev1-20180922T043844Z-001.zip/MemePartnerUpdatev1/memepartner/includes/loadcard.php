<?php
require_once "config.php";
require_once "database.php";
require_once "functions.php";
$sql = 'select Id,CardName from '.$table_prefix.'greetingcards where CardCate = '.intval($_GET['cardId']);
$qry = mysql_query($sql);
if($qry && mysql_num_rows($qry)>0){
	echo '<ul style="margin:0px; padding:0px;">';
	$i=1;
	while($row=mysql_fetch_array($qry)){
		$ml = ($i%3==1)?'':'margin-left:5px;';
		echo '<li style="list-style-type:none; float:left; text-align:center; margin-top:5px;"><img src="'.$base_url.'ecards/'.$row['CardName'].'" border="0" style="width:150px; height:195px; cursor:pointer; '.$ml.'" onclick="radioclick('.$row['Id'].')"/><br /><input type="radio" name="namecard" value="'.$row['Id'].'" onclick="radioclick(this.value)" id="namecard'.$row['Id'].'"/></li>';
		$i++;
		}
	echo '</ul>';
	}
else echo '<p>'.$norecord.'</p>';
?>