<?php
require_once "config.php";
require_once "database.php";
require_once "functions.php";
echo '<option value="0">- - '.$selectall.' - -</option>';
$sql = 'select StateID as Id, State as LName from '.$table_prefix.'states where CountryID = '.intval($_GET['countryId']).' order by TopSorted desc, LName asc';
dropdownlist($sql, 0);
?>