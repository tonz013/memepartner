<script language="javascript">
function onchangeSearch(){
	var str = '?g='+document.getElementById('slgender').value+'&a='+document.getElementById('slage').value+'&c='+document.getElementById('slcountry').value;
	window.location.href='<?php echo $base_url;?>index.php'+str;
	}
</script>
<div id="filter">
    <p><a href="<?php echo $base_url;?>members.php" <?php echo (!isset($_GET['t']))?'style="font-weight:bold"':'';?>>Latest members</a><a href="<?php echo $base_url;?>members.php?t=1" style="margin-left:20px; <?php echo (isset($_GET['t']) && intval($_GET['t'])==1)?'font-weight:bold':'';?>">Most viewed</a><a href="<?php echo $base_url;?>members.php?t=2" style="margin-left:20px; <?php echo (isset($_GET['t']) && intval($_GET['t'])==2)?'font-weight:bold':'';?>">Who's online</a><a href="<?php echo $base_url;?>members.php?t=3" style="margin-left:20px; <?php echo (isset($_GET['t']) && intval($_GET['t'])==3)?'font-weight:bold':'';?>">Top rated</a></p>
</div>