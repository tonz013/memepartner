<?php
$link = mysql_connect($hostname, $username, $password);
if (!$link) {
    die('Could not connect !');
	exit();
}
else{
	mysql_set_charset('utf8',$link);
	mysql_select_db($database, $link) or die('Could not select database.');
	}
$sqlcf = 'select Variable, Value from '.$table_prefix.'site_settings where IsRead = 0';
$qrycf = mysql_query($sqlcf);
if(!$qrycf)
	die('Can not load config data !');
elseif(mysql_num_rows($qrycf)>0){
	while($rowcf = mysql_fetch_array($qrycf)){
		if('filetype'==trim(strtolower($rowcf['Variable'])))
			$$rowcf['Variable'] = explode(',', $rowcf['Value']);
		elseif('numof_record_perpage'==trim(strtolower($rowcf['Variable'])))
			$$rowcf['Variable'] = intval($rowcf['Value']);
		elseif('default_language'==trim(strtolower($rowcf['Variable'])))
			$_SESSION['lang'] = isset($_SESSION['lang'])?$_SESSION['lang']:$rowcf['Value'];
		else eval("$\$rowcf['Variable'] = \"$rowcf[Value]\";");
		}
	}
else die('Can not find setting table !');