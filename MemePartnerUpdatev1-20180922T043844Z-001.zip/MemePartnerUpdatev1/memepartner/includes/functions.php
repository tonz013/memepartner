<?php

	function db(){
		return new PDO("mysql:host=localhost; dbname=memepartner", "root", "");
	}
	function add_post($user_id, $description){
		$db = db();
		$sql = "insert into dt_posts(UserID, Description) values(?,?)";
		$st = $db->prepare($sql);
		$st->execute(array($user_id, $description));
		$db = null;
	}
	function get_post(){
		$db = db();
		$sql = "select * from dt_posts order by PostID desc"; 
		$st = $db->prepare($sql);
		$st->execute();
		$post = $st->fetchAll();
		$db = null;
		return $post;
	}
if ( ! function_exists('valid_email')){
	function valid_email($address){
		return ( ! preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $address)) ? FALSE : TRUE;
		}
	}
if(!function_exists('exits_user')){
	function exits_user($user){
		$sql = "select UserID from ".$GLOBALS['table_prefix']."users where Email = '".$user."' and ProfileStatusID <> 0";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		elseif(mysql_num_rows($query)>0)
			return false;
		else return true;
		}
	}
if(!function_exists('new_user')){
	function new_user($data=array()){
		$sql = "insert into ".$GLOBALS['table_prefix']."users (MembershipID, RemainVIPContacts, SiteID, Name, ProfileName, Email, Password, GenderID, HeightID, Age, BodyTypeID, HairColorID, EyeColorID, City, StateID, CountryID, Zipcode, Phone, IMessagerID, IMessager, ReligionID, EducationID, Occupation, SmokingID, DrinkingID, MaritalStatusID, DatingInterestID, HaveChildren, WantChildren, WillingToTravel, IPaddress, DatePosted, DateUpdate, LastEmailSent, LastLogon, ProfileStatusID, NotificationScheduleID, MatchAgeFrom, MatchAgeTO, MatchGenderID, MatchHeightIDFrom, MatchHeightIDTo, MatchBodyStyleID, MatchReligionID, MatchEducationID, MatchCareerID, MatchSmokingID, MatchDrinkingID, MatchMaritalStatusID, MatchNumberofChild, MatchBeSameLocation, SubcribeList, RandomVerifyID, Goal, Interests, AboutMe, AboutMyMatch, PrimaryPhotoID, GroupID, Views, IsOnline, TotalRating, NumberOfVote, ThemeId) values (1, 0, 2, '', '', '".$data[0]."', '".$data[1]."', 0, 0, 0, 0, 0, 0, '', 0, 0, '', '', 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '".$data[3]."', '".gmdate("Y-m-d", time()+7*3600)."', '".gmdate("Y-m-d", time()+7*3600)."', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', NULL, 0, 0, 0, 0, 0, 1)";
		$query = mysql_query($sql);
		$newid = mysql_insert_id();
		if(!$query)
			return 0;
		else return $newid;
		}
	}
if(!function_exists('random_string')){
	function random_string($len=0){
		$pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$str = '';
		for ($i=0; $i < $len; $i++)
			$str .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
		return $str;
		}
	}
if(!function_exists('dropdownlist')){
	function dropdownlist($sql='', $val=0){
		$query = mysql_query($sql);
		if(!$query)
			echo '<option value="-1">- Error data -</option>';
		else{
			while($rows=mysql_fetch_array($query)){
				$sel = ($rows['Id']==$val)?' selected="selected"':'';
				echo '<option value="'.$rows['Id'].'" '.$sel.'>'.$rows['LName'].'</option>';
				}
			}
		}
	}
if(!function_exists('yourdetails')){
	function yourdetails($data=array(), $userid=0){
		$sql = "update ".$GLOBALS['table_prefix']."users set ProfileName = '".$data[0]."', AboutMe = '".$data[1]."', GenderID = ".$data[2].", Age = ".$data[3].", CountryID = ".$data[4].", StateID = ".$data[5].", City = '".$data[6]."', Zipcode = '".$data[7]."', Interests = '".$data[8]."', MaritalStatusID = ".$data[9].", Occupation = '".$data[10]."', Phone = '".$data[11]."', ReligionID = ".$data[12].", EducationID = ".$data[13].", BodyTypeID = ".$data[14].", HairColorID = ".$data[15].", EyeColorID = ".$data[16].", HeightID = ".$data[17].", SmokingID = ".$data[18].", DrinkingID = ".$data[19].", HaveChildren = ".$data[20].", WantChildren = ".$data[21].", WillingToTravel = ".$data[22].", DateUpdate = '".gmdate("Y-m-d", time()+7*3600)."', ProfileStatusID = 4 where UserID = ".$userid;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('yourmatch')){
	function yourmatch($data=array(), $userid=0){
		$sql = "update ".$GLOBALS['table_prefix']."users set MatchGenderID = ".$data[0].", MatchAgeFrom = ".$data[1].", MatchAgeTO = ".$data[2].", DatingInterestID = ".$data[3].", AboutMyMatch = '".$data[4]."', MatchMaritalStatusID = ".$data[5].", MatchReligionID = ".$data[6].", MatchEducationID = ".$data[7].", MatchBodyStyleID = ".$data[8].", MatchHeightIDFrom = ".$data[9].", MatchHeightIDTo = ".$data[10].", MatchSmokingID = ".$data[11].", MatchDrinkingID = ".$data[12].", MatchBeSameLocation = ".$data[13].", LastLogon = '".gmdate("Y-m-d H:i:s", time()+7*3600)."', DateUpdate = '".gmdate("Y-m-d", time()+7*3600)."', ProfileStatusID = 4 where UserID = ".$userid;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('UserLogin')){
	function UserLogin($info=array()){
		$sql = "select UserID from ".$GLOBALS['table_prefix']."users where Email = '".$info[0]."' and Password = '".$info[1]."' and ProfileStatusID <> 0";
		$query = mysql_query($sql);
		if(!$query)
			return 0;
		elseif(mysql_num_rows($query)>0){
			$row=mysql_fetch_array($query);
			return $row['UserID'];
			}
		else return -1;
		}
	}
if(!function_exists('GetPassword')){
	function GetPassword($user=''){
		$sql = "select Password from ".$GLOBALS['table_prefix']."users where Email = '".$user."'";
		$query = mysql_query($sql);
		$row=mysql_fetch_array($query);
		return $row['Password'];
		}
	}
if(!function_exists('GetProfileName')){
	function GetProfileName($userid=0){
		$sql = "select ProfileName from ".$GLOBALS['table_prefix']."users where UserID = ".$userid;
		$query = mysql_query($sql);
		$row=mysql_fetch_array($query);
		return $row['ProfileName'];
		}
	}
if(!function_exists('countMembsersPhotos')){
	function countMembsersPhotos($sqlsearch=''){
		$sql = "select u.UserID from ".$GLOBALS['table_prefix']."users as u inner join ".$GLOBALS['table_prefix']."photos as p on u.PrimaryPhotoID = p.PhotoID and p.IsApproved = 1 where ".$sqlsearch." u.ProfileStatusID = 1 and u.GenderID IS NOT NULL AND u.PrimaryPhotoID > 0";
		$query = mysql_query($sql);
		return mysql_num_rows($query);
		}
	}
if(!function_exists('getInfoMatch')){
	function getInfoMatch($userid=0){
		$sql = "select MatchAgeFrom, MatchAgeTO, MatchGenderID, MatchHeightIDFrom, MatchHeightIDTo, MatchBodyStyleID, MatchReligionID, MatchEducationID, MatchSmokingID, MatchDrinkingID, MatchMaritalStatusID, MatchBeSameLocation, CountryID, DatingInterestID from ".$GLOBALS['table_prefix']."users where UserID = ".$userid;
		$query = mysql_query($sql);
		return mysql_fetch_array($query);
		}
	}
if(!function_exists('Pagination')){
	function Pagination($config=array()){
		if($_SESSION['lang']=='L1'){
			$firstpage = 'First';
			$lastpage = 'Last';
			}
		else{
			{
			$firstpage = 'Trang đầu';
			$lastpage = 'Trang cuối';
			}
			}
		$output = '';
		$rs_maxpage = $config['js_numrows_page']>0?ceil($config['js_numrows_page']/$config['per_page']):0;
		$eitherside = ($config['showeachside'] * $config['per_page']);
		$paga = (strpos($config['cururl'], '?')!==false)?'&p=':'?p=';
		if($rs_maxpage>1){
			if($config['rs_start']+1 > $eitherside){
				$page = $config['curpage'] - 1;
				$output .= '<a href="'.$config['cururl'].'"><i>'.$firstpage.'</i></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$config['cururl'].$paga.$page.'"><i><<</i></a> . . . ';
				}
				$pg=1;
			for($y=0; $y<$config['js_numrows_page']; $y+=$config['per_page']){
				if(($y > ($config['rs_start'] - $eitherside)) && ($y < ($config['rs_start'] + $eitherside)))
					$output .= ($pg==$config['curpage'])?'<b> &nbsp;'.$pg.'</b>':' &nbsp;<a href="'.$config['cururl'].$paga.$pg.'">'.$pg.'</a>';
				$pg++;
				}
			if(($config['rs_start']+$eitherside)<$config['js_numrows_page']){
				$page = $config['curpage'] + 1;
				$output .=  ' . . . <a href="'.$config['cururl'].$paga.$page.'"><i>>></i></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$config['cururl'].$paga.$rs_maxpage.'"><i>'.$lastpage.'</i></a>';
				}
			}
		return $output;
		}
	}
if(!function_exists('getFullPersonal')){
	function getFullPersonal($userid=0){
		$sql = "select u.UserID, ProfileName, Age, AboutMe, City, MatchAgeFrom, MatchAgeTO, LastLogon, PrimaryPhotoID, m.".$_SESSION['lang']."MaritalStatus as LMaritalStatus, State, Country, g.".$_SESSION['lang']."Gender as LGender, PhotoExtension, h.HeightDescription, b.".$_SESSION['lang']."BodyType as LBodyType, ".$_SESSION['lang']."HairColor as LHairColor, ".$_SESSION['lang']."EyeColor as LEyeColor, r.".$_SESSION['lang']."Religion as LReligion, ed.".$_SESSION['lang']."Education as LEducation, Occupation, sm.".$_SESSION['lang']."Smoking as LSmoking, d.".$_SESSION['lang']."Drinking as LDrinking, ".$_SESSION['lang']."DatingInterest as LDatingInterest, HaveChildren, WantChildren, WillingToTravel, Goal, Interests, AboutMyMatch, ge.".$_SESSION['lang']."Gender as MLGender, edu.".$_SESSION['lang']."Education as MLEducation, ma.".$_SESSION['lang']."MaritalStatus as MLMaritalStatus, he.HeightDescription as MFHeightDescription, hei.HeightDescription as MTHeightDescription, MatchHeightIDFrom, MatchHeightIDTo, bo.".$_SESSION['lang']."BodyType as MLBodyType, re.".$_SESSION['lang']."Religion as MLReligion, smo.".$_SESSION['lang']."Smoking as MLSmoking, dr.".$_SESSION['lang']."Drinking as MLDrinking, u.GenderID, u.CountryID, RemainVIPContacts, Email, Phone, IsOnline, u.TotalRating, u.NumberOfVote from ".$GLOBALS['table_prefix']."users as u left join ".$GLOBALS['table_prefix']."maritalstatus as m on u.MaritalStatusID = m.MaritalStatusID left join ".$GLOBALS['table_prefix']."states as s on u.StateID = s.StateID left join ".$GLOBALS['table_prefix']."countries as c on u.CountryID = c.CountryID left join ".$GLOBALS['table_prefix']."gender as g on u.GenderID = g.GenderID left join ".$GLOBALS['table_prefix']."photos as p on u.PrimaryPhotoID = p.PhotoID left join ".$GLOBALS['table_prefix']."height as h on u.HeightID = h.HeightID left join ".$GLOBALS['table_prefix']."bodytypes as b on u.BodyTypeID = b.BodyTypeID left join ".$GLOBALS['table_prefix']."haircolors as ha on u.HairColorID = ha.HairColorID left join ".$GLOBALS['table_prefix']."eyescolors as e on u.EyeColorID = e.EyeColorID left join ".$GLOBALS['table_prefix']."religions as r on u.ReligionID = r.ReligionID left join ".$GLOBALS['table_prefix']."educations as ed on u.EducationID = ed.EducationID left join ".$GLOBALS['table_prefix']."smoking as sm on u.SmokingID = sm.SmokingID left join ".$GLOBALS['table_prefix']."drinking as d on u.DrinkingID = d.DrinkingID left join ".$GLOBALS['table_prefix']."datinginterest as da on u.DatingInterestID = da.DatingInterestID left join ".$GLOBALS['table_prefix']."gender as ge on u.MatchGenderID = ge.GenderID left join ".$GLOBALS['table_prefix']."educations as edu on u.MatchEducationID = edu.EducationID left join ".$GLOBALS['table_prefix']."maritalstatus as ma on u.MatchMaritalStatusID = ma.MaritalStatusID left join ".$GLOBALS['table_prefix']."height as he on u.MatchHeightIDFrom = he.HeightID left join ".$GLOBALS['table_prefix']."height as hei on u.MatchHeightIDTo = hei.HeightID left join ".$GLOBALS['table_prefix']."bodytypes as bo on u.MatchBodyStyleID = bo.BodyTypeID left join ".$GLOBALS['table_prefix']."religions as re on u.MatchReligionID = re.ReligionID left join ".$GLOBALS['table_prefix']."smoking as smo on u.MatchSmokingID = smo.SmokingID left join ".$GLOBALS['table_prefix']."drinking as dr on u.MatchDrinkingID = dr.DrinkingID where u.UserID = ".$userid." and u.ProfileStatusID = 1 and u.GenderID IS NOT NULL ";
		$query = mysql_query($sql);
		return mysql_fetch_array($query);
		}
	}
if(!function_exists('getUserPhotos')){
	function getUserPhotos($userid=0){
		$results = array();
		$sql = "select PhotoID, PhotoExtension from ".$GLOBALS['table_prefix']."photos where UserID = ".$userid." and IsApproved = 1 order by InsertDate desc";
		$query = mysql_query($sql);
		while($rows = mysql_fetch_array($query)){
			$results['id'][] = $rows['PhotoID'];
			$results['ext'][] = $rows['PhotoExtension'];
			}
		return $results;
		}
	}
if(!function_exists('getSameProfile')){
	function getSameProfile($gender=0, $country=0, $userid=0, $age=0){
		$agef = $age - 5;
		$aget = $age + 5;
		$sql = "select u.UserID, ProfileName, Age, City, PrimaryPhotoID, PhotoExtension, State, Country from ".$GLOBALS['table_prefix']."users as u left join ".$GLOBALS['table_prefix']."states as s on u.StateID = s.StateID left join ".$GLOBALS['table_prefix']."countries as c on u.CountryID = c.CountryID left join ".$GLOBALS['table_prefix']."photos as p on u.PrimaryPhotoID = p.PhotoID and p.IsApproved = 1 where u.UserID <> ".$userid." and u.GenderID = ".$gender." and u.ProfileStatusID = 1 and u.CountryID = ".$country.' AND p.PhotoID IS not NULL and (Age >= '.$agef.' and Age <= '.$aget.') order by rand() limit 5';
		$query = mysql_query($sql);
		return $query;
		}
	}
if(!function_exists('getPersonalInfo')){
	function getPersonalInfo($userid=0){
		$sql = "select ProfileName, AboutMe, GenderID, Age, CountryID, StateID, City, Zipcode, Interests, MaritalStatusID, Occupation, Phone, ReligionID, EducationID, BodyTypeID, HairColorID, EyeColorID, HeightID, SmokingID, DrinkingID, HaveChildren, WantChildren, WillingToTravel from ".$GLOBALS['table_prefix']."users where UserID = ".$userid;
		$query = mysql_query($sql);
		return mysql_fetch_array($query);
		}
	}
if(!function_exists('getPersonalMatch')){
	function getPersonalMatch($userid=0){
		$sql = "select MatchGenderID, MatchAgeFrom, MatchAgeTO, DatingInterestID, AboutMyMatch, MatchMaritalStatusID, MatchReligionID, MatchEducationID, MatchBodyStyleID, MatchHeightIDFrom, MatchHeightIDTo, MatchSmokingID, MatchDrinkingID, MatchBeSameLocation from ".$GLOBALS['table_prefix']."users where UserID = ".$userid;
		$query = mysql_query($sql);
		return mysql_fetch_array($query);
		}
	}
if(!function_exists('ChangePassword')){
	function ChangePassword($data=array()){
		$sql = "select UserID, Password from ".$GLOBALS['table_prefix']."users where UserID = ".$data[2]." and Password = '".$data[0]."'";
		$query = mysql_query($sql);
		if(!$query)
			return -1;
		elseif(mysql_num_rows($query)>0){
			$uppass = "update ".$GLOBALS['table_prefix']."users set Password = '".$data[1]."' where UserID = ".$data[2];
			$uqery = mysql_query($uppass);
			if(!$uqery)
				return -1;
			else return 1;
			}
		else return 0;
		}
	}
if(!function_exists('settingsAccount')){
	function settingsAccount($data=array()){
		$sql = "update ".$GLOBALS['table_prefix']."users set ProfileStatusID = ".$data[0].", NotificationScheduleID = ".$data[1]." where UserID = ".$data[2];
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('getSettingsAccount')){
	function getSettingsAccount($user=0){
		$sql = "select u.ProfileStatusID, NotificationScheduleID, ".$_SESSION['lang']."ProfileStatus as LProfileStatus, ".$_SESSION['lang']."NOTIFY as LNOTIFY from ".$GLOBALS['table_prefix']."users as u left join ".$GLOBALS['table_prefix']."profilestatus as p on u.ProfileStatusID = p.ProfileStatusID left join ".$GLOBALS['table_prefix']."notifyemail as n on u.NotificationScheduleID = n.Id where UserID = ".$user;
		$query = mysql_query($sql);
		return mysql_fetch_array($query);
		}
	}
if(!function_exists('setPrimaryPhoto')){
	function setPrimaryPhoto($data=array()){
		$sql = "update ".$GLOBALS['table_prefix']."users set PrimaryPhotoID = ".$data[1]." where UserID = ".$data[0];
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('getPrimaryPhoto')){
	function getPrimaryPhoto($user=0){
		$img='';
		$sql = "select u.PrimaryPhotoID, PhotoExtension from ".$GLOBALS['table_prefix']."users as u left join ".$GLOBALS['table_prefix']."photos as p on u.PrimaryPhotoID = p.PhotoID where u.UserID = ".$user.' and u.PrimaryPhotoID > 0';
		$query = mysql_query($sql);
		if(!$query)
			return $img;
		elseif(mysql_num_rows($query)>0){
			$row = mysql_fetch_array($query);
			return $user.'u'.$row['PrimaryPhotoID'].'.'.$row['PhotoExtension'];
			}
		else return $img;
		}
	}
if(!function_exists('delPhotos')){
	function delPhotos($data=array(), $user=0){
		$sql = "delete from ".$GLOBALS['table_prefix']."photos where PhotoID in (".implode(', ', $data).") and UserID = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('getAllPhotos')){
	function getAllPhotos($userid=0){
		$results = array();
		$sql = "select PhotoID, PhotoExtension, IsApproved from ".$GLOBALS['table_prefix']."photos where UserID = ".$userid." order by InsertDate desc";
		$query = mysql_query($sql);
		while($rows = mysql_fetch_array($query)){
			$results['id'][] = $rows['PhotoID'];
			$results['ext'][] = $rows['PhotoExtension'];
			$results['app'][] = $rows['IsApproved'];
			}
		return $results;
		}
	}
if(!function_exists('addPhotos')){
	function addPhotos($data=array()){
		$sql = "insert into ".$GLOBALS['table_prefix']."photos (UserID, PhotoExtension, PhotoDescription, IsApproved, PrimaryPhoto, InsertDate, TotalRating, NumberOfVote) values (".$data[0].", '".$data[1]."', '".$data[2]."', 1, 0, '".gmdate("Y-m-d", time()+7*3600)."', 0, 0)";
		$query = mysql_query($sql);
		$id = mysql_insert_id();
		if(!$query)
			return -1;
		else return $id;
		}
	}
if(!function_exists('countSearchProfile')){
	function countSearchProfile($sqlsearch='', $only = 0){
		if($only>0)
			$sql = "select u.UserID from ".$GLOBALS['table_prefix']."users as u left join ".$GLOBALS['table_prefix']."photos as p on u.PrimaryPhotoID = p.PhotoID and p.IsApproved = 1 where ".$sqlsearch." u.ProfileStatusID = 1 and u.GenderID IS NOT NULL AND p.PhotoID IS not NULL and GroupID <> 5";
		else $sql = "select u.UserID from ".$GLOBALS['table_prefix']."users as u left join ".$GLOBALS['table_prefix']."photos as p on u.PrimaryPhotoID = p.PhotoID and p.IsApproved = 1 where ".$sqlsearch." u.ProfileStatusID = 1 and u.GenderID IS NOT NULL and GroupID <> 5";
		$query = mysql_query($sql);
		return mysql_num_rows($query);
		}
	}
if(!function_exists('saveSearch')){
	function saveSearch($query='', $user = 0, $name = ''){
		$sql = "insert into ".$GLOBALS['table_prefix']."savedsearch (UserID, SearchName, Query, SearchValue, DateCreated, DateProcessed, SubcriptionStatusID) values (".$user.", '".$name."', '".$query."', '".$query."', '".gmdate("Y-m-d H:i:s", time()+7*3600)."', '".gmdate("Y-m-d H:i:s", time()+7*3600)."', 0)";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('savingProfile')){
	function savingProfile($user = 0, $profile = 0){
		$slsql = 'select UserID from '.$GLOBALS['table_prefix'].'hotlists where UserID = '.$user.' and SavedUserID = '.$profile;
		$slqry = mysql_query($slsql);
		if(!$slqry)
			return -1;
		elseif(mysql_num_rows($slqry)>0)
			return 0;
		else{
			$sql = "insert into ".$GLOBALS['table_prefix']."hotlists (UserID, SavedUserID, SavedDate) values (".$user.", ".$profile.", '".gmdate("Y-m-d H:i:s", time()+7*3600)."')";
			$query = mysql_query($sql);
			if(!$query)
				return -1;
			else return 1;
			}
		}
	}
if(!function_exists('sendSignal')){
	function sendSignal($user = 0, $profile = 0){
		$sql = "insert into ".$GLOBALS['table_prefix']."signalme (RecieverID, SenderID, SignalDate) values (".$profile.", ".$user.", '".gmdate("Y-m-d H:i:s", time()+7*3600)."')";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('countSavedProfile')){
	function countSavedProfile($user=0){
		$sql = "select UserID from ".$GLOBALS['table_prefix']."hotlists where UserID = ".$user;
		$query = mysql_query($sql);
		return mysql_num_rows($query);
		}
	}
if(!function_exists('delSavedProfile')){
	function delSavedProfile($user = 0, $profile = 0){
		$sql = "delete from ".$GLOBALS['table_prefix']."hotlists where UserID = ".$user." and SavedUserID = ".$profile;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('countSignalTo')){
	function countSignalTo($user=0){
		$sql = "select RecieverID from ".$GLOBALS['table_prefix']."signalme as s inner join ".$GLOBALS['table_prefix']."users as u on s.SenderID = u.UserID where RecieverID = ".$user;
		$query = mysql_query($sql);
		return mysql_num_rows($query);
		}
	}
if(!function_exists('countSignalFrom')){
	function countSignalFrom($user=0){
		$sql = "select SenderID from ".$GLOBALS['table_prefix']."signalme as s inner join ".$GLOBALS['table_prefix']."users as u on s.RecieverID = u.UserID where SenderID = ".$user;
		$query = mysql_query($sql);
		return mysql_num_rows($query);
		}
	}
if(!function_exists('updateWhoViews')){
	function updateWhoViews($user=0, $profile = 0){
		$sql = "select Id from ".$GLOBALS['table_prefix']."whoviews where UserId = ".$user.' and ViewUserId = '.$profile;
		$query = mysql_query($sql);
		if(!$query)
			return;
		elseif(mysql_num_rows($query)>0){
			$upsql = 'update '.$GLOBALS['table_prefix'].'whoviews set ViewDate = '.gmdate("Y-m-d H:i:s", time()+7*3600).' where UserId = '.$user.' and ViewUserId = '.$profile;
			$upqry = mysql_query($sql);
			if(!$upqry)
				return;
			}
		else{
			$insql = "insert into ".$GLOBALS['table_prefix']."whoviews (UserId, ViewUserId, ViewDate, IsView) values (".$user.", ".$profile.", '".gmdate("Y-m-d H:i:s", time()+7*3600)."', 0) ";
			$inqry = mysql_query($insql);
			if(!$inqry)
				return;
			}
		}
	}
if(!function_exists('countViewsProfile')){
	function countViewsProfile($user=0){
		$sql = "select Id from ".$GLOBALS['table_prefix']."whoviews as w inner join ".$GLOBALS['table_prefix']."users as u on w.UserId = u.UserID where ViewUserId = ".$user;
		$query = mysql_query($sql);
		return mysql_num_rows($query);
		}
	}
if(!function_exists('upViewsProfile')){
	function upViewsProfile($user=0){
		$sql = "update ".$GLOBALS['table_prefix']."whoviews set IsView = 1 where ViewUserId = ".$user;
		$query = mysql_query($sql);
		return true;
		}
	}
if(!function_exists('delFavoriteProfile')){
	function delFavoriteProfile($user = 0, $profile = 0){
		$sql = "delete from ".$GLOBALS['table_prefix']."signalme where SenderID = ".$user." and RecieverID = ".$profile;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('membersSendMail')){
	function membersSendMail($data=array(), $RecieverID = 0){
		$sql = "insert into ".$GLOBALS['table_prefix']."messages (RecieverID, SenderID, RecieverStatusID, SenderStatusID, SentOn, ReadOn, ReplyID, AttachmentUID, AttachmentExtension, Subject, Message, MessageStatus) values (".$RecieverID.", ".$data[2].", 0, 0, '".gmdate("Y-m-d H:i:s", time()+7*3600)."', NULL, 0, '', '', '".$data[0]."', '".$data[1]."', 1)";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('getIdFromProfileName')){
	function getIdFromProfileName($name=''){
		$sql = "select UserID from ".$GLOBALS['table_prefix']."users where ProfileName = '".$name."'";
		$query = mysql_query($sql);
		if(!$query)
			return -1;
		elseif(mysql_num_rows($query)>0){
			$row = mysql_fetch_array($query);
			return $row['UserID'];
			}
		else return 0;
		}
	}
if(!function_exists('getSentMessages')){
	function getSentMessages($user=0, $limit=''){
		$sql = "select MessageID, SentOn, Subject, SUBSTRING_INDEX(REPLACE(REPLACE(Message, '.', '. '), ',', ', '),' ', 4) as Message, MessageStatus, ProfileName from ".$GLOBALS['table_prefix']."messages as m left join ".$GLOBALS['table_prefix']."users as u on m.RecieverID = u.UserID where SenderID = ".$user." and SenderStatusID = 0 order by SentOn desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return $query;
		}
	}
if(!function_exists('delSentMessages')){
	function delSentMessages($mess=array(), $user=0){
		$sql = "update ".$GLOBALS['table_prefix']."messages set SenderStatusID = 1 where MessageID in (".implode(',', $mess).") and SenderID = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return $query;
		}
	}
if(!function_exists('MessagesDetails')){
	function MessagesDetails($user=0, $mess=0, $type=''){
		if($type=='s')
			$sql = "select SentOn, Subject, Message, MessageStatus, ProfileName from ".$GLOBALS['table_prefix']."messages as m left join ".$GLOBALS['table_prefix']."users as u on m.RecieverID = u.UserID where MessageID = ".$mess." and SenderID = ".$user;
		elseif($type=='i'){
			$sql = "select SenderID, SentOn, Subject, Message, MessageStatus, ProfileName, Email from ".$GLOBALS['table_prefix']."messages as m left join ".$GLOBALS['table_prefix']."users as u on m.SenderID = u.UserID where MessageID = ".$mess." and RecieverID = ".$user;
			upMessageStatus($user, array($mess));
			}
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return mysql_fetch_array($query);
		}
	}
if(!function_exists('getInbox')){
	function getInbox($user=0, $limit=''){
		$sql = "select MessageID, SentOn, Subject, SUBSTRING_INDEX(REPLACE(REPLACE(Message, '.', '. '), ',', ', '),' ', 4) as Message, MessageStatus, ProfileName, ReadOn from ".$GLOBALS['table_prefix']."messages as m inner join ".$GLOBALS['table_prefix']."users as u on m.SenderID = u.UserID where RecieverID = ".$user." and RecieverStatusID = 0 and MessageStatus = 1 order by SentOn desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return $query;
		}
	}
if(!function_exists('upMessageStatus')){
	function upMessageStatus($user=0, $mess=array()){
		$sql = "update ".$GLOBALS['table_prefix']."messages set ReadOn = '".gmdate("Y-m-d H:i:s", time()+7*3600)."' where RecieverID = ".$user." and MessageID in (".implode(',', $mess).")";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		return true;
		}
	}
if(!function_exists('delInbMessages')){
	function delInbMessages($mess=array(), $user=0){
		$sql = "update ".$GLOBALS['table_prefix']."messages set RecieverStatusID = 1 where MessageID in (".implode(',', $mess).") and RecieverID = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('countNewEmail')){
	function countNewEmail($user=0){
		$sql = "select MessageID from ".$GLOBALS['table_prefix']."messages as m inner join ".$GLOBALS['table_prefix']."users as u on u.UserID = m.SenderID where RecieverID = ".$user." and RecieverStatusID = 0 and MessageStatus = 1 and ReadOn IS NULL";
		$query = mysql_query($sql);
		if(!$query)
			return 0;
		else return mysql_num_rows($query);
		}
	}
if(!function_exists('isReplyMessages')){
	function isReplyMessages($mess=0, $user=0){
		$sql = "select MessageID from ".$GLOBALS['table_prefix']."messages where SenderID = ".$user." and ReplyID = ".$mess;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		elseif(mysql_num_rows($query)>0)
			return true;
		else return false;
		}
	}
if(!function_exists('AnswerMessage')){
	function AnswerMessage($data=array(), $user=0){
		$sql = "insert into ".$GLOBALS['table_prefix']."messages (RecieverID, SenderID, RecieverStatusID, SenderStatusID, SentOn, ReadOn, ReplyID, AttachmentUID, AttachmentExtension, Subject, Message, MessageStatus) values (".$data[3].", ".$user.", 0, 0, '".gmdate("Y-m-d H:i:s", time()+7*3600)."', NULL, ".$data[0].", '', '', '".$data[2]."', '".$data[1]."', 1)";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('countNewSignal')){
	function countNewSignal($user=0){
		$sql = "select RecieverID from ".$GLOBALS['table_prefix']."signalme as s inner join ".$GLOBALS['table_prefix']."users as u on u.UserID = s.SenderID where RecieverID = ".$user." and IsViews = 0";
		$query = mysql_query($sql);
		if(!$query)
			return 0;
		else return mysql_num_rows($query);
		}
	}
if(!function_exists('getTrashEmail')){
	function getTrashEmail($user=0, $limit=''){
		$sql = "select MessageID, SentOn, Subject, SUBSTRING_INDEX(REPLACE(REPLACE(Message, '.', '. '), ',', ', '),' ', 4) as Message, MessageStatus, ProfileName, ReadOn from ".$GLOBALS['table_prefix']."messages as m left join ".$GLOBALS['table_prefix']."users as u on m.SenderID = u.UserID where RecieverID = ".$user." and RecieverStatusID = 1 and MessageStatus = 1 order by SentOn desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return $query;
		}
	}
if(!function_exists('updTrashMessages')){
	function updTrashMessages($mess=array(), $user=0, $status=1){
		$sql = "update ".$GLOBALS['table_prefix']."messages set MessageStatus = ".$status." where MessageID in (".implode(',', $mess).") and RecieverID = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('recoveryMessages')){
	function recoveryMessages($mess=array(), $user=0){
		$sql = "update ".$GLOBALS['table_prefix']."messages set RecieverStatusID = 0 where MessageID in (".implode(',', $mess).") and RecieverID = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('blockUser')){
	function blockUser($mess=0, $user=0){
		$chksql = 'select UserID from '.$GLOBALS['table_prefix'].'blockedusers where UserID = '.$user.' and BlockedUserID in (select SenderID from '.$GLOBALS['table_prefix'].'messages where MessageID = '.$mess.')';
		$chkqry = mysql_query($chksql);
		if(!$chkqry)
			return false;
		elseif(mysql_num_rows($chkqry)>0)
			return true;
		else{
			$sql = "insert into ".$GLOBALS['table_prefix']."blockedusers (UserID, BlockedUserID, DateBlock) values ($user, (select SenderID from ".$GLOBALS['table_prefix']."messages where MessageID = ".$mess."), '".gmdate("Y-m-d H:i:s", time()+7*3600)."')";
			$query = mysql_query($sql);
			if(!$query)
				return false;
			else return true;
			}
		}
	}
if(!function_exists('getBlackList')){
	function getBlackList($user=0, $limit=''){
		$sql = "select BlockedUserID, ProfileName, Age, LastLogon, City, Country, State from ".$GLOBALS['table_prefix']."blockedusers as b left join ".$GLOBALS['table_prefix']."users as u on b.BlockedUserID = u.UserID left join ".$GLOBALS['table_prefix']."states as s on u.StateID = s.StateID left join ".$GLOBALS['table_prefix']."countries as c on u.CountryID = c.CountryID where b.UserID = ".$user." order by DateBlock desc ".$limit;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return $query;
		}
	}
if(!function_exists('unBlockUser')){
	function unBlockUser($user=0, $block=0){
		$sql = "delete from ".$GLOBALS['table_prefix']."blockedusers where UserID = ".$user." and BlockedUserID = ".$block;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('updFavorites')){
	function updFavorites($user=0){
		$sql = "update ".$GLOBALS['table_prefix']."signalme set IsViews = 1 where RecieverID = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('updLogon')){
	function updLogon($user=0){
		$sql = "update ".$GLOBALS['table_prefix']."users set LastLogon = '".gmdate("Y-m-d H:i:s", time()+7*3600)."', IsOnline = 1 where UserID = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('isBlockedMe')){
	function isBlockedMe($user=0, $block=0){
		$sql = "select UserID from ".$GLOBALS['table_prefix']."blockedusers where UserID = ".$user." and BlockedUserID = ".$block;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		elseif(mysql_num_rows($query)>0)
			return true;
		else return false;
		}
	}
if(!function_exists('getSaveSearch')){
	function getSaveSearch(){
		$sql = "select SearchName, SearchValue from ".$GLOBALS['table_prefix']."savedsearch where UserID = 0";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return $query;
		}
	}
if(!function_exists('chkBannedMe')){
	function chkBannedMe($user=0){
		$baned = array();
		$sql = "select Reason, BanedOn, LiftBanId, ".$_SESSION['lang']."LiftBan as LLiftBan from ".$GLOBALS['table_prefix']."bannedusers as b left join ".$GLOBALS['table_prefix']."liftbaned as l on b.LiftBanId = l.Id where UserId = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return $baned;
		elseif(mysql_num_rows($query)>0){
			return mysql_fetch_array($query);
			}
		else return $baned;
		}
	}
if(!function_exists('countSavedSearch')){
	function countSavedSearch($user=0){
		$sql = "select SearchID from ".$GLOBALS['table_prefix']."savedsearch where UserID = ".$user;
		$query = mysql_query($sql);
		return mysql_num_rows($query);
		}
	}
if(!function_exists('delSavedSearch')){
	function delSavedSearch($searchid=0, $user=0){
		$sql = "delete from ".$GLOBALS['table_prefix']."savedsearch where SearchID = ".$searchid." and UserID = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('updSavedSearch')){
	function updSavedSearch($data=array()){
		$sql = "update ".$GLOBALS['table_prefix']."savedsearch set SearchName = '".$data[2]."' where SearchID = ".$data[0]." and UserID = ".$data[1];
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('countEmailSent')){
	function countEmailSent($user=0, $newdate=''){
		$sql = "select MessageID from ".$GLOBALS['table_prefix']."messages where SenderID = ".$user." and date_format(SentOn, '%Y-%m-%d') = '".$newdate."'";
		$query = mysql_query($sql);
		if(!$query)
			return -1;
		else return mysql_num_rows($query);
		}
	}
if(!function_exists('neworder')){
	function neworder($data=array()){
		$sql = "insert into ".$GLOBALS['table_prefix']."orders (OrderId, UserId, PayDate, Amounts, Status, PaymentId_NL, PaymentType_NL, PriceId, ExpireDate) values ('', ".$data[0].", '".$data[2]."', ".$data[1].", 0, 0, 0, ".$data[3].", NULL)";
		$query = mysql_query($sql);
		if(!$query)
			return -1;
		else return mysql_insert_id();
		}
	}
if(!function_exists('updorder')){
	function updorder($data=array()){
		$sql = "update ".$GLOBALS['table_prefix']."orders set OrderId = '".$data[0]."', Status = ".$data[1].", PaymentId_NL = ".$data[2].", PaymentType_NL = ".$data[1]." where Id = ".$data[3]." and UserId = ".$data[4];
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('getDateorder')){
	function getDateorder($order=0){
		$sql = "select PayDate from ".$GLOBALS['table_prefix']."orders where Id = ".$order;
		$query = mysql_query($sql);
		if(!$query)
			return '';
		elseif(mysql_num_rows($query)>0){
			$row=mysql_fetch_array($query);
			return date('H:i:s d-m-Y', strtotime($row['PayDate']));
			}
		}
	}
if(!function_exists('IpAddress')){
	function IpAddress(){
		if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
			$ipAddress=$_SERVER['HTTP_CLIENT_IP'];
		elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
			$ipAddress=$_SERVER['HTTP_X_FORWARDED_FOR'];
		else
			$ipAddress=$_SERVER['REMOTE_ADDR'];
		return $ipAddress;
		}
	}
if(!function_exists('curdate')){
	function curdate($format='Y-m-d H:i:s'){
		return gmdate($format, time()+7*3600);
		}
	}
if(!function_exists('getPrices')){
	function getPrices(){
		$sql = "select * from ".$GLOBALS['table_prefix']."prices ";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return $query;
		}
	}
if(!function_exists('getAmount')){
	function getAmount($priceid=0){
		$sql = "select Prices from ".$GLOBALS['table_prefix']."prices where Id = ".$priceid;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		elseif(mysql_num_rows($query)>0){
			$row=mysql_fetch_array($query);
			return $row['Prices'];
			}
		}
	}
if(!function_exists('updMember')){
	function updMember($user=0){
		$sql = "update ".$GLOBALS['table_prefix']."users set RemainVIPContacts = 1 where UserID = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('chkSpam')){
	function chkSpam($mail=''){
		$domain = explode('@', $mail);
		$sql = "select BanEmail, BanDomain, BanDate, ReasonBaned from ".$GLOBALS['table_prefix']."filteremails where EmailAddress like '%@".$domain[1]."' and BanDomain = 1";
		$query = mysql_query($sql);
		if(!$query)
			return 0;
		elseif(mysql_num_rows($query)>0){
			return -1;
			}
		else{
			$sqlchk = "select BanEmail, BanDomain, BanDate, ReasonBaned from ".$GLOBALS['table_prefix']."filteremails where EmailAddress = '".$mail."'";
			$qrychk = mysql_query($sqlchk);
			if(!$qrychk)
				return 0;
			elseif(mysql_num_rows($qrychk)>0)
				return -2;
			else return 1;
			}
		}
	}
if(!function_exists('getEcards')){
	function getEcards($user=0, $limit=''){
		$sql = "select e.Id, Subjects, SentDate, ProfileName, Age, CardName, SenderId from ".$GLOBALS['table_prefix']."ecards as e inner join ".$GLOBALS['table_prefix']."users as u on e.SenderId = u.UserID left join ".$GLOBALS['table_prefix']."greetingcards as gc on e.CardId = gc.Id where RecieverId = ".$user.' order by SentDate desc '.$limit;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return $query;
		}
	}
if(!function_exists('getDetailCard')){
	function getDetailCard($user=0, $id=0){
		$sql = "select e.Id, SenderId, CardId, Subjects, Contents, WidthMess, HeightMess, LeftMess, TopMess, CardName, ProfileName, Age, SentDate, Music from ".$GLOBALS['table_prefix']."ecards as e inner join ".$GLOBALS['table_prefix']."users as u on e.SenderId = u.UserID left join ".$GLOBALS['table_prefix']."greetingcards as gc on e.CardId = gc.Id where e.Id = ".$id." and RecieverId = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return $query;
		}
	}
if(!function_exists('reportabuse')){
	function reportabuse($data=array()){
		$sql = "insert into ".$GLOBALS['table_prefix']."abuseprofiles(ReportBy, ProfileId, Reason, ReprotDate, IsProcess) values ('".$data[0]."', ".$data[1].", '".$data[2]."', '".gmdate("Y-m-d H:i:s", time()+7*3600)."', 0) ";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('increaseView')){
	function increaseView($user=0){
		$sql = "update ".$GLOBALS['table_prefix']."users set Views = Views + 1 where UserID = ".$user;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('FillListMembers')){
	function FillListMembers($sqlsearch=''){
		$sql = "select UserID from ".$GLOBALS['table_prefix']."users as u where ".$sqlsearch." ProfileStatusID = 1 and GenderID IS NOT NULL and MembershipID <> 3";
		$query = mysql_query($sql);
		return mysql_num_rows($query);
		}
	}
if(!function_exists('FullRows')){
	function FullRows($total=0, $colperrow=0, $str=''){
		$return = '';
		if(is_int($total/$colperrow))
			return $return;
		else{
			for($j=0; $j<$colperrow-($total%$colperrow); $j++)
				$return .= $str;
			return $return;
			}
		}
	}
if(!function_exists('ConfigPaypal')){
	function ConfigPaypal(){
		$return = array();
		$sql = "select APIKey,APIPassword,APISignature,CurrencyCode,ReturnURL,CancelURL,ButtonImg,APIMode from ".$GLOBALS['table_prefix']."paymentprovide where Id = 1";
		$query = mysql_query($sql);
		if($query!=false && mysql_num_rows($query)>0){
			$rs = mysql_fetch_array($query);
			$return['APIKey'] = $rs['APIKey'];
			$return['APIPassword'] = $rs['APIPassword'];
			$return['APISignature'] = $rs['APISignature'];
			$return['CurrencyCode'] = $rs['CurrencyCode'];
			$return['ReturnURL'] = $rs['ReturnURL'];
			$return['CancelURL'] = $rs['CancelURL'];
			$return['ButtonImg'] = $rs['ButtonImg'];
			$return['APIMode'] = $rs['APIMode'];
			}
		return $return;
		}
	}
if(!function_exists('getItem')){
	function getItem($id=0){
		$return = array();
		$sql = "select Prices,NumofEmail,Block from ".$GLOBALS['table_prefix']."prices where Id = ".$id;
		$query = mysql_query($sql);
		if($query!=false && mysql_num_rows($query)>0){
			$rs = mysql_fetch_array($query);
			$return['Prices'] = $rs['Prices'];
			$return['NumofEmail'] = $rs['NumofEmail'];
			$return['Block'] = $rs['Block'];
			}
		return $return;
		}
	}
if(!function_exists('getThemes')){
	function getThemes($id=0){
		if($id>0)
			$sql = "select Id, ThemeName, SourceName, FileView from ".$GLOBALS['table_prefix']."themes where Id = ".$id;
		else $sql = "select Id, ThemeName, SourceName, FileView from ".$GLOBALS['table_prefix']."themes";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return $query;
		}
	}
if(!function_exists('getCurrentTheme')){
	function getCurrentTheme($userid=0){
		$sql = "select ThemeId from ".$GLOBALS['table_prefix']."users where UserID = ".$userid;
		$query = mysql_query($sql);
		if(!$query)
			return 0;
		elseif(mysql_num_rows($query)>0){
			$row = mysql_fetch_array($query);
			return $row['ThemeId'];
			}
		else return 0;
		}
	}
if(!function_exists('getSourceThemes')){
	function getSourceThemes($id=1){
		$sql = "select SourceName from ".$GLOBALS['table_prefix']."themes where Id = ".$id;
		$query = mysql_query($sql);
		if(!$query)
			return '';
		elseif(mysql_num_rows($query)>0){
			$row = mysql_fetch_array($query);
			return $row['SourceName'];
			}
		else return '';
		}
	}
if(!function_exists('updateTheme')){
	function updateTheme($userid=0, $theme=0){
		$sql = "update ".$GLOBALS['table_prefix']."users set ThemeId = ".$theme." where UserID = ".$userid;
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}
if(!function_exists('myprofile')){
	function myprofile($userid=0){
		$sql = "select u.UserID, ProfileName, Age, AboutMe, City, MatchAgeFrom, MatchAgeTO, LastLogon, PrimaryPhotoID, m.".$_SESSION['lang']."MaritalStatus as LMaritalStatus, State, Country, g.".$_SESSION['lang']."Gender as LGender, PhotoExtension, h.HeightDescription, b.".$_SESSION['lang']."BodyType as LBodyType, ".$_SESSION['lang']."HairColor as LHairColor, ".$_SESSION['lang']."EyeColor as LEyeColor, r.".$_SESSION['lang']."Religion as LReligion, ed.".$_SESSION['lang']."Education as LEducation, Occupation, sm.".$_SESSION['lang']."Smoking as LSmoking, d.".$_SESSION['lang']."Drinking as LDrinking, ".$_SESSION['lang']."DatingInterest as LDatingInterest, HaveChildren, WantChildren, WillingToTravel, Goal, Interests, AboutMyMatch, ge.".$_SESSION['lang']."Gender as MLGender, edu.".$_SESSION['lang']."Education as MLEducation, ma.".$_SESSION['lang']."MaritalStatus as MLMaritalStatus, he.HeightDescription as MFHeightDescription, hei.HeightDescription as MTHeightDescription, MatchHeightIDFrom, MatchHeightIDTo, bo.".$_SESSION['lang']."BodyType as MLBodyType, re.".$_SESSION['lang']."Religion as MLReligion, smo.".$_SESSION['lang']."Smoking as MLSmoking, dr.".$_SESSION['lang']."Drinking as MLDrinking, u.GenderID, u.CountryID, RemainVIPContacts, Email, Phone, IsOnline, u.ProfileStatusID, ps.".$_SESSION['lang']."ProfileStatus as LProfileStatus from ".$GLOBALS['table_prefix']."users as u left join ".$GLOBALS['table_prefix']."maritalstatus as m on u.MaritalStatusID = m.MaritalStatusID left join ".$GLOBALS['table_prefix']."states as s on u.StateID = s.StateID left join ".$GLOBALS['table_prefix']."countries as c on u.CountryID = c.CountryID left join ".$GLOBALS['table_prefix']."gender as g on u.GenderID = g.GenderID left join ".$GLOBALS['table_prefix']."photos as p on u.PrimaryPhotoID = p.PhotoID left join ".$GLOBALS['table_prefix']."height as h on u.HeightID = h.HeightID left join ".$GLOBALS['table_prefix']."bodytypes as b on u.BodyTypeID = b.BodyTypeID left join ".$GLOBALS['table_prefix']."haircolors as ha on u.HairColorID = ha.HairColorID left join ".$GLOBALS['table_prefix']."eyescolors as e on u.EyeColorID = e.EyeColorID left join ".$GLOBALS['table_prefix']."religions as r on u.ReligionID = r.ReligionID left join ".$GLOBALS['table_prefix']."educations as ed on u.EducationID = ed.EducationID left join ".$GLOBALS['table_prefix']."smoking as sm on u.SmokingID = sm.SmokingID left join ".$GLOBALS['table_prefix']."drinking as d on u.DrinkingID = d.DrinkingID left join ".$GLOBALS['table_prefix']."datinginterest as da on u.DatingInterestID = da.DatingInterestID left join ".$GLOBALS['table_prefix']."gender as ge on u.MatchGenderID = ge.GenderID left join ".$GLOBALS['table_prefix']."educations as edu on u.MatchEducationID = edu.EducationID left join ".$GLOBALS['table_prefix']."maritalstatus as ma on u.MatchMaritalStatusID = ma.MaritalStatusID left join ".$GLOBALS['table_prefix']."height as he on u.MatchHeightIDFrom = he.HeightID left join ".$GLOBALS['table_prefix']."height as hei on u.MatchHeightIDTo = hei.HeightID left join ".$GLOBALS['table_prefix']."bodytypes as bo on u.MatchBodyStyleID = bo.BodyTypeID left join ".$GLOBALS['table_prefix']."religions as re on u.MatchReligionID = re.ReligionID left join ".$GLOBALS['table_prefix']."smoking as smo on u.MatchSmokingID = smo.SmokingID left join ".$GLOBALS['table_prefix']."drinking as dr on u.MatchDrinkingID = dr.DrinkingID left join ".$GLOBALS['table_prefix']."profilestatus as ps on u.ProfileStatusID = ps.ProfileStatusID where u.UserID = ".$userid;
		$query = mysql_query($sql);
		return mysql_fetch_array($query);
		}
	}
if(!function_exists('IsVIP')){
	function IsVIP($user=0){
		$sql = "select date_format(ExpireDate,'%Y-%m-%d') as ExpireDate from ".$GLOBALS['table_prefix']."orders where UserId = ".$user." order by ExpireDate desc limit 0,1";
		$query = mysql_query($sql);
		if($query && mysql_num_rows($query)>0){
			$row=mysql_fetch_array($query);
			$cudate = date("Y-m-d");
			if(strtotime($cudate)>strtotime($row['ExpireDate'])){
				if(isset($_SESSION['vipm'])) unset($_SESSION['vipm']);
				}
			else $_SESSION['vipm'] = true;
			}
		else{
			if(isset($_SESSION['vipm'])) unset($_SESSION['vipm']);
			}
		}
	}
if(!function_exists('UpdateVIPStatus')){
	function UpdateVIPStatus($user=0, $date=''){
		$sql = "update ".$GLOBALS['table_prefix']."users set RemainVIPContacts = 0 where UserID in (select UserId from ".$GLOBALS['table_prefix']."orders where UserId = ".$user." having max(ExpireDate) < '".$date."')";
		$query = mysql_query($sql);
		if(!$query)
			return false;
		else return true;
		}
	}