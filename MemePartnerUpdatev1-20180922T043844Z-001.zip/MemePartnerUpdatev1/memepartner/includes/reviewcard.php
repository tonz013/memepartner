<?php
require_once "config.php";
require_once "database.php";
require_once "functions.php";
$sql = 'select CardName,IsText,ViewFormat from '.$table_prefix.'greetingcards where Id = '.intval($_GET['cardId']);
$qry = mysql_query($sql);
if($qry && mysql_num_rows($qry)>0){
	$row=mysql_fetch_array($qry);
	?>
    <div style="width:330px; background:url(../ecards/<?php echo $row['CardName'];?>) no-repeat 100px 10px; height:307px; position:absolute">
    	<?php 
		if($row['IsText']==1) echo html_entity_decode($row['ViewFormat']);
		?>
    </div>
    <p style="clear:both; width:100%; margin-top:307px; margin-left:0px; text-align:left"><input type="text" placeholder="Subject" style="border-bottom:1px solid #CCC; border-left:hidden; border-right:hidden; border-top:hidden; width:350px; font-style:italic" id="subject" name="subject"/>
      	<input type="hidden" id="hddtext" value="<?php echo $row['IsText'];?>" />
    </p>
    <p style="clear:both; width:100%; margin-left:0px; text-align:left">
    <span><i>Attach a song (only type: *.mp3):</i></span><br /><input type="file" name="songname" id="songname"/>
    </p>
    <p>
    <input type="submit" value="Send Card" class="massbutton" id="btsendcard" name="btsendcard"/>
    </p>
    <?php
	}
else echo '<p>'.$norecord.'</p>';
?>