<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $title;?></title>
<?php
if(isset($_SESSION['memberid'])){
	$theme = getSourceThemes(getCurrentTheme($_SESSION['memberid']));
	$sourcetheme = (!empty($theme))?$theme:getSourceThemes(1);
	}
else $sourcetheme = getSourceThemes(1);
?>
<link href="<?php echo $base_url.'css/'.$sourcetheme;?>" type="text/css" rel="stylesheet" />
<link type="text/css" rel="stylesheet" media="all" href="<?php echo $base_url;?>css/chat.css" />
<link type="text/css" rel="stylesheet" media="all" href="<?php echo $base_url;?>css/screen.css" />
<link href="<?php echo $base_url.'fuploads/'.$logo;?>" rel="shortcut icon" type="image/x-icon" />
<script language="javascript" type="text/javascript" src="<?php echo $base_url;?>jss/jquery.min.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo $base_url;?>jss/styles.js"></script>
<script type="text/javascript" src="<?php echo $base_url;?>jss/chat.js"></script>
<input type="hidden" id="urlchat" value="<?php echo $base_url;?>chat/chat.php" />
</head>
<?php
$alerin = '';
if(isset($_SESSION['memberid'])){
	$banned = chkBannedMe($_SESSION['memberid']);
	if(count($banned)>0){
		unset($_SESSION['memberid']);
		header('Location: '.$base_url.'signin.php');
		exit();
		}
	$mninbox = countNewEmail($_SESSION['memberid']);
	$mnsignal = countNewSignal($_SESSION['memberid']);
	if($mninbox>0 && $mnsignal>0)
		$alerin = 'onload="AnimationSignal(); startAnimation()"';
	elseif($mninbox>0)
		$alerin = 'onload="startAnimation()"';
	elseif($mnsignal>0)
		$alerin = 'onload="AnimationSignal()"';
	else $alerin = '';
	}
$temp = str_replace('&', '%26',$pageURL.$_SERVER['REQUEST_URI']);
?>
<body <?php echo $alerin;?>>
	<div id="header">
    	<div class="maincontent">
        	<div class="headleft">
        	<a href="<?php echo $base_url;?>" >
            	<img src="<?php echo $base_url.'fuploads/'.$logo;?>" border="0" style="width:284px; height:64px;" />
            </a>
            </div>
            <div class="headright">
            	<?php
				if(isset($_SESSION['memberid']) && isset($_SESSION['memberemail'])){
					?>
                    <p class="bottright" style="margin-top:20px;"><b><span class="rightspan"><?php echo $welcome;?> <i><?php echo $_SESSION['memberemail'];?></i></span>
                    <?php
					if($mninbox>0)
                        echo '<a href="'.$base_url.'members/mail.php" title="'.$mninbox.'&nbsp;'.$newemail.'"><span id="animation"><img src="'.$base_url.'imgs/ipnew1.png" border="0" title="'.$mninbox.'&nbsp;'.$newemail.'"/><img src="'.$base_url.'imgs/oldmail.gif" border="0" style="display:none" title="'.$mninbox.'&nbsp;'.$newemail.'"/></span><span class="rightspan"><sup>&nbsp;'.$mninbox.'</sup></span></a>';
					else echo '<a href="'.$base_url.'members/mail.php" title="'.$mninbox.'&nbsp;'.$newemail.'"><span id="animation" class="rightspan"><img src="'.$base_url.'imgs/oldmail.gif" border="0" title="'.$mninbox.'&nbsp;'.$newemail.'"/></span>';
					if($mnsignal>0)
						echo '<a href="'.$base_url.'members/vaforitesyou.php" title="'.$mnsignal.'&nbsp;'.$whowant.'"><span id="signal"><img src="'.$base_url.'imgs/signal1.png" border="0" /><img src="'.$base_url.'imgs/wireless_signal_icon.png" border="0" style="display:none"/></span><span class="rightspan"><sup>&nbsp;'.$mnsignal.'</sup></span></a>';
					else echo '<a href="'.$base_url.'members/vaforitesyou.php" title="'.$mnsignal.'&nbsp;'.$whowant.'"><span id="signal" class="rightspan"><img src="'.$base_url.'imgs/wireless_signal_icon.png" border="0" /></span></a>';
					?>
                        <span class="rightspan">|</span><a href="<?php echo $base_url;?>signout.php"><?php echo $signout;?></a></b></p>
                    <?php
					}
				else{
				?>
                <p class="bottright" style="margin-top:20px;"><b><a href="<?php echo $base_url;?>signup.php"><?php echo $signup;?></a><span class="justspan">|</span><a href="<?php echo $base_url;?>signin.php"><?php echo $signin;?></a><span class="justspan">|</span><a href="<?php echo $base_url;?>help.php"><?php echo $help;?></a></b></p>
                <?php }?>
            </div>
        </div>
        <p class="linehead">&nbsp;</p>
    </div>
    <div id="contentbody">