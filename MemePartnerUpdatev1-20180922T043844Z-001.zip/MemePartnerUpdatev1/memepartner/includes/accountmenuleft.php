<?php
switch($ltmn){
	case 1:
		$ltmenu1 = 'class="mnactv"';
		$ltmenu2 = '';
		$ltmenu3 = '';
		$ltmenu4 = '';
		$ltmenu5 = '';
		$ltmenu6 = '';
		$ltmenu7 = '';
		$ltmenu8 = '';
		$ltmenu9 = '';
		$ltmenu10 = '';
		$ltmenu11 = '';
		$ltmenu12 = '';
		$ltmenu13 = '';
		$ltmenu14 = '';
	break;
	case 2:
		$ltmenu1 = '';
		$ltmenu2 = 'class="mnactv"';
		$ltmenu3 = '';
		$ltmenu4 = '';
		$ltmenu5 = '';
		$ltmenu6 = '';
		$ltmenu7 = '';
		$ltmenu8 = '';
		$ltmenu9 = '';
		$ltmenu10 = '';
		$ltmenu11 = '';
		$ltmenu12 = '';
		$ltmenu13 = '';
		$ltmenu14 = '';
	break;
	case 3:
		$ltmenu1 = '';
		$ltmenu2 = '';
		$ltmenu3 = 'class="mnactv"';
		$ltmenu4 = '';
		$ltmenu5 = '';
		$ltmenu6 = '';
		$ltmenu7 = '';
		$ltmenu8 = '';
		$ltmenu9 = '';
		$ltmenu10 = '';
		$ltmenu11 = '';
		$ltmenu12 = '';
		$ltmenu13 = '';
		$ltmenu14 = '';
	break;
	case 4:
		$ltmenu1 = '';
		$ltmenu2 = '';
		$ltmenu3 = '';
		$ltmenu4 = 'class="mnactv"';
		$ltmenu5 = '';
		$ltmenu6 = '';
		$ltmenu7 = '';
		$ltmenu8 = '';
		$ltmenu9 = '';
		$ltmenu10 = '';
		$ltmenu11 = '';
		$ltmenu12 = '';
		$ltmenu13 = '';
		$ltmenu14 = '';
	break;
	case 5:
		$ltmenu1 = '';
		$ltmenu2 = '';
		$ltmenu3 = '';
		$ltmenu4 = '';
		$ltmenu5 = 'class="mnactv"';
		$ltmenu6 = '';
		$ltmenu7 = '';
		$ltmenu8 = '';
		$ltmenu9 = '';
		$ltmenu10 = '';
		$ltmenu11 = '';
		$ltmenu12 = '';
		$ltmenu13 = '';
		$ltmenu14 = '';
	break;
	case 6:
		$ltmenu1 = '';
		$ltmenu2 = '';
		$ltmenu3 = '';
		$ltmenu4 = '';
		$ltmenu5 = '';
		$ltmenu6 = 'class="mnactv"';
		$ltmenu7 = '';
		$ltmenu8 = '';
		$ltmenu9 = '';
		$ltmenu10 = '';
		$ltmenu11 = '';
		$ltmenu12 = '';
		$ltmenu13 = '';
		$ltmenu14 = '';
	break;
	case 7:
		$ltmenu1 = '';
		$ltmenu2 = '';
		$ltmenu3 = '';
		$ltmenu4 = '';
		$ltmenu5 = '';
		$ltmenu6 = '';
		$ltmenu7 = 'class="mnactv"';
		$ltmenu8 = '';
		$ltmenu9 = '';
		$ltmenu10 = '';
		$ltmenu11 = '';
		$ltmenu12 = '';
		$ltmenu13 = '';
		$ltmenu14 = '';
	break;
	case 8:
		$ltmenu1 = '';
		$ltmenu2 = '';
		$ltmenu3 = '';
		$ltmenu4 = '';
		$ltmenu5 = '';
		$ltmenu6 = '';
		$ltmenu7 = '';
		$ltmenu8 = 'class="mnactv"';
		$ltmenu9 = '';
		$ltmenu10 = '';
		$ltmenu11 = '';
		$ltmenu12 = '';
		$ltmenu13 = '';
		$ltmenu14 = '';
	break;
	case 9:
		$ltmenu1 = '';
		$ltmenu2 = '';
		$ltmenu3 = '';
		$ltmenu4 = '';
		$ltmenu5 = '';
		$ltmenu6 = '';
		$ltmenu7 = '';
		$ltmenu8 = '';
		$ltmenu9 = 'class="mnactv"';
		$ltmenu10 = '';
		$ltmenu11 = '';
		$ltmenu12 = '';
		$ltmenu13 = '';
		$ltmenu14 = '';
	break;
	case 10:
		$ltmenu1 = '';
		$ltmenu2 = '';
		$ltmenu3 = '';
		$ltmenu4 = '';
		$ltmenu5 = '';
		$ltmenu6 = '';
		$ltmenu7 = '';
		$ltmenu8 = '';
		$ltmenu9 = '';
		$ltmenu10 = 'class="mnactv"';
		$ltmenu11 = '';
		$ltmenu12 = '';
		$ltmenu13 = '';
		$ltmenu14 = '';
	break;
	case 11:
		$ltmenu1 = '';
		$ltmenu2 = '';
		$ltmenu3 = '';
		$ltmenu4 = '';
		$ltmenu5 = '';
		$ltmenu6 = '';
		$ltmenu7 = '';
		$ltmenu8 = '';
		$ltmenu9 = '';
		$ltmenu10 = '';
		$ltmenu11 = 'class="mnactv"';
		$ltmenu12 = '';
		$ltmenu13 = '';
		$ltmenu14 = '';
	break;
	case 12:
		$ltmenu1 = '';
		$ltmenu2 = '';
		$ltmenu3 = '';
		$ltmenu4 = '';
		$ltmenu5 = '';
		$ltmenu6 = '';
		$ltmenu7 = '';
		$ltmenu8 = '';
		$ltmenu9 = '';
		$ltmenu10 = '';
		$ltmenu11 = '';
		$ltmenu12 = 'class="mnactv"';
		$ltmenu13 = '';
		$ltmenu14 = '';
	break;
	case 13:
		$ltmenu1 = '';
		$ltmenu2 = '';
		$ltmenu3 = '';
		$ltmenu4 = '';
		$ltmenu5 = '';
		$ltmenu6 = '';
		$ltmenu7 = '';
		$ltmenu8 = '';
		$ltmenu9 = '';
		$ltmenu10 = '';
		$ltmenu11 = '';
		$ltmenu12 = '';
		$ltmenu13 = 'class="mnactv"';
		$ltmenu14 = '';
	break;
	case 14:
		$ltmenu1 = '';
		$ltmenu2 = '';
		$ltmenu3 = '';
		$ltmenu4 = '';
		$ltmenu5 = '';
		$ltmenu6 = '';
		$ltmenu7 = '';
		$ltmenu8 = '';
		$ltmenu9 = '';
		$ltmenu10 = '';
		$ltmenu11 = '';
		$ltmenu12 = '';
		$ltmenu13 = '';
		$ltmenu14 = 'class="mnactv"';
	break;
	}
if($_SESSION['memberid']==3536){
$person = getFullPersonal($_SESSION['memberid']);
$title = $person['ProfileName'].' / '.$person['LGender'].' - '.$person['Age'].' '.$exage.' / '.$person['LMaritalStatus'];
if($person['PrimaryPhotoID']==0 || !file_exists('../fuploads/'.$person['UserID'].'u'.$person['PrimaryPhotoID'].'.'.$person['PhotoExtension']) || empty($person['PhotoExtension']))
	$sharephoto = $base_url.'imgs/noimage.jpg';
else $sharephoto = $base_url.'fuploads/'.$person['UserID'].'u'.$person['PrimaryPhotoID'].'.'.$person['PhotoExtension'];}
?>
<div class="menuleft">
                	<h4><?php echo ucfirst($account);?></h4>
                    	<ul>
                        	<a href="<?php echo $base_url;?>members/myprofile.php"><li <?php echo $ltmenu1;?>><?php echo $myprofile;?></li></a>
                            <a href="editdetails.php"><li <?php echo $ltmenu2;?>><?php echo $upinfo;?></li></a>
                            <a href="editmatch.php"><li <?php echo $ltmenu3;?>><?php echo $upmatch;?></li></a>
                            <a href="changepass.php"><li <?php echo $ltmenu4;?>><?php echo $changepass;?></li></a>
                            <a href="settings.php"><li <?php echo $ltmenu5;?>><?php echo $settingprofile;?></li></a>
                            <!--<?php 
							echo '<a target="_new" href="http://www.facebook.com/sharer/sharer.php?s=100&p[url]='.urlencode($base_url.'viewprofile.php?id='.$_SESSION['memberid']).'&p[title]='.urlencode($title).'&p[summary]='.urlencode($person['AboutMe']).'&p[images][0]='.urlencode($sharephoto).'"><li '.$ltmenu0.'>Share on facebook</li></a>';
							$clmn = (isset($ltmn) && $ltmn==16)?'class="mnactv"':'';
							echo '<a href="membership1.php"><li '.$clmn.'>'.$upgacc.'</li></a>';
							?>-->
                        </ul>
                    <h4><?php echo $galery;?></h4>
                    	<ul>
                        	<a href="uploadphoto.php"><li <?php echo $ltmenu6;?>><?php echo $newimg;?></li></a>
                            <a href="removeimg.php"><li <?php echo $ltmenu7;?>><?php echo $delimg;?></li></a>
                            <a href="setphoto.php"><li <?php echo $ltmenu8;?>><?php echo $setprimary;?></li></a>
                        </ul>
                    <h4><?php echo $communication;?></h4>
                    	<ul>
                        	<a href="vaforitesyou.php"><li <?php echo $ltmenu9;?>><?php echo $vaforitesyou;?></li></a>
                            <a href="youvaforites.php"><li <?php echo $ltmenu10;?>><?php echo $youvaforites;?></li></a>
                            <a href="whoviews.php"><li <?php echo $ltmenu11;?>><?php echo $whoview;?></li></a>
                            <a href="myaccount.php"><li <?php echo $ltmenu12;?>><?php echo $whomatch;?></li></a>
                            <a href="hostlist.php"><li <?php echo $ltmenu13;?>><?php echo $savedprofile;?></li></a>
                            <a href="savedsearch.php"><li <?php echo $ltmenu14;?>><?php echo $savedsearch;?></li></a>
                            <a href="ecards.php"><li <?php echo (isset($ltmn) && $ltmn==15)?'class="mnactv"':'';?>><?php echo 'Greeting Cards';?></li></a>
                            <a href="themes.php"><li <?php echo (isset($ltmn) && $ltmn==17)?'class="mnactv"':'';?>><?php echo 'Setting Themes';?></li></a>
                        </ul><br />&nbsp;
                </div>