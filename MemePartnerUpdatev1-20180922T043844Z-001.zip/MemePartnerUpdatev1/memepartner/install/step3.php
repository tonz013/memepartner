<?php
require_once "../includes/config.php";
include ("function.php");
@mysql_connect ($GLOBALS["hostname"],$GLOBALS["username"],$GLOBALS["password"]);
@mysql_select_db($GLOBALS["database"]);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Create admin account</title>
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
	function slAccount(intval){
		if(intval==1){
			document.getElementById('usecurr').style.display = '';
			document.getElementById('create').style.display = 'none';
			}
		else if(intval==2){
			document.getElementById('create').style.display = '';
			document.getElementById('usecurr').style.display = 'none';
			}
		}
</script>
</head>

<body>
<?php
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smcurr'])){
	mysql_close();
	echo "<script language=\"javascript\">window.location.href=\"step4.php\";</script>";	
	exit();
	}
$iscurr = 'style="display:none"';
$iscrea = '';
$flag = 0;
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['CreateAdminAcc'])){
	if($_POST['over']==2 || $_POST['over']==3){
		$iscurr = 'style="display:none"';
		$iscrea = '';
		$flag = 1;
		}
	if(isset($_POST['txtemail'])) if($_POST['txtemail']=='') $mess_erre = 'Enter your email, please';
	else if(!is_valid_email($_POST['txtemail']))$mess_errei = 'Your email is incorrect';
	elseif($_POST['txtyourusername']=='') $mess_erru = 'Enter your fullname, please';
	else if(strlen($_POST['txtyourusername'])<5) $mess_errl = 'Your username must be longer than 5 characters';
	elseif(isset($_POST['txtyourpassword']))if( $_POST['txtyourpassword']=='') $mess_errp = 'Enter your password, please';
	else if(strlen($_POST['txtyourpassword'])<6) $mess_errpl = 'Your password must be longer than 6 characters';
	elseif($_POST['txtyourretypepassword']!=$_POST['txtyourpassword']) $mess_errnm = 'You typed in two completely different passwords !';
	elseif($_POST['over']==2){
		$sqlup = "update ".$table_prefix."users set Name = '".mysql_real_escape_string(trim($_POST['txtyourusername']))."', Email = '".mysql_real_escape_string(trim($_POST['txtemail']))."', Password = '".mysql_real_escape_string(trim($_POST['txtyourpassword']))."' where UserID = ".intval($_POST['hddval']);
		$qryup = mysql_query($sqlup);
		if(!$qryup)
			$error = 'Can not update admin account';
		else{
			mysql_close();
			echo "<script language=\"javascript\">window.location.href=\"step4.php\";</script>";	
			exit();
			}
		}
	elseif($_POST['over']==3){
		$sqldl = 'delete from '.$table_prefix.'users where UserID = '.intval($_POST['hddval']);
		$qrydl = mysql_query($sqldl);
		if(!$qrydl)
			$error = 'Can not delete current account';
		else{
			$sqlin = "INSERT INTO ".$table_prefix."users VALUES(31, 3, 0, 1, '".mysql_real_escape_string(trim($_POST['txtyourusername']))."', 'admin', '".mysql_real_escape_string(trim($_POST['txtemail']))."', '".trim($_POST['txtyourpassword'])."', 1, 349, 18, 1, 1, 1, '', 235, 230, '', '', 2, '', 1, 1, '', 1, 1, 1, 2, 1, 1, 50, '113.162.232.13', '2010-12-16', '2012-10-22', NULL, '".date('Y-m-d H:i:s')."', 1, 2, 18, 18, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '', '', '', '', 55471, 5, 27, 0, 0, 0, 1)";
			$qryin = mysql_query($sqlin);
			if(!$qryin)
				$error = 'Error occurred, please try again !';
			else{
				mysql_close();
				echo "<script language=\"javascript\">window.location.href=\"step4.php\";</script>";	
				exit();
				}
			}
		}
	else{
		$new = "INSERT INTO ".$table_prefix."users VALUES(31, 3, 0, 1, '".trim($_POST['txtyourusername'])."', 'admin', '".trim($_POST['txtemail'])."', '".trim($_POST['txtyourpassword'])."', 1, 349, 18, 1, 1, 1, '', 235, 230, '', '', 2, '', 1, 1, '', 1, 1, 1, 2, 1, 1, 50, '113.162.232.13', '2010-12-16', '2012-10-22', NULL, '".date('Y-m-d H:i:s')."', 1, 2, 18, 18, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, '', '', '', '', 55471, 5, 27, 0, 0, 0, 1)";
		$qrnew = mysql_query($new);
		if(!$qrnew){
			$error = 'Error occurred, please try again !';
			echo $new;
			}
		else{
			mysql_close();
			echo "<script language=\"javascript\">window.location.href=\"step4.php\";</script>";	
			exit();
			}
		}	
	}
?>
<div id="templatemo_wrapper">
    
  <div id="templatemo_menu"><h2 style="padding-top:5px; text-transform:uppercase; color:#125e9a; font-weight:bold">installation</h2>
  </div> <!-- end of templatemo_menu -->
  <div id="templatemo_main">
    <div id="templatemo_content">
                
<h2>Step 3: Creating an Administrator account</h2>
<br />
       	<div id="contact_form">Please enter the information below to create an Administrator account for your site.<br />&nbsp;

<form method="post" action="" >
<?php
$sqlck = 'select UserID from '.$table_prefix.'users where MembershipID = 3';
$qryck = mysql_query($sqlck) or die(mysql_error());
if(!$qryck)
	$error = 'Can not check user exist';
if(!empty($error))
	echo '<font color="#FF0000"><i>'.$error.'</i></font><br>&nbsp;';
?>
                <table>
                <?php
				if(mysql_num_rows($qryck)>0){
					$rsck = mysql_fetch_array($qryck);
					if($flag==0){
						$iscurr = '';
						$iscrea = 'style="display:none"';
						}
					?>
                    <tr>
                    	<td colspan="2" width="100%" align="left">
                        <font color="#FF0000">An account administrator is exist !</font><br /><br />
                        <input type="radio" value="1" name="over" style="margin-left:0px; margin-bottom:0px;" checked="checked" onclick="slAccount(1)"/> Use current account<input type="radio" value="2" name="over" style="margin-left:100px;" onclick="slAccount(2)" <?php echo (isset($_POST['over']) && $_POST['over']==2)?'checked="checked"':'';?> /> Update current account<br /><input type="radio" value="3" name="over" onclick="slAccount(2)" style="margin-left:0px; margin-bottom:0px;" <?php echo (isset($_POST['over']) && $_POST['over']==3)?'checked="checked"':'';?>/> Delete current account and Create new account<br />&nbsp;<input type="hidden" value="<?php echo $rsck['UserID'];?>" name="hddval" />
                        </td>
                    </tr>
                    <tbody id="usecurr" <?php echo $iscurr;?>>
                    <tr>
                    	<td colspan="2" width="100%"><input type="submit" name="smcurr" value="CONTINUTE" /></td>
                    </tr>
                    </tbody>
                    <?php
					}
				?>
                	<tbody id="create" <?php echo $iscrea;?>>
                    <tr>
                        <td valign="top">Email:&nbsp;</td>
                        <td><input type="text" name="txtemail" id="txtemail" class="input_field" value="<?php echo @$_POST['txtemail'];?>"/>
                        <?php
						if(!empty($mess_erre)) echo '<br><font color="#FF0000"><i>'.$mess_erre.'</i></font>';
						if(!empty($mess_errei)) echo '<br><font color="#FF0000"><i>'.$mess_errei.'</i></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top"><?php echo 'Full name';?>:&nbsp;</td>
                        <td><input name="txtyourusername" type="text" id="txtyourusername" class="input_field" value="<?php echo @$_POST['txtyourusername'];?>" maxlength="255">
                        <?php
						if(!empty($mess_erru)) echo '<br><font color="#FF0000"><i>'.$mess_erru.'</i></font>';
						if(!empty($mess_errl)) echo '<br><font color="#FF0000"><i>'.$mess_errl.'</i></font>';
						if(!empty($mess_erri)) echo '<br><font color="#FF0000"><i>'.$mess_erri.'</i></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top">Password:&nbsp;</td>
                        <td><input type="password" name="txtyourpassword" id="txtyourpassword" class="input_field" />
                        <?php
						if(!empty($mess_errp)) echo '<br><font color="#FF0000"><i>'.$mess_errp.'</i></font>';
						if(!empty($mess_errpl)) echo '<br><font color="#FF0000"><i>'.$mess_errpl.'</i></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top">Retype Password:&nbsp;</td>
                        <td><input type="password" name="txtyourretypepassword" id="txtyourretypepassword" class="input_field" />
                        <?php
						if(!empty($mess_errnm)) echo '<br><font color="#FF0000"><i>'.$mess_errnm.'</i></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2"><p><br />Verify your input carefully and click "Continue" button to continue.</p></td>
                    </tr>
                    <tr>
                    	<td>&nbsp;</td>
                        <td ><input type="submit" class="submit_btn float_l" name="CreateAdminAcc" id="CreateAdminAcc" value="CONTINUTE" /></td>
                    </tr>
                    </tbody>
                </table>
            </form>
</div>      

        	</div><!-- end of content -->
			<div id="templatemo_sidebar">
            </div>
       	<div class="cleaner"></div>
     </div>     <!-- end of main -->
<div id="templatemo_main_bottom"></div><!-- end of main -->
    
    <div id="templatemo_footer">
    
   	 Copyright &copy; <?php echo date('Y');?> <?php echo $sitename; mysql_close();?>
    
    </div> <!-- end of templatemo_footer -->

</div> <!-- end of wrapper -->

</body>
</html>