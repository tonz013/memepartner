<?php
require_once "../includes/config.php";
set_time_limit(0);
include ("function.php");
$isversion = '1.0';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Populating database . . .</title>
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
$link = mysql_connect ($GLOBALS["hostname"],$GLOBALS["username"],$GLOBALS["password"]);
mysql_set_charset('utf8',$link);
mysql_select_db($GLOBALS["database"], $link);
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['config'])){
	$err = 0;
	$dbms_schema = "dbupgrade.sql";
	$sql_query = @fread(@fopen($dbms_schema, 'r'), @filesize($dbms_schema)) or die('The path may be wrong!');
	$sql_query = remove_remarks($sql_query);
	$sql_query = split_sql_file($sql_query, ';');	
	$pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	for ($i=0; $i < 8; $i++)
		$rand_string .= substr($pool, mt_rand(0, strlen($pool) -1), 1);	
	$rand_string = strtolower($rand_string);
	foreach($sql_query as $sql){								
		if(!@mysql_query(str_replace('tbld_', $rand_string.'_',$sql))){
			$err=1;
			$mess = 'Can not import database';
			break;
			}						
		}
	if($err==1)
		exit($mess);
	$tables = 'SHOW TABLES FROM '.$GLOBALS["database"]." like '".$table_prefix."%'";
	$qrytb = mysql_query($tables);
	if(!$qrytb){
		$err = 1;
		$mess = 'Can not show tables from database';
		}
	elseif(mysql_num_rows($qrytb)>0){
		$ttcols = 0;
		$tttbls = 0;
		$oldtbl = array();
		while($row = mysql_fetch_row($qrytb)){
			array_push($oldtbl, $row[0]);
			$strcmd = '';
			$newfield = getNewFields($row[0], str_replace($table_prefix, $rand_string.'_', $row[0]));
			if(count($newfield)>0){
				$strcmd = 'ALTER TABLE '.$row[0].' '.implode(', ',$newfield);
				$qry = mysql_query($strcmd);
				if(!$qry){
					$err = 1;
					$mess = 'Can not alter table '.$row[0];
					}
				else $ttcols += count($newfield);
				}
			if($err==1) break;
			}
		if($err==1)
			exit($mess);
		$ntbl = 'SHOW TABLES FROM '.$GLOBALS["database"]." like '".$rand_string."_%'";
		$nqryn = mysql_query($ntbl);
		if(!$nqryn){
			$err = 1;
			$mess = 'Can not show table ';
			}
		elseif(mysql_num_rows($nqryn)>0){
			while($nrow = mysql_fetch_row($nqryn)){
				if(!in_array(str_replace($rand_string.'_', $table_prefix, $nrow[0]), $oldtbl)){
					$newtb = str_replace($rand_string.'_', $table_prefix, $nrow[0]);
					$sqln = 'CREATE TABLE '.$newtb.' LIKE '.$nrow[0];
					$qrynw = mysql_query($sqln);
					if(!$qrynw){
						$err = 1;
						$mess = 'Can not create new table';
						}
					else{
						$tttbls++;
						$sqli = 'INSERT INTO '.$newtb.' SELECT * FROM '.$nrow[0];
						mysql_query($sqli);
						}
					}
				$sqld = 'drop table '.$nrow[0];
				mysql_query($sqld);
				}
			}
		}
	if($err==0){
		$sqlu = "update ".$table_prefix."site_settings set Value = '".$isversion."' where Variable = 'Version'";
		$qryu = mysql_query($sqlu);
		if(!$qryu){
			$err = 1;
			$mess = 'Can not update data';
			}
		}
	}
if($err==1) exit($mess);
?>
<div id="templatemo_wrapper">
  <div id="templatemo_menu"><h2 style="padding-top:5px; text-transform:uppercase; color:#125e9a; font-weight:bold">installation</h2>
  </div> <!-- end of templatemo_menu -->
  <div id="templatemo_main">
    <div id="templatemo_content">
<h2>Step 2: Adding database tables and sample data</h2>
       	<div id="contact_form"><form>
        All required information has been verified and sample database has been populated. <br />
            <br>&nbsp;&nbsp;&nbsp;+ <b><?php echo $tttbls;?> </b><?php echo "new table(s) created";?>.
			<br>&nbsp;&nbsp;&nbsp;+ <b><?php echo $ttcols;?> </b><?php echo "column(s) added";?>.															
			<br><?php echo '<br>Click "Continue" button to continue.';?> <br /><br />
            <input type="button" class="submit_btn float_l" onclick="window.location.href='step3.php'" value="CONTINUTE"/></form>
  
</div>      

        	</div><!-- end of content -->
			<div id="templatemo_sidebar">
            </div>
       	<div class="cleaner"></div>
     </div>     <!-- end of main -->
<div id="templatemo_main_bottom"></div><!-- end of main -->
    
    <div id="templatemo_footer">
    
   	 Copyright &copy; <?php echo date('Y').' '.$sitename;?>
    
    </div> <!-- end of templatemo_footer -->

</div> <!-- end of wrapper -->

</body>
</html>