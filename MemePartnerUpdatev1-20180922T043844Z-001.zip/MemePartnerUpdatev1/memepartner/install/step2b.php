<?php
require_once "../includes/config.php";
if(!ini_get('safe_mode'))
    set_time_limit(0);
include ("function.php");
$err = 0;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Populating database . . .</title>
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

</head>

<body>
<?php
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['config'])){
	$dbms_schema = "website.sql";
	$link = mysql_connect ($GLOBALS["hostname"],$GLOBALS["username"],$GLOBALS["password"]);
	mysql_set_charset('utf8',$link);
	mysql_select_db($GLOBALS["database"], $link);
	$sql_query = @fread(@fopen($dbms_schema, 'r'), @filesize($dbms_schema)) or die('The path may be wrong!');
	$sql_query = remove_remarks($sql_query);
	$sql_query = split_sql_file($sql_query, ';');							
	foreach($sql_query as $sql){								
		if(!@mysql_query(str_replace('tbld_', $table_prefix, $sql))){
			mysql_close();
			$err=1;
			$mess = 'Can not import database<br>'.$sql;
			break;
			}						
		}
	if(intval($err)==0) mysql_close();
	}
if($err==1) exit($mess);
?>
<div id="templatemo_wrapper">
  <div id="templatemo_menu"><h2 style="padding-top:5px; text-transform:uppercase; color:#125e9a; font-weight:bold">installation</h2>
  </div> <!-- end of templatemo_menu -->
  <div id="templatemo_main">
    <div id="templatemo_content">
<h2>Step 2: Adding database tables and sample data</h2>
       	<div id="contact_form"><form>
        All required information has been verified and sample database has been populated. <br />
        	<?php
			if(intval($err)==0){
				@mysql_connect ($GLOBALS["hostname"],$GLOBALS["username"],$GLOBALS["password"]);
				@mysql_select_db($GLOBALS["database"]);
				$result=mysql_query("SHOW TABLES FROM ".$GLOBALS["database"])	;						
				$total_tables=mysql_num_rows($result);
				$total_rows=0;
				while($rows = mysql_fetch_array($result)) {
					mysql_select_db($GLOBALS["database"]);								
					$total_rows +=mysql_num_rows(mysql_query("select * from ".$rows[0]));																
					}
				}
			?> 
            <br>&nbsp;&nbsp;&nbsp;+ <b><?php echo $total_tables;?> </b><?php echo "new tables created";?>.
			<br>&nbsp;&nbsp;&nbsp;+ <b><?php echo $total_rows;?> </b><?php echo "rows inserted";?>.															
			<br><?php echo '<br>Click "Continue" button to continue.';?> <br /><br />
            <input type="button" class="submit_btn float_l" onclick="window.location.href='step3.php'" value="CONTINUTE"/></form>
  
</div>      

        	</div><!-- end of content -->
			<div id="templatemo_sidebar">
            </div>
       	<div class="cleaner"></div>
     </div>     <!-- end of main -->
<div id="templatemo_main_bottom"></div><!-- end of main -->
    
    <div id="templatemo_footer">
    
   	 Copyright &copy; <?php echo date('Y');?> <?php echo $sitename;?>
    
    </div> <!-- end of templatemo_footer -->

</div> <!-- end of wrapper -->

</body>
</html>