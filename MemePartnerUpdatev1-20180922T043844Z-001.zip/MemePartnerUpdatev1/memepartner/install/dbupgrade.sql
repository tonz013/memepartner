-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 184.168.194.156
-- Generation Time: Mar 03, 2013 at 06:29 PM
-- Server version: 5.0.96
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `doc12SQLTn`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbld_bannedusers`
--

CREATE TABLE IF NOT EXISTS `tbld_bannedusers` (
  `Id` int(11) NOT NULL auto_increment,
  `UserId` int(11) NOT NULL,
  `Reason` text collate utf8_unicode_ci NOT NULL,
  `BanedOn` datetime default NULL,
  `LiftBanId` int(11) NOT NULL,
  `BannedBy` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbld_bannedusers`
--
--
-- Table structure for table `tbld_blockedusers`
--

CREATE TABLE IF NOT EXISTS `tbld_blockedusers` (
  `UserID` int(11) NOT NULL,
  `BlockedUserID` int(11) NOT NULL,
  `DateBlock` datetime default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Table structure for table `tbld_bodytypes`
--

CREATE TABLE IF NOT EXISTS `tbld_bodytypes` (
  `BodyTypeID` smallint(5) unsigned NOT NULL auto_increment,
  `L1BodyType` varchar(30) collate utf8_unicode_ci NOT NULL,
  `L2BodyType` varchar(30) collate utf8_unicode_ci NOT NULL,
  `L3BodyType` varchar(30) collate utf8_unicode_ci NOT NULL,
  `L4BodyType` varchar(30) collate utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`BodyTypeID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbld_bodytypes`
--
--
-- Table structure for table `tbld_countries`
--

CREATE TABLE IF NOT EXISTS `tbld_countries` (
  `CountryID` smallint(5) unsigned NOT NULL auto_increment,
  `Country` varchar(50) collate utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`CountryID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbld_countries`
--
--
-- Table structure for table `tbld_datinginterest`
--

CREATE TABLE IF NOT EXISTS `tbld_datinginterest` (
  `DatingInterestID` int(10) unsigned NOT NULL auto_increment,
  `L1DatingInterest` varchar(30) collate utf8_unicode_ci NOT NULL,
  `L2DatingInterest` varchar(35) collate utf8_unicode_ci NOT NULL,
  `L3DatingInterest` varchar(30) collate utf8_unicode_ci NOT NULL,
  `L4DatingInterest` varchar(30) collate utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`DatingInterestID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Dumping data for table `tbld_datinginterest`
--
--
-- Table structure for table `tbld_drinking`
--

CREATE TABLE IF NOT EXISTS `tbld_drinking` (
  `DrinkingID` smallint(5) unsigned NOT NULL auto_increment,
  `L1Drinking` varchar(50) collate utf8_unicode_ci NOT NULL,
  `L2Drinking` varchar(50) collate utf8_unicode_ci NOT NULL,
  `L3Drinking` varchar(50) collate utf8_unicode_ci NOT NULL,
  `L4Drinking` varchar(50) collate utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`DrinkingID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;
--
-- Dumping data for table `tbld_drinking`
--
--
-- Table structure for table `tbld_educations`
--

CREATE TABLE IF NOT EXISTS `tbld_educations` (
  `EducationID` smallint(5) unsigned NOT NULL auto_increment,
  `L1Education` varchar(30) collate utf8_unicode_ci NOT NULL,
  `L2Education` varchar(40) collate utf8_unicode_ci NOT NULL,
  `L3Education` varchar(30) collate utf8_unicode_ci NOT NULL,
  `L4Education` varchar(30) collate utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`EducationID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Dumping data for table `tbld_educations`
--
--
-- Table structure for table `tbld_eyescolors`
--

CREATE TABLE IF NOT EXISTS `tbld_eyescolors` (
  `EyeColorID` int(10) unsigned NOT NULL auto_increment,
  `L1EyeColor` varchar(20) collate utf8_unicode_ci NOT NULL,
  `L2EyeColor` varchar(40) collate utf8_unicode_ci NOT NULL,
  `L3EyeColor` varchar(20) collate utf8_unicode_ci NOT NULL,
  `L4EyeColor` varchar(20) collate utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`EyeColorID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Dumping data for table `tbld_eyescolors`
--
--
-- Table structure for table `tbld_gender`
--

CREATE TABLE IF NOT EXISTS `tbld_gender` (
  `GenderID` smallint(5) unsigned NOT NULL auto_increment,
  `L1Gender` varchar(6) collate utf8_unicode_ci NOT NULL,
  `L2Gender` varchar(12) collate utf8_unicode_ci NOT NULL,
  `L3Gender` varchar(12) collate utf8_unicode_ci NOT NULL,
  `L4Gender` varchar(12) collate utf8_unicode_ci NOT NULL,
  `TopSorted` tinyint(4) default NULL,
  PRIMARY KEY  (`GenderID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Dumping data for table `tbld_gender`
--
--
-- Table structure for table `tbld_haircolors`
--

CREATE TABLE IF NOT EXISTS `tbld_haircolors` (
  `HairColorID` int(10) unsigned NOT NULL auto_increment,
  `L1HairColor` varchar(20) collate utf8_unicode_ci NOT NULL,
  `L2HairColor` varchar(40) collate utf8_unicode_ci NOT NULL,
  `L3HairColor` varchar(20) collate utf8_unicode_ci NOT NULL,
  `L4HairColor` varchar(20) collate utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`HairColorID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Dumping data for table `tbld_haircolors`
--
--
-- Table structure for table `tbld_height`
--

CREATE TABLE IF NOT EXISTS `tbld_height` (
  `HeightID` smallint(5) unsigned NOT NULL auto_increment,
  `Height` decimal(3,2) NOT NULL default '0.00',
  `HeightDescription` varchar(50) collate utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`HeightID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Dumping data for table `tbld_height`
--
--
-- Table structure for table `tbld_hotlists`
--

CREATE TABLE IF NOT EXISTS `tbld_hotlists` (
  `UserID` int(10) unsigned NOT NULL default '0',
  `SavedUserID` int(10) unsigned NOT NULL default '0',
  `SavedDate` datetime NOT NULL default '0000-00-00 00:00:00',
  KEY `IdxtblDHotListsUserID` (`UserID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Table structure for table `tbld_liftbaned`
--

CREATE TABLE IF NOT EXISTS `tbld_liftbaned` (
  `Id` int(11) NOT NULL auto_increment,
  `L1LiftBan` varchar(255) character set utf8 NOT NULL,
  `L2LiftBan` varchar(255) character set utf8 NOT NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Dumping data for table `tbld_liftbaned`
--
--
-- Table structure for table `tbld_maritalstatus`
--

CREATE TABLE IF NOT EXISTS `tbld_maritalstatus` (
  `MaritalStatusID` smallint(5) unsigned NOT NULL auto_increment,
  `L1MaritalStatus` varchar(30) collate utf8_unicode_ci NOT NULL,
  `L2MaritalStatus` varchar(60) collate utf8_unicode_ci NOT NULL,
  `L3MaritalStatus` varchar(35) collate utf8_unicode_ci NOT NULL,
  `L4MaritalStatus` varchar(35) collate utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) default NULL,
  PRIMARY KEY  (`MaritalStatusID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Dumping data for table `tbld_maritalstatus`
--
--
-- Table structure for table `tbld_messages`
--

CREATE TABLE IF NOT EXISTS `tbld_messages` (
  `MessageID` int(10) unsigned NOT NULL auto_increment,
  `RecieverID` int(10) unsigned NOT NULL default '0',
  `SenderID` int(10) unsigned NOT NULL default '0',
  `RecieverStatusID` tinyint(3) unsigned default '1',
  `SenderStatusID` tinyint(3) unsigned default '1',
  `SentOn` datetime default NULL,
  `ReadOn` datetime default NULL,
  `ReplyID` int(10) unsigned default NULL,
  `AttachmentUID` varchar(20) collate utf8_unicode_ci default NULL,
  `AttachmentExtension` varchar(7) collate utf8_unicode_ci default NULL,
  `Subject` varchar(50) collate utf8_unicode_ci NOT NULL,
  `Message` text collate utf8_unicode_ci,
  `MessageStatus` tinyint(3) NOT NULL default '1',
  PRIMARY KEY  (`MessageID`),
  KEY `tblDMessageRecieverID` (`RecieverID`),
  KEY `tblDMessageSenderID` (`SenderID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `tbld_notifyemail`
--

CREATE TABLE IF NOT EXISTS `tbld_notifyemail` (
  `Id` int(11) NOT NULL auto_increment,
  `L1NOTIFY` varchar(255) collate utf8_unicode_ci default NULL,
  `L2NOTIFY` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Dumping data for table `tbld_notifyemail`
--
--
-- Table structure for table `tbld_orders`
--

CREATE TABLE IF NOT EXISTS `tbld_orders` (
  `Id` int(11) NOT NULL auto_increment,
  `OrderId` varchar(255) character set utf8 default NULL,
  `UserId` int(11) NOT NULL default '0',
  `PayDate` datetime default NULL,
  `Amounts` int(11) NOT NULL default '0',
  `Status` tinyint(1) NOT NULL default '0',
  `PaymentId_NL` bigint(20) NOT NULL default '0',
  `PaymentType_NL` tinyint(3) NOT NULL default '0',
  `PriceId` int(11) NOT NULL default '0',
  `ExpireDate` datetime DEFAULT NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

-- --------------------------------------------------------

--
-- Table structure for table `tbld_photos`
--

CREATE TABLE IF NOT EXISTS `tbld_photos` (
  `PhotoID` int(10) unsigned NOT NULL auto_increment,
  `UserID` int(10) unsigned NOT NULL default '0',
  `PhotoExtension` varchar(20) collate utf8_unicode_ci NOT NULL,
  `PhotoDescription` varchar(20) collate utf8_unicode_ci NOT NULL,
  `IsApproved` tinyint(4) default NULL,
  `PrimaryPhoto` smallint(5) unsigned default NULL,
  `InsertDate` date default NULL,
  `TotalRating` int(11) default NULL,
  `NumberOfVote` int(11) default NULL,
  PRIMARY KEY  (`PhotoID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;
--
-- Table structure for table `tbld_prices`
--

CREATE TABLE IF NOT EXISTS `tbld_prices` (
  `Id` int(11) NOT NULL auto_increment,
  `Prices` int(11) NOT NULL default '0',
  `NumofEmail` int(11) NOT NULL default '0',
  `Block` int(11) NOT NULL default '0',
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Dumping data for table `tbld_prices`
--
--
-- Table structure for table `tbld_profilestatus`
--

CREATE TABLE IF NOT EXISTS `tbld_profilestatus` (
  `ProfileStatusID` int(11) unsigned NOT NULL auto_increment,
  `L1ProfileStatus` varchar(100) collate utf8_unicode_ci NOT NULL,
  `L2ProfileStatus` varchar(100) collate utf8_unicode_ci NOT NULL,
  `L3ProfileStatus` varchar(100) collate utf8_unicode_ci NOT NULL,
  `L4ProfileStatus` varchar(30) collate utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`ProfileStatusID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Dumping data for table `tbld_profilestatus`
--
--
-- Table structure for table `tbld_religions`
--

CREATE TABLE IF NOT EXISTS `tbld_religions` (
  `ReligionID` smallint(5) unsigned NOT NULL auto_increment,
  `L1Religion` varchar(50) collate utf8_unicode_ci NOT NULL,
  `L2Religion` varchar(50) collate utf8_unicode_ci NOT NULL,
  `L3Religion` varchar(50) collate utf8_unicode_ci NOT NULL,
  `L4Religion` varchar(50) collate utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) default NULL,
  PRIMARY KEY  (`ReligionID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Dumping data for table `tbld_religions`
--
--
-- Table structure for table `tbld_savedsearch`
--

CREATE TABLE IF NOT EXISTS `tbld_savedsearch` (
  `SearchID` int(10) unsigned NOT NULL auto_increment,
  `UserID` int(10) unsigned NOT NULL default '0',
  `SearchName` varchar(75) collate utf8_unicode_ci default NULL,
  `Query` text collate utf8_unicode_ci,
  `SearchValue` text collate utf8_unicode_ci,
  `DateCreated` datetime default NULL,
  `DateProcessed` datetime default NULL,
  `SubcriptionStatusID` tinyint(3) unsigned default NULL,
  PRIMARY KEY  (`SearchID`),
  KEY `tblDSavedSearchUserID` (`UserID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Dumping data for table `tbld_savedsearch`
--
--
-- Table structure for table `tbld_signalme`
--

CREATE TABLE IF NOT EXISTS `tbld_signalme` (
  `RecieverID` int(10) unsigned NOT NULL default '0',
  `SenderID` int(10) unsigned NOT NULL default '0',
  `SignalDate` datetime default '0000-00-00 00:00:00',
  `IsViews` tinyint(3) NOT NULL default '0',
  KEY `tblDSignalMeRecieverID` (`RecieverID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
--
-- Table structure for table `tbld_smoking`
--

CREATE TABLE IF NOT EXISTS `tbld_smoking` (
  `SmokingID` smallint(5) unsigned NOT NULL auto_increment,
  `L1Smoking` varchar(50) collate utf8_unicode_ci NOT NULL,
  `L2Smoking` varchar(50) collate utf8_unicode_ci NOT NULL,
  `L3Smoking` varchar(50) collate utf8_unicode_ci NOT NULL,
  `L4Smoking` varchar(50) collate utf8_unicode_ci NOT NULL,
  `TopSorted` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`SmokingID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Dumping data for table `tbld_smoking`
--
--
-- Table structure for table `tbld_states`
--

CREATE TABLE IF NOT EXISTS `tbld_states` (
  `StateID` int(11) NOT NULL auto_increment,
  `State` varchar(50) collate utf8_unicode_ci NOT NULL,
  `CountryID` int(11) NOT NULL default '0',
  `TopSorted` tinyint(4) default NULL,
  PRIMARY KEY  (`StateID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Dumping data for table `tbld_states`
--
--
-- Table structure for table `tbld_users`
--

CREATE TABLE IF NOT EXISTS `tbld_users` (
  `UserID` int(11) unsigned NOT NULL auto_increment,
  `MembershipID` smallint(5) unsigned NOT NULL default '1',
  `RemainVIPContacts` bigint(20) unsigned default '0',
  `SiteID` tinyint(3) unsigned default '1',
  `Name` varchar(75) collate utf8_unicode_ci default NULL,
  `ProfileName` varchar(75) collate utf8_unicode_ci default NULL,
  `Email` varchar(75) collate utf8_unicode_ci NOT NULL,
  `Password` varchar(75) collate utf8_unicode_ci NOT NULL,
  `GenderID` smallint(5) unsigned default NULL,
  `HeightID` smallint(5) unsigned default NULL,
  `Age` smallint(5) unsigned default NULL,
  `BodyTypeID` smallint(5) unsigned default NULL,
  `HairColorID` smallint(5) unsigned default NULL,
  `EyeColorID` smallint(5) unsigned default NULL,
  `City` varchar(75) collate utf8_unicode_ci NOT NULL,
  `StateID` int(11) default NULL,
  `CountryID` smallint(6) NOT NULL default '0',
  `Zipcode` varchar(20) collate utf8_unicode_ci NOT NULL,
  `Phone` varchar(30) collate utf8_unicode_ci NOT NULL,
  `IMessagerID` smallint(5) unsigned default NULL,
  `IMessager` varchar(30) collate utf8_unicode_ci default NULL,
  `ReligionID` smallint(6) default NULL,
  `EducationID` smallint(6) default NULL,
  `Occupation` varchar(75) collate utf8_unicode_ci default NULL,
  `SmokingID` smallint(6) default NULL,
  `DrinkingID` smallint(6) default NULL,
  `MaritalStatusID` tinyint(3) unsigned default NULL,
  `DatingInterestID` smallint(5) unsigned default NULL,
  `HaveChildren` smallint(5) unsigned default NULL,
  `WantChildren` smallint(5) unsigned default NULL,
  `WillingToTravel` decimal(18,0) default NULL,
  `IPaddress` varchar(20) collate utf8_unicode_ci default NULL,
  `DatePosted` date NOT NULL default '0000-00-00',
  `DateUpdate` date NOT NULL default '0000-00-00',
  `LastEmailSent` datetime default NULL,
  `LastLogon` datetime default NULL,
  `ProfileStatusID` smallint(5) unsigned default '0',
  `NotificationScheduleID` tinyint(3) unsigned default '3',
  `MatchAgeFrom` tinyint(4) default NULL,
  `MatchAgeTO` tinyint(4) default NULL,
  `MatchGenderID` tinyint(6) default NULL,
  `MatchHeightIDFrom` smallint(6) default NULL,
  `MatchHeightIDTo` smallint(6) default NULL,
  `MatchBodyStyleID` smallint(6) default NULL,
  `MatchReligionID` smallint(6) default NULL,
  `MatchEducationID` smallint(6) default NULL,
  `MatchCareerID` smallint(6) default NULL,
  `MatchSmokingID` smallint(6) default NULL,
  `MatchDrinkingID` smallint(6) default NULL,
  `MatchMaritalStatusID` smallint(6) default NULL,
  `MatchNumberofChild` smallint(6) default NULL,
  `MatchBeSameLocation` smallint(6) default NULL,
  `SubcribeList` smallint(6) default NULL,
  `RandomVerifyID` int(10) unsigned NOT NULL default '0',
  `Goal` text collate utf8_unicode_ci,
  `Interests` text collate utf8_unicode_ci,
  `AboutMe` text collate utf8_unicode_ci,
  `AboutMyMatch` text collate utf8_unicode_ci,
  `PrimaryPhotoID` int(11) default NULL,
  `GroupID` smallint(5) unsigned NOT NULL default '0',
  `Views` bigint(20) default '0',
  `IsOnline` tinyint(3) NOT NULL DEFAULT '0',
  `TotalRating` bigint(20) NOT NULL DEFAULT '0',
  `NumberOfVote` bigint(20) NOT NULL DEFAULT '0',
  `ThemeId` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY  (`UserID`),
  KEY `tblDtblDUsersProfileStatusID` (`ProfileStatusID`),
  KEY `tblDUserIndexOnEmail` (`Email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Table structure for table `tbld_whoviews`
--

CREATE TABLE IF NOT EXISTS `tbld_whoviews` (
  `Id` int(11) NOT NULL auto_increment,
  `UserId` int(11) NOT NULL,
  `ViewUserId` int(11) NOT NULL,
  `ViewDate` datetime NOT NULL,
  `IsView` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Table structure for table `tbld_filteremails`
--

CREATE TABLE IF NOT EXISTS `tbld_filteremails` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `EmailAddress` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BanEmail` tinyint(3) NOT NULL DEFAULT '0',
  `BanDomain` tinyint(3) NOT NULL DEFAULT '0',
  `BanDate` datetime DEFAULT NULL,
  `ReasonBaned` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Table structure for table `tbld_filteremails`
--

CREATE TABLE IF NOT EXISTS `tbld_pages` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PageName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PageBody` longtext COLLATE utf8_unicode_ci,
  `LastUpdated` datetime DEFAULT NULL,
  `IsActive` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
--
-- Table structure for table `tbld_cards_categories`
--

CREATE TABLE IF NOT EXISTS `tbld_cards_categories` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameCate` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
--
-- Table structure for table `tbld_greetingcards`
--

CREATE TABLE IF NOT EXISTS `tbld_greetingcards` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CardCate` int(11) NOT NULL DEFAULT '0',
  `CardName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IsText` int(11) NOT NULL DEFAULT '0',
  `ViewFormat` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `tbld_ecards` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `SenderId` int(11) NOT NULL DEFAULT '0',
  `RecieverId` int(11) NOT NULL DEFAULT '0',
  `CardId` int(11) NOT NULL DEFAULT '0',
  `CateCardId` int(11) NOT NULL DEFAULT '0',
  `Subjects` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Contents` text COLLATE utf8_unicode_ci,
  `SentDate` datetime DEFAULT NULL,
  `WidthMess` int(11) NOT NULL DEFAULT '0',
  `HeightMess` int(11) NOT NULL DEFAULT '0',
  `LeftMess` int(11) NOT NULL DEFAULT '0',
  `TopMess` int(11) NOT NULL DEFAULT '0',
  `IsReed` tinyint(3) NOT NULL DEFAULT '0',
  `Music` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Table structure for table `tbld_chat`
--

CREATE TABLE IF NOT EXISTS `tbld_chat` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `from` varchar(255) collate utf8_unicode_ci NOT NULL,
  `to` varchar(255) collate utf8_unicode_ci NOT NULL,
  `message` text collate utf8_unicode_ci NOT NULL,
  `sent` datetime NOT NULL default '0000-00-00 00:00:00',
  `recd` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

--
-- Table structure for table `tbld_abuseprofiles`
--

CREATE TABLE IF NOT EXISTS `tbld_abuseprofiles` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ReportBy` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ProfileId` int(11) NOT NULL DEFAULT '0',
  `Reason` text COLLATE utf8_unicode_ci,
  `ReprotDate` datetime DEFAULT NULL,
  `IsProcess` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Table structure for table `tbld_flirt_categories`
--

CREATE TABLE IF NOT EXISTS `tbld_flirt_categories` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NameCate` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
--
-- Table structure for table `tbld_flirts`
--

CREATE TABLE IF NOT EXISTS `tbld_flirts` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CateId` int(11) NOT NULL DEFAULT '0',
  `FilrtValue` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
--
-- Table structure for table `tbld_themes`
--

CREATE TABLE IF NOT EXISTS `tbld_themes` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ThemeName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IsActive` tinyint(3) NOT NULL DEFAULT '1',
  `SourceName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FileView` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Table structure for table `tbld_site_settings`
--
CREATE TABLE IF NOT EXISTS `tbld_site_settings` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Variable` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IsRead` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO `tbld_site_settings` VALUES (1,'totallogin','5',0) ON DUPLICATE KEY UPDATE Id=1;
INSERT INTO `tbld_site_settings` VALUES (2,'default_language','L1',0) ON DUPLICATE KEY UPDATE Id=2;
INSERT INTO `tbld_site_settings` VALUES (3,'sitename','Sample website 1',0) ON DUPLICATE KEY UPDATE Id=3;
INSERT INTO `tbld_site_settings` VALUES (4,'slogan','goodbye to the single life 1',0) ON DUPLICATE KEY UPDATE Id=4;
INSERT INTO `tbld_site_settings` VALUES (5,'strfoot','All right reserved &amp;copy; 2014',0) ON DUPLICATE KEY UPDATE Id=5;
INSERT INTO `tbld_site_settings` VALUES (6,'currency','$',0) ON DUPLICATE KEY UPDATE Id=6;
INSERT INTO `tbld_site_settings` VALUES (7,'numof_record_perpage','30',0) ON DUPLICATE KEY UPDATE Id=7;
INSERT INTO `tbld_site_settings` VALUES (8,'filetype','gif,jpg',0) ON DUPLICATE KEY UPDATE Id=8;
INSERT INTO `tbld_site_settings` VALUES (9,'max_size','25000',0) ON DUPLICATE KEY UPDATE Id=9;
INSERT INTO `tbld_site_settings` VALUES (10,'max_height','1000',0) ON DUPLICATE KEY UPDATE Id=10;
INSERT INTO `tbld_site_settings` VALUES (11,'max_width','1000',0) ON DUPLICATE KEY UPDATE Id=11;
INSERT INTO `tbld_site_settings` VALUES (12,'maxemail','20',0) ON DUPLICATE KEY UPDATE Id=12;
INSERT INTO `tbld_site_settings` VALUES (13,'uploaddir','fuploads',0) ON DUPLICATE KEY UPDATE Id=13;
INSERT INTO `tbld_site_settings` VALUES (14,'adminemail','admin@yourdomain.com',0) ON DUPLICATE KEY UPDATE Id=14;
INSERT INTO `tbld_site_settings` VALUES (15,'Version','1.0',0) ON DUPLICATE KEY UPDATE Id=15;
INSERT INTO `tbld_site_settings` VALUES (16,'logo','logo.png',0) ON DUPLICATE KEY UPDATE Id=16;
--
-- Table structure for table `tbld_paymentprovide`
--
CREATE TABLE IF NOT EXISTS `tbld_paymentprovide` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PaymentType` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `APIKey` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `APIPassword` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `APISignature` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `APISucrect` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CurrencyCode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ReturnURL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CancelURL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ButtonImg` text CHARACTER SET utf8,
  `APIMode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IsActive` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;