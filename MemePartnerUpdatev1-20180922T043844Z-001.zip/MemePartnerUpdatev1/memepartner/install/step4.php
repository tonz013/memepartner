<?php
require_once "../includes/config.php";
include ("function.php");
function delete_directory($dirname) {
	   if (is_dir($dirname))
		  $dir_handle = opendir($dirname);
	   if (!$dir_handle)
		  return false;
	   while($file = readdir($dir_handle)) {
		  if ($file != "." && $file != "..") {
			 if (!is_dir($dirname."/".$file))
				unlink($dirname."/".$file);
			 else
				delete_directory($dirname.'/'.$file);    
		  }
	   }
	   closedir($dir_handle);
	   rmdir($dirname);
	   return true;
	}
$link=str_replace("install/step4.php",'',curPageURL());
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Congratulations !</title>
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php
$_SESSION['completed'] = 1;
if(isset($_GET['s']) && intval($_GET['s'])==5 && isset($_GET['r'])){
	if(delete_directory("../install")){
		mysql_close();
		echo "<script language=\"javascript\">window.location.href=\"".$_GET['r']."\";</script>";	
		exit();
		}
	else{
		mysql_close();
		exit('canot delete folder');
		}
	}
?>
<div id="templatemo_wrapper">
    
  <div id="templatemo_menu"><h2 style="padding-top:5px; text-transform:uppercase; color:#125e9a; font-weight:bold">installation</h2>
  </div> <!-- end of templatemo_menu -->
  <div id="templatemo_main">
    <div id="templatemo_content">
                
<h2>Congratulations! You've completed the installation.
</h2>
<br />
       	<div id="contact_form">
You've completed the installation.<br />
Please manually remove the /install folder.<br />
 Please <a href="<?php echo '../';?>">click here</a> to see the new site.

</div>      

        	</div><!-- end of content -->
			<div id="templatemo_sidebar">
            </div>
       	<div class="cleaner"></div>
     </div>     <!-- end of main -->
<div id="templatemo_main_bottom"></div><!-- end of main -->
    
    <div id="templatemo_footer">
    
   	 Copyright &copy; <?php echo date('Y');?> <?php echo $sitename;?>
    
    </div> <!-- end of templatemo_footer -->

</div> <!-- end of wrapper -->

</body>
</html>