<?php
require_once "includes/config.php";
require_once "includes/database.php";
require_once "includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smsendmail'])){
	$err = 0;
	if(empty($_POST['email'])){
		$err_e = $emailnull;
		$err = 1;
		}
	elseif(!valid_email(trim($_POST['email']))){
		$err_e = $emailinvalid;
		$err = 1;
		}
	elseif(empty($_POST['subject'])){
		$err_s = $subjectnull;
		$err = 1;
		}
	elseif(strlen($_POST['subject'])<6){
		$err_s = $datashort;
		$err = 1;
		}
	elseif(empty($_POST['content'])){
		$err_co = $contentnull;
		$err = 1;
		}
	elseif(strlen($_POST['content'])<6){
		$err_co = $datashort;
		$err = 1;
		}
	elseif(!isset($_SESSION['memberid']) || $_SESSION['memberid']==0){
		if(empty($_POST['captcha'])){
			$err_c = $captchanull;
			$err = 1;
			}
		elseif(strlen($_POST['captcha'])<6){
			$err_c = $datashort;
			$err = 1;
			}
		elseif($_POST['captcha'] != $_SESSION['encoded_captcha']){
			$err_c = $captnomatch;
			$err = 1;
			}
		}
	if(intval($err)==0){
		$mess = $_POST['content'];
		if(!mail($adminemail, '=?UTF-8?B?'.base64_encode($_POST['subject']).'?=', $mess, "Content-Type: text/html; charset=utf-8\r\n"."From: ".$_POST['email']))
			$error = $cannotsendemail;
		else $succ = $contactsucc;
		}
	}
$title = $contactus;
$ismenu = 6;
require_once 'includes/header.php';
require_once 'includes/menus.php';
?>
       <div class="maincontent"><br />
       		<div class="signup">
            	<form action="" method="post">
            	<p class="styletop"><?php echo $title;?></p>
                <?php
				if(isset($error) && !empty($error))
					echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
				echo '<br />';
				$valemail = isset($_SESSION['memberemail'])?$_SESSION['memberemail']:'';
				if(isset($succ) && !empty($succ))
					echo '<p style="padding-left:20px;"><font color="009933">'.$succ.'</font></p>';
				else{
				?>
                <table width="100%" cellpadding="3" cellspacing="3">
                	<tr>
                    	<td width="30%" align="right" valign="top">Email: </td>
                        <td width="70%" align="left"><input type="text" style="width:265px;" name="email" value="<?php echo isset($_POST['email'])?$_POST['email']:$valemail;?>" maxlength="255"/><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_e) && !empty($err_e))
							echo '<br><font color="#FF0000"><small><i>'.$err_e.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $subject.': ';?></td>
                        <td width="70%" align="left"><input type="text" style="width:265px;" name="subject" value="<?php echo isset($_POST['subject'])?$_POST['subject']:'';?>" maxlength="255"/><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_s) && !empty($err_s))
							echo '<br><font color="#FF0000"><small><i>'.$err_s.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $emailcontent.': ';?></td>
                        <td width="70%" align="left">
                        	<textarea rows="5" cols="40" name="content"><?php echo isset($_POST['content'])?$_POST['content']:'';?></textarea>
                        <font color="#FF0000"> *</font>
                        <?php
						if(isset($err_co) && !empty($err_co))
							echo '<br><font color="#FF0000"><small><i>'.$err_co.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <?php
					if(!isset($_SESSION['memberid']) || $_SESSION['memberid']==0){
					?>
                    <tr>
                    	<td width="30%" align="right" valign="top">&nbsp;</td>
                        <td width="70%" align="left">
                        <img src="<?php echo $base_url;?>includes/capcha.php" border="0"/><br />
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $captcha;?>: </td>
                        <td width="70%" align="left">
                        <input type="text" size="10" name="captcha" maxlength="6"/><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_c) && !empty($err_c))
							echo '<br><font color="#FF0000"><small><i>'.$err_c.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <?php
						}
					?>
                </table>
                <?php }?>
                <br />
                <div class="stylebott" align="center">
                    	<p style="margin:0px; padding:7px 0px;">
                        <?php if(!empty($succ))
							echo '&nbsp;';
						else echo '<input type="submit" value="'.$sendmail.'" class="massbutton" name="smsendmail"/>&nbsp;<input type="reset" value="'.$cancel.'" class="massbutton"/>';
						?>
                        </p>
                </div>
                </form>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
require_once 'includes/footer.php';
?>