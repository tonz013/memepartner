<?php
require_once "includes/config.php";
require_once "includes/database.php";
$temp = $_SESSION['memberid'];
unset($_SESSION['memberid']);
unset($_SESSION['memberemail']);
$sql = 'update '.$table_prefix.'users set IsOnline = 0 where UserID = '.$temp;
$qry = mysql_query($sql);
mysql_close();
header('Location: '.$base_url);
exit();
?>