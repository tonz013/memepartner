<?php
require_once "../includes/config.php";
require_once "../includes/database.php";

if ($_GET['action'] == "chatheartbeat") { chatHeartbeat(); } 
if ($_GET['action'] == "sendchat") { sendChat(); } 
if ($_GET['action'] == "closechat") { closeChat(); } 
if ($_GET['action'] == "startchatsession") { startChatSession(); } 
if ($_GET['action'] == "chatname") { chatName(); } 

if (!isset($_SESSION['chatHistory'])) {
	$_SESSION['chatHistory'] = array();	
}

if (!isset($_SESSION['openChatBoxes'])) {
	$_SESSION['openChatBoxes'] = array();	
}

function chatHeartbeat() {
	$tempid = array();
	$sqlfi = "select id from ".$GLOBALS['table_prefix']."chat as chat, ".$GLOBALS['table_prefix']."users as users where (chat.to = '".mysql_real_escape_string($_SESSION['chatuser'])."' AND recd = 0) and chat.from=users.UserID order by chat.sent desc limit 0, 10";
	$qryfi = mysql_query($sqlfi);
	if($qryfi && mysql_num_rows($qryfi)==10){
		while($rowsfi=mysql_fetch_array($qryfi))
			array_push($tempid, $rowsfi['id']);
		$sql = "select users.ProfileName as username, chat.from, chat.message, chat.to, chat.id, chat.sent, chat.recd from ".$GLOBALS['table_prefix']."chat as chat, ".$GLOBALS['table_prefix']."users as users where (chat.to = '".mysql_real_escape_string($_SESSION['chatuser'])."' AND recd = 0) and chat.from=users.UserID and chat.id in (".implode(',', $tempid).") order by chat.id ASC";
		}
	else $sql = "select users.ProfileName as username, chat.from, chat.message, chat.to, chat.id, chat.sent, chat.recd from ".$GLOBALS['table_prefix']."chat as chat, ".$GLOBALS['table_prefix']."users as users where (chat.to = '".mysql_real_escape_string($_SESSION['chatuser'])."' AND recd = 0) and chat.from=users.UserID order by chat.id ASC";
	$query = mysql_query($sql);
	$items = '';

	$chatBoxes = array();
	while ($chat = mysql_fetch_array($query)) {
		if (!isset($_SESSION['openChatBoxes'][$chat['from']]) && isset($_SESSION['chatHistory'][$chat['from']]))
			$items = $_SESSION['chatHistory'][$chat['from']];

		$chat['message'] = sanitize($chat['message']);

		$items .= <<<EOD
					   {
			"s": "0",
			"u": "{$chat['username']}",
			"f": "{$chat['from']}",
			"m": "{$chat['message']}"
	   },
EOD;

		if (!isset($_SESSION['chatHistory'][$chat['from']])) 
			$_SESSION['chatHistory'][$chat['from']] = '';

		$_SESSION['chatHistory'][$chat['from']] .= <<<EOD
						   {
			"s": "0",
			"u": "{$chat['username']}",
			"f": "{$chat['from']}",
			"m": "{$chat['message']}"
	   },
EOD;
		
		unset($_SESSION['tsChatBoxes'][$chat['from']]);
		$_SESSION['openChatBoxes'][$chat['from']] = $chat['sent'];
	}

	if (!empty($_SESSION['openChatBoxes'])) {
	foreach ($_SESSION['openChatBoxes'] as $chatbox => $time) {
		if (!isset($_SESSION['tsChatBoxes'][$chatbox])) {
			$now = time()-strtotime($time);
			$time = date('g:iA M dS', strtotime($time));

			$message = "Sent at $time";
			if ($now > 180) {
				$items .= <<<EOD
{
"s": "2",
"f": "$chatbox",
"m": "{$message}"
},
EOD;

	if (!isset($_SESSION['chatHistory'][$chatbox])) {
		$_SESSION['chatHistory'][$chatbox] = '';
	}

	$_SESSION['chatHistory'][$chatbox] .= <<<EOD
		{
"s": "2",
"f": "$chatbox",
"m": "{$message}"
},
EOD;
			$_SESSION['tsChatBoxes'][$chatbox] = 1;
		}
		}
	}
}

	$sql = "update ".$GLOBALS['table_prefix']."chat set recd = 1 where ".$GLOBALS['table_prefix']."chat.to = '".mysql_real_escape_string($_SESSION['chatuser'])."' and recd = 0";
	$query = mysql_query($sql);

	if ($items != '') {
		$items = substr($items, 0, -1);
	}
header('Content-type: application/json');
?>
{
		"items": [
			<?php echo $items;?>
        ]
}

<?php
			exit(0);
}

function chatBoxSession($chatbox) {
	
	$items = '';
	
	if (isset($_SESSION['chatHistory'][$chatbox])) {
		$temp_array = explode("},", $_SESSION['chatHistory'][$chatbox]);    
		$total = count($temp_array);
		if($total>10){
			for($i = ($total-11); $i < $total-1;$i++)
			{
				$val = str_replace('{','',$temp_array[$i]);
				$items .= <<<EOD
{
	$val
},
EOD;
			}
		}
		else $items = $_SESSION['chatHistory'][$chatbox];
	}
	
	return $items;
}

function startChatSession() {
	$items = '';
	if (!empty($_SESSION['openChatBoxes'])) {
		foreach ($_SESSION['openChatBoxes'] as $chatbox => $void) {
			$items .= chatBoxSession($chatbox);
		}
	}

	if ($items != '') {
		$items = substr($items, 0, -1);
	}

header('Content-type: application/json');
?>
{
		"username": "<?php echo $_SESSION['chatuser'];?>",
		"items": [
			<?php echo $items;?>
        ]
}

<?php
	exit(0);
	
}

function chatName() {
	$un = '';
	
$su=$_GET['usw'];
$sc2=mysql_query("select ProfileName as username from ".$GLOBALS['table_prefix']."users where UserID=".$su." limit 1");
while($row_sc2=mysql_fetch_array($sc2))
{
$un=$row_sc2["username"];
}
?>
{
		"unm": ["<?php echo $un;?>"]
		
}

<?php


	exit(0);
}



function sendChat() {
	$from = $_SESSION['chatuser'];
	$to = $_POST['to'];
	$message = $_POST['message'];
	$sql = "select ".$GLOBALS['table_prefix']."users.ProfileName as username from ".$GLOBALS['table_prefix']."users where ".$GLOBALS['table_prefix']."users.UserID=".$from." limit 1";
	$uname = mysql_query($sql);
	$from_user='';
	while ($un = mysql_fetch_array($uname)) {
	$from_user=$un['username'];
	}
	
	
	$_SESSION['openChatBoxes'][$_POST['to']] = date('Y-m-d H:i:s', time());
	
	$messagesan = sanitize($message);

	if (!isset($_SESSION['chatHistory'][$_POST['to']])) {
		$_SESSION['chatHistory'][$_POST['to']] = '';
	}
	$temp_array1 = explode("},", $_SESSION['chatHistory'][$_POST['to']]);    
	$total1 = count($temp_array1);
	if($total1>10){
		$_SESSION['chatHistory'][$_POST['to']] = '';
		for($i = ($total1-11); $i < $total1-1;$i++){
			$val1 = str_replace('{','',$temp_array1[$i]);
			$_SESSION['chatHistory'][$_POST['to']] .= <<<EOD
{
	$val1
},
EOD;
			}
		}
	else $_SESSION['chatHistory'][$_POST['to']] .= <<<EOD
	   {
			"s": "1",
			"u": "{$from_user}",
			"f": "{$to}",
			"m": "{$messagesan}"
	   },
EOD;
	
	unset($_SESSION['tsChatBoxes'][$_POST['to']]);
	$sql = "insert into ".$GLOBALS['table_prefix']."chat (".$GLOBALS['table_prefix']."chat.from, ".$GLOBALS['table_prefix']."chat.to, ".$GLOBALS['table_prefix']."chat.message, ".$GLOBALS['table_prefix']."chat.sent) values ('".mysql_real_escape_string($from)."', '".mysql_real_escape_string($to)."','".mysql_real_escape_string($message)."',NOW())";
	$query = mysql_query($sql);
	echo "1";
	exit(0);
}

function closeChat() {

	unset($_SESSION['openChatBoxes'][$_POST['chatbox']]);
	$_SESSION['chatHistory'][$_POST['chatbox']] = '';
	echo "1";
	exit(0);
}

function sanitize($text) {
	$text = htmlspecialchars($text, ENT_QUOTES);
	$text = str_replace("\n\r","\n",$text);
	$text = str_replace("\r\n","\n",$text);
	$text = str_replace("\n","<br>",$text);
	return $text;
}