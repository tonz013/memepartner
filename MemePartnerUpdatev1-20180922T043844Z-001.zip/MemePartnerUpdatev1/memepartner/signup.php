<?php
require_once "includes/config.php";
require_once "includes/database.php";
require_once "includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smsignup'])){
	if(empty($_POST['email']))
		$err_e = $emailnull;
	elseif(!valid_email($_POST['email']))
		$err_e = $emailinvalid;
	elseif(empty($_POST['password']))
		$err_p = $passnull;
	elseif(strlen($_POST['password'])<6)
		$err_p = $datashort;
	elseif($_POST['password'] != $_POST['repassword'])
		$err_rp = $passnomatch;
	elseif(empty($_POST['captcha']))
		$err_c = $captchanull;
	elseif(strlen($_POST['captcha'])<6)
		$err_c = $datashort;
	elseif($_POST['captcha'] != $_SESSION['encoded_captcha'])
		$err_c = $captnomatch;
	elseif($_POST['termof']!='on')
		$err_t = $termofoff;
	else{
		if(!exits_user(mysql_real_escape_string($_POST['email'])))
			$error = $emailexits;
		else{
			$chkspam = chkSpam(mysql_real_escape_string(trim($_POST['email'])));
			if($chkspam==0)
				$error = $errordata;
			elseif($chkspam==-1)
				$error = 'Your domain in list spam on site, try again with other domain';
			elseif($chkspam==-2)
				$error = 'Your email in list spam on site, try again with other email';
			elseif($chkspam==1){
				$str = random_string(6);
				$data = array(mysql_real_escape_string(trim($_POST['email'])), mysql_real_escape_string(trim($_POST['password'])), $str.mysql_real_escape_string($_POST['captcha']), IpAddress());
				$result = new_user($data);
				if($result==0)
					$error = $errordata;
				else{
					mysql_close();
					$_SESSION['user_temp'] = $result;
					$_SESSION['email_temp'] = $_POST['email'];
					header('Location: '.$base_url.'yourdetails.php');
					exit();
					}
				}
			}
		}
	}
$title = $userreg;
require_once 'includes/header.php';
require_once 'includes/menus.php';
$isstep = 1;
require_once 'includes/stepreg.php';
?>
       <div class="maincontent"><br />
       		<div class="signup">
            	<form action="" method="post">
            	<p class="styletop"><?php echo $createaccount;?></p>
                <?php
				if(isset($error) && !empty($error))
					echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
				?>
                <br />
                <table width="100%" cellpadding="3" cellspacing="3">
                	<tr>
                    	<td width="30%" align="right" valign="top">Email: </td>
                        <td width="70%" align="left"><input type="text" style="width:265px;" name="email" value="<?php echo isset($_POST['email'])?$_POST['email']:'';?>"/><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_e) && !empty($err_e))
							echo '<br><font color="#FF0000"><small><i>'.$err_e.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $mypassword;?>: </td>
                        <td width="70%" align="left"><input type="password" style="width:265px;" name="password" value="<?php echo isset($_POST['password'])?$_POST['password']:'';?>" autocomplete="off"/><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_p) && !empty($err_p))
							echo '<br><font color="#FF0000"><small><i>'.$err_p.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $repassword;?>: </td>
                        <td width="70%" align="left"><input type="password" style="width:265px;" name="repassword"/><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_rp) && !empty($err_rp))
							echo '<br><font color="#FF0000"><small><i>'.$err_rp.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">&nbsp;</td>
                        <td width="70%" align="left">
                        <img src="<?php echo $base_url;?>includes/capcha.php" border="0"/><br />
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $captcha;?>: </td>
                        <td width="70%" align="left">
                        <input type="text" size="10" name="captcha" maxlength="6"/><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_c) && !empty($err_c))
							echo '<br><font color="#FF0000"><small><i>'.$err_c.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">&nbsp;</td>
                        <td width="70%" align="left"><font color="#FF0000">* </font>
                        <input type="checkbox" style="margin-left:0px; padding-left:0px;" name="termof"/>&nbsp;<i><?php echo str_replace('<link>', '<a href="termofuse.php">', str_replace('</link>', '</a>', str_replace('<site>', $sitename, $agreetemof)));?></i>
                        <?php
						if(isset($err_t) && !empty($err_t))
							echo '<br><font color="#FF0000"><small><i>'.$err_t.'</i></small></font>';
						?>
                        </td>
                    </tr>
                </table><br />
                <div class="stylebott">
                	<div class="bottleft"><?php echo $noteaccount;?></div>
                    <div class="bottright">
                    	<input type="submit" value="<?php echo $continute;?>" class="massbutton" name="smsignup"/>&nbsp;<input type="reset" value="<?php echo $cancel;?>" class="massbutton"/>
                    </div>
                    <p class="linespace">&nbsp;</p>
                </div>
                </form>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
require_once 'includes/footer.php';
?>