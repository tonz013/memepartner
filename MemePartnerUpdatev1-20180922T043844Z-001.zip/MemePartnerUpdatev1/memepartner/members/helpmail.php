<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	$_SESSION['direct'] = $base_url.'members/sentmail.php';
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
$title = $helpmail.' - '.GetProfileName($_SESSION['memberid']);
require_once '../includes/header.php';
$ismenu = 4;
require_once '../includes/menus.php';
?>
       <div class="maincontent"><br />
       <form action="" method="post">
       		<div id="browsemail">
                <div class="titletop">
                	<div class="lefttitletop">
                    	<h3><?php echo $mail;?></h3>
                    </div>
                    <div class="righttitletop">&nbsp;</div>
                    <p class="linespace">&nbsp;</p>
                </div>
                <?php
				$mailmn = 6;
				require_once "../includes/emailleft.php";
				?>
                <div class="mailright">
                	<?php
					if($_SESSION['lang']=='L1'){?>
						<p><?php echo $helpmails1;?></p>
                        <p><?php echo str_replace('<hinh>', '<img src="../imgs/ipnew.gif" border="0" />', $helpmails2).str_replace('<hinh>', '<img src="../imgs/oldmail.gif" style="margin-left:30px;" border="0"/>', $helpmails3).str_replace('<hinh>', '<img src="../imgs/ipattach.gif" style="margin-left:30px;" border="0"/>', $helpmails4).str_replace('<hinh>', '<img src="../imgs/replied.gif" style="margin-left:30px;" border="0"/>', $helpmails5).'</p><p>'.str_replace('<hinh>', '<img src="../imgs/replied.gif" border="0"/>', $helpmails6);?></p>
                        <p><?php echo $helpmails7;?></p>
                        <p><?php echo $helpmails8;?></p>
						<?php }
					else{
					?>
                        <p><?php echo $helpmails1;?></p>
                        <p><?php echo str_replace('<hinh>', '<img src="../imgs/ipnew.gif" border="0" />', $helpmails2).str_replace('<hinh>', '<img src="../imgs/oldmail.gif" style="margin-left:30px;" border="0"/>', $helpmails3).str_replace('<hinh>', '<img src="../imgs/ipattach.gif" style="margin-left:30px;" border="0"/>', $helpmails4).str_replace('<hinh>', '<img src="../imgs/replied.gif" style="margin-left:30px;" border="0"/>', $helpmails5).'</p><p>'.str_replace('<hinh>', '<img src="../imgs/replied.gif" border="0"/>', $helpmails6);?></p>
                        <p><?php echo $helpmails7;?></p>
                        <p><?php echo $helpmails8;?></p>
                   <?php }?>
                </div>
                <p class="linespace"><br />&nbsp;</p><br />&nbsp;
            </div>
            <p class="linespace">&nbsp;</p></form>
       </div>
<?php
mysql_close();
require_once '../includes/footer.php';
?>