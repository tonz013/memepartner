<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	$_SESSION['direct'] = $base_url.'members/blacklist.php';
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
if(isset($_GET['bid']) && isset($_GET['a']) && intval($_GET['bid']) > 0 && $_GET['a']=='d'){
	if(!unBlockUser($_SESSION['memberid'], intval($_GET['bid'])))
		$_SESSION['error'] = $errordata;
	else{
		$_SESSION['succ'] = $delsucc;
		mysql_close();
		header('Location: '.$base_url.'members/blacklist.php');
		exit();
		}
	}
$title = $blacklist.' - '.GetProfileName($_SESSION['memberid']);
require_once '../includes/header.php';
$ismenu = 4;
require_once '../includes/menus.php';
$lblack = getBlackList($_SESSION['memberid'], '');
$config['showeachside'] = 4;
$config['per_page'] = 30;
$config['js_numrows_page'] = mysql_num_rows($lblack);
$config['curpage'] = empty($_GET['p'])?1:$_GET['p'];
$config['rs_start'] = ($config['curpage']*$config['per_page'])-$config['per_page'];
if($config['js_numrows_page'] < $config['per_page'])
	$config['per_page'] = $config['js_numrows_page'];
$config['cururl'] = $base_url.'members/sentmail.php';
$paging = Pagination($config);
$limit = " limit ".$config['rs_start'].", ".$config['per_page'];
$lblack = getBlackList($_SESSION['memberid'], $limit);
?>
       <div class="maincontent"><br />
       <form action="" method="post">
       		<div id="browsemail">
                <div class="titletop">
                	<div class="lefttitletop">
                    	<h3><?php echo $mail;?></h3>
                    </div>
                    <div class="righttitletop">
                    	<ul>
                            <li style="float:right"><span style="float:right"><i><b><?php echo ($config['curpage']==1)?1:($config['curpage']*$config['per_page'] - ($config['per_page'] - 1));?> - <?php echo ($config['curpage']*$config['per_page'] > $config['js_numrows_page'])?$config['js_numrows_page']:$config['curpage']*$config['per_page'];?></b> <?php echo $inall;?> <b><?php echo $config['js_numrows_page'];?></b>&nbsp;</i></span></li>
                        </ul>
                    </div>
                    <p class="linespace">&nbsp;</p>
                </div>
                <?php
				$mailmn = 5;
				require_once "../includes/emailleft.php";
				?>
                <div class="mailright">
				<?php
				if(isset($_SESSION['succ']) && !empty($_SESSION['succ'])){
					echo '<p style="margin:0px; padding:5px 0px"><font color="#009933"><i>'.$_SESSION['succ'].'</i></font></p>';
					unset($_SESSION['succ']);
					}
				if(isset($_SESSION['error']) && !empty($_SESSION['error'])){
					echo '<p style="margin:0px; padding:5px 0px"><font color="#FF0000"><small><i>'.$_SESSION['error'].'</i></small></font></p>';
					unset($_SESSION['error']);
					}
				?>
                	<p><?php echo str_replace('<hinh>', '<img src="../imgs/delete.gif"  border="0"/>', $blacklistnote);?></p>
                    <?php
					if(mysql_num_rows($lblack)>0){
					?>
					<table width="100%" cellpadding="0" cellspacing="0">
                    	<tr class="topblachlist">
                        	<td width="5%" class="blacklistrow1"><?php echo $order;?></td>
                        	<td width="35%" class="blacklistrow1"><?php echo $profilename;?></td>
                            <td width="5%" class="blacklistrow1"><?php echo ucfirst($exage);?></td>
                            <td width="30%" class="blacklistrow1"><?php echo $address;?></td>
                            <td width="20%" class="blacklistrow1"><?php echo $signin;?></td>
                            <td width="5%" class="blacklistrow1"><?php echo $del;?></td>
                        </tr>
                        <?php
						$i=1;
						while($rows=mysql_fetch_array($lblack)){
							$blcl = '';
							$bstate = empty($rows['State'])?'':$rows['State'].', ';
							$hometown = (empty($rows['City']) || $rows['City']=='')?$bstate.$rows['Country']:$rows['City'].', '.$bstate.$rows['Country'];
							?>
							<tr <?php echo $blcl;?>>
								<td width="5%" class="blacklistrow2" align="center"><?php echo $i;?></td>
								<td width="35%" class="blacklistrow2" align="left"><a href="<?php echo $base_url;?>viewprofile.php?id=<?php echo $rows['BlockedUserID'];?>"><?php echo $rows['ProfileName'];?></a></td>
								<td width="5%" class="blacklistrow2" align="center"><?php echo $rows['Age'];?></td>
								<td width="30%" class="blacklistrow2" align="left"><?php echo $hometown;?></td>
								<td width="20%" class="blacklistrow2" align="center"><?php echo date('h:i:s d-m-Y', strtotime($rows['LastLogon']));?></td>
								<td width="5%" class="blacklistrow2" align="center"><a href="javascript:void(0)" onclick="confirmDel('<?php echo $base_url;?>members/blacklist.php?bid=<?php echo $rows['BlockedUserID'];?>&a=d', '<?php echo $alertdel;?>')"><img src="../imgs/delete.gif" border="0"/></a></td>
							</tr>
							<?php 
							$i++;
							}
						?>
                    </table>
                    <?php
						}
					else echo '<p><b>'.$notblacklist.'</b></p>';
					?>
                </div><p id="paging" style="clear:both; margin-right:0px; text-align:center"><?php echo $paging;?></p>
                <p class="linespace"><br />&nbsp;</p><br />&nbsp;
            </div>
            <p class="linespace">&nbsp;</p></form>
       </div>
<?php
mysql_close();
require_once '../includes/footer.php';
?>