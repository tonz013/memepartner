<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	$_SESSION['direct'] = $base_url.'members/ecards.php';
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
if(isset($_GET['id']) && isset($_GET['a']) && intval($_GET['id'])>0 && $_GET['a']=='del'){
	$sqld = 'delete from '.$table_prefix.'ecards where Id = '.intval($_GET['id']).' and RecieverId = '.$_SESSION['memberid'];
	$qryd = mysql_query($sqld);
	if(!$qryd) $error = 'Can not delete card';
	else{
		mysql_close();
		$_SESSION['succ'] = 'You deleted a card from list<br>';
		header('Location: '.$base_url.'members/ecards.php');
		exit();
		}
	}
$title = GetProfileName($_SESSION['memberid']).' - Your greeting cards';	
require_once '../includes/header.php';
$ismenu = 2;
require_once '../includes/menus.php';
?>
       <div class="maincontent"><br />
       		<div id="acounts">
                <?php
				echo '<h3>'.$settingaccount.'</h3>';
				$ltmn = 15;
				require_once '../includes/accountmenuleft.php';
				
				$config['showeachside'] = 4;
				$config['per_page'] = 20;
				$config['js_numrows_page'] = mysql_num_rows(getEcards($_SESSION['memberid'], ''));
				$config['curpage'] = empty($_GET['p'])?1:$_GET['p'];
				$config['rs_start'] = ($config['curpage']*$config['per_page'])-$config['per_page'];
				if($config['js_numrows_page'] < $config['per_page'])
					$config['per_page'] = $config['js_numrows_page'];
				$config['cururl'] = $base_url.'members/ecards.php';
				$paging = Pagination($config);
				$sql = " limit ".$config['rs_start'].", ".$config['per_page'];
				$qry = getEcards($_SESSION['memberid'], $sql);
				?>
                <div class="displayright">
                	<div class="headtop">
                    	<ul>
                        	<li class="contleft"><?php echo 'Your greeting cards';?></li>
                            <li class="contright"><i><?php echo str_replace('<from>', ($config['curpage']==1)?1:($config['curpage']*$config['per_page'] - ($config['per_page'] - 1)), str_replace('<to>', ($config['curpage']*$config['per_page'] > $config['js_numrows_page'])?$config['js_numrows_page']:$config['curpage']*$config['per_page'], str_replace('<total>', $config['js_numrows_page'], $stringdisplay)));?></i></li>
                        </ul>
                        <p class="linespace">&nbsp;</p>
                    </div>
                    <?php
					if(!$qry)
						exit($errordata);
					elseif(mysql_num_rows($qry)>0){
						?>
                        <div style="margin-right:20px; margin-top:10px;">
                        <?php
						if(isset($error) && !empty($error))
							echo '<br /><font color="#FF0000"><small><i>'.$error.'</i></small></font>';
						if(isset($_SESSION['succ']) && !empty($_SESSION['succ'])){
							echo '<br /><font color="#009933"><small><i>'.$_SESSION['succ'].'</i></small></font>';
							unset($_SESSION['succ']);
							}
						?>
                        <table width="100%" border="0" cellpadding="0" cellspacing="0">
                        	<tr bgcolor="#f2f2f2">
                            	<td width="5%" align="center" style="padding:5px 0px; border-left:1px solid #c3ccdf; border-top:1px solid #c3ccdf; border-bottom:1px solid #c3ccdf"><b>No.</b></td>
                                <td width="16%" align="center" style="padding:5px 0px; border-left:1px solid #c3ccdf; border-top:1px solid #c3ccdf; border-bottom:1px solid #c3ccdf"><b>Card image</b></td>
                                <td width="22%" align="center" style="padding:5px 0px; border-left:1px solid #c3ccdf; border-top:1px solid #c3ccdf; border-bottom:1px solid #c3ccdf"><b>Subject</b></td>
                                <td width="22%" align="center" style="padding:5px 0px; border-left:1px solid #c3ccdf; border-top:1px solid #c3ccdf; border-bottom:1px solid #c3ccdf"><b>Sender</b></td>
                                <td width="21%" align="center" style="padding:5px 0px; border-left:1px solid #c3ccdf; border-top:1px solid #c3ccdf; border-bottom:1px solid #c3ccdf"><b>Sent Date</b></td>
                                <td colspan="2" align="center" width="14%" style="padding:5px 0px; border:1px solid #c3ccdf"><b>Actions</b></td>
                            </tr>
                            <?php
							$i=1;
							while($row=mysql_fetch_array($qry)){
								?>
                                <tr>
                                    <td width="5%" align="center" style="padding:3px 0px; border-left:1px solid #c3ccdf; border-bottom:1px solid #c3ccdf"><?php echo $i;?></td>
                                    <td width="16%" align="center" style="padding:3px 0px; border-left:1px solid #c3ccdf; border-bottom:1px solid #c3ccdf">
                                    	<img src="<?php echo $base_url;?>ecards/<?php echo $row['CardName'];?>" border="0" style="width:95px; height:120px;"/>
                                    </td>
                                    <td width="22%" align="left" style="padding:3px 3px; border-left:1px solid #c3ccdf; border-bottom:1px solid #c3ccdf"><a href="viewcard.php?id=<?php echo $row['Id'];?>"><?php echo $row['Subjects'];?></a></td>
                                    <td width="22%" align="left" style="padding:3px 3px; border-left:1px solid #c3ccdf; border-bottom:1px solid #c3ccdf"><a href="<?php echo $base_url;?>viewprofile.php?id=<?php echo $row['SenderId'];?>"><?php echo $row['ProfileName'];?></a></td>
                                    <td width="21%" align="center" style="padding:3px 0px; border-left:1px solid #c3ccdf; border-bottom:1px solid #c3ccdf"><?php echo $row['SentDate'];?></td>
                                    <td width="7%" align="center" style="padding:3px 0px; border-left:1px solid #c3ccdf; border-bottom:1px solid #c3ccdf"><a href="viewcard.php?id=<?php echo $row['Id'];?>"><i>View</i></a></td>
                                    <td align="center" width="7%" style="padding:3px 0px; border-left:1px solid #c3ccdf; border-bottom:1px solid #c3ccdf; border-right:1px solid #c3ccdf"><a href="?id=<?php echo $row['Id'];?>&a=del"><i>Del</i></a></td>
                                </tr>
                                <?php
								$i++;
								}
							?>
                        </table>
                        </div>
                        <?php
						}
					else echo '<p>There are no record</p>';
					?>
                    <p id="paging"><?php echo $paging;?></p>
                </div>
                <p class="linespace"><br />&nbsp;</p>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
$_SESSION['process'] = true;
require_once '../includes/footer.php';
?>