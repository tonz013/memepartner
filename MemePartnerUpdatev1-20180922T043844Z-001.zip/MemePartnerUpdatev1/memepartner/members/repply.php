<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	if(!empty($_SERVER['QUERY_STRING']))
		$_SESSION['direct'] = $base_url.'members/compose.php?'.$_SERVER['QUERY_STRING'];
	else $_SESSION['direct'] = $base_url.'members/compose.php';
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smsendmail'])){
	if(empty($_POST['touser']))
		$err_t = $sendtonull;
	elseif(empty($_POST['subject']))
		$err_s = $subjectnull;
	elseif(strlen($_POST['subject'])<6)
		$err_s = $datashort;
	elseif(empty($_POST['contentmail']))
		$err_c = $contentnull;
	elseif(strlen($_POST['contentmail'])<6)
		$err_c = $datashort;
	else{
		$array = array(mysql_real_escape_string($_POST['subject']), mysql_real_escape_string($_POST['contentmail']), $_SESSION['memberid']);
		if(strpos($_POST['touser'], ',')!==false){
			$temp = explode(',', trim($_POST['touser']));
			$idtemp = array();
			for($i=0; $i<count($temp); $i++){
				if(!empty($temp[$i])){
					$rstemp = getIdFromProfileName(trim($temp[$i]));
					if($rstemp<=0){
						$error = $onceofnotexists.'<br>'.$temp[$i];
						break;
						}
					else array_push($idtemp, $rstemp);
					}
				}
			if(empty($error) && count($idtemp)>0){
				foreach($idtemp as $val){
					if(!membersSendMail($array, $val)){
						$error = $notsendall;
						break;
						}
					}
				$_SESSION['succ'] = $sendallsucc.' <b>'.$_POST['touser'].'</b>';
				mysql_close();
				header('Location: '.$base_url.'members/mail.php');
				exit();
				}
			}
		else{
			$rstemp = getIdFromProfileName(mysql_real_escape_string(trim($_POST['touser'])));
			if($rstemp>0){
				if(!membersSendMail($array, $rstemp))
					$error = $errordata;
				else{ $_SESSION['succ'] = $sendallsucc.' <b>'.$_POST['touser'].'</b>';
					mysql_close();
					header('Location: '.$base_url.'members/mail.php');
					exit();
					}
				}
			else $error = $notexists;
			}
		}
	}
$title = $newmess;
require_once '../includes/header.php';
$ismenu = 4;
require_once '../includes/menus.php';
?>
<link rel="stylesheet" href="<?php echo $base_url;?>css/jquery.wysiwyg.css" type="text/css" />
<script language="javascript" type="text/javascript" src="<?php echo $base_url;?>jss/jquery.wysiwyg.js"></script>
<script language="javascript">
$(function()
  {
      $('#contentmail').wysiwyg();
  });
</script>
       <div class="maincontent"><br />
       		<form action="" method="post">
       		<div id="browsemail">
                <div class="titletop">
                	<div class="lefttitletop">
                    	<h3><?php echo $mail;?></h3>
                    </div>
                    <div class="righttitletop">
                    	<ul>
                        	<li><input type="submit" value="<?php echo $send;?>" name="smsendmail" /></li>
                            <li><input type="button" value="<?php echo $discard;?>" onclick="window.location.href='mail.php'"/></li>
                        </ul>
                    </div>
                    <p class="linespace">&nbsp;</p>
                </div>
                <?php
				$mailmn = 1;
				require_once "../includes/emailleft.php";
				?>
                <div class="mailright">
                <?php
				if(isset($error) && !empty($error))
					echo '<p style="margin:0px; padding:5px 0px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
				if(isset($succ) && !empty($succ))
					echo '<p style="margin:0px; padding:5px 0px"><font color="#009933"><i>'.$succ.'</i></font></p>';
				?>
                	<table width="100%" cellpadding="3" cellspacing="3">
                    	<tr>
                        	<td width="10%" align="left" class="compmail" valign="top"><?php echo $sendto;?></td>
                            <td width="90%" align="left" class="compmail"><input type="text" value="<?php echo (intval($_GET['pr'])>0)?GetProfileName(intval($_GET['pr'])):$_POST['touser'];?>" name="touser"/>
                            <br /><i><?php echo $notesendto;?></i>
                            <?php
							if(isset($err_t) && !empty($err_t))
								echo '<br><small><font color="#FF0000"><i>'.$err_t.'</i></font></small>';
							?>
                            </td>
                        </tr>
                        <tr>
                        	<td width="10%" align="left" class="compmail" ><?php echo $subject;?></td>
                            <td width="90%" align="left" class="compmail"><input type="text" name="subject" value="<?php echo (isset($_POST['subject']))?$_POST['subject']:'';?>" maxlength="255"/>
                            <?php
							if(isset($err_s) && !empty($err_s))
								echo '<br><small><font color="#FF0000"><i>'.$err_s.'</i></font></small>';
							?>
                            </td>
                        </tr>
                        <tr>
                        	<td width="10%" align="left" class="compmail" >&nbsp;</td>
                            <td width="90%" align="left" class="compmail">
                            	<textarea id="contentmail" name="contentmail" rows="24" ><?php echo (isset($_POST['contentmail']))?$_POST['contentmail']:'';?></textarea>
                            <?php
							if(isset($err_c) && !empty($err_c))
								echo '<small><font color="#FF0000"><i>'.$err_c.'</i></font></small>';
							?>
                            </td>
                        </tr>
                    </table>
                </div>
                <p class="linespace"><br />&nbsp;</p><br />&nbsp;
            </div>
            <p class="linespace">&nbsp;</p></form>
       </div>
<?php
mysql_close();
require_once '../includes/footer.php';
?>