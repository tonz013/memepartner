<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
$info = myprofile($_SESSION['memberid']);
$title = $myprofile.' - '.stripslashes($info['ProfileName']);
require_once '../includes/header.php';
$ismenu = 2;
require_once '../includes/menus.php';
?>
       <div class="maincontent"><br />
       		<div id="acounts">
                <?php
				echo '<h3>'.$settingaccount.'</h3>';
				$ltmn = 1;
				require_once '../includes/accountmenuleft.php';
				?>
                <div class="displayright">
                	<div class="headtop">
                    	<ul>
                        	<li class="contleft"><?php echo $myprofile;?></li>
                        </ul>
                        <p class="linespace">&nbsp;</p>
                    </div>
                        <form action="" method="post">
                        <?php
						echo ($info['ProfileStatusID']==1)?'<p><font color="#009933">'.$aproved.'</font></p>':'<p><font color="#009933">'.$info['LProfileStatus'].'</font></p>';
						?>
                        <ul style="margin:0px; padding:0px;">
                        	<li style="list-style-type:none; float:left; width:300px; height:400px;">
                            	<?php
								if($info['PrimaryPhotoID']==0 || !file_exists('../fuploads/'.$info['UserID'].'u'.$info['PrimaryPhotoID'].'.'.$info['PhotoExtension']) || empty($info['PhotoExtension']))
									echo '<img src="../imgs/noimage.jpg" border="0" style="width:300px; height:400px;"/>';
								else echo '<img src="'.$base_url.'fuploads/'.$info['UserID'].'u'.$info['PrimaryPhotoID'].'.'.$info['PhotoExtension'].'" border="0" id="prphoto" style="width:300px; height:400px;"/>';
								$paddress = '';
								if(!empty($info['City']))
									$paddress .= $info['City'].', ';
								if(!empty($info['State']))
									$paddress .= $info['State'].', ';
								if(!empty($person['Country']))
									$paddress .= $info['Country'];
								$hchild = ($info['HaveChildren']==3)?$not:$yes;
								$wchild = ($info['WantChildren']==3)?$notwant:$want;
								$pheight = '';
								if($info['MatchHeightIDFrom']==0 && $info['MatchHeightIDTo']==0)
									$pheight = $any;
								elseif($info['MatchHeightIDFrom']>0 && $info['MatchHeightIDTo']>0 && $info['MatchHeightIDFrom']<$info['MatchHeightIDTo'])
									$pheight = $from.' '.$info['MFHeightDescription'].' '.$to.' '.$info['MTHeightDescription'];
								$wfind = empty($info['MLGender'])?$selectall:$info['MLGender'];
								?>
                            </li>
                            <li style="float:left; margin-left:10px; list-style-type:none; width:360px">
                            	<p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$profilename.':</b> '.stripslashes($info['ProfileName']).' ( '.$info['Age'].' '.$exage.' )';?></p>
                            	<p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$aboutme.':</b> '.stripslashes($info['AboutMe']);?></p>
                                <p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$interest.':</b> '.stripslashes($info['Interests']);?></p>
                                <p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$gender.':</b> '.stripslashes($info['LGender']);?></p>
                                <p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$address.':</b> '.$paddress;?></p>
                                <p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$educate.':</b> '.stripslashes($info['LEducation']);?></p>
                                <p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$opcupation.':</b> '.stripslashes($info['Occupation']);?></p>
                                <p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$shortmarital.':</b> '.stripslashes($info['LMaritalStatus']);?></p>
                                <p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$height.':</b> '.stripslashes($info['HeightDescription']);?></p>
                                <p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$haircolor.':</b> '.stripslashes($info['LHairColor']);?></p>
                                <p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$eyeColor.':</b> '.stripslashes($info['LEyeColor']);?></p>
                                <p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$bodytype.':</b> '.stripslashes($info['LBodyType']);?></p>
                                <p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$religion.':</b> '.stripslashes($info['LReligion']);?></p>
                                <p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$smoking.':</b> '.stripslashes($info['LSmoking']);?></p>
                                <p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$drinking.':</b> '.stripslashes($info['LDrinking']);?></p>
                                <p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$havechild.':</b> '.$hchild;?></p>
                                <p style="text-indent:20px; margin:0px; padding:0px;"><?php echo '<b>'.$wantchild.':</b> '.$wchild;?></p>
                            </li>
                        </ul><p style="clear:both; margin:0px; padding:0px">&nbsp;</p>
                        <h3><?php echo $yourmatch;?></h3>
                        <table width="100%" border="0">
                        	<tr>
                            	<td colspan="2"><?php echo '<p>'.stripslashes($info['AboutMyMatch']).'</p>';?></td>
                            </tr>
                            <tr>
                            	<td width="50%"><?php echo '<b>'.$wantfind.':</b> '.$wfind.', '.$from.' '.$info['MatchAgeFrom'].' '.$to.' '.$info['MatchAgeTO'];?></td>
                                <td width="50%"><?php echo '<b>'.$purposeto.':</b> '.$info['LDatingInterest'];?></td>
                            </tr>
                            <tr>
                            	<td width="50%"><?php echo empty($info['MLEducation'])?'<b>'.$educate.':</b> '.$any:'<b>'.$educate.':</b> '.$info['MLEducation'];?></td>
                                <td width="50%"><?php echo empty($info['MLMaritalStatus'])?'<b>'.$shortmarital.':</b> '.$any:'<b>'.$shortmarital.':</b> '.$info['MLMaritalStatus'];?></td>
                            </tr>
                            <tr>
                            	<td width="50%"><?php echo '<b>'.$height.':</b> '.$pheight;?></td>
                                <td width="50%"><?php echo empty($info['MLBodyType'])?'<b>'.$bodytype.':</b> '.$any:'<b>'.$bodytype.':</b> '.$info['MLBodyType'];?></td>
                            </tr>
                            <tr>
                            	<td width="50%"><?php echo empty($info['MLReligion'])?'<b>'.$religion.':</b> '.$any:'<b>'.$religion.':</b> '.$info['MLReligion'];?></td>
                                <td width="50%"><?php echo empty($info['MLSmoking'])?'<b>'.$smoking.':</b> '.$any:'<b>'.$smoking.':</b> '.$info['MLSmoking'];?></td>
                            </tr>
                            <tr>
                            	<td width="50%"><?php echo empty($info['MLDrinking'])?'<b>'.$drinking.':</b> '.$any:'<b>'.$drinking.':</b> '.$info['MLDrinking'];?></td>
                                <td width="50%">&nbsp;</td>
                            </tr>
                        </table>
                        </form>
                    <p class="linespace">&nbsp;</p><br />&nbsp;
                </div>
                <p class="linespace"><br />&nbsp;</p>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
require_once '../includes/footer.php';
?>