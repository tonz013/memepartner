<?php
require_once "../includes/config.php";
//check if account is signed-in
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
$title = $myaccount.' - '.GetProfileName($_SESSION['memberid']);
$match = getInfoMatch($_SESSION['memberid']);
$strsql = '';
if($match['MatchAgeTO']>$match['MatchAgeFrom'])
	$strsql .= 'Age >= '.$match['MatchAgeFrom'].' and Age <= '.$match['MatchAgeTO'].' and ';
else $strsql .= 'Age >= '.$match['MatchAgeFrom'].' and ';
if($match['MatchGenderID']>0)
	$strsql .= 'u.GenderID = '.$match['MatchGenderID'].' and ';
if($match['MatchHeightIDTo']>0 && $match['MatchHeightIDFrom']>0){
	if($match['MatchHeightIDTo']>$match['MatchHeightIDFrom'])
		$strsql .= '(HeightID >= '.$match['MatchHeightIDFrom'].' and HeightID <= '.$match['MatchHeightIDTo'].') and ';
	else $strsql .= 'HeightID >= '.$match['MatchHeightIDFrom'].' and ';
	}
elseif($match['MatchHeightIDTo']>0 && $match['MatchHeightIDFrom']<=0)
	$strsql .= 'HeightID = '.$match['MatchHeightIDTo'].' and ';
elseif($match['MatchHeightIDFrom']>0 && $match['MatchHeightIDTo']<=0)
	$strsql .= 'HeightID = '.$match['MatchHeightIDFrom'].' and ';
if($match['MatchBodyStyleID']>0)
	$strsql .= 'u.BodyTypeID = '.$match['MatchBodyStyleID'].' and ';
if($match['MatchReligionID']>0)
	$strsql .= 'u.ReligionID = '.$match['MatchReligionID'].' and ';
if($match['MatchEducationID']>0)
	$strsql .= 'u.EducationID = '.$match['MatchEducationID'].' and ';
if($match['MatchSmokingID']>0)
	$strsql .= 'u.SmokingID = '.$match['MatchSmokingID'].' and ';
if($match['MatchDrinkingID']>0)
	$strsql .= 'u.DrinkingID = '.$match['MatchDrinkingID'].' and ';
if($match['MatchMaritalStatusID']>0)
	$strsql .= 'u.MaritalStatusID = '.$match['MatchMaritalStatusID'].' and ';
if($match['DatingInterestID']>0)
	$strsql .= 'u.DatingInterestID = '.$match['DatingInterestID'].' and ';
if($match['MatchBeSameLocation']==1)
	$strsql .= 'u.CountryID = '.$match['CountryID'].' and ';
	
require_once '../includes/header.php';
$ismenu = 2;
require_once '../includes/menus.php';
?>
       <div class="maincontent"><br />
       		<div id="acounts">
                <?php
				echo '<h3>'.$settingaccount.'</h3>';
				$ltmn = 12;
				require_once '../includes/accountmenuleft.php';
				
				$config['showeachside'] = 4;
				$config['per_page'] = 20;
				$config['js_numrows_page'] = countMembsersPhotos($strsql);
				$config['curpage'] = empty($_GET['p'])?1:$_GET['p'];
				$config['rs_start'] = ($config['curpage']*$config['per_page'])-$config['per_page'];
				if($config['js_numrows_page'] < $config['per_page'])
					$config['per_page'] = $config['js_numrows_page'];
				$config['cururl'] = $base_url.'members/myaccount.php';
				$paging = Pagination($config);
				$sql = "select u.UserID, SUBSTRING_INDEX(ProfileName, ' ', 4) as ProfileName, Age, REPLACE(REPLACE(AboutMe, '.', '. '), ',', ', ') as AboutMe, SUBSTRING_INDEX(REPLACE(REPLACE(REPLACE(AboutMe, '-', ' - '), '.', '. '), ',', ', '),' ', 4) as subAboutMe, City, MatchAgeFrom, MatchAgeTO, LastLogon, PrimaryPhotoID, ".$_SESSION['lang']."MaritalStatus as LMaritalStatus, State, Country, ".$_SESSION['lang']."Gender as LGender, PhotoExtension from ".$table_prefix."users as u left join ".$table_prefix."maritalstatus as m on u.MaritalStatusID = m.MaritalStatusID left join ".$table_prefix."states as s on u.StateID = s.StateID left join ".$table_prefix."countries as c on u.CountryID = c.CountryID left join ".$table_prefix."gender as g on u.MatchGenderID = g.GenderID left join ".$table_prefix."photos as p on u.PrimaryPhotoID = p.PhotoID where ".$strsql." u.ProfileStatusID = 1 and u.GenderID IS NOT NULL order by LastLogon desc";
				$sql = $sql." limit ".$config['rs_start'].", ".$config['per_page'];
				//exit($sql);
				$qry = mysql_query($sql);
				?>
                <div class="displayright">
                	<div class="headtop">
                    	<ul>
                        	<li class="contleft"><?php echo $listmatch;?></li>
                            <li class="contright"><i><?php echo str_replace('<from>', ($config['curpage']==1)?1:($config['curpage']*$config['per_page'] - ($config['per_page'] - 1)), str_replace('<to>', ($config['curpage']*$config['per_page'] > $config['js_numrows_page'])?$config['js_numrows_page']:$config['curpage']*$config['per_page'], str_replace('<total>', $config['js_numrows_page'], $stringdisplay)));?></i></li>
                        </ul>
                        <p class="linespace">&nbsp;</p>
                    </div>
                    <?php
					if(!$qry)
						exit($errordata);
					elseif(mysql_num_rows($qry)>0){
						$i=1;
						while($rows = mysql_fetch_array($qry)){
							$city = '';
							if(!empty($rows['State'])) $city .= $rows['State'].', ';
							$city .= $rows['Country'];
							$aboutme = (strlen($rows['AboutMe'])>22)?$rows['subAboutMe'].' ...':$rows['AboutMe'];
							if(is_int($i/2)){
							?>
                            	<div class="memright mem20right">
                                <p class="tbltop"><b><a href="<?php echo $base_url;?>viewprofile.php?id=<?php echo $rows['UserID'];?>"><?php echo $rows['ProfileName'].' ('.$rows['Age'].') / '.$rows['LMaritalStatus'];?></a></b></p>
                                    <table width="100%" cellpadding="3" cellspacing="3">
                                        <tr>
                                            <td width="35%" valign="top"><a href="<?php echo $base_url;?>viewprofile.php?id=<?php echo $rows['UserID'];?>">
                                            <?php
											if($rows['PrimaryPhotoID']==0 || empty($rows['PhotoExtension']))
												echo '<img src="../imgs/noimage.jpg" border="0" style="width:115px; height:135px"/>';
											else echo '<img src="../fuploads/'.$rows['UserID'].'u'.$rows['PrimaryPhotoID'].'.'.$rows['PhotoExtension'].'" border="0" style="width:115px; height:135px"/>';
											?>
                                            </a></td>
                                            <td width="65%" valign="top" align="left">
                                                <p class="desc"><?php echo str_replace(',', ', ', $aboutme);?></p>
                                                <p style="padding-top:15px;"><?php echo $city;?></p>
                                                <p><b><?php echo $wantfind;?>:</b> <?php echo $rows['LGender'].' '.$rows['MatchAgeFrom'].' - '.$rows['MatchAgeTO'];?></p><p><small><i><b><?php echo $signin;?>:</b> <?php echo date('h:i:s d-m-Y', strtotime($rows['LastLogon']));?></i></small></p><br />
                                        <p><input type="button" value="Email" class="massbutton" onclick="redirect('<?php echo $base_url.'members/compose.php?pr='.$rows['UserID'];?>', 0)"/>&nbsp;<input type="button" value="<?php echo $signal;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'alerts.php?ty=2&pr='.$rows['UserID'];?>', 0)"/>&nbsp;<input type="button" value="<?php echo $saveit;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'alerts.php?ty=3&pr='.$rows['UserID'];?>', 0)"/></p>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            <?php
								}
							else{
								?>
                                <div class="memleft">
                                    <p class="tbltop"><b><a href="<?php echo $base_url;?>viewprofile.php?id=<?php echo $rows['UserID'];?>"><?php echo $rows['ProfileName'].' ('.$rows['Age'].') / '.$rows['LMaritalStatus'];?></a></b></p>
                                    <table width="100%" cellpadding="3" cellspacing="3">
                                        <tr>
                                            <td width="35%" valign="top"><a href="<?php echo $base_url;?>viewprofile.php?id=<?php echo $rows['UserID'];?>">
                                            <?php
											if($rows['PrimaryPhotoID']==0 || empty($rows['PhotoExtension']))
												echo '<img src="../imgs/noimage.jpg" border="0" style="width:115px; height:135px"/>';
											else echo '<img src="../fuploads/'.$rows['UserID'].'u'.$rows['PrimaryPhotoID'].'.'.$rows['PhotoExtension'].'" border="0" style="width:115px; height:135px"/>';
											?>
                                            </a></td>
                                            <td width="65%" valign="top" align="left">
                                                <p class="desc"><?php echo str_replace(',', ', ', str_replace('.', '. ', $aboutme));?></p>
                                                <p style="padding-top:15px;"><?php echo $city;?></p>
                                                <p><b><?php echo $wantfind;?>:</b> <?php echo $rows['LGender'].' '.$rows['MatchAgeFrom'].' - '.$rows['MatchAgeTO'];?></p><p><small><i><b><?php echo $signin;?>:</b> <?php echo date('h:i:s d-m-Y', strtotime($rows['LastLogon']));?></i></small></p><br />
                                        <p><input type="button" value="Email" class="massbutton" onclick="redirect('<?php echo $base_url.'members/compose.php?pr='.$rows['UserID'];?>', 0)"/>&nbsp;<input type="button" value="<?php echo $signal;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'alerts.php?ty=2&pr='.$rows['UserID'];?>', 0)"/>&nbsp;<input type="button" value="<?php echo $saveit;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'alerts.php?ty=3&pr='.$rows['UserID'];?>', 0)"/></p>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                                <?php
								}
							$i++;
							}
						}
					else echo '<p>'.$norecord.' !!</p>';
					?>
                    <p id="paging"><?php echo $paging;?></p>
                </div>
                <p class="linespace"><br />&nbsp;</p>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
require_once '../includes/footer.php';
?>