<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smchangepass'])){
	if(empty($_POST['curpass']))
		$err_cp = $curpassnull;
	elseif(strlen($_POST['curpass'])<6)
		$err_cp = $datashort;
	elseif(empty($_POST['password']))
		$err_p = $passnull;
	elseif(strlen($_POST['password'])<6)
		$err_p = $datashort;
	elseif($_POST['password'] != $_POST['repassword'])
		$err_rp = $passnomatch;
	else{
		$data = array(mysql_real_escape_string($_POST['curpass']), mysql_real_escape_string($_POST['password']), $_SESSION['memberid']);
		$result = ChangePassword($data);
		if($result==0)
			$err_cp = $curpassinvalid;
		elseif($result==-1)
			$error = $mailpassnotmatch;
		else{
			$succ = $changepasssucc;
			}
		}
	}
$title = GetProfileName($_SESSION['memberid']).' - '.$changepass;
require_once '../includes/header.php';
$ismenu = 2;
require_once '../includes/menus.php';
?>
       <div class="maincontent"><br />
       		<div id="acounts">
                <?php
				echo '<h3>'.$settingaccount.'</h3>';
				$ltmn = 4;
				require_once '../includes/accountmenuleft.php';
				?>
                <div class="displayright">
                	<div class="headtop">
                    	<ul>
                        	<li class="contleft"><?php echo $changepass;?></li>
                        </ul>
                        <p class="linespace">&nbsp;</p>
                    </div>
                    <div class="signup">
            	<form action="" method="post">
                <?php
				if(isset($error) && !empty($error))
					echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
				if(isset($succ) && !empty($succ))
							echo '<p style="margin:0px; padding:5px 20px"><font color="#009933"><i>'.$succ.'</i></font></p>';
				?>
                <br />
                <table width="100%" cellpadding="3" cellspacing="3">
                	<tr>
                    	<td width="35%" align="right" valign="top"><b>Email:</b> </td>
                        <td width="65%" align="left"><b><?php echo $_SESSION['memberemail'];?></b></td>
                    </tr>
                	<tr>
                    	<td width="35%" align="right" valign="top"><?php echo $curpass.': ';?></td>
                        <td width="65%" align="left"><input type="password" style="width:265px;" name="curpass" value="<?php echo isset($_POST['curpass'])?$_POST['curpass']:'';?>"/><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_cp) && !empty($err_cp))
							echo '<br><font color="#FF0000"><small><i>'.$err_cp.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="35%" align="right" valign="top"><?php echo $newpass.': ';?></td>
                        <td width="65%" align="left"><input type="password" style="width:265px;" name="password" /><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_p) && !empty($err_p))
							echo '<br><font color="#FF0000"><small><i>'.$err_p.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="35%" align="right" valign="top"><?php echo $renewpass.': ';?></td>
                        <td width="65%" align="left"><input type="password" style="width:265px;" name="repassword" /><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_rp) && !empty($err_rp))
							echo '<br><font color="#FF0000"><small><i>'.$err_rp.'</i></small></font>';
						?>
                        </td>
                    </tr>
                </table><br />
                <div class="stylebott" align="center">
                    	<p style="margin:0px; padding:7px 0px;"><input type="submit" value="<?php echo $save;?>" class="massbutton" name="smchangepass"/>&nbsp;<input type="reset" value="<?php echo $cancel;?>" class="massbutton"/></p>
                </div>
                </form>
            </div>
                    <p class="linespace">&nbsp;</p><br />&nbsp;
                </div>
                <p class="linespace"><br />&nbsp;</p>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
require_once '../includes/footer.php';
?>