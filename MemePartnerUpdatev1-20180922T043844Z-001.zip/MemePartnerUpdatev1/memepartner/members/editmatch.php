<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smupdatematch'])){
	if(empty($_POST['abouth']))
		$err_h = $aboutherorhis;
	elseif(strlen($_POST['abouth'])<6)
		$err_h = $datashort;
	else{
		$match = ($_POST['matchsame']=='on')?1:0;
		$data = array($_POST['rdgender'], $_POST['slagefrom'], $_POST['slageto'], $_POST['slDatingInterest'], mysql_real_escape_string($_POST['abouth']), $_POST['slMarital'], $_POST['slReligion'], $_POST['slEducation'], $_POST['slBodyType'], $_POST['slHeightfrom'], $_POST['slHeightto'], $_POST['slSmoking'], $_POST['slDrinking'], $match);
		if(!yourmatch($data, $_SESSION['memberid']))
			$error = $errordata;
		else $succ = $updateprofile;
		}
	}
$match = getPersonalMatch($_SESSION['memberid']);
$title = GetProfileName($_SESSION['memberid']).' - '.$yourmatch;
require_once '../includes/header.php';
$ismenu = 2;
require_once '../includes/menus.php';
?>
       <div class="maincontent"><br />
       		<div id="acounts">
                <?php
				echo '<h3>'.$settingaccount.'</h3>';
				$ltmn = 3;
				require_once '../includes/accountmenuleft.php';
				?>
                <div class="displayright">
                	<div class="headtop">
                    	<ul>
                        	<li class="contleft"><?php echo $upmatch;?></li>
                        </ul>
                        <p class="linespace">&nbsp;</p>
                    </div>
                        <form action="" method="post">
                        <?php
                        if(isset($error) && !empty($error))
                            echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
						if(isset($succ) && !empty($succ))
							echo '<p style="margin:0px; padding:5px 20px"><font color="#009933"><i>'.$succ.'</i></font></p>';
                        ?>
                        <br />
                        <table width="100%" cellpadding="3" cellspacing="3">
                            <tr>
                                <td width="30%" align="right" valign="top"><?php echo $youfind;?>: </td>
                                <td width="70%" align="left">
                                <?php
								if(isset($_POST['rdgender'])){
									if($_POST['rdgender']==1){
										 $gen1 = ' checked="checked"';
                                    	 $gen2 = '';
                                     	$gen3 = '';
										}
									if($_POST['rdgender']==2){
										$gen1 = '';
                                     	$gen2 = ' checked="checked"';
                                     	$gen3 = '';
										}
									if($_POST['rdgender']==0){
										$gen1 = '';
                                     	$gen2 = '';
                                     	$gen3 = ' checked="checked"';
										}
									}
                                 else{
									 if(intval($match['MatchGenderID'])==1){
										 $gen1 = ' checked="checked"';
										 $gen2 = '';
										 $gen3 = '';
										 }
									 elseif($_POST['rdgender']==2 || intval($match['MatchGenderID'])==2){
										 $gen1 = '';
										 $gen2 = ' checked="checked"';
										 $gen3 = '';
										 }
									 elseif($_POST['rdgender']==0 || intval($match['MatchGenderID'])==0){
										 $gen1 = '';
										 $gen2 = '';
										 $gen3 = ' checked="checked"';
										 }
									}
                                ?>
                                <input type="radio" value="1" style="margin-left:0px; padding-left:0px;" <?php echo $gen1;?> name="rdgender"/>&nbsp;<?php echo $male;?><input type="radio" value="2" style="margin-left:40px; padding-left:0px;" name="rdgender" <?php echo $gen2;?>/>&nbsp;<?php echo $female;?><input type="radio" value="0" style="margin-left:40px; padding-left:0px;" name="rdgender" <?php echo $gen3;?>/>&nbsp;<?php echo $selectall;?>
                                </td>
                            </tr>
                            <tr>
                                <td width="30%" align="right" valign="top"><?php echo $age;?>: </td>
                                <td width="70%" align="left">
                                <select name="slagefrom">
                                    <?php
                                    for($i=18; $i<76; $i++){
                                        $val = isset($_POST['slagefrom'])?$_POST['slagefrom']:$match['MatchAgeFrom'];
                                        $sel = ($val==$i)?' selected="selected"':'';
                                        echo '<option value="'.$i.'" '.$sel.'>'.$i.'</option>';
                                        }
                                    ?>
                                </select><span style="margin-left:10px; margin-right:10px;"><?php echo $to;?></span><select name="slageto">
                                    <?php
                                    for($i=18; $i<76; $i++){
                                        $val = isset($_POST['slageto'])?$_POST['slageto']:$match['MatchAgeTO'];
                                        $sel = ($val==$i)?' selected="selected"':'';
                                        echo '<option value="'.$i.'" '.$sel.'>'.$i.'</option>';
                                        }
                                    ?>
                                </select>
                                </td>
                            </tr>
                            <tr>
                                <td width="30%" align="right" valign="top"><?php echo $purposeto;?>: </td>
                                <td width="70%" align="left">
                                <select name="slDatingInterest">
                                    <?php
                                    $sel = isset($_POST['slDatingInterest'])?$_POST['slDatingInterest']:$match['DatingInterestID'];
                                    $sql = 'select DatingInterestID as Id, '.$_SESSION['lang'].'DatingInterest as LName from '.$table_prefix.'datinginterest order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
                                    ?>
                                </select>
                                </td>
                            </tr>
                            <tr>
                                <td width="30%" align="right"><?php echo $aboutthem;?>: </td>
                                <td width="70%" align="left">
                                <textarea rows="3" cols="40" name="abouth"><?php echo isset($_POST['abouth'])?$_POST['abouth']:stripslashes($match['AboutMyMatch']);?></textarea>
                                <font color="#FF0000"> *</font>
                                <?php
                                if(isset($err_h) && !empty($err_h))
                                    echo '<br><font color="#FF0000"><small><i>'.$err_h.'</i></small></font>';
                                ?>
                                </td>
                            </tr>
                            <tr>
                                <td width="30%" align="right" valign="top"><?php echo $marital;?>: </td>
                                <td width="70%" align="left">
                                <select name="slMarital"><option value="0">- - <?php echo $selectall;?> - -</option>
                                    <?php
                                    $sel = isset($_POST['slMarital'])?$_POST['slMarital']:$match['MatchMaritalStatusID'];
                                    $sql = 'select MaritalStatusID as Id, '.$_SESSION['lang'].'MaritalStatus as LName from '.$table_prefix.'maritalstatus order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
                                    ?>
                                </select>
                                </td>
                            </tr>
                            <tr>
                                <td width="30%" align="right" valign="top"><?php echo $religion;?>: </td>
                                <td width="70%" align="left">
                                <select name="slReligion"><option value="0">- - <?php echo $selectall;?> - -</option>
                                    <?php
                                    $sel = isset($_POST['slReligion'])?$_POST['slReligion']:$match['MatchReligionID'];
                                    $sql = 'select ReligionID as Id, '.$_SESSION['lang'].'Religion as LName from '.$table_prefix.'religions order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
                                    ?>
                                </select>
                                </td>
                            </tr>
                            <tr>
                                <td width="30%" align="right" valign="top"><?php echo $education;?>: </td>
                                <td width="70%" align="left">
                                <select name="slEducation"><option value="0">- - <?php echo $selectall;?> - -</option>
                                    <?php
                                    $sel = isset($_POST['slEducation'])?$_POST['slEducation']:$match['MatchEducationID'];
                                    $sql = 'select EducationID as Id, '.$_SESSION['lang'].'Education as LName from '.$table_prefix.'educations order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
                                    ?>
                                </select>
                                </td>
                            </tr>
                            <tr>
                                <td width="30%" align="right" valign="top"><?php echo $bodytype;?>: </td>
                                <td width="70%" align="left">
                                <select name="slBodyType"><option value="0">- - <?php echo $selectall;?> - -</option>
                                    <?php
                                    $sel = isset($_POST['slBodyType'])?$_POST['slBodyType']:$match['MatchBodyStyleID'];
                                    $sql = 'select BodyTypeID as Id, '.$_SESSION['lang'].'BodyType as LName from '.$table_prefix.'bodytypes order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
                                    ?>
                                </select>
                                </td>
                            </tr>
                            <tr>
                                <td width="30%" align="right" valign="top"><?php echo $height;?>: </td>
                                <td width="70%" align="left">
                                <select name="slHeightfrom">
                                    <?php
                                    $sel = isset($_POST['slHeightfrom'])?$_POST['slHeightfrom']:$match['MatchHeightIDFrom'];
                                    $sql = 'select HeightID as Id, HeightDescription as LName from '.$table_prefix.'height order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
                                    ?>
                                </select><span style="margin-left:10px; margin-right:10px;"><?php echo $to;?></span>
                                <select name="slHeightto">
                                    <?php
                                    $sel = isset($_POST['slHeightto'])?$_POST['slHeightto']:$match['MatchHeightIDTo'];
                                    $sql = 'select HeightID as Id, HeightDescription as LName from '.$table_prefix.'height order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
                                    ?>
                                </select>
                                </td>
                            </tr>
                            <tr>
                                <td width="30%" align="right" valign="top"><?php echo $smoking;?>: </td>
                                <td width="70%" align="left">
                                <select name="slSmoking"><option value="0">- - <?php echo $selectall;?> - -</option>
                                    <?php
                                    $sel = isset($_POST['slSmoking'])?$_POST['slSmoking']:$match['MatchSmokingID'];
                                    $sql = 'select SmokingID as Id, '.$_SESSION['lang'].'Smoking as LName from '.$table_prefix.'smoking order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
                                    ?>
                                </select>
                                </td>
                            </tr>
                            <tr>
                                <td width="30%" align="right" valign="top"><?php echo $drinking;?>: </td>
                                <td width="70%" align="left">
                                <select name="slDrinking"><option value="0">- - <?php echo $selectall;?> - -</option>
                                    <?php
                                    $sel = isset($_POST['slDrinking'])?$_POST['slDrinking']:$match['MatchDrinkingID'];
                                    $sql = 'select DrinkingID as Id, '.$_SESSION['lang'].'Drinking as LName from '.$table_prefix.'drinking order by TopSorted desc, LName asc';
                                    dropdownlist($sql, $sel);
									$chk = ($match['MatchBeSameLocation']==1)?' checked="checked"':'';
                                    ?>
                                </select>
                                </td>
                            </tr>
                            <tr>
                                <td width="30%" align="right" valign="top">&nbsp;</td>
                                <td width="70%" align="left">
                                <input type="checkbox" style="margin-left:0px; padding-left:0px;" name="matchsame" <?php echo $chk;?>/>&nbsp;<i><?php echo $samelocaotion;?></i>
                                <?php
                                if(isset($err_t) && !empty($err_t))
                                    echo '<br><font color="#FF0000"><small><i>'.$err_t.'</i></small></font>';
                                ?>
                                </td>
                            </tr>
                            <tr>
                                <td width="30%" align="right" valign="top">&nbsp;</td>
                                <td width="70%" align="left"><input type="submit" value="<?php echo $save;?>" class="massbutton" name="smupdatematch"/>&nbsp;<input type="reset" value="<?php echo $cancel;?>" class="massbutton"/>
                                </td>
                            </tr>
                        </table>
                        </form>
                    <p class="linespace">&nbsp;</p><br />&nbsp;
                </div>
                <p class="linespace"><br />&nbsp;</p>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
require_once '../includes/footer.php';
?>