<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smsetpri'])){
	$temp = explode('/', $_POST['primary']);
	$temp = substr($temp[count($temp)-1], 0, -4);
	$temp = explode('u', $temp);
	if(!setPrimaryPhoto($temp))
		$error = $errordata;
	else $succ = $settingsucc;
	}
$title = GetProfileName($_SESSION['memberid']).' - '.$setprofile;
require_once '../includes/header.php';
$ismenu = 2;
require_once '../includes/menus.php';
?>
<script language="javascript">
function viewphoto(strId,strUrl){
	document.getElementById(strId).src = strUrl;
	document.getElementById('primary').value = strUrl;
	}
</script>
<div class="maincontent"><br />
       		<div id="acounts">
                <?php
				echo '<h3>'.$settingaccount.'</h3>';
				$ltmn = 8;
				require_once '../includes/accountmenuleft.php';
				?>
                <div class="displayright">
                	<div class="headtop">
                    	<ul>
                        	<li class="contleft"><?php echo $setprimary;?></li>
                        </ul>
                        <p class="linespace">&nbsp;</p>
                    </div>
                    <?php
                    if(isset($error) && !empty($error))
                        echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
					if(isset($succ) && !empty($succ))
						echo '<p style="margin:0px; padding:5px 20px"><font color="#009933"><i>'.$succ.'</i></font></p>';
					$primaryimg = getPrimaryPhoto($_SESSION['memberid']);
                    ?>
                    <form action="" method="post">
                    	<p align="center">
                        <?php
						if(!empty($primaryimg))
							echo '<img src="'.$base_url.'fuploads/'.$primaryimg.'" border="0" style="width:300px; height:400px;" id="prphoto"/></p>';
						else echo '<img src="'.$base_url.'imgs/noimage.jpg" border="0" style="width:300px; height:400px;" id="prphoto"/><br><i>'.$notprimary.'</i></p>';
						$photos = getUserPhotos($_SESSION['memberid']);
						if(count($photos['id'])>0){
						?>
                        <div class="moreimg">
                            <p>
                            <?php 
                            $i=0;
                            foreach($photos['id'] as $val){
                                echo '<img src="'.$base_url.'fuploads/'.$_SESSION['memberid'].'u'.$val.'.'.$photos['ext'][$i].'" border="0" onclick="viewphoto(\'prphoto\',\''.$base_url.'fuploads/'.$_SESSION['memberid'].'u'.$val.'.'.$photos['ext'][$i].'\')"/>&nbsp;';
                                $i++;
                                }
                            ?>
                            </p>
                        </div><input type="hidden" name="primary" id="primary"/>
                        <p align="center"><input type="submit" value="<?php echo $save;?>" class="massbutton" name="smsetpri"/></p>
                        <?php
							}
						?>
                    </form>
                </div>
                <p class="linespace"><br />&nbsp;</p>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
require_once '../includes/footer.php';
?>