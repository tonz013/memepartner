<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
$title = GetProfileName($_SESSION['memberid']).' - '.$vaforitesyou;	
updFavorites($_SESSION['memberid']);
require_once '../includes/header.php';
$ismenu = 2;
require_once '../includes/menus.php';
?>
       <div class="maincontent"><br />
       		<div id="acounts">
                <?php
				echo '<h3>'.$settingaccount.'</h3>';
				$ltmn = 9;
				require_once '../includes/accountmenuleft.php';
				
				$config['showeachside'] = 4;
				$config['per_page'] = 20;
				$config['js_numrows_page'] = countSignalTo($_SESSION['memberid']);
				$config['curpage'] = empty($_GET['p'])?1:$_GET['p'];
				$config['rs_start'] = ($config['curpage']*$config['per_page'])-$config['per_page'];
				if($config['js_numrows_page'] < $config['per_page'])
					$config['per_page'] = $config['js_numrows_page'];
				$config['cururl'] = $base_url.'members/vaforitesyou.php';
				$paging = Pagination($config);
				
				$sql = "select hl.SenderID as UserID, LOWER(SUBSTRING_INDEX(ProfileName, ' ', 4)) as ProfileName, Age, REPLACE(REPLACE(AboutMe, '.', '. '), ',', ', ') as AboutMe, SUBSTRING_INDEX(REPLACE(REPLACE(AboutMe, '.', '. '), ',', ', '),' ', 4) as subAboutMe, City, MatchAgeFrom, MatchAgeTO, SignalDate as LastLogon, PrimaryPhotoID, ".$_SESSION['lang']."MaritalStatus as LMaritalStatus, State, Country, ".$_SESSION['lang']."Gender as LGender, PhotoExtension from ".$table_prefix."signalme as hl inner join ".$table_prefix."users as u on hl.SenderID = u.UserID left join ".$table_prefix."maritalstatus as m on u.MaritalStatusID = m.MaritalStatusID left join ".$table_prefix."states as s on u.StateID = s.StateID left join ".$table_prefix."countries as c on u.CountryID = c.CountryID left join ".$table_prefix."gender as g on u.MatchGenderID = g.GenderID left join ".$table_prefix."photos as p on u.PrimaryPhotoID = p.PhotoID AND p.IsApproved = 1 where hl.RecieverID = ".$_SESSION['memberid']." order by SignalDate desc";
				$sql = $sql." limit ".$config['rs_start'].", ".$config['per_page'];
				$qry = mysql_query($sql);
				?>
                <div class="displayright">
                	<div class="headtop">
                    	<ul>
                        	<li class="contleft"><?php echo $vaforitesyou;?></li>
                            <li class="contright"><i><?php echo str_replace('<from>', ($config['curpage']==1)?1:($config['curpage']*$config['per_page'] - ($config['per_page'] - 1)), str_replace('<to>', ($config['curpage']*$config['per_page'] > $config['js_numrows_page'])?$config['js_numrows_page']:$config['curpage']*$config['per_page'], str_replace('<total>', $config['js_numrows_page'], $stringdisplay)));?></i></li>
                        </ul>
                        <p class="linespace">&nbsp;</p>
                    </div>
                    <?php
					if(!$qry)
						exit($errordata);
					else{
						$i=1;
						if(mysql_num_rows($qry)>0){
						echo '<p>'.$autodel.'</p>';
						while($rows = mysql_fetch_array($qry)){
							$city = '';
							if(!empty($rows['State'])) $city .= $rows['State'].', ';
							$city .= $rows['Country'];
							$aboutme = (strlen($rows['AboutMe'])>22)?$rows['subAboutMe'].' ...':$rows['AboutMe'];
							if(is_int($i/2)){
							?>
                            	<div class="memright mem20right">
                                <p class="tbltop"><b><a href="<?php echo $base_url;?>viewprofile.php?id=<?php echo $rows['UserID'];?>"><?php echo $rows['ProfileName'].' ('.$rows['Age'].') / '.$rows['LMaritalStatus'];?></a></b></p>
                                    <table width="100%" cellpadding="3" cellspacing="3">
                                        <tr>
                                            <td width="35%" valign="top"><a href="<?php echo $base_url;?>viewprofile.php?id=<?php echo $rows['UserID'];?>">
                                            <?php
											if($rows['PrimaryPhotoID']==0 || empty($rows['PhotoExtension']))
												echo '<img src="../imgs/noimage.jpg" border="0" style="width:115px; height:135px"/>';
											else echo '<img src="../fuploads/'.$rows['UserID'].'u'.$rows['PrimaryPhotoID'].'.'.$rows['PhotoExtension'].'" border="0" style="width:115px; height:135px"/>';
											?>
                                            </a></td>
                                            <td width="65%" valign="top" align="left">
                                                <p class="desc"><?php echo str_replace(',', ', ', $aboutme);?></p>
                                                <p style="padding-top:15px;"><?php echo $city;?></p>
                                                <p><b><?php echo $wantfind;?>:</b> <?php echo $rows['LGender'].' '.$rows['MatchAgeFrom'].' - '.$rows['MatchAgeTO'];?></p><p><small><i><b><?php echo $senddate;?>:</b> <?php echo date('h:i:s d-m-Y', strtotime($rows['LastLogon']));?></i></small></p><br />
                                        <p><input type="button" value="Email" class="massbutton" onclick="redirect('<?php echo $base_url.'members/compose.php?pr='.$rows['UserID'];?>', 0)"/>&nbsp;<input type="button" value="<?php echo $save;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'alerts.php?ty=2&pr='.$rows['UserID'];?>', 0)"/></p>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            <?php
								}
							else{
								?>
                                <div class="memleft">
                                    <p class="tbltop"><b><a href="<?php echo $base_url;?>viewprofile.php?id=<?php echo $rows['UserID'];?>"><?php echo $rows['ProfileName'].' ('.$rows['Age'].') / '.$rows['LMaritalStatus'];?></a></b></p>
                                    <table width="100%" cellpadding="3" cellspacing="3">
                                        <tr>
                                            <td width="35%" valign="top"><a href="<?php echo $base_url;?>viewprofile.php?id=<?php echo $rows['UserID'];?>">
                                            <?php
											if(intval($rows['PrimaryPhotoID'])==0 || empty($rows['PhotoExtension']) )
												echo '<img src="../imgs/noimage.jpg" border="0" style="width:115px; height:135px"/>';
											else echo '<img src="../fuploads/'.$rows['UserID'].'u'.$rows['PrimaryPhotoID'].'.'.$rows['PhotoExtension'].'" border="0" style="width:115px; height:135px"/>';
											?>
                                            </a></td>
                                            <td width="65%" valign="top" align="left">
                                                <p class="desc"><?php echo str_replace(',', ', ', str_replace('.', '. ', $aboutme));?></p>
                                                <p style="padding-top:15px;"><?php echo $city;?></p>
                                                <p><b><?php echo $wantfind;?>:</b> <?php echo $rows['LGender'].' '.$rows['MatchAgeFrom'].' - '.$rows['MatchAgeTO'];?></p><p><small><i><b><?php echo $senddate;?>:</b> <?php echo date('h:i:s d-m-Y', strtotime($rows['LastLogon']));?></i></small></p><br />
                                        <p><input type="button" value="Email" class="massbutton" onclick="redirect('<?php echo $base_url.'members/compose.php?pr='.$rows['UserID'];?>', 0)"/>&nbsp;<input type="button" value="<?php echo $save;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'alerts.php?ty=2&pr='.$rows['UserID'];?>', 0)"/></p>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                                <?php
								}
							$i++;
							}
							}
						else echo '<p>'.str_replace('<linka>', '<a href="editdetails.php">', str_replace('</linka>', '</a>', $notevaforiteyou)).'</p>';
						}
					?>
                    <p id="paging"><?php echo $paging;?></p>
                </div>
                <p class="linespace"><br />&nbsp;</p>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
$_SESSION['process'] = true;
require_once '../includes/footer.php';
?>