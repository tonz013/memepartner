<?php
require_once "../includes/config.php";
require_once "../includes/database.php";
require_once "../includes/functions.php";
if($check){
	$id = explode('_', $order_code);
	$user = substr($id[0], 2);
	$_SESSION['memberid'] = $user;
	$info = getPersonalInfo($_SESSION['memberid']);
	$title = $info['ProfileName'].' - Upgrade your account successfull';
	}
else{
	$title = 'Upgrade failed account';
	}
require_once '../includes/header.php';
$ismenu = 2;
require_once '../includes/menus.php';
	?>
       <div class="maincontent"><br />
       		<div id="searchs">
            	<h3><?php echo $title;?></h3>
                	<div class="dispsearch">
                    <?php
					if(!$check)
						echo '<p>Payment process fails, <a href="membership.php">try again.</a></p>';
					else{
						$data = array($order_code, $payment_type, $payment_id, $id[1], $user);
						if(updorder($data)){
							updMember($_SESSION['memberid']);
							echo '<p>Thank you for supporting</p>';
							?>
                            <table width="100%" cellpadding="3" cellspacing="3" border="0">
                            	<tr>
                                	<td width="25%" align="right">Code bill: </td>
                                    <td align="left"><?php echo $order_code;?></td>
                                </tr>
                                <tr>
                                	<td width="25%" align="right">Trading Code: </td>
                                    <td align="left"><?php echo $payment_id;?></td>
                                </tr>
                                <tr>
                                	<td width="25%" align="right">Value: </td>
                                    <td align="left"><?php echo number_format($price);?> <i>(vnd)</i></td>
                                </tr>
                                <tr>
                                	<td width="25%" align="right">Type of payment: </td>
                                    <td align="left"><?php echo ($payment_type==1)?'Paying soon':'Payment custody';?></td>
                                </tr>
                                <tr>
                                	<td width="25%" align="right">Date of payment: </td>
                                    <td align="left"><?php echo getDateorder($id[1]);?></td>
                                </tr>
                            </table>
                            <?php
							if($payment_type==2){
								echo '<p>As your choice is <b>payment hold</a>, your account will be upgraded after a hold period.</p>';
								echo '<br>If you choose <b>immediate payment</b>, your account will be upgraded immediately.<br>If you choose <b>payment hold</b>, your account will be upgrade after a hold period.</p>';
								}
							}
						else echo 'Could not update invoice status, please contact admin';
						}
					?>
                    </div>
                <p class="linespace"><br />&nbsp;</p><br />&nbsp;
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
require_once '../includes/footer.php';
?>