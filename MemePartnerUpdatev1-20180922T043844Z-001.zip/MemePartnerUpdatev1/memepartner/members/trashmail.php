<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	$_SESSION['direct'] = $base_url.'members/sentmail.php';
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['delmess'])){
	if(count($_POST['messdel'])>0){
		if(!updTrashMessages($_POST['messdel'], $_SESSION['memberid'], 2))
			$error = $errordata;
		else{
			$_SESSION['succ'] = str_replace('<num>', '<b>'.count($_POST['messdel']).'</b>', $numofdel);
			mysql_close();
			header('Location: '.$base_url.'members/trashmail.php');
			exit();
			}
		}
	else $error = $sloneofdel;
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['recoverymess'])){
	if(count($_POST['messdel'])>0){
		if(!recoveryMessages($_POST['messdel'], $_SESSION['memberid']))
			$error = $errordata;
		else{
			mysql_close();
			header('Location: '.$base_url.'members/mail.php');
			exit();
			}
		}
	else $error = $sloneofdel;
	}
$usent = getTrashEmail($_SESSION['memberid'],'');
$config['showeachside'] = 4;
$config['per_page'] = 30;
$config['js_numrows_page'] = mysql_num_rows($usent);
$config['curpage'] = empty($_GET['p'])?1:$_GET['p'];
$config['rs_start'] = ($config['curpage']*$config['per_page'])-$config['per_page'];
if($config['js_numrows_page'] < $config['per_page'])
	$config['per_page'] = $config['js_numrows_page'];
$config['cururl'] = $base_url.'members/sentmail.php';
$paging = Pagination($config);
$limit = " limit ".$config['rs_start'].", ".$config['per_page'];
$usent = getTrashEmail($_SESSION['memberid'],$limit);

$title = $trashmail.' - '.GetProfileName($_SESSION['memberid']);
require_once '../includes/header.php';
$ismenu = 4;
require_once '../includes/menus.php';
?>
<script language="javascript">
function MailchkAll(strChecked, strval){
	if(document.getElementById(strval).value == 0){
		document.getElementById(strChecked).value = '<?php echo $mailselectall;?>';
		document.getElementById(strval).value = 1;
		for(var i=1; i<document.getElementById('hddval').value; i++){
			document.getElementById('chkval'+i).checked = false;
			//document.getElementById('tr'+i).bgColor = '#FFFFFF';
			}
		document.getElementById('recoverymess').style.display = 'none';
		document.getElementById('delmess').style.display = 'none';
		}
	else if(document.getElementById(strval).value == 1){
		document.getElementById(strChecked).value = '<?php echo $unselect;?>';
		document.getElementById(strval).value = 0;
		for(var i=1; i<document.getElementById('hddval').value; i++){
			document.getElementById('chkval'+i).checked = true;
			//document.getElementById('tr'+i).bgColor = '#F2F2F2';
			}
		document.getElementById('recoverymess').style.display = '';
		document.getElementById('delmess').style.display = '';
		}
	}
function sentChk(strchk, strChecked, strtr){
	if(document.getElementById(strchk).checked){
		document.getElementById('delmess').style.display = '';
		document.getElementById(strChecked).value = '<?php echo $unselect;?>';
		//document.getElementById(strtr).bgColor = '#F2F2F2';
		document.getElementById('tempval').value = 0;
		document.getElementById('recoverymess').style.display = '';
		}
	else{
		//document.getElementById(strtr).bgColor = '#FFFFFF';
		document.getElementById('tempval').value = 1;
		document.getElementById('recoverymess').style.display = 'none';
		var temp = 0;
		for(var i=1; i<document.getElementById('hddval').value; i++){
			if(document.getElementById('chkval'+i).checked){
				temp =1;
				break;
				}
			}
		if(temp==0){
			document.getElementById('delmess').style.display = 'none';
			document.getElementById(strChecked).value = '<?php echo $mailselectall;?>';
			}
		}
	}
</script>
       <div class="maincontent"><br />
       <form action="" method="post">
       		<div id="browsemail">
                <div class="titletop">
                	<div class="lefttitletop">
                    	<h3><?php echo $mail;?></h3>
                    </div>
                    <div class="righttitletop">
                    	<ul>
                        	<li><input type="button" value="<?php echo $mailselectall;?>" onclick="MailchkAll('chkAll','tempval')" id="chkAll"/><input type="hidden" id="tempval" value="1" /></li>
                            <li><input type="submit" value="<?php echo $del;?>" id="delmess" style="display:none" name="delmess"/></li>
                            <li><input type="submit" value="<?php echo 'Restore';?>" id="recoverymess" style="display:none" name="recoverymess"/></li>
                            <li style="float:right"><span style="float:right"><i><b><?php echo ($config['curpage']==1)?1:($config['curpage']*$config['per_page'] - ($config['per_page'] - 1));?> - <?php echo ($config['curpage']*$config['per_page'] > $config['js_numrows_page'])?$config['js_numrows_page']:$config['curpage']*$config['per_page'];?></b> <?php echo $inall;?> <b><?php echo $config['js_numrows_page'];?></b>&nbsp;</i></span></li>
                        </ul>
                    </div>
                    <p class="linespace">&nbsp;</p>
                </div>
                <?php
				$mailmn = 4;
				require_once "../includes/emailleft.php";
				?>
                <div class="mailright">
                <?php
				if(isset($error) && !empty($error))
					echo '<p style="margin:0px; padding:5px 0px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
				if(isset($succ) && !empty($succ))
					echo '<p style="margin:0px; padding:5px 0px"><font color="#009933"><i>'.$succ.'</i></font></p>';
				if(isset($_SESSION['succ']) && !empty($_SESSION['succ'])){
					echo '<p style="margin:0px; padding:5px 0px"><font color="#009933"><i>'.$_SESSION['succ'].'</i></font></p>';
					unset($_SESSION['succ']);
					}
				?>
                	<table width="100%" cellpadding="0" cellspacing="0">
                    	<?php
						if($usent!==false && mysql_num_rows($usent) > 0){
							$i=1;
							while($rows = mysql_fetch_array($usent)){
								if(is_null($rows['ReadOn'])){
									$uname = '<b>'.$rows['ProfileName'].'</b>';
									$usub = '<b>'.$rows['Subject'].'</b>';
									$sday = '<b>'.date('d-m-Y', strtotime($rows['SentOn'])).'</b>';
									$clss = '';
									}
								else{
									$uname = $rows['ProfileName'];
									$usub = $rows['Subject'];
									$sday = date('d-m-Y', strtotime($rows['SentOn']));
									$clss = 'class="oldmail"';
									}
								?>
								<tr id="tr<?php echo $i;?>">
									<td width="3%" align="left" <?php echo $clss;?>><input type="checkbox" id="chkval<?php echo $i;?>" value="<?php echo $rows['MessageID'];?>" onclick="sentChk('chkval<?php echo $i;?>', 'chkAll', 'tr<?php echo $i;?>')" name="messdel[]"/></td>
									<td width="23%" align="left" <?php echo $clss;?> onclick="redirect('<?php echo $base_url;?>members/viewmess.php?id=<?php echo $rows['MessageID'];?>&t=t', 0)"><?php echo '<img src="'.$base_url.'imgs/foldertrash.gif" border="0" /> '.$uname;?></td>
									<td width="64%" align="left" <?php echo $clss;?> onclick="redirect('<?php echo $base_url;?>members/viewmess.php?id=<?php echo $rows['MessageID'];?>&t=t', 0)"><?php echo $usub.'<font color="#b0b0b0"> - '.$rows['Message'].'</font> . . .';?></td>
									<td width="10%" align="left" <?php echo $clss;?> onclick="redirect('<?php echo $base_url;?>members/viewmess.php?id=<?php echo $rows['MessageID'];?>&t=t', 0)"><?php echo $sday;?></td>
								</tr>
								<?php
								$i++;
								}
							}
						else echo '<tr><td align="left" colspan="4"><p>'.$notboxtrash.'</p></td></tr>';
						?>
                    </table><input type="hidden" id="hddval" value="<?php echo $i;?>" />
                </div><p id="paging" style="clear:both; margin-right:0px; text-align:center"><?php echo $paging;?></p>
                <p class="linespace"><br />&nbsp;</p><br />&nbsp;
            </div>
            <p class="linespace">&nbsp;</p></form>
       </div>
<?php
mysql_close();
require_once '../includes/footer.php';
?>