<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smdelphoto'])){
	if(count($_POST['imgdel'])>0){
		$photoid = array();
		foreach($_POST['imgdel'] as $name => $pval){
			$pval = substr($pval, 0, -4);
			$temp = explode('u', $pval);
			array_push($photoid, $temp[1]);
			}
		if(!delPhotos($photoid, $_SESSION['memberid']))
			$error = $errordata;
		else{ 
			$succ = str_replace('<num>', count($photoid), $youdel);
			foreach($_POST['imgdel'] as $name => $pval)
				unlink(dirname(dirname(__FILE__)).$uploaddir.'/'.$pval);
			}
		}
	else $error = $sldelimg;
	}
$title = GetProfileName($_SESSION['memberid']).' - '.$setprofile;
require_once '../includes/header.php';
$ismenu = 2;
require_once '../includes/menus.php';
?>
<script language="javascript">
function checkAll(field, master){
	if(document.getElementById(master).checked){
		for (i = 0; i < document.getElementById('hddtotal').value; i++)
			document.getElementById('imgdel'+i).checked = true ;
		}
	else{
		for (i = 0; i < document.getElementById('hddtotal').value; i++)
			document.getElementById('imgdel'+i).checked = false ;
		}
	}
</script>
<div class="maincontent"><br />
       		<div id="acounts">
                <?php
				echo '<h3>'.$settingaccount.'</h3>';
				$ltmn = 7;
				require_once '../includes/accountmenuleft.php';
				$primaryimg = getPrimaryPhoto($_SESSION['memberid']);
				$primaryimg = substr($primaryimg, 0, -4);
				$primaryimg = explode('u', $primaryimg);
				$photos = getAllPhotos($_SESSION['memberid']);
				?>
                <div class="displayright">
                	<div class="headtop">
                    	<ul>
                        	<li class="contleft"><?php echo $notesldel;?></li>
                            <?php
							if(count($photos['id'])>0)
								echo '<li class="contright"><i>'.$delall.'</i> <input type="checkbox" id="chkall" onclick="checkAll(document.myform.imgdel, \'chkall\')"/></li>';
							else echo '<li class="contright">&nbsp;</li>';
							?>
                        </ul>
                        <p class="linespace">&nbsp;</p>
                    </div>
                    <?php
                    if(isset($error) && !empty($error))
                        echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
					if(isset($succ) && !empty($succ))
						echo '<p style="margin:0px; padding:5px 20px"><font color="#009933"><i>'.$succ.'</i></font></p>';
					if(count($photos['id'])>0){
                    ?>
                    <form action="" method="post" name="myform">
                        <div class="moreimg">
                        	<table width="100%" border="0">
                            	<tr>
                                	<?php 
									$i=0;
									foreach($photos['id'] as $val){
										$j=$i+1;
										echo '<td><p style="padding-bottom:0px;">';
										echo '<img src="'.$base_url.'fuploads/'.$_SESSION['memberid'].'u'.$val.'.'.$photos['ext'][$i].'" border="0" onclick="viewphoto(\'prphoto\',\''.$base_url.'fuploads/'.$_SESSION['memberid'].'u'.$val.'.'.$photos['ext'][$i].'\')"/>&nbsp;';
										echo '</p>';
										if($val==$primaryimg[1])
											echo '&nbsp;<i>'.$priphoto.'</i></td>';
										else echo '<input type="checkbox" value="'.$_SESSION['memberid'].'u'.$val.'.'.$photos['ext'][$i].'" name="imgdel[]" id="imgdel'.$i.'"/> '.$sldele.'</td>';
										if(is_int($j/5) && $j<count($photos['id']))
											echo '</tr><tr>';
										$i++;
										}
									?>
                                </tr>
                            </table><br />&nbsp;
                        </div>
                        <p align="center"><input type="submit" value="<?php echo $delselected;?>" class="massbutton" name="smdelphoto"/><input type="hidden" value="<?php echo $i;?>" id="hddtotal" /></p>
                    </form>
                    <?php }
					else echo '<p>&nbsp;'.$younotupload.'</p>';
					?>
                </div>
                <p class="linespace"><br />&nbsp;</p>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
require_once '../includes/footer.php';
?>