<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	$_SESSION['direct'] = $base_url.'members/sentmail.php';
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['delmess'])){
	if(isset($_GET['id']) && intval($_GET['id'])>0 && isset($_GET['t']) && $_GET['t']=='s'){
		if(!delSentMessages(array(intval($_GET['id'])), $_SESSION['memberid']))
			$error = $errordata;
		else{ $_SESSION['succ'] = str_replace('<num>', '<b>1</b>', $numofdel);
			mysql_close();
			header('Location: '.$base_url.'members/sentmail.php');
			exit();
			}
		}
	elseif(isset($_GET['id']) && intval($_GET['id'])>0 && isset($_GET['t']) && $_GET['t']=='i'){
		if(!delInbMessages(array(intval($_GET['id'])), $_SESSION['memberid']))
			$error = $errordata;
		else{ $_SESSION['succ'] = str_replace('<num>', '<b>1</b>', $numofdel);
			mysql_close();
			header('Location: '.$base_url.'members/mail.php');
			exit();
			}
		}
	elseif(isset($_GET['id']) && intval($_GET['id'])>0 && isset($_GET['t']) && $_GET['t']=='t'){
		if(!updTrashMessages(array(intval($_GET['id'])), $_SESSION['memberid'], 2))
			$error = $errordata;
		else{ $_SESSION['succ'] = str_replace('<num>', '<b>1</b>', $numofdel);
			mysql_close();
			header('Location: '.$base_url.'members/trashmail.php');
			exit();
			}
		}
	else $error = $sloneofdel;
	}
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['blockuser']) && isset($_GET['id']) && intval($_GET['id'])>0){
	if(!blockUser(intval($_GET['id']), $_SESSION['memberid']))
		$error = $errordata;
	else{
		mysql_close();
		header('Location: '.$base_url.'members/blacklist.php');
		exit();
		}
	}
if(isset($_GET['t']) && $_GET['t']=='s'){
	$return = $base_url.'members/sentmail.php';
	$usent = MessagesDetails($_SESSION['memberid'], intval($_GET['id']), $_GET['t']);
	$mailmn = 3;
	}
elseif(isset($_GET['t']) && $_GET['t']=='i'){
	$return = $base_url.'members/mail.php';
	$usent = MessagesDetails($_SESSION['memberid'], intval($_GET['id']), $_GET['t']);
	$mailmn = 2;
	}
elseif(isset($_GET['t']) && $_GET['t']=='t'){
	$return = $base_url.'members/trashmail.php';
	$usent = MessagesDetails($_SESSION['memberid'], intval($_GET['id']), 'i');
	$mailmn = 4;
	}
$andis = 'style="display:none"';
$clandis = '';
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smrepply'])){
	$andis = '';
	$clandis = 'style="display:none"';
	if(empty($_POST['contentmail']))
		$err_c = 'Nhập nội dung email';
	else{
		$data = array(intval($_GET['id']), mysql_real_escape_string($_POST['contentmail']), 're.'.$usent['Subject'], $usent['SenderID']);
		if(!AnswerMessage($data, $_SESSION['memberid']))
			$error = $errordata;
		else{
			mysql_close();
			$_SESSION['succ'] = $sendallsucc.' <b>'.$usent['ProfileName'].'</b>';
			header('Location: '.$base_url.'members/mail.php');
			exit();
			}
		}
	}
$title = $usent['Subject'].' - '.GetProfileName($_SESSION['memberid']);
require_once '../includes/header.php';
$ismenu = 4;
require_once '../includes/menus.php';
?>
<script language="javascript">
function MessAnswer(strdis, strhid, temp){
	if(temp==1){
		document.getElementById(strhid).style.display = 'none';
		document.getElementById(strdis).style.display = '';
		document.getElementById('contentmail').focus();
		}
	else if(temp==0){
		document.getElementById('contentmail').value = '';
		document.getElementById(strhid).style.display = '';
		document.getElementById(strdis).style.display = 'none';
		}
	}
</script>
       <div class="maincontent"><br />
       <form action="" method="post">
       		<div id="browsemail">
                <div class="titletop">
                	<div class="lefttitletop">
                    	<h3><?php echo $mail;?></h3>
                    </div>
                    <div class="righttitletop">
                    	<ul>
                        	<li><input type="button" value="<?php echo $goback;?>" onclick="redirect('<?php echo $return;?>', 0)"/></li>
                            <li><input type="submit" value="<?php echo $del;?>" id="delmess" name="delmess"/></li>
                            <?php
							if(isset($_GET['t']) && $_GET['t']!='s')
								echo '<li><input type="submit" value="'.$noreciver.'" id="blockuser" name="blockuser"/></li>';
							?>
                        </ul>
                    </div>
                    <p class="linespace">&nbsp;</p>
                </div>
                <?php
				require_once "../includes/emailleft.php";
				?>
                <div class="mailright">
                	<?php
					if(!empty($usent['Subject'])){
						if(isset($_GET['t']) && $_GET['t']=='s')
							$eform = '<b>'.GetProfileName($_SESSION['memberid']).'</b> <font color="#b0b0b0">< '.$_SESSION['memberemail'].' ><br />'.$sendto.': '.$usent['ProfileName'].'</font>';
						elseif(isset($_GET['t']) && $_GET['t']=='i' || $_GET['t']=='t')
							$eform = '<a href="'.$base_url.'viewprofile.php?id='.$usent['SenderID'].'"><b>'.$usent['ProfileName'].'</b></a>';
						
					?>
                	<h3 class="mailsubject"><b><?php echo $usent['Subject'];?></b></h3>
                	<ul>
                    	<li class="fromleft"><?php echo $eform;?></li>
                        <li class="sentright"><i><?php echo date('h:i:s d-m-Y', strtotime($usent['SentOn']));?>&nbsp;</i></li>
                    </ul>
                    <div class="contentmail">
                    	<?php echo $usent['Message'];
						if(isset($_GET['t']) && $_GET['t']!='s')
							echo '<p class="answertop" id="clanswer" '.$clandis.'>'.str_replace('<link>', '<a href="javascript:MessAnswer(\'answer\', \'clanswer\', 1)">', str_replace('</link>', '</a>', $clickaply)).'</p>';
						?>
                        <div class="answerform" id="answer" <?php echo $andis;?>>
                        	<table width="100%" cellpadding="0" cellspacing="0">
                            	<tr>
                                	<td width="100%" class="rows1">&nbsp;&nbsp;<img src="<?php echo $base_url;?>imgs/replied.gif" border="0" />&nbsp;<?php echo $usent['ProfileName'];?></td>
                                </tr>
                                <tr>
                                	<td width="100%" class="rows2">
									<textarea rows="5" id="contentmail" name="contentmail"></textarea>
                                    <?php
									if(isset($err_c) && !empty($err_c))
										echo '<br><small><font color="#FF0000"><i>'.$err_c.'</i></font></small>';
									?>
                                    </td>
                                </tr>
                                <tr>
                                	<td width="100%" class="rows2">
                                    &nbsp;&nbsp;<input type="submit" value="<?php echo $reply;?>" name="smrepply" class="massbutton" />&nbsp;<input type="button" value="<?php echo $discard;?>" onclick="MessAnswer('answer', 'clanswer', 0)" class="massbutton"/>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <?php
						}
					else echo '<h3 style="border-bottom:1px solid #F2F2F2; margin-top:5px; padding-top:5px; margin-bottom:3px; padding-bottom:3px">'.$datainvalid.'</h3>';
					?>
                </div>
                <p class="linespace"><br />&nbsp;</p><br />&nbsp;
            </div>
            <p class="linespace">&nbsp;</p></form>
       </div>
<?php
mysql_close();
require_once '../includes/footer.php';
?>