<?php
ob_start();
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
require_once "../includes/paypal.class.php";
$Ppconfig = ConfigPaypal();
if($_SERVER['REQUEST_METHOD']=='POST'){
	$date = date("Y-m-d H:i:s");
	$amount = getItem(intval($_POST['namount']));
	$rs = neworder(array($_SESSION['memberid'], $amount['Prices'], $date, intval($_POST['namount'])));
	if($rs>0){
		$ItemName = $amount['Block'].' '.$month; //Item Name
		$ItemPrice = $amount['Prices']; //Item Price
		$ItemNumber = $_POST['namount']; //Item Number
		$ItemQty = 1; // Item Quantity
		$ItemTotalPrice = ($ItemPrice*$ItemQty); //(Item Price x Quantity = Total) Get total amount of product;
		if(count($Ppconfig)>0){
			$padata = '&CURRENCYCODE='.urlencode($Ppconfig['CurrencyCode']).
					'&PAYMENTACTION=Sale'.
					'&ALLOWNOTE=1'.
					'&PAYMENTREQUEST_0_CURRENCYCODE='.urlencode($Ppconfig['CurrencyCode']).
					'&PAYMENTREQUEST_0_AMT='.urlencode($ItemTotalPrice).
					'&PAYMENTREQUEST_0_ITEMAMT='.urlencode($ItemTotalPrice). 
					'&L_PAYMENTREQUEST_0_QTY0='. urlencode($ItemQty).
					'&L_PAYMENTREQUEST_0_AMT0='.urlencode($ItemPrice).
					'&L_PAYMENTREQUEST_0_NAME0='.urlencode($ItemName).
					'&L_PAYMENTREQUEST_0_NUMBER0='.urlencode($ItemNumber).
					'&AMT='.urlencode($ItemTotalPrice).				
					'&RETURNURL='.urlencode($base_url.$Ppconfig['ReturnURL'].'?u='.$_SESSION['memberid'].'&o='.$rs).
					'&CANCELURL='.urlencode($base_url.$Ppconfig['CancelURL']);	
			$paypal= new MyPayPal();
			$httpParsedResponseAr = $paypal->PPHttpPost('SetExpressCheckout', $padata, $Ppconfig['APIKey'], $Ppconfig['APIPassword'], $Ppconfig['APISignature'], $Ppconfig['APIMode']);
			if("SUCCESS" == strtoupper($httpParsedResponseAr["ACK"]) || "SUCCESSWITHWARNING" == strtoupper($httpParsedResponseAr["ACK"])){
				$_SESSION['itemprice'] =  $ItemPrice;
				$_SESSION['totalamount'] = $ItemTotalPrice;
				$_SESSION['itemName'] =  $ItemName;
				$_SESSION['itemNo'] =  $ItemNumber;
				$_SESSION['itemQTY'] =  $ItemQty;
				if($Ppconfig['APIMode']=='sandbox')
					$paypalmode 	=	'.sandbox';
				else $paypalmode 	=	'';
				$paypalurl ='https://www'.$paypalmode.'.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token='.$httpParsedResponseAr["TOKEN"].'';
				header('Location: '.$paypalurl);
				exit();
				}
			else $error = urldecode($httpParsedResponseAr["L_LONGMESSAGE0"]);
			}
		else $error = 'Please contact admin for setting paypal account';
		}
	else $error = $orderfail;
	}
if(isset($_GET["token"]) && isset($_GET["PayerID"])){
	$token = $_GET["token"];
	$playerid = $_GET["PayerID"];
	$ItemPrice 		= $_SESSION['itemprice'];
	$ItemTotalPrice = $_SESSION['totalamount'];
	$ItemName 		= $_SESSION['itemName'];
	$ItemNumber 	= $_SESSION['itemNo'];
	$ItemQTY 		= $_SESSION['itemQTY'];
	
	unset($_SESSION['itemprice']);
	unset($_SESSION['totalamount']);
	unset($_SESSION['itemName']);
	unset($_SESSION['itemNo']);
	unset($_SESSION['itemQTY']);
	
	$padata = 	'&TOKEN='.urlencode($token).
				'&PAYERID='.urlencode($playerid).
				'&PAYMENTACTION='.urlencode("SALE").
				'&AMT='.urlencode($ItemTotalPrice).
				'&CURRENCYCODE='.urlencode($PayPalCurrencyCode);
	$paypal= new MyPayPal();
	$httpParsedResponseAr = $paypal->PPHttpPost('DoExpressCheckoutPayment', $padata, $Ppconfig['APIKey'], $Ppconfig['APIPassword'], $Ppconfig['APISignature'], $Ppconfig['APIMode']);
	
	if("SUCCESS" == strtoupper($httpParsedResponseAr["ACK"]) || "SUCCESSWITHWARNING" == strtoupper($httpParsedResponseAr["ACK"])){
		$succ = '<p>Success</p>';
		$succ .= 'Your Transaction ID :'.urldecode($httpParsedResponseAr["TRANSACTIONID"]);
		if('Completed' == $httpParsedResponseAr["PAYMENTSTATUS"]){
			$transactionID = urlencode($httpParsedResponseAr["TRANSACTIONID"]);
			$nvpStr = "&TRANSACTIONID=".$transactionID;
			$paypal= new MyPayPal();
			$httpParsedResponseAr = $paypal->PPHttpPost('GetTransactionDetails', $nvpStr, $Ppconfig['APIKey'], $Ppconfig['APIPassword'], $Ppconfig['APISignature'], $Ppconfig['APIMode']);
			if("SUCCESS" == strtoupper($httpParsedResponseAr["ACK"]) || "SUCCESSWITHWARNING" == strtoupper($httpParsedResponseAr["ACK"])) {
				$sqls = 'select PayDate, Block from '.$table_prefix.'orders as o left join '.$table_prefix.'prices as p on p.Id = o.PriceId where o.Id = '.intval($_GET['o']);
				$qrys = mysql_query($sqls);
				if(!$qrys)
					$error = 'Can not update order, please contact admin for helps.<br>'.$sqls;
				elseif(mysql_num_rows($qrys)>0){
					$rowso = mysql_fetch_array($qrys);
					$newdate = strtotime ( '+ '.$rowso['Block'].'  month' , strtotime ($rowso['PayDate']) ) ;
					$sqlui = "update ".$table_prefix."orders set OrderId = 'DT".$_GET['u']."_".$_GET['o']."', Status = 1, ExpireDate = '".date("Y-m-d H:i:s", $newdate)."' where Id = ".$_GET['o']." and UserId = ".$_GET['u'];
					$qryui = mysql_query($sqlui);
					if(!$qryui)
						$error = $orderfail;
					else{
						$primg = '';
						$sqlsu = "select PrimaryPhotoID from ".$table_prefix."users where UserID = ".$_GET['u'];
						$qrysu = mysql_query($sqlsu);
						if($qrysu && mysql_num_rows($qrysu)>0){
							$rowpr = mysql_fetch_array($qrysu);
							if($rowpr['PrimaryPhotoID']==0){
								$sqlui = "insert into ".$table_prefix."photos (UserID, PhotoExtension, PhotoDescription, IsApproved, PrimaryPhoto, InsertDate, TotalRating, NumberOfVote) values (".$arrid[1].", 'jpg', '', 1, 1, now(), 0, 0)";
								$qryui = mysql_query($sqlui);
								if($qryui){
									$imgid = mysql_insert_id();
									$primg = ', PrimaryPhotoID = '.$imgid;
									$fp = fopen('../fuploads/'.$_GET['u'].'u'.$imgid.'.jpg', 'w');
									$content = file_get_contents($base_url.'imgs/noimage.jpg');
									fwrite($fp, $content);
									fclose($fp);
									}
								}
							}
						$sqlup = "update ".$table_prefix."users set RemainVIPContacts = 1 ".$primg." where UserID = ".$_GET['u'];
						$qryup = mysql_query($sqlup);
						if(!$qryup)
							$error = $orderfail;
						else $succ .= '<br>Payment Received! Your account upgraded successfull !';
						}
					}
				else $error = 'Order id can not exist';
				/*$sqlui = "update ".$table_prefix."orders set OrderId = 'DT".$_GET['u']."_".$_GET['o']."', Status = 1 where Id = ".$_GET['o']." and UserId = ".$_GET['u'];
				$qryui = mysql_query($sqlui);
				if(!$qryui)
					$error = $orderfail;
				$primg = '';
				$sqlsu = "select PrimaryPhotoID from ".$table_prefix."users where UserID = ".$_GET['u'];
				$qrysu = mysql_query($sqlsu);
				if($qrysu && mysql_num_rows($qrysu)>0){
					$rowpr = mysql_fetch_array($qrysu);
					if($rowpr['PrimaryPhotoID']==0){
						$sqlui = "insert into ".$table_prefix."photos (UserID, PhotoExtension, PhotoDescription, IsApproved, PrimaryPhoto, InsertDate, TotalRating, NumberOfVote) values (".$arrid[1].", 'jpg', '', 1, 1, now(), 0, 0)";
						$qryui = mysql_query($sqlui);
						if($qryui){
							$imgid = mysql_insert_id();
							$primg = ', PrimaryPhotoID = '.$imgid;
							$fp = fopen('../fuploads/'.$_GET['u'].'u'.$imgid.'.jpg', 'w');
							$content = file_get_contents($base_url.'imgs/noimage.jpg');
							fwrite($fp, $content);
							fclose($fp);
							}
						}
					}
				$sqlup = "update ".$table_prefix."users set RemainVIPContacts = 1 ".$primg." where UserID = ".$_GET['u'];
				$qryup = mysql_query($sqlup);
				if(!$qryup)
					$error = $orderfail;
				else $succ .= '<br>Payment Received! Your account upgraded successfull !';*/
				} 
			else $error = urldecode($httpParsedResponseAr["L_LONGMESSAGE0"]);
			}
		elseif('Pending' == $httpParsedResponseAr["PAYMENTSTATUS"])
			$error = 'Transaction Complete, but payment is still pending! You need to manually authorize this payment in your <a target="_new" href="http://www.paypal.com">Paypal Account</a>';
		}
	else $error = urldecode($httpParsedResponseAr["L_LONGMESSAGE0"]);
	}
$title = $upgacc.' - '.stripslashes(GetProfileName($_SESSION['memberid']));
$setting = getSettingsAccount($_SESSION['memberid']);
require_once '../includes/header.php';
$ismenu = 2;
require_once '../includes/menus.php';
?>
<script language="javascript" type="text/javascript">
function changeMethod(str1,str2,str3){
	document.getElementById('bt'+str1).className = 'upmassbutton';
	document.getElementById('bt'+str2).className = 'upmassbutton notupmassbutton';
	document.getElementById('bt'+str3).className = 'upmassbutton notupmassbutton';
	document.getElementById(str1).style.display = '';
	document.getElementById(str2).style.display = 'none';
	document.getElementById(str3).style.display = 'none';
	}
</script>
       <div class="maincontent"><br />
       		<div id="acounts">
                <?php
				echo '<h3>'.$settingaccount.'</h3>';
				$ltmn = 16;
				require_once '../includes/accountmenuleft.php';
				if(isset($_GET['ty']) && strtolower(trim($_GET['ty']))=='upsms'){
					$clbt1 = 'class="upmassbutton notupmassbutton"';
					$clbt2 = 'class="upmassbutton"';
					$clbt3 = 'class="upmassbutton notupmassbutton"';
					}
				elseif(isset($_GET['ty']) && strtolower(trim($_GET['ty']))=='card'){
					$clbt1 = 'class="upmassbutton notupmassbutton"';
					$clbt2 = 'class="upmassbutton notupmassbutton"';
					$clbt3 = 'class="upmassbutton"';
					}
				else{
					$clbt1 = 'class="upmassbutton"';
					$clbt2 = 'class="upmassbutton notupmassbutton"';
					$clbt3 = 'class="upmassbutton notupmassbutton"';
					}
				?>
                <div class="displayright">
                	<div class="headtop">
                    	<ul>
                        	<li class="contleft"><?php echo $upgacc;?></li>
                        </ul>
                        <p class="linespace">&nbsp;</p>
                    </div>
                    <div style="padding-right:20px;" id="nganluong">
                    <?php
					if(isset($error) && !empty($error))
						echo '<p><font color="#FF0000"><i>'.$error.'</i></font></p>';
					if(isset($succ) && !empty($succ))
						echo '<p><font color="#009933">'.$succ.'</font></p>';
					?>
                    <p style="line-height:21px;"><?php echo $memship1;?></p>
                    <p><?php echo str_replace('nganluong.vn', ': ', $memship2);?></p>
                    <form action="" method="post">
                    	<table width="100%" cellpadding="3" cellspacing="3">
                        	<?php
							$lispr = getPrices();
							if($lispr){
								$i=1;
								while($rows=mysql_fetch_array($lispr)){
									$chk = ($i==3)?' checked="checked"':'';
									echo '<tr><td width="30%"><input type="radio" value="'.$rows['Id'].'" name="namount" '.$chk.'>'.$rows['Block'].' '.$month.' = ('.$currency.') '.number_format($rows['Prices']).'</td></tr>';
									$i++;
									}
								}
							?>
                        </table>
                        <p align="center"><br />
						<?php
						if(empty($Ppconfig['ButtonImg']))
							echo '<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif" border="0" name="smagree" alt="PayPal - The safer, easier way to pay online!"> <img alt="PayPal - The safer, easier way to pay online!" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">';
						else echo html_entity_decode($Ppconfig['ButtonImg']);
						?>
                        </p>
                        </form>
                    </div>
                </div>
                <p class="linespace"><br />&nbsp;</p>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
require_once '../includes/footer.php';
?>