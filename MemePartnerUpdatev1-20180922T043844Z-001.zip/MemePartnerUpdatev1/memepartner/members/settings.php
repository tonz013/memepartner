<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smsettings'])){
	$set = (intval($_POST['setting'])==0)?4:$_POST['setting'];
	$data = array($set, $_POST['notify'], $_SESSION['memberid']);
	if(!settingsAccount($data))
		$error = $errordata;
	else $succ = $settingsucc;
	}
$title = GetProfileName($_SESSION['memberid']).' - '.$setprofile;
$setting = getSettingsAccount($_SESSION['memberid']);
require_once '../includes/header.php';
$ismenu = 2;
require_once '../includes/menus.php';
?>
       <div class="maincontent"><br />
       		<div id="acounts">
                <?php
				echo '<h3>'.$settingaccount.'</h3>';
				$ltmn = 5;
				require_once '../includes/accountmenuleft.php';
				?>
                <div class="displayright">
                	<div class="headtop">
                    	<ul>
                        	<li class="contleft"><?php echo $optionprofile;?></li>
                        </ul>
                        <p class="linespace">&nbsp;</p>
                    </div>
                    <?php
                    if(isset($error) && !empty($error))
                        echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
					if(isset($succ) && !empty($succ))
						echo '<p style="margin:0px; padding:5px 20px"><font color="#009933"><i>'.$succ.'</i></font></p>';
                    ?>
                    <form action="" method="post">
                    <p class="setting"><?php echo $openprofile;?></p>
                    <table width="100%" cellpadding="3" cellspacing="3">
                    	<tr>
                        	<td width="30%" align="right"><?php echo $curprofile.' : ';?></td>
                            <td width="70%" align="left">
                            	<?php
								if($setting['ProfileStatusID']==4){
									echo '<b>'.$waitapprove.'</b>';
									$disable = ' disabled="disabled"';
									}
								else{
									echo '<b>'.$setting['LProfileStatus'].'</b>';
									$disable = '';
									}
								?>
                            </td>
                        </tr>
                        <tr>
                        	<td width="30%" align="right"><?php echo $ortheroptions.' : ';?></td>
                            <td width="70%" align="left">
                            	<?php
								$sql = 'select ProfileStatusID, '.$_SESSION['lang'].'ProfileStatus as LProfileStatus from '.$table_prefix.'profilestatus where ProfileStatusID < 4';
								$qry = mysql_query($sql);
								if(!$qry)
									echo $errordata;
								else{
									$i=1;
									while($rows = mysql_fetch_array($qry)){
										$style = ($i>1)?' style="margin-left:40px; padding-left:0px;"':' style="margin-left:0px; padding-left:0px;"';
										echo '<input type="radio" '.$style.' name="setting" value="'.$rows['ProfileStatusID'].'" '.$disable.'/>'.$rows['LProfileStatus'];
										$i++;
										}
									}
								?>
                            </td>
                        </tr>
                        <tr>
                            <td width="60%" align="center" valign="top" colspan="2"><small><i><font color="#FF0000"><?php echo '* '.$noteprofile;?></font></i></small></td>
                        </tr>
                    </table>
                    <p class="setting"><?php echo $notifyemail;?></p>
                    <table width="100%" cellpadding="3" cellspacing="3">
                    	<tr>
                        	<td width="40%" align="right"><?php echo $curalert.' : ';?></td>
                            <td width="60%" align="left"><?php echo '<b>'.$setting['LNOTIFY'].'<b>';?></td>
                        </tr>
                        <tr>
                        	<td width="40%" align="right"><?php echo $newalert;?></td>
                            <td width="60%" align="left" valign="top">
                            	<select name="notify">
                                	<?php
									$sql = 'select Id, '.$_SESSION['lang'].'NOTIFY as LName from '.$table_prefix.'notifyemail';
									dropdownlist($sql, 0);
									?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                        	<td width="40%" align="right">&nbsp;</td>
                            <td width="60%" align="left" valign="top"><input type="submit" value="<?php echo $savesetting;?>" class="massbutton" name="smsettings"/></td>
                        </tr>
                    </table>
                    </form>
                </div>
                <p class="linespace"><br />&nbsp;</p>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
require_once '../includes/footer.php';
?>