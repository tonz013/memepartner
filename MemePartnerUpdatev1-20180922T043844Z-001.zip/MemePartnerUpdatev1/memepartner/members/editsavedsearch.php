<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	$_SESSION['direct'] = $base_url.'members/savedsearch.php';
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smeditserach']) && isset($_GET['id']) && intval($_GET['id'])>0){
	if(empty($_POST['newname']))
		$err_n = $entername;
	elseif(strlen($_POST['newname'])<6)
		$err_n = $datashort;
	elseif(!updSavedSearch(array(intval($_GET['id']), $_SESSION['memberid'], $_POST['newname'])))
		$error = $errordata;
	else{
		mysql_close();
		header('Location: '.$base_url.'members/savedsearch.php');
		exit();
		}
	}
$title = GetProfileName($_SESSION['memberid']).' - '.$editsavedsearch;	
require_once '../includes/header.php';
$ismenu = 2;
require_once '../includes/menus.php';
?>
       <div class="maincontent"><br />
       		<div id="acounts">
                <?php
				echo '<h3>'.$settingaccount.'</h3>';
				$ltmn = 14;
				require_once '../includes/accountmenuleft.php';
				
				$sql = "select SearchName from ".$table_prefix."savedsearch where SearchID = ".intval($_GET['id'])." and UserID = ".$_SESSION['memberid']." order by DateCreated desc";
				$qry = mysql_query($sql);
				?>
                <div class="displayright">
                	<div class="headtop">
                    	<ul>
                        	<li class="contleft"><?php echo $editsavedsearch;?></li>
                        </ul>
                        <p class="linespace">&nbsp;</p>
                    </div>
                    <?php
					if(isset($error) && !empty($error))
						echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
					if(isset($_SESSION['succ']) && !empty($_SESSION['succ'])){
						echo '<p style="margin:0px; padding:5px 0px"><font color="#009933"><i>'.$_SESSION['succ'].'</i></font></p>';
						unset($_SESSION['succ']);
						}
					if(mysql_num_rows($qry)>0){
						echo '<br>';
						$rows = mysql_fetch_array($qry);
					?>
                    <form action="" method="post">
                    <table width="97%" border="0" cellpadding="3" cellspacing="3">
                        <tr>
                        	<td width="40%" align="right" valign="top"><?php echo $namesaved.'&nbsp;:&nbsp;';?></td>
                            <td width="60%" align="left"><input type="text" style="width:265px;" value="<?php echo (isset($_POST['newname']))?$_POST['newname']:$rows['SearchName'];?>" name="newname" /><font color="#FF0000"> *</font>
                            <?php
							if(isset($err_n) && !empty($err_n))
								echo '<br><font color="#FF0000"><small><i>'.$err_n.'</i></small></font>';
							?>
                            </td>
                        </tr>
                        <tr>
                        	<td width="40%" align="right">&nbsp;</td>
                            <td width="60%" align="left"><input type="submit" value="<?php echo $saveit;?>" name="smeditserach" class="massbutton"/></td>
                        </tr>
                    </table>
                    </form>
                    <?php }
					else echo '<p>'.$norecord.' !</p>';
					?>
                </div>
                <p class="linespace"><br />&nbsp;</p>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
$_SESSION['process'] = true;
require_once '../includes/footer.php';
?>