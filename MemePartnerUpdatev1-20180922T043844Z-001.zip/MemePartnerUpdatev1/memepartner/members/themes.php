<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smsavetheme'])){
	if(!updateTheme($_SESSION['memberid'], $_POST['themes']))
		$error = $errordata;
	}
$title = GetProfileName($_SESSION['memberid']).' - Setting theme';
require_once '../includes/header.php';
$ismenu = 2;
require_once '../includes/menus.php';
?>
<script language="javascript">
function checkAll(field, master){
	if(document.getElementById(master).checked){
		for (i = 0; i < field.length; i++)
			field[i].checked = true ;
		}
	else{
		for (i = 0; i < field.length; i++)
			field[i].checked = false ;
		}
	}
</script>
<div class="maincontent"><br />
       		<div id="acounts">
                <?php
				echo '<h3>Setting theme</h3>';
				$ltmn = 17;
				require_once '../includes/accountmenuleft.php';
				?>
                <div class="displayright">
                	<div class="headtop">
                    	<ul>
                        	<li class="contleft"><?php echo 'Setting your theme';?></li>
                            <li class="contright">&nbsp;</li>
                        </ul>
                        <p class="linespace">&nbsp;</p>
                    </div>
                    <?php
                    if(isset($error) && !empty($error))
                        echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
					if(isset($succ) && !empty($succ))
						echo '<p style="margin:0px; padding:5px 20px"><font color="#009933"><i>'.$succ.'</i></font></p>';
					$photos = getThemes(0);
					$curretntheme = getCurrentTheme($_SESSION['memberid']);
					if($photos!=false){
						$sum = mysql_num_rows($photos);
                    ?>
                    <form action="" method="post" name="myform">
                        <div class="moreimg">
                        	<table width="100%" border="0">
                            	<tr>
                                	<?php 
									$i=0;
									while($val=mysql_fetch_array($photos)){
										$j=$i+1;
										$chk = ($curretntheme==$val['Id'])?'checked="checked"':'';
										echo '<td width="50%"><p style="padding-bottom:0px;"><a href="'.$base_url.'imgs/'.$val['FileView'].'">';
										echo '<img src="'.$base_url.'imgs/'.$val['FileView'].'" border="0" style="width:300px; height:200px"/>';
										echo '</a></p>';
										echo '<input type="radio" value="'.$val['Id'].'" '.$chk.' name="themes"/> '.$val['ThemeName'].'</td>';
										if(is_int($j/2) && $j<$sum)
											echo '</tr><tr>';
										$i++;
										}
									?>
                                </tr>
                            </table><br />&nbsp;
                        </div>
                        <p align="center"><input type="submit" value="<?php echo 'Save setting';?>" class="massbutton" name="smsavetheme"/></p>
                    </form>
                    <?php }
					else echo '<p>&nbsp;'.$younotupload.'</p>';
					?>
                </div>
                <p class="linespace"><br />&nbsp;</p>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
require_once '../includes/footer.php';
?>