<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smuplphoto'])){
	if(strlen($_POST['description'])>255)
		$err_p = 'Max lengt is 255';
	elseif(empty($_FILES['photo']['name']))
		$err_p = $photonotselect;
	elseif($_FILES['photo']['size'] > $max_size)
		$err_p = $sizeinvalid;
	else{
		$extension = pathinfo($_FILES['photo']['name']);
		$extension = $extension['extension'];
		if(in_array(strtolower($extension), $filetype)){
			list($width, $height, $type, $w) = getimagesize($_FILES['photo']['tmp_name']);
			if($width > $max_width || $height > $max_height)
				$err_p = str_replace('<cur>', $width.' x '.$height, str_replace('<max>', $max_width.' x '.$max_height, $widthheightinvalid));
			else{
				$insval = array($_SESSION['memberid'], $extension, mysql_real_escape_string($_POST['description']));
				$rs = addPhotos($insval);
				if($rs>1){
					$filename = $_SESSION['memberid'].'u'.$rs.'.'.$extension;
					if(move_uploaded_file($_FILES['photo']['tmp_name'],dirname(dirname(__FILE__)).'/'.$uploaddir.'/'.$filename))
						$succ = $uploadsucc;
					else{
						delPhotos(array($rs), $_SESSION['memberid']);
						$error = $uploaderr;
						}
					}
				else $error = $errordata;
				}
			}
		else $err_p = $filetypeinvalid;
		}
	}
$title = GetProfileName($_SESSION['memberid']).' - '.$setprofile;
require_once '../includes/header.php';
$ismenu = 2;
require_once '../includes/menus.php';
?>
<div class="maincontent"><br />
       		<div id="acounts">
                <?php
				echo '<h3>'.$settingaccount.'</h3>';
				$ltmn = 6;
				require_once '../includes/accountmenuleft.php';
				?>
                <div class="displayright">
                	<div class="headtop">
                    	<ul>
                        	<li class="contleft"><?php echo $newupload;?></li>
                        </ul>
                        <p class="linespace">&nbsp;</p>
                    </div>
                    <?php
                    if(isset($error) && !empty($error))
                        echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
					if(isset($succ) && !empty($succ))
						echo '<p style="margin:0px; padding:5px 20px"><font color="#009933"><i>'.$succ.'</i></font></p>';
					$primaryimg = getPrimaryPhoto($_SESSION['memberid']);
					$primaryimg = substr($primaryimg, 0, -4);
					$primaryimg = explode('u', $primaryimg);
                    ?>
                    <form action="" method="post" name="myform" enctype="multipart/form-data">
                    	<p><b><?php echo $rulesupload;?></b></p>
                    	<ul>
                        	<li><?php echo $rulesupload1.strtoupper(implode(', ', $filetype)).' .';?></li>
                            <li><?php echo $rulesupload2;?></li>
                            <li><?php echo $rulesupload3;?></li>
                            <li><?php echo $rulesupload4;?></li>
                        </ul>
                        <table width="100%" cellpadding="3" cellspacing="3">
                        	<tr>
                            	<td width="30%" valign="top" align="right"><?php echo $photodesc.' : '?></td>
                                <td width="70%" align="left"><input type="text" style="width:265px;" name="description" /></td>
                            </tr>
                            <tr>
                            	<td width="30%" valign="top" align="right"><?php echo $choiceimg.' : ';?></td>
                                <td width="70%" align="left"><input type="file" style="width:265px;" name="photo"/><font color="#FF0000"> *</font>
                                	<?php
									if(isset($err_p) && !empty($err_p))
										echo '<br><font color="#FF0000"><small><i>'.$err_p.'</i></small></font>';
                                    ?>
                                </td>
                            </tr>
                            <tr>
                            	<td width="30%" valign="top" align="right">&nbsp;</td>
                                <td width="70%" align="left"><input type="submit" value="<?php echo $uploadphoto;?>" class="massbutton" name="smuplphoto"/></td>
                            </tr>
                        </table>
                        <p><i><font color="#3b5998"><?php echo '* '.$noteupload;?></font></i></p>
                        <?php
						$photos = getAllPhotos($_SESSION['memberid']);
						if(count($photos['id'])>0){
						?>
                        <div class="moreimg">
                        	<table width="100%" border="0">
                            	<tr>
                                	<?php 
									$i=0;
									foreach($photos['id'] as $val){
										$j=$i+1;
										echo '<td><p style="padding-bottom:0px;">';
										echo '<img src="'.$base_url.'fuploads/'.$_SESSION['memberid'].'u'.$val.'.'.$photos['ext'][$i].'" border="0" />';
										echo '</p>';
										if($photos['app'][$i]==0)
											echo '&nbsp;'.$waitforapp.'</td>';
										else echo '&nbsp;'.$aproved.'</td>';
										if(is_int($j/5) && $j<count($photos['id']))
											echo '</tr><tr>';
										$i++;
										}
									?>
                                </tr>
                            </table><br />&nbsp;
                        </div>
                        <?php }?>
                    </form>
                </div>
                <p class="linespace"><br />&nbsp;</p>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
require_once '../includes/footer.php';
?>