<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	$_SESSION['direct'] = $base_url.'members/viewcard.php';
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
$detail = getDetailCard($_SESSION['memberid'], intval($_GET['id']));
if(!$detail){
	$title = 'View greeting cards - Your bad URL !!';
	$subject = 'View greeting cards';
	}
else{
	$row=mysql_fetch_array($detail);
	$title = 'View greeting cards - '.$row['Subjects'];
	$subject = $row['Subjects'];
	}
require_once '../includes/header.php';
$ismenu = 2;
require_once '../includes/menus.php';
?>
       <div class="maincontent"><br />
       		<div id="acounts">
                <?php
				echo '<h3>'.$settingaccount.'</h3>';
				$ltmn = 15;
				require_once '../includes/accountmenuleft.php';
				?>
                <div class="displayright">
                	<div class="headtop">
                    	<ul>
                        	<li class="contleft"><?php echo $subject;?></li>
                            <li class="contright">&nbsp;</li>
                        </ul>
                        <p class="linespace">&nbsp;</p>
                    </div>
                    <?php
					if(!$detail)
						exit($errordata);
					else{
						?>
                        <div style="margin-right:20px; margin-top:10px; text-align:left; height:307px;">
                        	<div style="width:330px; background:url(../ecards/<?php echo $row['CardName'];?>) no-repeat 100px 10px; height:307px; position:absolute; ">
                            	<div style="width:<?php echo $row['WidthMess'];?>px; background-color:#999; height:<?php echo $row['HeightMess'];?>px; margin-left:<?php echo $row['LeftMess'];?>px; margin-top:<?php echo $row['TopMess'];?>px; background:transparent; text-align:justify">
								<?php 
                                echo html_entity_decode($row['Contents']);
                                ?>
                                </div>
                            </div>
                            <div style="margin-left:340px; padding-top:5px;">
                            	From: <a href="<?php echo $base_url.'viewprofile.php?id='.$row['SenderId'];?>"><?php echo $row['ProfileName'];?></a><br /> <?php echo $row['Age'];?> years old<br /><br />
                                <i><small>Send date: <?php echo $row['SentDate'];?></small></i>
                                <?php
								if(!empty($row['Music']))
									echo '<object height="50" width="200" data="../ecards/musics/'.$row['Music'].'"></object>';
								?>
                            </div>
                        </div>
                        <p><a href="sendcard.php?id=<?php echo $row['SenderId'];?>">Send card to: <?php echo $row['ProfileName'];?></a></p>
                        <?php
						}
					?>
                    <p id="paging"><?php echo $paging;?></p>
                </div>
                <p class="linespace"><br />&nbsp;</p>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
$_SESSION['process'] = true;
require_once '../includes/footer.php';
?>