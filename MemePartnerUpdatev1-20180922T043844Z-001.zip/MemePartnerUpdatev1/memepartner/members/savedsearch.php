<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	$_SESSION['direct'] = $base_url.'members/savedsearch.php';
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "../includes/database.php";
require_once "../includes/functions.php";
if(isset($_GET['id']) && intval($_GET['id'])>0 && isset($_GET['a']) && trim($_GET['a'])=='d'){
	if(!delSavedSearch(intval($_GET['id']), $_SESSION['memberid']))
		$error = $errordata;
	else{
		$_SESSION['succ'] = 'Deleted successfull !';
		mysql_close();
		header('Location: '.$base_url.'members/savedsearch.php');
		exit();
		}
	}
$title = GetProfileName($_SESSION['memberid']).' - '.$savedsearch;	
require_once '../includes/header.php';
$ismenu = 2;
require_once '../includes/menus.php';
?>
       <div class="maincontent"><br />
       		<div id="acounts">
                <?php
				echo '<h3>'.$settingaccount.'</h3>';
				$ltmn = 14;
				require_once '../includes/accountmenuleft.php';
				
				$config['showeachside'] = 4;
				$config['per_page'] = 20;
				$config['js_numrows_page'] = countSavedSearch($_SESSION['memberid']);
				$config['curpage'] = empty($_GET['p'])?1:$_GET['p'];
				$config['rs_start'] = ($config['curpage']*$config['per_page'])-$config['per_page'];
				if($config['js_numrows_page'] < $config['per_page'])
					$config['per_page'] = $config['js_numrows_page'];
				$config['cururl'] = $base_url.'members/savedsearch.php';
				$paging = Pagination($config);
				
				$sql = "select SearchID, SearchName, Query, SearchValue, DateCreated, SubcriptionStatusID from ".$table_prefix."savedsearch where UserID = ".$_SESSION['memberid']." order by DateCreated desc";
				$sql = $sql." limit ".$config['rs_start'].", ".$config['per_page'];
				$qry = mysql_query($sql);
				?>
                <div class="displayright">
                	<div class="headtop">
                    	<ul>
                        	<li class="contleft"><?php echo $savedsearch;?></li>
                            <li class="contright"><i><?php echo str_replace('<from>', ($config['curpage']==1)?1:($config['curpage']*$config['per_page'] - ($config['per_page'] - 1)), str_replace('<to>', ($config['curpage']*$config['per_page'] > $config['js_numrows_page'])?$config['js_numrows_page']:$config['curpage']*$config['per_page'], str_replace('<total>', $config['js_numrows_page'], $stringdisplay)));?></i></li>
                        </ul>
                        <p class="linespace">&nbsp;</p>
                    </div>
                    <?php
					if(isset($error) && !empty($error))
						echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
					if(isset($_SESSION['succ']) && !empty($_SESSION['succ'])){
						echo '<p style="margin:0px; padding:5px 0px"><font color="#009933"><i>'.$_SESSION['succ'].'</i></font></p>';
						unset($_SESSION['succ']);
						}
					if(mysql_num_rows($qry)>0){
					?>
                    <table width="97%" border="0" cellpadding="0" cellspacing="0">
                    	<tr bgcolor="#F2F2F2">
                        	<td width="5%" class="rows1head" align="center"><?php echo $order;?></td>
                            <td width="67%" class="rows1head"><?php echo $namesaved;?></td>
                            <td width="13%" class="rows1head" align="center"><?php echo $savedate;?></td>
                            <td width="15%" class="rows2head" align="center" colspan="2"><?php echo $action;?></td>
                        </tr>
                        <?php
						$i=1;
						while($rows=mysql_fetch_array($qry)){
						?>
                        <tr>
                        	<td width="5%" class="rows3head" align="center"><?php echo $i;?></td>
                            <td width="67%" class="rows3head"><a href="<?php echo $base_url;?>results.php?<?php echo $rows['SearchValue'];?>"><?php echo $rows['SearchName'];?></a></td>
                            <td width="13%" class="rows3head" align="center"><?php echo date('d-m-Y', strtotime($rows['DateCreated']));?></td>
                            <td width="5%" class="rows3head" align="center">
                            	<a href="editsavedsearch.php?id=<?php echo $rows['SearchID'];?>" title="<?php echo $uedit;?>"><img src="<?php echo $base_url;?>imgs/edit.png" border="0" /></a>
                            </td>
                            <td width="5%" class="rows4head" align="center"><a href="javascript:void(0)" onclick="confirmDel('<?php echo $base_url.'members/savedsearch.php?id='.$rows['SearchID'].'&a=d';?>','<?php echo $alertdel;?>')" title="<?php echo $del;?>"><img src="<?php echo $base_url;?>imgs/delete.gif" border="0" /></a></td>
                        </tr>
                        <?php
							$i++; 
							}?>
                    </table>
                    <p id="paging"><?php echo $paging;?></p>
                    <?php }?>
                </div>
                <p class="linespace"><br />&nbsp;</p>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
$_SESSION['process'] = true;
require_once '../includes/footer.php';
?>