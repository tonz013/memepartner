<?php
require_once "../includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	header('Location: '.$base_url.'signin.php');
	exit();
	}
if(!isset($_GET['id']) || empty($_GET['id']) || intval($_GET['id'])==0){
	header('Location: '.$base_url);
	exit();
	}
$isload = ' display:none';
$isreview = ' display:none';
require_once "../includes/database.php";
require_once "../includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['btsendcard'])){
	$isload = '';
	$isreview = '';
	$newname = '';
	if(!empty($_FILES['songname']['name']) && $_FILES["songname"]["error"]==0){
		$RandomNumber = rand(0, 9999999999);
		$nametemp = explode('.', $_FILES['songname']['name']);
		$newname = $RandomNumber.'.'.$nametemp[count($nametemp) - 1];
		$temp = ($_FILES["songname"]["size"]/1024)/1024;
		$size = round( $temp, 2, PHP_ROUND_HALF_UP);
		if($size>intval(substr(ini_get('upload_max_filesize'), 0, -1)))
			$error = 'File size too large, max file size is '.ini_get('upload_max_filesize');
		elseif(!move_uploaded_file($_FILES['songname']['tmp_name'],dirname(dirname(__FILE__)).'/ecards/musics/'.$newname))
			$error = 'Error upload file !!';
		}
	if(empty($error)){
		$sql = "insert into ".$table_prefix."ecards (SenderId, RecieverId, CardId, CateCardId, Subjects, Contents, SentDate, WidthMess, HeightMess, LeftMess, TopMess, IsReed, Music) values (".$_SESSION['memberid'].", ".intval($_GET['id']).", ".intval($_POST['namecard']).", ".intval($_POST['cardtype']).", '".mysql_real_escape_string(trim($_POST['subject']))."', '".mysql_real_escape_string(trim($_POST['hddmessage']))."', '".date('Y-m-d H:i:s')."', ".intval($_POST['hddwidth']).", ".intval($_POST['hddheight']).", ".intval($_POST['hddleft']).", ".intval($_POST['hddtop']).", 0, '".$newname."')";
		$qry = mysql_query($sql);
		if(!$qry)
			$error = $errordata;
		else $succ = 'Your card has been sent success !';
		}
	}
$person = getFullPersonal(intval($_GET['id']));
if(empty($person['ProfileName'])){
	mysql_close();
	header('Location: '.$base_url);
	exit();
	}
$title = 'Send card to '.$person['ProfileName'].' / '.$person['LGender'].' - '.$person['Age'].$exage.' / '.$person['Country'].' / '.$sitename;
$paddress = '';
if(!empty($person['City']))
	$paddress .= $person['City'].', ';
if(!empty($person['State']))
	$paddress .= $person['State'].', ';
if(!empty($person['Country']))
	$paddress .= $person['Country'];
require_once '../includes/header.php';
$ismenu = 1;
require_once '../includes/menus.php';
require_once '../includes/filters.php';
?>
<script language="javascript" type="text/javascript">
$(document).ready(function(){
	$('#cardtype').change(function() {
		var valchange = this.value;
		$('#loadcard').show();
		$('#loadcard').html('<img src="../imgs/loading3.gif" border="0" />');
	  	$('#loadcard').load('<?php echo $base_url;?>includes/loadcard.php?cardId=' + valchange);
		$('#reviewcard').html('');
		$('#reviewcard').hide();
	  	});
	});
function radioclick(intval){
	$('#namecard'+intval).attr('checked', true);
	$('#reviewcard').show();
	$('#reviewcard').html('<img src="../imgs/loading3.gif" border="0" />');
	$('#reviewcard').load('<?php echo $base_url;?>includes/reviewcard.php?cardId=' + intval);
	}
function chkfrmCard(){
	if($('#subject').val()==''){
		alert('Please enter subject !');
		$('#subject').focus();
		return false;
		}
	else{
		if($('#hddtext').val()==1){
			if($('#yourmess').val()==''){
				alert('Please enter your message !');
				$('#yourmess').focus();
				return false;
				}
			document.getElementById('hddwidth').value = document.getElementById('yourmess').offsetWidth;
			document.getElementById('hddheight').value = document.getElementById('yourmess').offsetHeight;
			document.getElementById('hddleft').value = document.getElementById('loadtext').offsetLeft;
			document.getElementById('hddtop').value = document.getElementById('loadtext').offsetTop;
			document.getElementById('hddmessage').value = $('#yourmess').val();
			}
		if($('input[type=file]').val()!=''){
			var str = $('input[type=file]').val();
			var n=str.split(".");
			if(n[n.length - 1].toLowerCase()!='mp3'){
				alert('File format invalid !!');
				return false;
				}
			}
		return true;
		}
	}
</script>
       <div class="maincontent">
       		<div id="viewpro">
            	<p class="protitle"><?php echo $person['ProfileName'].' / '.$person['LGender'].' - '.$person['Age'].$exage.' / '.$person['Country'];?></p>
                <form action="" method="post" enctype="multipart/form-data" onsubmit="return chkfrmCard();">
                <div style="width:48%; float:left; margin-left:10px; margin-top:10px; border-right:1px solid #CCC; min-height:320px;">
                	<table width="100%">
                    	<tr>
                        	<td width="20%">To</td>
                            <td width="10%"><?php 
							if($person['PrimaryPhotoID']==0 || !file_exists('../fuploads/'.$person['UserID'].'u'.$person['PrimaryPhotoID'].'.'.$person['PhotoExtension']) || empty($person['PhotoExtension']))
								echo '<img src="../imgs/noimage.jpg" border="0" style="width:58px; height:64px;"/>';
							else echo '<img src="'.$base_url.'fuploads/'.$person['UserID'].'u'.$person['PrimaryPhotoID'].'.'.$person['PhotoExtension'].'" border="0" id="prphoto" style="width:58px; height:64px;"/>';
							?></td>
                            <td width="70%" valign="top">
                            	<?php
								echo $person['ProfileName'].'<br>'.$person['Age'].' '.$exage.'<br>'.$paddress;
								?>
                            </td>
                        </tr>
                        <tr>
                        	<td width="20%" style="padding-top:5px;">Card type:</td>
                            <td width="80%" colspan="2">
                            	<select name="cardtype" id="cardtype"><option value="0">- - Select - -</option>
                                	<?php
									$valcmp = isset($_POST['cardtype'])?$_POST['cardtype']:0;
									$sql = "select Id,NameCate from ".$table_prefix."cards_categories";
									$qry = mysql_query($sql);
									if($qry && mysql_num_rows($qry)>0){
										while($row=mysql_fetch_array($qry)){
											$sel = ($row['Id']==$valcmp)?' selected="selected"':'';
											echo '<option value="'.$row['Id'].'" '.$sel.'>'.$row['NameCate'].'</option>';
											}
										}
									else echo '<option value="0">Error data</option>';
									?>
                                </select>
                            </td>
                        </tr>
                    </table>
                    <div id="loadcard" style="overflow:auto; height:440px; width:100%; margin-top:10px; text-align:center; <?php echo $isload;?>">
                    	<?php
						if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['btsendcard'])){
							$sql = 'select Id,CardName from '.$table_prefix.'greetingcards where CardCate = '.intval($_POST['cardtype']);
							$qry = mysql_query($sql);
							if($qry && mysql_num_rows($qry)>0){
								echo '<ul style="margin:0px; padding:0px;">';
								$i=1;
								$valcmp = isset($_POST['namecard'])?$_POST['namecard']:0;
								while($row=mysql_fetch_array($qry)){
									$ml = ($i%3==1)?'':'margin-left:5px;';
									$sel = $row['Id']==$valcmp?' checked="checked"':'';
									echo '<li style="list-style-type:none; float:left; text-align:center; margin-top:5px;"><img src="'.$base_url.'ecards/'.$row['CardName'].'" border="0" style="width:150px; height:195px; cursor:pointer; '.$ml.'" onclick="radioclick('.$row['Id'].')"/><br /><input type="radio" name="namecard" value="'.$row['Id'].'" '.$sel.' onclick="radioclick(this.value)" id="namecard'.$row['Id'].'"/></li>';
									$i++;
									}
								echo '</ul>';
								}
							else echo '<p>'.$norecord.'</p>';
							}
						?>
                    </div>
                </div>
                <div style="width:49%; float:right; margin-left:10px; margin-top:10px; text-align:center; min-height:320px; <?php echo $isreview;?>" id="reviewcard">
                	
                	<?php
					if(isset($error) && !empty($error))
						echo '<br><p align="left"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p><br>';
					if(isset($succ) && !empty($succ))
						echo '<br><p align="left"><font color="#009933"><i>'.$succ.'</i></font></p><br>';
					if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['btsendcard'])){
						$sql = 'select CardName,IsText,ViewFormat from '.$table_prefix.'greetingcards where Id = '.intval($_POST['namecard']);
						$qry = mysql_query($sql);
						if($qry && mysql_num_rows($qry)>0){
							$row=mysql_fetch_array($qry);
							?>
							<div style="width:330px; background:url(../ecards/<?php echo $row['CardName'];?>) no-repeat 100px 10px; height:307px; position:absolute">
								<?php 
								if($row['IsText']==1) echo html_entity_decode($row['ViewFormat']);
								?>
							</div>
							<p style="clear:both; width:100%; margin-top:307px; margin-left:0px; text-align:left"><input type="text" placeholder="Subject" style="border-bottom:1px solid #CCC; border-left:hidden; border-right:hidden; border-top:hidden; width:350px; font-style:italic" id="subject" name="subject" />
								<input type="hidden" id="hddtext" value="<?php echo $row['IsText'];?>" />
							</p>
							<p style="clear:both; width:100%; margin-left:0px; text-align:left">
							<span><i>Attach a song (only type: *.mp3):</i></span><br /><input type="file" name="songname" id="songname" />
							</p>
							<p>
                            <input type="submit" value="Send Card" class="massbutton" id="btsendcard" name="btsendcard"/>
							</p>
							<?php
							
							}
						else echo '<p>'.$norecord.'</p>';
						}
					?>
                </div>
                <p style="clear:both; height:5px;">&nbsp;</p>
                <input type="hidden" name="hddwidth" id="hddwidth" />
                <input type="hidden" name="hddheight" id="hddheight" />
                <input type="hidden" name="hddleft" id="hddleft" />
                <input type="hidden" name="hddtop" id="hddtop" />
                <input type="hidden" name="hddmessage" id="hddmessage" />
             </form>
       </div>
<?php
$_SESSION['process'] = true;
if($_SESSION['memberid'])
	updateWhoViews($_SESSION['memberid'], intval($_GET['id']));
require_once '../includes/footer.php';
?>