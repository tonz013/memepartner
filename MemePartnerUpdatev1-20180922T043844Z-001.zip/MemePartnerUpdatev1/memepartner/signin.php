<?php
require_once "includes/config.php";
require_once "includes/database.php";
require_once "includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smsignin'])){
	$err = 0;
	if(empty($_POST['email'])){
		$err_e = $emailnull;
		$err = 1;
		}
	elseif(!valid_email(trim($_POST['email']))){
		$err_e = $emailinvalid;
		$err = 1;
		}
	elseif(empty($_POST['password'])){
		$err_p = $passnull;
		$err = 1;
		}
	elseif($_SESSION['loginfalse']>=$totallogin){
		if(empty($_POST['captcha'])){
			$err_c = $captchanull;
			$err = 1;
			}
		elseif(strlen($_POST['captcha'])<6){
			$err_c = $datashort;
			$err = 1;
			}
		elseif($_POST['captcha'] != $_SESSION['encoded_captcha']){
			$err_c = $captnomatch;
			$err = 1;
			}
		}
	if(intval($err)==0){
		$data = array(mysql_real_escape_string(trim($_POST['email'])), mysql_real_escape_string(trim($_POST['password'])));
		$result = UserLogin($data);
		if($result==0)
			$error = $errordata;
		elseif($result==-1){
			$_SESSION['loginfalse'] = isset($_SESSION['loginfalse'])?$_SESSION['loginfalse']+1:1;
			$error = $mailpassnotmatch;
			}
		else{
			$banned = chkBannedMe($result);
			if(count($banned)>0)
				$error = str_replace('<lydo>', $banned[0], str_replace('<ngay>', date('H:i:s d-m-Y', strtotime($banned[1])), str_replace('<link>', '<a href="'.$base_url.'contact.php">', str_replace('</link>', '</a>', $bannedacc))));
			else{
				$date = date("Y-m-d H:i:s");
				updLogon($result);
				UpdateVIPStatus($result, $date);
				IsVIP($result);
				mysql_close();
				unset($_SESSION['loginfalse']);
				$_SESSION['memberid'] = $result;
				$_SESSION['memberemail'] = $_POST['email'];
				$direct = $_SESSION['direct']?$_SESSION['direct']:$base_url;
				header('Location: '.$direct);
				exit();
				}
			}
		}
	}
$title = $memberlogin;
require_once 'includes/header.php';
require_once 'includes/menus.php';
?>
       <div class="maincontent"><br />
       		<div class="signup">
            	<form action="" method="post">
            	<p class="styletop"><?php echo $title;?></p>
                <?php
				if(isset($error) && !empty($error))
					echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
				?>
                <br />
                <table width="100%" cellpadding="3" cellspacing="3">
                	<tr>
                    	<td width="30%" align="right" valign="top">Email: </td>
                        <td width="70%" align="left"><input type="text" style="width:265px;" name="email" value="<?php echo isset($_POST['email'])?$_POST['email']:'';?>" autofocus /><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_e) && !empty($err_e))
							echo '<br><font color="#FF0000"><small><i>'.$err_e.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $mypassword;?>: </td>
                        <td width="70%" align="left"><input type="password" style="width:265px;" name="password" /><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_p) && !empty($err_p))
							echo '<br><font color="#FF0000"><small><i>'.$err_p.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <?php
					if(isset($_SESSION['loginfalse']) && $_SESSION['loginfalse']>=$totallogin){
						?>
                        <tr>
                            <td width="30%" align="right" valign="top">&nbsp;</td>
                            <td width="70%" align="left">
                            <img src="<?php echo $base_url;?>includes/capcha.php" border="0"/><br />
                            </td>
                        </tr>
                        <tr>
                            <td width="30%" align="right" valign="top"><?php echo $captcha;?>: </td>
                            <td width="70%" align="left">
                            <input type="text" size="10" name="captcha" maxlength="6"/><font color="#FF0000"> *</font>
                            <?php
                            if(isset($err_c) && !empty($err_c))
                                echo '<br><font color="#FF0000"><small><i>'.$err_c.'</i></small></font>';
                            ?>
                            </td>
                        </tr>
                        <?php
						}
					?>
                    <tr>
                    	<td width="30%" align="right" valign="top">&nbsp;</td>
                        <td width="70%" align="left"><a href="forgot.php"><i><?php echo $forgotpass;?></i></a>
                        </td>
                    </tr>
                </table><br />
                <div class="stylebott" align="center">
                    	<p style="margin:0px; padding:7px 0px;"><input type="submit" value="<?php echo $signin;?>" class="massbutton" name="smsignin"/>&nbsp;<input type="reset" value="<?php echo $cancel;?>" class="massbutton"/></p>
                </div>
                </form>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
require_once 'includes/footer.php';
?>