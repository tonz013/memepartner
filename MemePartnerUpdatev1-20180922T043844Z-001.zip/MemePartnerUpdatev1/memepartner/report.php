<?php
require_once "includes/config.php";
if(!isset($_GET['id']) || empty($_GET['id']) || intval($_GET['id'])==0){
	header('Location: '.$base_url);
	exit();
	}
require_once "includes/database.php";
require_once "includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smreport'])){
	if(empty($_POST['email']))
		$err_e = $emailnull;
	elseif(!valid_email($_POST['email']))
		$err_e = $emailinvalid;
	elseif(empty($_POST['reason']))
		$err_r = 'Please enter reason to report abuse !';
	else{
		if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
			if(empty($_POST['captcha']))
				$err_c = $captchanull;
			elseif(strlen($_POST['captcha'])<6)
				$err_c = $datashort;
			elseif($_POST['captcha'] != $_SESSION['encoded_captcha'])
				$err_c = $captnomatch;
			}
		if(!isset($err_c) && empty($err_c)){
			$data = array(mysql_real_escape_string(trim($_POST['email'])), intval($_GET['id']), mysql_real_escape_string(trim($_POST['reason'])));
			if(!reportabuse($data))
				$error = $errordata;
			else $succ = 'Thank you for report user !';
			}
		}
	}
$person = getFullPersonal(intval($_GET['id']));
if(empty($person['ProfileName'])){
	mysql_close();
	header('Location: '.$base_url);
	exit();
	}
$title = 'Report abuse - '.$person['ProfileName'];
require_once 'includes/header.php';
$ismenu = -1;
require_once 'includes/menus.php';
require_once 'includes/filters.php';
$sameprofile = getSameProfile($person['GenderID'], $person['CountryID'], intval($_GET['id']), $person['Age']);
?>
       <div class="maincontent">
       		<div id="viewpro">
            	<p class="protitle"><?php echo 'Report abuse profile - '.$person['ProfileName'];?></p><br /><br /><br />
                <?php
				if(isset($error) && !empty($error))
					echo '<p style="margin:0px; padding:5px 10px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
				if(isset($succ) && !empty($succ)){
					echo '<p style="margin:0px; padding:5px 10px"><font color="#009933"><i>'.$succ.'</i></font></p>';
					echo '<META HTTP-EQUIV="refresh" CONTENT="3;URL='.$base_url.'">';
					}
				else{
				?>
                <form action="?<?php echo $_SERVER['QUERY_STRING'];?>" method="post">
                <table width="100%" cellpadding="3" cellspacing="3">
                	<tr>
                    	<td width="35%" align="right" valign="top">Your email:</td>
                        <td width="65%" align="left"><input type="text" size="40" name="email" value="<?php echo isset($_POST['email'])?$_POST['email']:'';?>"/>
                        <?php
						if(isset($err_e) && !empty($err_e))
							echo '<br><font color="#FF0000"><small><i>'.$err_e.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="35%" align="right" >Reason:</td>
                        <td width="65%" align="left"><textarea rows="5" cols="48" name="reason"><?php echo isset($_POST['reason'])?$_POST['reason']:'';?></textarea>
                        <?php
						if(isset($err_r) && !empty($err_r))
							echo '<br><font color="#FF0000"><small><i>'.$err_r.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <?php
					if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){?>
                    <tr>
                    	<td width="35%" align="right" valign="top"><?php echo $captcha;?>:</td>
                        <td width="65%" align="left"><img src="<?php echo $base_url;?>includes/capcha.php" border="0"/><br />
                        	<input type="text" size="10" name="captcha" maxlength="6" style="margin-top:5px;"/><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_c) && !empty($err_c))
							echo '<br><font color="#FF0000"><small><i>'.$err_c.'</i></small></font>';
						?>    
                        </td>
                    </tr>
                    <?php }?>
                    <tr>
                    	<td width="35%" align="right" >&nbsp;</td>
                        <td width="65%" align="left"><input type="submit" value="<?php echo 'Report';?>" class="massbutton" name="smreport"/></td>
                    </tr>
                </table>
                </form>
                <?php }?>
                <p style="clear:both">&nbsp;</p>
            </div>
       </div>
       
<?php
$_SESSION['process'] = true;
if($_SESSION['memberid'])
	updateWhoViews($_SESSION['memberid'], intval($_GET['id']));
require_once 'includes/footer.php';