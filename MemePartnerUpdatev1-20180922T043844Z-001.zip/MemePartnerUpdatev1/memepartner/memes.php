<?php
require_once "includes/config.php";
require_once "includes/database.php";
require_once "includes/functions.php";
$title = $sitename.' - '.$slogan;
$ismenu = 7;
require_once 'includes/header.php';
require_once 'includes/menus.php';
$user_id = $_SESSION['memberid'];
if(isset($_POST['create'])){
	
	$description = trim($_POST['description']);
	echo $desciption;
	add_post($user_id, $description);
}

$get_post = get_post();


?>


<html>
<head>
	<meta name="viewport" content="width=device-width,initial-scale=1">
	  <link rel="stylesheet" href="model/css/bootstrap.min.css">
	  <link rel="stylesheet" href="model/w3.css">
	  <script src="model/js/bootstrap.min.js" type="text/javascript"></script> 
      <script src="model/jquery.min.js" type="text/javascript"> </script>
      <script src="model/jquery.js" type="text/javascript"> </script>
</head>
<body>	
	<div class="maincontent" style="margin-top: 10px;font-size:12px;">
		<div class="panel panel-default" style="margin-left:'.$marginleft.'px">

			<?php if(isset($_SESSION['memberid']) && intval($_SESSION['memberid'])>0){ ?>
			
				<div class="panel-heading"><br>
				</div>
					
				<div class = "uploadphoto" style="margin-top: 10px;">
					<form method="post" >
						<!--<input type="file" name="photo" required />-->
				</div>
					<div class="panel-body">
					<textarea name="description" required="required" placeholder="Description..." maxlength="255" rows="4" cols="160" ></textarea>
					</div>
					<div class="panel-footer" align="right"><input style="margin-top: -5px;margin-bottom: -5px;" type="submit" class="w3-button w3-green" value="Post" name="create">
					</div>
				</form>
				<?php } ?>
		</div>
	</div>

	<?php foreach($get_post as $c): ?>
	<div class="maincontent" style="margin-top: 10px;font-size:12px;">
		<div class="panel panel-default" style="margin-left:'.$marginleft.'px">
			
				<div class="panel-heading"><?php echo htmlentities($c['UserID']); ?>
				</div>
					
				<div class="panel-body">
				<?php echo htmlentities($c['Description']); ?>
				</div>
				<div class="panel-footer" align="right">
				</div>
		</div>
	</div>
	<?php endforeach; ?>
	<!--
			
				
					<div class="panel panel-default" style="margin-left:'.$marginleft.'px">
					<div class="panel-heading"  style="margin-top: 10px;">
					</div>
					<div class="panel-body">
						
					</div>
					<div class="panel-footer" align="right"><br>
					</div>
				
		
	</div>-->
	<?php
		mysql_close();
		$_SESSION['process'] = true;
		require_once 'includes/footer.php';
	?>
</body>
</html>