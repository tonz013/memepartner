<?php
require_once "includes/config.php";
if(!isset($_GET['id']) || empty($_GET['id']) || intval($_GET['id'])==0){
	header('Location: '.$base_url);
	exit();
	}
require_once "includes/database.php";
require_once "includes/functions.php";
$person = getFullPersonal(intval($_GET['id']));
if(empty($person['ProfileName'])){
	mysql_close();
	header('Location: '.$base_url);
	exit();
	}
$title = $person['ProfileName'].' / '.$person['LGender'].' - '.$person['Age'].' '.$exage.' / '.$person['Country'].' / '.$sitename;
$paddress = '';
if(!empty($person['City']))
	$paddress .= $person['City'].', ';
if(!empty($person['State']))
	$paddress .= $person['State'].', ';
if(!empty($person['Country']))
	$paddress .= $person['Country'];
$pheight = '';
if($person['MatchHeightIDFrom']==0 && $person['MatchHeightIDTo']==0)
	$pheight = $any;
elseif($person['MatchHeightIDFrom']>0 && $person['MatchHeightIDTo']>0 && $person['MatchHeightIDFrom']<$person['MatchHeightIDTo'])
	$pheight = $from.' '.$person['MFHeightDescription'].' '.$to.' '.$person['MTHeightDescription'];
else $pheight = $from.' '.$person['MFHeightDescription'].' '.$above;
require_once 'includes/header.php';
$ismenu = 1;
require_once 'includes/menus.php';
require_once 'includes/filters.php';
$sameprofile = getSameProfile($person['GenderID'], $person['CountryID'], intval($_GET['id']), $person['Age']);
?>
<script language="javascript" type="text/javascript">
function sendaflirt(strdiv){
	document.getElementById(strdiv).style.display = '';
	document.getElementById('slidediv1').style.display = '';
	window.scroll(0,0);
	}
function closeflirt(){
	document.getElementById('slidediv').style.display = 'none';
	document.getElementById('slidediv1').style.display = 'none';
	var cateid = document.getElementById('hddtemp').value.split(',');
	for(var j=0; j<cateid.length; j++){
		$("#cate"+cateid[j]).hide();
		$("#titlecate"+cateid[j]).css('background','url(imgs/b.png) no-repeat 5px 5px');
		}
	}
$(document).ready(function(){
	$('#clksendrequest').click(function() {
		var val = $('#selval').val();
		if(val==0){
			alert('Please select a flirt to send !');
			return;
			}
		$.get("includes/sendaflirt.php?<?php echo $_SERVER['QUERY_STRING'];?>&val="+val,
			function(data) {
				if(data.jval==-1)
					alert('Please login to site');
				else if(data.jval==-2)
					alert('An error !');
				else if(data.jval==1){
					alert('Your a flirt has been sent success !');
					closeflirt();
					}
				}, "json");
	  	});
	$("#rate1").mouseover(function(){
		  $("#rate1").addClass("active");
		}); 
	$("#rate1").mouseout(function(){
		  $("#rate1").removeClass("active");
		});
	$("#rate2").mouseover(function(){
		  $("#rate1").addClass("active");
		  $("#rate2").addClass("active");
		}); 
	$("#rate2").mouseout(function(){
		  $("#rate1").removeClass("active");
		  $("#rate2").removeClass("active");
		});
	$("#rate3").mouseover(function(){
		  $("#rate1").addClass("active");
		  $("#rate2").addClass("active");
		  $("#rate3").addClass("active");
		}); 
	$("#rate3").mouseout(function(){
		  $("#rate1").removeClass("active");
		  $("#rate2").removeClass("active");
		  $("#rate3").removeClass("active");
		});
	$("#rate4").mouseover(function(){
		  $("#rate1").addClass("active");
		  $("#rate2").addClass("active");
		  $("#rate3").addClass("active");
		  $("#rate4").addClass("active");
		}); 
	$("#rate4").mouseout(function(){
		  $("#rate1").removeClass("active");
		  $("#rate2").removeClass("active");
		  $("#rate3").removeClass("active");
		  $("#rate4").removeClass("active");
		});
	$("#rate5").mouseover(function(){
		  $("#rate1").addClass("active");
		  $("#rate2").addClass("active");
		  $("#rate3").addClass("active");
		  $("#rate4").addClass("active");
		  $("#rate5").addClass("active");
		}); 
	$("#rate5").mouseout(function(){
		  $("#rate1").removeClass("active");
		  $("#rate2").removeClass("active");
		  $("#rate3").removeClass("active");
		  $("#rate4").removeClass("active");
		  $("#rate5").removeClass("active");
		});
	});
function ratingprofile(intval,intprofile,intuser){
	if(intuser==0){
		alert('Please login before rating !');
		return;
		}
	else{
		$('#reloadrate').html('<img src="imgs/loading3.gif" border="0" style="width:35px; height:35px"/>');
		$(document).ready(function(){
			$.get("includes/ratingprofile.php?val="+intval+'&pr='+intprofile,
			function(data) {
				if(data.jval==-2)
					alert('An error !');
				else if(data.jval==1){
					$('#reloadrate').load('<?php echo $base_url;?>includes/loadrate.php?pr=' + intprofile+'&val='+intval);
					}
				}, "json");
			});
		}
	}
function ashow(intval){
	$('#selval').val('0');
	var cateid = document.getElementById('hddtemp').value.split(',');
	for(var j=0; j<cateid.length; j++){
		if(cateid[j]==intval){
			$("#cate"+cateid[j]).show();
			$("#titlecate"+cateid[j]).css('background','url(imgs/down.png) no-repeat 5px 7px');
			}
		else{
			$("#cate"+cateid[j]).hide();
			$("#titlecate"+cateid[j]).css('background','url(imgs/b.png) no-repeat 5px 5px');
			}
		}
	}
function bclick(intval){
	$('#selval').val(intval);
	}
</script>
       <div class="maincontent">
       		<div id="viewpro">
            	<p class="protitle"><?php echo $person['ProfileName'].' / '.$person['LGender'].' - '.$person['Age'].' '.$exage.' / '.$person['Country'];?></p>
                <div class="proimg">
                	<?php
					if($person['PrimaryPhotoID']==0 || !file_exists('fuploads/'.$person['UserID'].'u'.$person['PrimaryPhotoID'].'.'.$person['PhotoExtension']) || empty($person['PhotoExtension']))
						echo '<img src="imgs/noimage.jpg" border="0"/>';
					else echo '<img src="'.$base_url.'fuploads/'.$person['UserID'].'u'.$person['PrimaryPhotoID'].'.'.$person['PhotoExtension'].'" border="0" id="prphoto"/>';
					$bvip = '';
					if($person['RemainVIPContacts']==1 && $person['IsOnline']==1 && $_SESSION['vipm']==true){
						//echo '<p style="padding-left:10px"><b>Email: '.$person['Email'].'</b></p>';
						echo '&nbsp;&nbsp;<a href="javascript:chatWith(\''.intval($_GET['id']).'\',\''.$person['ProfileName'].'\')"><img src="imgs/chatnow.png" border="0" align="middle" style="width:190px; height:32px; margin-left:50px;"/></a>';
						$bvip = 'dtvip';
						}
					$ispixel = ($person['NumberOfVote']>0)?round(($person['TotalRating']*100)/($person['NumberOfVote']*5)).'px':'0px';
					?>
                    <p style="margin-bottom:0px; padding-bottom:0px; padding-left:5px;"><i>Rating for this profile:</i></p>
                    <div id="reloadrate" style="margin-left:5px;">
                        <span style="float:left; " class="rates_cont"><small><i>Your rate:</i></small><br />
                            <a href="javascript:ratingprofile(1, <?php echo intval($_GET['id']);?>, <?php echo isset($_SESSION['memberid'])?intval($_SESSION['memberid']):0;?>)" id="rate1">&nbsp;</a>
                            <a href="javascript:ratingprofile(2, <?php echo intval($_GET['id']);?>, <?php echo isset($_SESSION['memberid'])?intval($_SESSION['memberid']):0;?>)" id="rate2">&nbsp;</a>
                            <a href="javascript:ratingprofile(3, <?php echo intval($_GET['id']);?>, <?php echo isset($_SESSION['memberid'])?intval($_SESSION['memberid']):0;?>)" id="rate3">&nbsp;</a>
                            <a href="javascript:ratingprofile(4, <?php echo intval($_GET['id']);?>, <?php echo isset($_SESSION['memberid'])?intval($_SESSION['memberid']):0;?>)" id="rate4">&nbsp;</a>
                            <a href="javascript:ratingprofile(5, <?php echo intval($_GET['id']);?>, <?php echo isset($_SESSION['memberid'])?intval($_SESSION['memberid']):0;?>)" id="rate5">&nbsp;</a>
                        </span>
                        <span style="float:right; text-align:left"><small><i>Total: <?php echo ($person['NumberOfVote']>0)?round($person['TotalRating']/$person['NumberOfVote'], 2):0;?> (<?php echo $person['NumberOfVote'];?> votes)</i></small><br />
                            <div style="width:100px;margin:0 auto;"><div class="active_rate_list"><div class="inactive_rate_list" style="width:<?php echo $ispixel;?>;"></div></div></div>
                        </span>
                    </div>
                </div>
                <div class="prodetails <?php echo $bvip;?>">
                	<p class="dtabout">- <b><?php echo $aboutme.':';?></b> <?php echo $person['AboutMe'];?></p>
                    <p class="dtinterest">- <b><?php echo $interest.':';?></b> <?php echo $person['Interests'];?></p>
                	<div class="dtleft">
                        <p class="dtlhead"><?php echo $overview.': '.$person['ProfileName'];?></p>
                        <p class="matchsec"><?php echo '<b>'.$age.':</b> '.$person['Age'];?></p>
                        <p class="matchsec"><?php echo '<b>'.$gender.':</b> '.$person['LGender'];?></p>
                        <p class="matchsec"><?php echo '<b>'.$address.':</b> '.$paddress;?></p>
                        <p class="matchsec"><?php echo '<b>'.$educate.':</b> '.$person['LEducation'];?></p>
                        <p class="matchsec"><?php echo '<b>'.$opcupation.':</b> '.$person['Occupation'];?></p>
                        <p class="matchsec"><?php echo '<b>'.$shortmarital.':</b> '.$person['LMaritalStatus'];?></p>
                        <p class="matchsec"><?php echo '<b>'.$height.':</b> '.$person['HeightDescription'];?></p>
                        <p class="matchsec"><?php echo '<b>'.$haircolor.':</b> '.$person['LHairColor'];?></p>
                        <p class="matchsec"><?php echo '<b>'.$eyeColor.':</b> '.$person['LEyeColor'];?></p>
                        <p class="matchsec"><?php echo '<b>'.$bodytype.':</b> '.$person['LBodyType'];?></p>
                        <p class="matchsec"><?php echo '<b>'.$religion.':</b> '.$person['LReligion'];?></p>
                        <p class="matchsec"><?php echo '<b>'.$smoking.':</b> '.$person['LSmoking'];?></p>
                        <p class="matchsec"><?php echo '<b>'.$drinking.':</b> '.$person['LDrinking'];?></p>
                        <p class="matchsec"><b><?php echo $havechild.': ';?></b> <?php echo ($person['HaveChildren']==3)?$not:$yes;?></p>
                        <p class="matchlast"><b><?php echo $wantchild.': ';?></b> <?php echo ($person['WantChildren']==3)?$notwant:$want;?></p>
                    </div>
                    <div class="dtright">
                        <p class="dtlhead"><?php echo $person['ProfileName'].', '.$wantwho;?></p>
                        <p class="mymatch"><?php echo $person['AboutMyMatch'];?></p>
                        <p class="matchtop"><?php echo '<b>'.$wantfind.':</b> '.$person['MLGender'].', '.$from.' '.$person['MatchAgeFrom'].' '.$to.' '.$person['MatchAgeTO'];?></p>
                        <p class="matchsec"><?php echo '<b>'.$purposeto.': </b>'.$person['LDatingInterest'];?></p>
                        <p class="matchsec"><b><?php echo $educate.':';?></b> <?php echo empty($person['MLEducation'])?$any:$person['MLEducation'];?></p>
                        <p class="matchsec"><b><?php echo $shortmarital.':';?></b> <?php echo empty($person['MLMaritalStatus'])?'Any':$person['MLMaritalStatus'];?></p>
                        <p class="matchsec"><b><?php echo $height.':';?></b> <?php echo $pheight;?></p>
                        <p class="matchsec"><b><?php echo $bodytype.':';?></b> <?php echo empty($person['MLBodyType'])?$any:$person['MLBodyType'];?></p>
                        <p class="matchsec"><b><?php echo $religion.':';?></b> <?php echo empty($person['MLReligion'])?$any:$person['MLReligion'];?></p>
                        <p class="matchsec"><b><?php echo $smoking.':';?></b> <?php echo empty($person['MLSmoking'])?$any:$person['MLSmoking'];?></p>
                        <p class="matchsec"><b><?php echo $drinking.':';?></b> <?php echo empty($person['MLDrinking'])?$any:$person['MLDrinking'];?></p>
                        <p class="matchsec">&nbsp;</p>
                    </div><p class="linespace">&nbsp;</p>
                    <p align="center"><input type="button" value="<?php echo $sendmail;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'members/compose.php?pr='.$person['UserID'];?>', 0)"/>&nbsp;<input type="button" value="<?php echo 'Flirt';?>" class="massbutton"  onclick="sendaflirt('slidediv')"/>&nbsp;<input type="button" value="<?php echo 'Send Memes';?>" class="massbutton" onclick="redirect('<?php echo $base_url.'members/sendcard.php?id='.$person['UserID'];?>', 0)" />&nbsp;<input type="button" value="<?php echo $save;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'alerts.php?ty=3&pr='.$person['UserID'];?>', 0)" />
                    <?php
					if(strpos($person['ProfileName'], ' ')===false && strlen($person['ProfileName'])>20)
						$prof = substr($person['ProfileName'], 0, 16).' ...';
					else $prof = (strlen($person['ProfileName'])>20)?substr(strip_tags($person['ProfileName']), 0, 25).' ...':strip_tags($person['ProfileName']);
					?>
                    &nbsp;<input type="button" value="<?php echo 'Report Abuse';?>" class="massbutton" onclick="redirect('<?php echo $base_url.'report.php?id='.$person['UserID'];?>', 0)" />
                    <span style="margin-left:10%">Share: &nbsp;</span><a target="_new" href="http://www.facebook.com/sharer/sharer.php?s=100&p[url]=<?php echo urlencode($base_url);?>viewprofile.php?<?php echo $_SERVER['QUERY_STRING'];?>&p[title]=<?php echo urlencode($title);?>&p[summary]=<?php echo urlencode(stripslashes($person['AboutMe']));?>&p[images][0]=<?php echo urlencode($sharephoto);?>" title="Share on Facebook"><img src="imgs/fbshare.jpg" border="0" alt="Share on Facebook"/></a>&nbsp;
                    <a target="_new" href="https://twitter.com/intent/tweet?source=webclient&text=<?php echo urlencode(stripslashes($person['ProfileName']).' / '.$person['LGender'].' - '.$person['Age'].' '.$exage.' - '.stripslashes($person['AboutMe']).' at '.$base_url.'viewprofile.php?'.$_SERVER['QUERY_STRING']);?>" title="Share on Twitter"><img src="imgs/twitter.png" border="0" alt="Share on Twitter"/></a>&nbsp;
                    <a href="https://plus.google.com/share?url=<?php echo urlencode($base_url.'viewprofile.php?'.$_SERVER['QUERY_STRING']);?>" onclick="javascript:window.open(this.href,
  '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" title="Share on Google+"><img
  src="https://www.gstatic.com/images/icons/gplus-16.png" alt="Share on Google+" border="0"/></a>
                    </p>
                </div>
                <?php
					$photos = getUserPhotos(intval($_GET['id']));
					if(count($photos['id'])>0){
					?>
                    <div class="mpreimgnew">
                    	<p>
                    	<?php 
						$i=0;
						foreach($photos['id'] as $val){
							echo '<img src="'.$base_url.'fuploads/'.$person['UserID'].'u'.$val.'.'.$photos['ext'][$i].'" border="0" onclick="viewphoto(\'prphoto\',\''.$base_url.'fuploads/'.$person['UserID'].'u'.$val.'.'.$photos['ext'][$i].'\')"/>&nbsp;';
							$i++;
							}
						?>
                        </p>
                    </div>
                    <?php } 
					else echo '<p style="clear:both">&nbsp;</p>';
					?><br />&nbsp;
            </div>
            <div id="morepro">
            	<p><?php echo $sameprofiles;?></p>
                <table width="100%" cellpadding="3" cellspacing="3" border="0">
                	<tr>
                    	<?php
						if(mysql_num_rows($sameprofile)>0){
							while($rows = mysql_fetch_array($sameprofile)){
								$sadd = '';
								if(!empty($rows['City']))
									$sadd .= $rows['City'].', ';
								if(!empty($rows['State']))
									$sadd .= $rows['State'].', ';
								if(!empty($rows['Country']))
									$sadd .= $rows['Country'];
								?>
								<td width="5%"><a href="?id=<?php echo $rows['UserID'];?>"><img src="<?php echo $base_url;?>fuploads/<?php echo ($rows['PrimaryPhotoID']>0)?$rows['UserID'].'u'.$rows['PrimaryPhotoID'].'.'.$rows['PhotoExtension']:'7u6.gif';?>" border="0"/></a></td>
								<td width="12%" valign="top">
									<small><a href="?id=<?php echo $rows['UserID'];?>"><?php echo $rows['ProfileName'].' ('.$rows['Age'].' '.$exage.') ';?></a><br /><?php echo $sadd;?></small>
								</td>
								<?php
								}
							echo FullRows(mysql_num_rows($sameprofile), 5, '<td width="5%">&nbsp;</td><td width="12%" valign="top">&nbsp;</td>');
							}
						else echo '<td width="100%">No similar profile !</td>';
						?>
                    </tr>
                </table>                
            </div>
       </div>
<?php
$_SESSION['process'] = true;
if(isset($_SESSION['memberid']))
	updateWhoViews($_SESSION['memberid'], intval($_GET['id']));
increaseView(intval($_GET['id']));
require_once 'includes/footer.php';
?>
<div style="position:absolute; background-color:#CCC; width:100%; height:150%; opacity:0.5; filter:alpha(opacity=50); -moz-opacity:0.5; -khtml-opacity:0.5; top:0px; z-index:100; display:none" id="slidediv">
</div>
<div style="width:500px; margin-left:35%; margin-top:1%; height:90%; position:absolute; z-index:1000; top:0px; text-align:left; background:#FFF; -moz-border-radius:10px; -webkit-border-radius:10px; border-radius:10px; border:1px solid #dfe6f0; padding:5px 10px; display:none; overflow:auto;" id="slidediv1">
	<h3 style="padding:0px 0px 3px 0px; margin:0px; border-bottom:1px solid #637bad">Send a Flirt</h3>
    <div style="padding:5px 0px; min-height:50%;">
    	<?php
		require_once "includes/database.php";
		$sqlf = "select Id,NameCate from ".$table_prefix."flirt_categories";
		$qryf = mysql_query($sqlf);
		$idtemp = array();
		if($qryf!=false && mysql_num_rows($qryf)>0){
			while($rowf = mysql_fetch_array($qryf)){
			?>
            <p style="border:1px solid #CCC; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; padding-left:17px; background:url(imgs/b.png) no-repeat 5px 5px; padding-bottom:0px; margin-bottom:0px; cursor:pointer" onclick="ashow(<?php echo $rowf['Id'];?>)" id="titlecate<?php echo $rowf['Id'];?>"><?php echo $rowf['NameCate'];?></p>
            <?php
			array_push($idtemp, $rowf['Id']);
			$sqlfl = 'select Id,FilrtValue from '.$table_prefix.'flirts where CateId = '.$rowf['Id'];
			$qryfl = mysql_query($sqlfl);
			if(!$qryfl){
				$str = '<ul style="margin:0px; padding:0px;">';
				$str .= '<li style="list-style-type:none; margin-left:20px; padding-left:0px; margin-bottom:0px; padding-bottom:0px">There are no data !!</li>';
				$str .= '</ul>';
				echo $str;
				}
			elseif(mysql_num_rows($qryfl)>0){
				echo '<ul style="margin:0px; padding:0px; display:none;" id="cate'.$rowf['Id'].'">';
				$i=1;
				while($rowfl=mysql_fetch_array($qryfl)){
					echo '<li style="list-style-type:none; margin-left:20px; padding-left:0px; margin-bottom:0px; padding-bottom:0px"><input type="radio" id="flirt'.$i.'" name="flirt" value="'.$rowfl['Id'].'" onclick="bclick('.$rowfl['Id'].')"/>'.$rowfl['FilrtValue'].'</li>';
					$i++;
					}
				echo '</ul>';
				}
			else{
				$str = '<ul style="margin:0px; padding:0px;">';
				$str .= '<li style="list-style-type:none; margin-left:20px; padding-left:0px; margin-bottom:0px; padding-bottom:0px">There are no data !!</li>';
				$str .= '</ul>';
				echo $str;
				}
				}
			}
		else echo '<p>'.$norecord.' !!</p>';
		mysql_close();
		?>
    	<div>
            <p align="center"><input type="button" value="Send a Flirt" class="massbutton" id="clksendrequest"/>&nbsp;<input type="button" value="Close" class="massbutton" onclick="closeflirt()"/></p><input type="hidden" id="hddtotal" value="<?php echo $i;?>"/><input type="hidden" id="hddtemp" value="<?php echo implode(',', $idtemp);?>" /><input type="hidden" id="selval" />
        </div>
    </div>
</div>