<?php
require_once "includes/config.php";
require_once "includes/database.php";
require_once "includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smforgot'])){
	if(empty($_POST['email']))
		$err_e = $emailnull;
	elseif(!valid_email($_POST['email']))
		$err_e = $emailinvalid;
	elseif(empty($_POST['captcha']))
		$err_c = $captchanull;
	elseif(strlen($_POST['captcha'])<6)
		$err_c = $datashort;
	elseif($_POST['captcha'] != $_SESSION['encoded_captcha'])
		$err_c = $captnomatch;
	else{
		if(exits_user(mysql_real_escape_string($_POST['email'])))
			$error = $mailnotreg;
		else{
			$rs = GetPassword(mysql_real_escape_string(trim($_POST['email'])));
			$mess = $welcome.$_POST['email'].'<br>';
			$mess .= $yourequestpass.':<br><br>';
			$mess .= 'Email: '.$_POST['email'].'<br>';
			$mess .= $mypassword.': '.$rs.'<br><br>';
			$mess .= '<b>'.$goodquestion.'<br>'.$sitename.'</b>';
			if(!mail(trim($_POST['email']), '=?UTF-8?B?'.base64_encode($forgotpass).'?=', $mess, "Content-Type: text/html; charset=utf-8\r\nFrom: ".$adminemail))
				$error = $cannotsendemail;
			else $succ = $recoverysucc;
			}
		}
	}
$title = $recoverypass;
require_once 'includes/header.php';
require_once 'includes/menus.php';
?>
       <div class="maincontent"><br />
       		<div class="signup">
            	<form action="" method="post">
            	<p class="styletop"><?php echo $title;?></p>
                <?php
				if(isset($error) && !empty($error))
					echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
				echo '<br />';
				if(isset($succ) && !empty($succ))
					echo '<p style="padding-left:20px;"><font color="009933">'.$succ.'</font></p>';
				else{
				?>
                <table width="100%" cellpadding="3" cellspacing="3">
                	<tr>
                    	<td width="30%" align="right" valign="top">Email: </td>
                        <td width="70%" align="left"><input type="text" style="width:265px;" name="email" value="<?php echo isset($_POST['email'])?$_POST['email']:'';?>"/><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_e) && !empty($err_e))
							echo '<br><font color="#FF0000"><small><i>'.$err_e.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top">&nbsp;</td>
                        <td width="70%" align="left">
                        <img src="<?php echo $base_url;?>includes/capcha.php" border="0"/><br />
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $captcha;?>: </td>
                        <td width="70%" align="left">
                        <input type="text" size="10" name="captcha" maxlength="6"/><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_c) && !empty($err_c))
							echo '<br><font color="#FF0000"><small><i>'.$err_c.'</i></small></font>';
						?>
                        </td>
                    </tr>
                </table>
                <?php }?>
                <br />
                <div class="stylebott">
                    <div class="bottleft"><?php echo $noterecovery;?></div>
                    <div class="bottright">
                    	<input type="submit" value="<?php echo $sendrequest;?>" class="massbutton" name="smforgot"/>
                    </div>
                    <p class="linespace">&nbsp;</p>
                </div>
                </form>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
require_once 'includes/footer.php';
?>