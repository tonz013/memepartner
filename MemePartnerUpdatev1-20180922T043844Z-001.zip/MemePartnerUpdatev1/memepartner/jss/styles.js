// JavaScript Document
function chgLange(strval,strurl,returnurl){
	window.location.href=strurl+'changelang.php?val='+strval+'&rt='+encodeURI(returnurl);
	}
function redirect(strURL, temp){
	if(temp==1)
		window.location.href = strURL+'&k='+document.getElementById('keyword').value;
	else window.location.href = strURL;
	}
function viewphoto(strId,strUrl){
	document.getElementById(strId).src = strUrl;
	}
function confirmDel(strUrl, stralert){
	if(confirm(stralert))
		window.location.href = strUrl;
	else return;
	}
function startAnimation() { 
    var frames = document.getElementById("animation").children;
    var frameCount = frames.length;
    var i = 0;
    setInterval(function () { 
        frames[i % frameCount].style.display = "none";
        frames[++i % frameCount].style.display = "";
    }, 500);
} 
function AnimationSignal() { 
    var frames = document.getElementById("signal").children;
    var frameCount = frames.length;
    var i = 0;
    setInterval(function () { 
        frames[i % frameCount].style.display = "none";
        frames[++i % frameCount].style.display = "";
    }, 500);
} 
function stdisplayhelp(intval){
	if(intval!=document.getElementById('currdis').value){
		for(var i=1; i<document.getElementById('hdval').value; i++)
			document.getElementById('faq'+i).style.display = 'none';
		document.getElementById('faq'+intval).style.display = '';
		document.getElementById('currdis').value = intval;
		}
	else{
		document.getElementById('faq'+intval).style.display = 'none';
		document.getElementById('currdis').value = 0;
		}
	}
function opennewwindow(url){
	if(url!='')
		window.open(url,'_blank');
	}
function adclkActions(id,val1,val2,type){
	if(type==1){
		document.getElementById('frmEdit').style.display = '';
		document.getElementById('frmnew').style.display = 'none'
		document.getElementById('hddid').value = id;
		document.getElementById('envalue').value = decodeURIComponent(val1.split('+').join(' '));
		//document.getElementById('vnvalue').value = val2;
		}
	else if(type==2){ 
		document.getElementById('frmnew').style.display = '';
		document.getElementById('frmEdit').style.display = 'none';
		}
	}