<?php
require_once "includes/config.php";
require_once "includes/database.php";
require_once "includes/functions.php";
$strsearch = '';
if(intval($_GET['fg'])>0)
	$strsearch .= 'u.GenderID = '.intval($_GET['fg']).' and ';
if(intval($_GET['af'])>0)
	$strsearch .= 'u.Age >= '.intval($_GET['af']).' and ';
if(intval($_GET['at'])>0)
	$strsearch .= 'u.Age <= '.intval($_GET['at']).' and ';
if(intval($_GET['m'])>0)
	$strsearch .= 'u.MaritalStatusID = '.intval($_GET['m']).' and ';
if(intval($_GET['c'])>0)
	$strsearch .= 'u.CountryID = '.intval($_GET['c']).' and ';
if(intval($_GET['st'])>0)
	$strsearch .= 'u.StateID = '.intval($_GET['st']).' and ';
if(!empty($_GET['tp']))
	$strsearch .= "u.City like '%".mysql_real_escape_string($_GET['tp'])."%' and ";
if(intval($_GET['d'])>0)
	$strsearch .= 'u.DatingInterestID = '.intval($_GET['d']).' and ';
if(intval($_GET['t'])==1){
	if(!empty($_GET['pr']))
		$strsearch .= "u.ProfileName like '%".mysql_real_escape_string(urldecode($_GET['pr']))."%' and ";
	if(!empty($_GET['ab']))
		$strsearch .= "u.AboutMe like '%".mysql_real_escape_string($_GET['ab'])."%' and ";
	if(intval($_GET['h'])>0)
		$strsearch .= 'u.HairColorID = '.intval($_GET['h']).' and ';
	if(intval($_GET['e'])>0)
		$strsearch .= 'u.EyeColorID='.intval($_GET['e']).' and ';
	if(intval($_GET['hf'])>0)
		$strsearch .= 'u.HeightID >= '.intval($_GET['hf']).' and ';
	if(intval($_GET['ht'])>0)
		$strsearch .= 'u.HeightID <= '.intval($_GET['ht']).' and ';
	if(intval($_GET['b'])>0)
		$strsearch .= 'u.BodyTypeID = '.intval($_GET['b']).' and ';
	if(intval($_GET['sm'])>0)
		$strsearch .= 'u.SmokingID = '.intval($_GET['sm']).' and ';
	if(intval($_GET['dr'])>0)
		$strsearch .= 'u.DrinkingID = '.intval($_GET['dr']).' and ';
	if(intval($_GET['ed'])>0)
		$strsearch .= 'u.EducationID = '.intval($_GET['ed']).' and ';
	if(intval($_GET['r'])>0)
		$strsearch .= 'u.ReligionID = '.intval($_GET['r']).' and ';
	if(intval($_GET['rh'])>0)
		$strsearch .= 'u.HaveChildren = '.intval($_GET['rh']).' and ';
	if(intval($_GET['w'])>0)
		$strsearch .= 'u.WantChildren = '.intval($_GET['w']).' and ';
	}
if(intval($_SESSION['memberid'])>0)
	$sqlsearch .= 'u.UserID <> '.$_SESSION['memberid'].' and ';

$title = $resultssearch;
require_once 'includes/header.php';
$ismenu = 3;
require_once 'includes/menus.php';
$config['showeachside'] = 4;
$config['per_page'] = 30;
$config['js_numrows_page'] = countSearchProfile($strsearch, intval($_GET['o']));
$config['curpage'] = empty($_GET['p'])?1:$_GET['p'];
$config['rs_start'] = ($config['curpage']*$config['per_page'])-$config['per_page'];
if($config['js_numrows_page'] < $config['per_page'])
	$config['per_page'] = $config['js_numrows_page'];
$str = '';
foreach($_GET as $name => $val){
	if($name != 'p')
		$str .= $name.'='.$val.'&';
	}
$config['cururl'] = $base_url.'results.php?'.substr($str, 0, -1);
$paging = Pagination($config);
?>
       <div class="maincontent"><br />
       		<div id="searchs">
            	<h3><?php echo $title;?></h3>
                <p style="padding-left:10px; line-height:25px"><i><?php echo str_replace('<num>', $config['js_numrows_page'], $totalresults);?></i>&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="button" value="<?php echo $editsearch;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'search.php?'.substr($str, 0, -1);?>', 0)" />&nbsp;<input type="button" value="<?php echo $newsearch;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'search.php';?>', 0)" />
                <?php
				if($_SESSION['memberid'] && $config['js_numrows_page']>0){
					echo '<input type="text" style="width:265px;" placeholder="'.$notesearchname.'" style="font-style:italic; margin-left:260px;" id="keyword" />';
					echo '&nbsp;<input type="button" value="'.$saveresults.'" class="massbutton" onclick="redirect(\''.$base_url.'alerts.php?ty=1'.'\', 1)" />';
					$_SESSION['strquery'] = substr($str, 0, -1);
					}
				elseif($config['js_numrows_page']>0){
					echo '&nbsp;<input type="button" value="'.$loginsave.'" class="massbutton" onclick="redirect(\''.$base_url.'signin.php'.'\', 0)" />';
					$_SESSION['direct'] = $base_url.'results.php?'.$_SERVER['QUERY_STRING'];
					}
				?>
                </p>
                	<?php
					if(intval($_GET['o'])>0)
						$sql = "select u.UserID, SUBSTRING_INDEX(ProfileName, ' ', 4) as ProfileName, Age, REPLACE(REPLACE(AboutMe, '.', '. '), ',', ', ') as AboutMe, SUBSTRING_INDEX(REPLACE(REPLACE(AboutMe, '.', '. '), ',', ', '),' ', 4) as subAboutMe, City, MatchAgeFrom, MatchAgeTO, LastLogon, PrimaryPhotoID, ".$_SESSION['lang']."MaritalStatus as LMaritalStatus, State, Country, ".$_SESSION['lang']."Gender as LGender, PhotoExtension, RemainVIPContacts from ".$table_prefix."users as u left join ".$table_prefix."maritalstatus as m on u.MaritalStatusID = m.MaritalStatusID left join ".$table_prefix."states as s on u.StateID = s.StateID left join ".$table_prefix."countries as c on u.CountryID = c.CountryID left join ".$table_prefix."gender as g on u.MatchGenderID = g.GenderID left join ".$table_prefix."photos as p on u.PrimaryPhotoID = p.PhotoID AND p.IsApproved = 1 where ".$strsearch." u.ProfileStatusID = 1 and u.GenderID IS NOT NULL AND p.PhotoID IS not NULL and GroupID <> 5 order by RemainVIPContacts desc, LastLogon desc";
					else $sql = "select u.UserID, SUBSTRING_INDEX(ProfileName, ' ', 4) as ProfileName, Age, REPLACE(REPLACE(AboutMe, '.', '. '), ',', ', ') as AboutMe, SUBSTRING_INDEX(REPLACE(REPLACE(AboutMe, '.', '. '), ',', ', '),' ', 4) as subAboutMe, City, MatchAgeFrom, MatchAgeTO, LastLogon, PrimaryPhotoID, ".$_SESSION['lang']."MaritalStatus as LMaritalStatus, State, Country, ".$_SESSION['lang']."Gender as LGender, PhotoExtension, RemainVIPContacts from ".$table_prefix."users as u left join ".$table_prefix."maritalstatus as m on u.MaritalStatusID = m.MaritalStatusID left join ".$table_prefix."states as s on u.StateID = s.StateID left join ".$table_prefix."countries as c on u.CountryID = c.CountryID left join ".$table_prefix."gender as g on u.MatchGenderID = g.GenderID left join ".$table_prefix."photos as p on u.PrimaryPhotoID = p.PhotoID AND p.IsApproved = 1 where ".$strsearch." u.ProfileStatusID = 1 and u.GenderID IS NOT NULL and GroupID <> 5 order by RemainVIPContacts desc, LastLogon desc";
					$sql = $sql." limit ".$config['rs_start'].", ".$config['per_page'];
					$qry = mysql_query($sql);
					if(!$qry)
						exit($errordata);
					else{
						$i=1;
						$j=1;
						while($rows = mysql_fetch_array($qry)){
							$mvip = ($rows['RemainVIPContacts']==1)?'style="background:url(imgs/icon_vip.gif) #FFFFFF no-repeat right 30px"':'';
							$city = '';
							if(!empty($rows['State'])) $city .= $rows['State'].', ';
							$city .= $rows['Country'];
							$aboutme = (strlen($rows['AboutMe'])>22)?str_replace('....', ' ', $rows['subAboutMe']).' ...':$rows['AboutMe'];
							$aboutme = str_replace('-', ' - ', $aboutme);
							if(is_int($j/2)){
							?>
								<div class="memcnter" <?php echo $mvip;?>>
									<p class="tbltop"><b><a href="viewprofile.php?id=<?php echo $rows['UserID'];?>"><?php echo $rows['ProfileName'].' ('.$rows['Age'].') / '.$rows['LMaritalStatus'];?></a></b></p>
									<table width="100%" cellpadding="3" cellspacing="3">
										<tr>
											<td width="35%"><a href="viewprofile.php?id=<?php echo $rows['UserID'];?>">
                                            	<?php
												if($rows['PrimaryPhotoID']==0 || !file_exists('fuploads/'.$rows['UserID'].'u'.$rows['PrimaryPhotoID'].'.'.$rows['PhotoExtension']) || empty($rows['PhotoExtension']))
													echo '<img src="imgs/noimage.jpg" border="0"/>';
												else echo '<img src="fuploads/'.$rows['UserID'].'u'.$rows['PrimaryPhotoID'].'.'.$rows['PhotoExtension'].'" border="0"/>';
												?>
                                            </a></td>
											<td width="65%" valign="top" align="left">
												<p class="desc"><?php echo preg_replace('/(\w+) (\w+) (\w+),(\w+)/i', '${1} 1 2, $3', $aboutme);?></p>
												<p style="padding-top:15px;"><?php echo $city;?></p>
												<p><b><?php echo $wantfind;?>:</b> <?php echo $rows['LGender'].' '.$rows['MatchAgeFrom'].' - '.$rows['MatchAgeTO'];?></p><p><small><i><b><?php echo $signin;?>:</b> <?php echo date('H:i:s d-m-Y', strtotime($rows['LastLogon']));?></i></small></p><br />
												<p><input type="button" value="Email" class="massbutton" onclick="redirect('<?php echo $base_url.'members/compose.php?pr='.$rows['UserID'];?>', 0)"/>&nbsp;<input type="button" value="<?php echo $signal;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'alerts.php?ty=2&pr='.$rows['UserID'];?>', 0)"/>&nbsp;<input type="button" value="<?php echo $saveit;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'alerts.php?ty=3&pr='.$rows['UserID'];?>', 0)"/></p>
											</td>
										</tr>
									</table>
								</div>
							<?php
								}
							elseif(is_int($j/3)){
							?>
								<div class="memright" <?php echo $mvip;?>>
									<p class="tbltop"><b><a href="viewprofile.php?id=<?php echo $rows['UserID'];?>"><?php echo $rows['ProfileName'].' ('.$rows['Age'].') / '.$rows['LMaritalStatus'];?></a></b></p>
									<table width="100%" cellpadding="3" cellspacing="3">
										<tr>
											<td width="35%"><a href="viewprofile.php?id=<?php echo $rows['UserID'];?>"><?php
												if($rows['PrimaryPhotoID']==0 || !file_exists('fuploads/'.$rows['UserID'].'u'.$rows['PrimaryPhotoID'].'.'.$rows['PhotoExtension']) || empty($rows['PhotoExtension']))
													echo '<img src="imgs/noimage.jpg" border="0"/>';
												else echo '<img src="fuploads/'.$rows['UserID'].'u'.$rows['PrimaryPhotoID'].'.'.$rows['PhotoExtension'].'" border="0"/>';
												?>
                                             </a></td>
											<td width="65%" valign="top" align="left">
												<p class="desc"><?php echo $aboutme;?></p>
												<p style="padding-top:15px;"><?php echo $city;?></p>
												<p><b><?php echo $wantfind;?>:</b> <?php echo $rows['LGender'].' '.$rows['MatchAgeFrom'].' - '.$rows['MatchAgeTO'];?></p><p><small><i><b><?php echo $signin;?>:</b> <?php echo date('H:i:s d-m-Y', strtotime($rows['LastLogon']));?></i></small></p><br />
												<p><input type="button" value="Email" class="massbutton" onclick="redirect('<?php echo $base_url.'members/compose.php?pr='.$rows['UserID'];?>', 0)"/>&nbsp;<input type="button" value="<?php echo $signal;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'alerts.php?ty=2&pr='.$rows['UserID'];?>', 0)"/>&nbsp;<input type="button" value="<?php echo $saveit;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'alerts.php?ty=3&pr='.$rows['UserID'];?>', 0)"/></p>
											</td>
										</tr>
									</table>
								</div>
							<?php
								}
							else{
								?>
								<div class="memleft" <?php echo $mvip;?>>
									<p class="tbltop"><b><a href="viewprofile.php?id=<?php echo $rows['UserID'];?>"><?php echo $rows['ProfileName'].' ('.$rows['Age'].') / '.$rows['LMaritalStatus'];?></a></b></p>
									<table width="100%" cellpadding="3" cellspacing="3">
										<tr>
											<td width="35%"><a href="viewprofile.php?id=<?php echo $rows['UserID'];?>"><?php
												if($rows['PrimaryPhotoID']==0 || !file_exists('fuploads/'.$rows['UserID'].'u'.$rows['PrimaryPhotoID'].'.'.$rows['PhotoExtension']) || empty($rows['PhotoExtension']))
													echo '<img src="imgs/noimage.jpg" border="0"/>';
												else echo '<img src="fuploads/'.$rows['UserID'].'u'.$rows['PrimaryPhotoID'].'.'.$rows['PhotoExtension'].'" border="0"/>';
												?>
                                             </a></td>
											<td width="65%" valign="top" align="left">
												<p class="desc"><?php echo str_replace(',', ', ', $aboutme);?></p>
												<p style="padding-top:15px;"><?php echo $city;?></p>
												<p><b><?php echo $wantfind;?>:</b> <?php echo $rows['LGender'].' '.$rows['MatchAgeFrom'].' - '.$rows['MatchAgeTO'];?></p><p><small><i><b><?php echo $signin;?>:</b> <?php echo date('H:i:s d-m-Y', strtotime($rows['LastLogon']));?></i></small></p><br />
												<p><input type="button" value="Email" class="massbutton" onclick="redirect('<?php echo $base_url.'members/compose.php?pr='.$rows['UserID'];?>', 0)"/>&nbsp;<input type="button" value="<?php echo $signal;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'alerts.php?ty=2&pr='.$rows['UserID'];?>', 0)"/>&nbsp;<input type="button" value="<?php echo $saveit;?>" class="massbutton" onclick="redirect('<?php echo $base_url.'alerts.php?ty=3&pr='.$rows['UserID'];?>', 0)"/></p>
											</td>
										</tr>
									</table>
								</div>
								<?php
								}
							if($j==3)
								$j=0;
							$j++;
							$i++;
							}
						}
					if(!empty($paging))
						echo '<p id="paging" style="clear:both; margin-right:0px; text-align:center">'.$paging.'</p>';
					?>
                <p class="linespace">&nbsp;</p>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
if($_SESSION['memberid'] && $_SESSION['direct'])
	unset($_SESSION['direct']);
$_SESSION['process'] = true;
require_once 'includes/footer.php';
?>