<?php
require_once "includes/config.php";
require_once "includes/database.php";
require_once "includes/functions.php";
$title = 'Options to find profile';
require_once 'includes/header.php';
$ismenu = 5;
require_once 'includes/menus.php';
$opsearch = getSaveSearch();
?>
       <div class="maincontent"><br />
       <form action="" method="post">
       		<div id="browsemail">
                <div class="titletop">
                	<div class="lefttitletop">
                    	<h3><?php echo $title;?></h3>
                    </div>
                    <div class="righttitletop">&nbsp;</div>
                    <p class="linespace">&nbsp;</p>
                </div>
                <table width="100%" cellpadding="0" cellspacing="0">
                	<tr bgcolor="#637bad">
                        <td width="5%" class="blacklistrows1" align="center"><?php echo $order;?></td>
                        <td width="85%" class="blacklistrows2" align="left">&nbsp;<?php echo $profilename;?></td>
                        <td width="10%" class="blacklistrows2" align="center"><?php echo $updatesearch;?></td>
                    </tr>
                    <?php
					$i=1;
					while($rows=mysql_fetch_array($opsearch)){
						$blcl = (is_int($i/2))?'bgcolor="#F2F2F2"':'';
						?>
                        <tr <?php echo $blcl;?>>
                            <td width="5%" class="blacklistrows3" align="center"><?php echo $i;?></td>
                            <td width="85%" class="blacklistrows4" align="left">&nbsp;<a href="<?php echo $base_url;?>results.php?<?php echo $rows['SearchValue'];?>"><?php echo $rows['SearchName'];?></a></td>
                            <td width="10%" class="blacklistrows4" align="center"><a href="<?php echo $base_url;?>search.php?<?php echo $rows['SearchValue'];?>"><?php echo $uedit;?></a></td>
                        </tr>
                        <?php
						$i++;
						}
					?>
                </table>
                <p class="linespace"><br />&nbsp;</p><br />&nbsp;
            </div>
            <p class="linespace">&nbsp;</p></form>
       </div>
<?php
mysql_close();
require_once 'includes/footer.php';
?>