<?php
require_once "includes/config.php";
if(!$_SESSION['memberid'] || $_SESSION['memberid']==0){
	header('Location: '.$base_url.'signin.php');
	exit();
	}
require_once "includes/database.php";
require_once "includes/functions.php";
if(!$_SESSION['process']){
	$title = $alert;
	$message = '<font color="#FF0000"><i>'.$datainvalid.'</i></font>';
	}
else{
	unset($_SESSION['process']);
	if(isset($_GET['ty'])){
		switch($_GET['ty']){
			case 1: // save search
				$title = $savesearch;
				$direct = $_SESSION['strquery'];
				unset($_SESSION['strquery']);
				if(!saveSearch($direct, $_SESSION['memberid'], mysql_real_escape_string($_GET['k'])))
					$message = '<font color="#FF0000"><i>'.$errordata.'</i></font>';
				else $message = str_replace('<link>', '<a href="'.$base_url.'members/savedsearch.php">', str_replace('</link>', '</a>', $messsearch));
			break;
			case 2: // send signal
				if(intval($_GET['pr'])==0){
					$title = $alert;
					$message = '<font color="#FF0000"><i>'.$datainvalid.'</i></font>';
					}
				else{
					$title = $requestsend;
					if(!sendSignal($_SESSION['memberid'], intval($_GET['pr'])))
						$message = '<font color="#FF0000"><i>'.$errordata.'</i></font>';
					else{
						$message = str_replace('<name>', GetProfileName($_GET['pr']), $sentsignal);
						$message = str_replace('<linka>', '<a href="'.$base_url.'members/youvaforites.php">', str_replace('</linka>', '</a>', $message));
						$message = str_replace('<linkb>', '<a href="'.$base_url.'members/vaforitesyou.php">', str_replace('</linkb>', '</a>', $message));
						}
					}
			break;
			case 3: // save profile
				if(intval($_GET['pr'])==0){
					$title = $alert;
					$message = '<font color="#FF0000"><i>'.$datainvalid.'/i></font>';
					}
				else{
					$title = $profilesaved;
					$rs = savingProfile($_SESSION['memberid'], intval($_GET['pr']));
					if($rs==-1)
						$message = '<font color="#FF0000"><i>'.$errordata.'</i></font>';
					elseif($rs==0)
						$message = str_replace('<linka>', '<a href="'.$base_url.'members/hostlist.php">', str_replace('</linka>', '</a>', $exitsprofilesaved));
					else $message = str_replace('<linka>', '<a href="'.$base_url.'members/hostlist.php">', str_replace('</linka>', '</a>', $succprofilesaved));
					}
			break;
			case 4: // delete from saved profile
				if(intval($_GET['pr'])==0){
					$title = $alert;
					$message = '<font color="#FF0000"><i>'.$datainvalid.'/i></font>';
					}
				else{
					$title = $delprofilesaved;
					if(!delSavedProfile($_SESSION['memberid'], intval($_GET['pr'])))
						$message = '<font color="#FF0000"><i>'.$errordata.'</i></font>';
					else $message = str_replace('<linka>', '<a href="'.$base_url.'members/hostlist.php">', str_replace('</linka>', '</a>', $succdelprofilesaved));
					}
			break;
			case 5: // delete from favorite profile
				if(intval($_GET['pr'])==0){
					$title = $alert;
					$message = '<font color="#FF0000"><i>'.$datainvalid.'/i></font>';
					}
				else{
					$title = $delprofilesaved;
					if(!delFavoriteProfile($_SESSION['memberid'], intval($_GET['pr'])))
						$message = '<font color="#FF0000"><i>'.$errordata.'</i></font>';
					else $message = str_replace('<linka>', '<a href="'.$base_url.'members/youvaforites.php">', str_replace('</linka>', '</a>', $succdelfavorite));;
					}
			break;
			default:
				$title = $alert;
				$message = $datainvalid;
			break;
			}
		}
	else{
		$title = $alert;
		$message = '<font color="#FF0000"><i>'.$datainvalid.'</i></font>';
		}
	}
require_once 'includes/header.php';
require_once 'includes/menus.php';
?>
       <div class="maincontent"><br />
       		<div class="signup">
            	<form action="" method="post">
            	<p class="styletop"><?php echo $title;?></p>
                <?php
				if(isset($error) && !empty($error))
					echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
				?>
                <br />
                	<p style="padding-left:20px; line-height:25px">
                    <?php echo $message;?>
                    
                    </p>
                <br />
                <div class="stylebott" align="center">
                    	<p style="margin:0px; padding:7px 0px;">&nbsp;</p>
                </div>
                </form>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
require_once 'includes/footer.php';
?>