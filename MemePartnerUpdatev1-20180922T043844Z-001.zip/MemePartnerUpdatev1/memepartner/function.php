<?php 

	function db(){
		return new PDO("mysql:host=localhost; dbname=scroll", "root", "");
	}
	function add_comment($user_id, $description){
		$db = db();
		$sql = "insert into dt_posts(UserID, Description) values(?,?)";
		$st = $db->prepare($sql);
		$st->execute(array($user_id, $description));
		$db = null;
	}
?>