<?php
require_once "includes/config.php";
if(!$_SESSION['user_temp'] || $_SESSION['user_temp']==0){
	header('Location: '.$base_url.'signup.php');
	exit();
	}
require_once "includes/database.php";
require_once "includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smdetails'])){
	if(empty($_POST['profilename']))
		$err_p = $profilenull;
	elseif(strlen($_POST['profilename'])<6)
		$err_p = $datashort;
	elseif(empty($_POST['abloutme']))
		$err_a = $aboutnull;
	elseif(strlen($_POST['abloutme'])<6)
		$err_a = $datashort;
	elseif(intval($_POST['slcountry'])==0)
		$err_co = $countrynull;
	elseif(intval($_POST['slcity'])==0)
		$err_ci = $statenull;
	elseif(empty($_POST['txtinterests']))
		$err_i = $interestnull;
	elseif(strlen($_POST['txtinterests'])<6)
		$err_i = $datashort;
	else{
		$data = array(mysql_real_escape_string($_POST['profilename']), mysql_real_escape_string($_POST['abloutme']), $_POST['rdgender'], $_POST['slage'], $_POST['slcountry'], $_POST['slcity'], mysql_real_escape_string($_POST['txtstate']), mysql_real_escape_string($_POST['zipcode']), mysql_real_escape_string($_POST['txtinterests']), $_POST['slMarital'], mysql_real_escape_string($_POST['opcupation']), mysql_real_escape_string($_POST['phone']), $_POST['slReligion'], $_POST['slEducation'], $_POST['slBodyType'], $_POST['slHairColor'], $_POST['slEyeColor'], $_POST['slHeight'], $_POST['slSmoking'], $_POST['slDrinking'], $_POST['rdhave'], $_POST['rdwant'], $_POST['sltravel']);
		if(!yourdetails($data, $_SESSION['user_temp']))
			$error = $errordata;
		else{
			mysql_close();
			header('Location: '.$base_url.'yourmatch.php');
			exit();
			}
		}
	}
$title = $aboutme;
require_once 'includes/header.php';
require_once 'includes/menus.php';
$isstep = 2;
require_once 'includes/stepreg.php';
?>
<script language="javascript">
$(document).ready(function(){
		$('#slcountry').change(function() {
			var valchange = this.value;
	  		$('#slcity').load('includes/loadcities.php?countryId=' + valchange);
	  		});
		});
</script>
       <div class="maincontent"><br />
       		<div class="signup sudwidth700">
            	<form action="" method="post">
            	<p class="styletop"><?php echo $title;?></p>
                <?php
				if(isset($error) && !empty($error))
					echo '<p style="margin:0px; padding:5px 20px"><font color="#FF0000"><small><i>'.$error.'</i></small></font></p>';
				?>
                <br />
                <table width="100%" cellpadding="3" cellspacing="3">
                	<tr>
                    	<td width="30%" align="right" valign="top"><?php echo $profilename;?>: </td>
                        <td width="70%" align="left"><input type="text" style="width:265px;" name="profilename" value="<?php echo isset($_POST['profilename'])?$_POST['profilename']:'';?>" /><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_p) && !empty($err_p))
							echo '<br><font color="#FF0000"><small><i>'.$err_p.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right"><?php echo $aboutyou;?>: </td>
                        <td width="70%" align="left">
                        <textarea rows="3" cols="40" name="abloutme"><?php echo isset($_POST['abloutme'])?$_POST['abloutme']:'';?></textarea>
                        <font color="#FF0000"> *</font>
                        <?php
						if(isset($err_a) && !empty($err_a))
							echo '<br><font color="#FF0000"><small><i>'.$err_a.'</i></small></font>';
						?>
                        </td>
                    </tr>
                	<tr>
                    	<td width="30%" align="right" valign="top"><?php echo $youare;?>: </td>
                        <td width="70%" align="left">
                        <?php
						if(isset($_POST['rdgender'])){
							if($_POST['rdgender']==1){
								$gen1 = ' checked="checked"';
								$gen2 = '';
								}
							elseif($_POST['rdgender']==2){
								$gen1 = '';
								$gen2 = ' checked="checked"';
								}
							}
						else{
							$gen1 = ' checked="checked"';
							$gen2 = '';
							}
						?>
                        <input type="radio" value="1" style="margin-left:0px; padding-left:0px;" <?php echo $gen1;?> name="rdgender"/>&nbsp;<?php echo $male;?><input type="radio" value="2" style="margin-left:40px; padding-left:0px;" name="rdgender" <?php echo $gen2;?>/>&nbsp;<?php echo $female;?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $age;?>: </td>
                        <td width="70%" align="left">
                        <select name="slage">
                        	<?php
							for($i=18; $i<76; $i++){
								$val = isset($_POST['slage'])?$_POST['slage']:18;
								$sel = ($val==$i)?' selected="selected"':'';
								echo '<option value="'.$i.'" '.$sel.'>'.$i.'</option>';
								}
							?>
                        </select>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $country;?>: </td>
                        <td width="70%" align="left">
                        <select name="slcountry" id="slcountry"><option value="0">- - <?php echo $select;?> - -</option>
                        	<?php
							$sel = isset($_POST['slcountry'])?$_POST['slcountry']:0;
							$sqlcountry = 'select CountryID as Id, Country as LName from '.$table_prefix.'countries order by TopSorted desc, LName asc';
							dropdownlist($sqlcountry, $sel);
							?>
                        </select><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_co) && !empty($err_co))
							echo '<br><font color="#FF0000"><small><i>'.$err_co.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $state;?>: </td>
                        <td width="70%" align="left">
                        <select name="slcity" id="slcity">
                        	<?php
							if(isset($_POST['slcountry']) && $_POST['slcountry']>0){
								$sql = 'select StateID as Id, State as LName from '.$table_prefix.'states where CountryID = '.intval($_POST['slcountry']).' order by TopSorted desc, LName asc';
								dropdownlist($sql, $_POST['slcity']);
								}
							else{
								echo '<option value="0">- - '.$select.' - -</option>';
								}
							?>
                        </select><font color="#FF0000"> *</font>
                        <?php
						if(isset($err_ci) && !empty($err_ci))
							echo '<br><font color="#FF0000"><small><i>'.$err_ci.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $city;?>: </td>
                        <td width="70%" align="left"><input type="text" style="width:265px;" name="txtstate" value="<?php echo isset($_POST['txtstate'])?$_POST['txtstate']:'';?>" maxlength="255"/>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $zipcode;?>: </td>
                        <td width="70%" align="left"><input type="text" size="10" name="zipcode" value="<?php echo isset($_POST['zipcode'])?$_POST['zipcode']:'';?>" maxlength="10"/>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right"><?php echo $interest;?>: </td>
                        <td width="70%" align="left">
                        <textarea rows="3" cols="40" name="txtinterests"><?php echo isset($_POST['txtinterests'])?$_POST['txtinterests']:'';?></textarea>
                        <font color="#FF0000"> *</font>
                        <?php
						if(isset($err_i) && !empty($err_i))
							echo '<br><font color="#FF0000"><small><i>'.$err_i.'</i></small></font>';
						?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $marital;?>: </td>
                        <td width="70%" align="left">
                        <select name="slMarital">
                        	<?php
							$sel = isset($_POST['slMarital'])?$_POST['slMarital']:1;
							$sql = 'select MaritalStatusID as Id, '.$_SESSION['lang'].'MaritalStatus as LName from '.$table_prefix.'maritalstatus order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $opcupation;?>: </td>
                        <td width="70%" align="left"><input type="text" style="width:265px;" name="opcupation" value="<?php echo isset($_POST['opcupation'])?$_POST['opcupation']:'';?>" />
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $phone;?>: </td>
                        <td width="70%" align="left"><input type="text" style="width:265px;" name="phone" value="<?php echo isset($_POST['phone'])?$_POST['phone']:'';?>" />
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $religion;?>: </td>
                        <td width="70%" align="left">
                        <select name="slReligion">
                        	<?php
							$sel = isset($_POST['slReligion'])?$_POST['slReligion']:1;
							$sql = 'select ReligionID as Id, '.$_SESSION['lang'].'Religion as LName from '.$table_prefix.'religions order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $education;?>: </td>
                        <td width="70%" align="left">
                        <select name="slEducation">
                        	<?php
							$sel = isset($_POST['slEducation'])?$_POST['slEducation']:1;
							$sql = 'select EducationID as Id, '.$_SESSION['lang'].'Education as LName from '.$table_prefix.'educations order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $bodytype;?>: </td>
                        <td width="70%" align="left">
                        <select name="slBodyType">
                        	<?php
							$sel = isset($_POST['slBodyType'])?$_POST['slBodyType']:1;
							$sql = 'select BodyTypeID as Id, '.$_SESSION['lang'].'BodyType as LName from '.$table_prefix.'bodytypes order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $haircolor;?>: </td>
                        <td width="70%" align="left">
                        <select name="slHairColor">
                        	<?php
							$sel = isset($_POST['slHairColor'])?$_POST['slHairColor']:1;
							$sql = 'select HairColorID as Id, '.$_SESSION['lang'].'HairColor as LName from '.$table_prefix.'haircolors order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $eyeColor;?>: </td>
                        <td width="70%" align="left">
                        <select name="slEyeColor">
                        	<?php
							$sel = isset($_POST['slEyeColor'])?$_POST['slEyeColor']:1;
							$sql = 'select EyeColorID as Id, '.$_SESSION['lang'].'EyeColor as LName from '.$table_prefix.'eyescolors order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $height;?>: </td>
                        <td width="70%" align="left">
                        <select name="slHeight">
                        	<?php
							$sel = isset($_POST['slHeight'])?$_POST['slHeight']:358;
							$sql = 'select HeightID as Id, HeightDescription as LName from '.$table_prefix.'height order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $smoking;?>: </td>
                        <td width="70%" align="left">
                        <select name="slSmoking">
                        	<?php
							$sel = isset($_POST['slSmoking'])?$_POST['slSmoking']:1;
							$sql = 'select SmokingID as Id, '.$_SESSION['lang'].'Smoking as LName from '.$table_prefix.'smoking order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $drinking;?>: </td>
                        <td width="70%" align="left">
                        <select name="slDrinking">
                        	<?php
							$sel = isset($_POST['slDrinking'])?$_POST['slDrinking']:1;
							$sql = 'select DrinkingID as Id, '.$_SESSION['lang'].'Drinking as LName from '.$table_prefix.'drinking order by TopSorted desc, LName asc';
							dropdownlist($sql, $sel);
							?>
                        </select>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $havechild;?> ? </td>
                        <td width="70%" align="left">
                        <?php
						if(isset($_POST['rdhave'])){
							if($_POST['rdhave']==2){
								$rdhave1 = ' checked="checked"';
								$rdhave2 = '';
								}
							elseif($_POST['rdhave']==3){
								$rdhave1 = '';
								$rdhave2 = ' checked="checked"';
								}
							}
						else{
							$rdhave1 = ' checked="checked"';
							$rdhave2 = '';
							}
						?>
                        <input type="radio" value="2" style="margin-left:0px; padding-left:0px;" <?php echo $rdhave1;?> name="rdhave"/>&nbsp;<?php echo $yes;?><input type="radio" value="3" style="margin-left:40px; padding-left:0px;" name="rdhave" <?php echo $rdhave2;?>/>&nbsp;<?php echo $not;?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $wantchild;?> ? </td>
                        <td width="70%" align="left">
                        <?php
						if(isset($_POST['rdwant'])){
							if($_POST['rdwant']==2){
								$rdwant1 = ' checked="checked"';
								$rdwant2 = '';
								}
							elseif($_POST['rdwant']==3){
								$rdwant1 = '';
								$rdwant2 = ' checked="checked"';
								}
							}
						else{
							$rdwant1 = ' checked="checked"';
							$rdwant2 = '';
							}
						?>
                        <input type="radio" value="2" style="margin-left:0px; padding-left:0px;" name="rdwant" <?php echo $rdwant1;?>/>&nbsp;<?php echo $yes;?><input type="radio" value="3" style="margin-left:40px; padding-left:0px;" name="rdwant" <?php echo $rdwant2;?>/>&nbsp;<?php echo $notwant;?>
                        </td>
                    </tr>
                    <tr>
                    	<td width="30%" align="right" valign="top"><?php echo $abletogo;?> </td>
                        <td width="70%" align="left">
                        <select name="sltravel">
                        <?php
							for($i=50; $i<501; $i++)
								echo '<option value="'.$i.'">'.$i.'</option>';
							?>
                        </select> <?php echo $tovisit;?>
                        </td>
                    </tr>
                </table><br />
                <div class="stylebott">
                	<div class="bottleft"><?php echo $aboutwithother;?></div>
                    <div class="bottright">
                    	<input type="submit" value="<?php echo $continute;?>" class="massbutton" name="smdetails"/>&nbsp;<input type="reset" value="<?php echo $cancel;?>" class="massbutton"/>
                    </div>
                    <p class="linespace">&nbsp;</p>
                </div>
                </form>
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
mysql_close();
require_once 'includes/footer.php';
?>