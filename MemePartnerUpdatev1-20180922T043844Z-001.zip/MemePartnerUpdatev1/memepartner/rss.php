<?php
    header("Content-Type: application/rss+xml; charset=utf-8");
 
require_once "includes/config.php";
require_once "includes/database.php";
require_once "includes/functions.php";
 
    $rssfeed = '<?xml version="1.0" encoding="utf-8"?>';
    $rssfeed .= '<rss version="2.0">';
    $rssfeed .= '<channel>';
    $rssfeed .= "<title>".$sitename." RSS </title>";
    $rssfeed .= "<link>".$base_url."</link>";
    $rssfeed .= "<description>Share new jobs from ".$sitename."</description>";
    $rssfeed .= "<language>en-vi</language>";
    $rssfeed .= "<copyright>Copyright (C) ".date('Y')." ".$sitename."</copyright>";
 
    Connect_Database();
	$day = getdate();
	$curday = strtotime($day['year']."-".$day['mon']."-".$day['mday']);
	//$query = "SELECT OtherJobTitle , JobTitle,  Id FROM ".$prefix."jobs where IsDelete=0 and IsApprove = 1 ORDER BY DateCreate DESC limit 0,10 ";
     $query = "select j.Id as jId, j.UserId as jUserId, SUBSTRING_INDEX(OtherJobTitle, ' ',6) as Title, OtherJobTitle, CompanyName, pn.".$lang."Position as lPosition, SUBSTRING_INDEX(pnn.".$lang."Position, ' ',6) as PosTitle from ".$prefix."jobs as j inner join ".$prefix."employers as e on e.Id = j.UserId left join ".$prefix."position_nganhnghe as pn on pn.Id = j.JobTitle left join ".$prefix."position_nganhnghe as pnn on pnn.Id = j.JobTitle where ExpiringDate >= $curday and  IsDelete = 0 and IsApprove = 1 order by j.Id DESC";
	 
    $result = QuerySQL($query);
    while($row = @mysql_fetch_array($result)) {
		$title = $row['Title'];
		if($title=="") $title=$row['lPosition'];
		$link = $real_path."jobseeker/job_details.php?id=".$row['jId'];
		$description = $row['CompanyName'];
		$title = str_replace("&", "and", $title);
		$description = str_replace("&", "and", $description);				
        $rssfeed .= '<item>';
        $rssfeed .= '<title>' . $title . '</title>';
		$rssfeed .= '<description>' . $description . '</description>';
        $rssfeed .= '<link>' . $link . '</link>';
        $rssfeed .= '<pubDate>' . date("D, d M Y H:i:s O", strtotime($date)) . '</pubDate>';
        $rssfeed .= '</item>';
    }
 
    $rssfeed .= '</channel>';
    $rssfeed .= '</rss>';
    echo $rssfeed;
	Close_Connect();
?>