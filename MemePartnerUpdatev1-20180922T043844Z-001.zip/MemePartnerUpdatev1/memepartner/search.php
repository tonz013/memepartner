<?php
require_once "includes/config.php";
require_once "includes/database.php";
require_once "includes/functions.php";
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['smsearch'])){
	$strqury = '';
	if(intval($_POST['findgen'])>0)
		$strqury .= 'fg='.$_POST['findgen'].'&';
	if(intval($_POST['slagefrom'])>0)
		$strqury .= 'af='.$_POST['slagefrom'].'&';
	if(intval($_POST['slageto'])>0)
		$strqury .= 'at='.$_POST['slageto'].'&';
	if(intval($_POST['slMarital'])>0)
		$strqury .= 'm='.$_POST['slMarital'].'&';
	if(intval($_POST['slcountry'])>0)
		$strqury .= 'c='.$_POST['slcountry'].'&';
	if(intval($_POST['slcity'])>0)
		$strqury .= 'st='.$_POST['slcity'].'&';
	if(!empty($_POST['txtprovince']))
		$strqury .= 'tp='.$_POST['txtprovince'].'&';
	if(intval($_POST['slDatingInterest'])>0)
		$strqury .= 'd='.$_POST['slDatingInterest'].'&';
	$strqury .= ($_POST['onlyphoto'])=='on'?'o=1&':'o=0&';
	if(intval($_POST['typesearch'])==1){
		if(!empty($_POST['profilename']))
			$strqury .= 'pr='.urlencode($_POST['profilename']).'&';
		if(!empty($_POST['about']))
			$strqury .= 'ab='.$_POST['about'].'&';
		if(intval($_POST['slHairColor'])>0)
			$strqury .= 'h='.$_POST['slHairColor'].'&';
		if(intval($_POST['slEyeColor'])>0)
			$strqury .= 'e='.$_POST['slEyeColor'].'&';
		if(intval($_POST['slHeightfrom'])>0)
			$strqury .= 'hf='.$_POST['slHeightfrom'].'&';
		if(intval($_POST['slHeightto'])>0)
			$strqury .= 'ht='.$_POST['slHeightto'].'&';
		if(intval($_POST['slBodyType'])>0)
			$strqury .= 'b='.$_POST['slBodyType'].'&';
		if(intval($_POST['slSmoking'])>0)
			$strqury .= 'sm='.$_POST['slSmoking'].'&';
		if(intval($_POST['slDrinking'])>0)
			$strqury .= 'dr='.$_POST['slDrinking'].'&';
		if(intval($_POST['slEducation'])>0)
			$strqury .= 'ed='.$_POST['slEducation'].'&';
		if(intval($_POST['slReligion'])>0)
			$strqury .= 'r='.$_POST['slReligion'].'&';
		if(intval($_POST['rdhave'])>0)
			$strqury .= 'rh='.$_POST['rdhave'].'&';
		if(intval($_POST['rdwant'])>0)
			$strqury .= 'w='.$_POST['rdwant'].'&';
		$strqury .= 't=1';
		}
	else $strqury .= 't=0';
	header('Location: '.$base_url.'results.php?'.$strqury);
	exit();
	}
$title = $findprofile;
require_once 'includes/header.php';
$ismenu = 3;
require_once 'includes/menus.php';
if(isset($_GET['t']) && intval($_GET['t']==1)){
	$adds = 'style="display:none"';
	$subs = '';
	}
else{
	$adds = '';
	$subs = 'style="display:none"';
	}
?>
<script language="javascript">
function changeSearch(str1, str2, str3, str4, str5, intval){
	document.getElementById(str1).style.display = 'none';
	document.getElementById(str2).style.display = '';
	document.getElementById(str3).style.display = str4;
	document.getElementById(str5).value = intval;
}
$(document).ready(function(){
		$('#slcountry').change(function() {
			var valchange = this.value;
	  		$('#slcity').load('includes/loadcities.php?countryId=' + valchange);
	  		});
		});
</script>
       <div class="maincontent"><br />
       		<div id="searchs">
            	<h3><?php echo $title;?></h3>
                	<div class="dispsearch">
                    <form action="" method="post">
                    	<p class="heads"><?php echo $quicksearch;?></p>
                        	<table width="70%" cellpadding="3" cellspacing="3">
                            	<tr>
                                	<td width="25%" align="right"><?php echo $youare.' : ';?></td>
                                    <td width="20%" align="left"><select name="iam">
                                    	<?php
										$sqlgender = 'select GenderID as Id, '.$_SESSION['lang'].'Gender as LName from '.$table_prefix.'gender order by TopSorted desc, LName asc';
										dropdownlist($sqlgender, 1);
										?>
                                    </select></td>
                                    <td width="20%" align="right"><?php echo $youfind.' : ';?></td>
                                    <td width="25%" align="left"><select name="findgen"><option value="0">- - <?php echo $selectall;?> - -</option>
                                    	<?php
										$newval = intval($_GET['fg'])>0?intval($_GET['fg']):2;
										$sqlgender = 'select GenderID as Id, '.$_SESSION['lang'].'Gender as LName from '.$table_prefix.'gender order by TopSorted desc, LName asc';
										dropdownlist($sqlgender, $newval);
										?>
                                    </select></td>
                                </tr>
                                <tr>
                                	<td width="20%" align="right"><?php echo $age.' : ';?></td>
                                    <td width="25%" align="left"><select name="slagefrom">
                                    	<?php
										for($i=18; $i<76; $i++){
											$val = isset($_GET['af'])?$_GET['af']:18;
											$sel = ($val==$i)?' selected="selected"':'';
											echo '<option value="'.$i.'" '.$sel.'>'.$i.'</option>';
											}
										?>
                                    </select><span style="margin-left:10px; margin-right:10px;"><?php echo $to;?></span><select name="slageto">
										<?php
                                        for($i=18; $i<76; $i++){
                                            $val = isset($_GET['at'])?$_GET['at']:25;
                                            $sel = ($val==$i)?' selected="selected"':'';
                                            echo '<option value="'.$i.'" '.$sel.'>'.$i.'</option>';
                                            }
                                        ?>
                                    </select></td>
                                    <td width="21%" align="right"><?php echo $marital.' : ';?></td>
                                    <td width="25%" align="left"><select name="slMarital"><option value="0">- - <?php echo $selectall;?> - -</option>
                                    	<?php
										$sel = isset($_GET['m'])?$_GET['m']:0;
										$sql = 'select MaritalStatusID as Id, '.$_SESSION['lang'].'MaritalStatus as LName from '.$table_prefix.'maritalstatus order by TopSorted desc, LName asc';
										dropdownlist($sql, $sel);
										?>
                                    </select></td>
                                </tr>
                                <tr>
                                	<td width="25%" align="right"><?php echo $country.' : ';?></td>
                                    <td width="20%" align="left"><select name="slcountry" id="slcountry" style="width:200px;"><option value="0">- - <?php echo $selectall;?> - -</option>
										<?php
                                        $sel = isset($_GET['c'])?$_GET['c']:0;
                                        $sqlcountry = 'select CountryID as Id, Country as LName from '.$table_prefix.'countries order by TopSorted desc, LName asc';
                                        dropdownlist($sqlcountry, $sel);
                                        ?>
                                    </select></td>
                                    <td width="20%" align="right"><?php echo $state.' : ';?></td>
                                    <td width="25%" align="left"><select name="slcity" id="slcity">
										<?php
                                        if(isset($_GET['c']) && $_GET['c']>0){
                                            $sql = 'select StateID as Id, State as LName from '.$table_prefix.'states where CountryID = '.intval($_GET['c']).' order by TopSorted desc, LName asc';
                                            dropdownlist($sql, $_GET['st']);
                                            }
                                        else echo '<option value="0">- - '.$selectall.' - -</option>';
                                        ?>
                                    </select></td>
                                </tr>
                                <tr>
                                	<td width="25%" align="right"><?php echo $city.' : ';?></td>
                                    <td width="20%" align="left">
                                    	<input type="text" size="28" name="txtprovince" value="<?php echo (isset($_GET['tp']) && !empty($_GET['tp']))?$_GET['tp']:'';?>"/>
                                    </td>
                                    <td width="20%" align="right"><?php echo $purposeto.' : ';?></td>
                                    <td width="28%" align="left"><select name="slDatingInterest"><option value="0">- - <?php echo $selectall;?> - -</option>
											<?php
                                            $sel = isset($_GET['d'])?$_GET['d']:0;
                                            $sql = 'select DatingInterestID as Id, '.$_SESSION['lang'].'DatingInterest as LName from '.$table_prefix.'datinginterest order by TopSorted desc, LName asc';
                                            dropdownlist($sql, $sel);
											$chk = (isset($_GET['o']) && intval($_GET['o'])==1)?'checked="checked"':'';
                                            ?>
                                        </select></td>
                                </tr>
                                <tr>
                                	<td width="25%" align="right">&nbsp;</td>
                                    <td align="left" colspan="3"><input type="checkbox" style="margin-left:0px; padding-left:0px;" <?php echo $chk;?> name="onlyphoto"/> <?php echo $onlyphotos;?></td>
                                </tr>
                            </table>
                        <p class="addcons" onclick="changeSearch('advande','advandesearch', 'moresearch', '', 'typesearch', 1)" id="advande" <?php echo $adds;?>><?php echo $addsearch;?></p>
                        <p class="subcons" onclick="changeSearch('advandesearch','advande', 'moresearch', 'none', 'typesearch', 0)" id="advandesearch" <?php echo $subs;?>><?php echo $subsearch;?></p>
                        <span id="moresearch" <?php echo $subs;?>>
                        	<table width="70%" cellpadding="3" cellspacing="3">
                            	<tr>
                                	<td width="25%" align="right"><?php echo $profilename.' : ';?></td>
                                    <td width="20%" align="left" colspan="3"><input type="text" name="profilename" style="width:265px;" value="<?php echo (!empty($_GET['pr']))?$_GET['pr']:'';?>" /></td>
                                </tr>
                                <tr>
                                	<td width="25%" align="right"><?php echo $lightwho.' : ';?></td>
                                    <td width="20%" align="left" colspan="3"><input type="text" name="about" style="width:265px;" value="<?php echo (!empty($_GET['ab']))?$_GET['ab']:'';?>" /></td>
                                </tr>
                            	<tr>
                                	<td width="25%" align="right"><?php echo $haircolor.' : ';?></td>
                                    <td width="20%" align="left"><select name="slHairColor"><option value="0">- - <?php echo $selectall;?> - -</option>
										<?php
                                        $sel = isset($_GET['h'])?$_GET['h']:0;
                                        $sql = 'select HairColorID as Id, '.$_SESSION['lang'].'HairColor as LName from '.$table_prefix.'haircolors order by TopSorted desc, LName asc';
                                        dropdownlist($sql, $sel);
                                        ?>
                                    </select></td>
                                    <td width="20%" align="right"><?php echo $eyeColor.' : ';?></td>
                                    <td width="25%" align="left"><select name="slEyeColor"><option value="0">- - <?php echo $selectall;?> - -</option>
										<?php
                                        $sel = isset($_GET['e'])?$_GET['e']:0;
                                        $sql = 'select EyeColorID as Id, '.$_SESSION['lang'].'EyeColor as LName from '.$table_prefix.'eyescolors order by TopSorted desc, LName asc';
                                        dropdownlist($sql, $sel);
                                        ?>
                                    </select></td>
                                </tr>
                                <tr>
                                	<td width="20%" align="right"><?php echo $height.' : ';?></td>
                                    <td width="35%" align="left"><select name="slHeightfrom">
										<?php
                                        $sel = isset($_GET['hf'])?$_GET['hf']:358;
                                        $sql = 'select HeightID as Id, HeightDescription as LName from '.$table_prefix.'height order by TopSorted desc, LName asc';
                                        dropdownlist($sql, $sel);
                                        ?>
                                    </select><span style="margin-left:10px; margin-right:10px;"><?php echo $to;?></span>
                                    <select name="slHeightto">
                                        <?php
                                        $sel = isset($_GET['ht'])?$_GET['ht']:363;
                                        $sql = 'select HeightID as Id, HeightDescription as LName from '.$table_prefix.'height order by TopSorted desc, LName asc';
                                        dropdownlist($sql, $sel);
                                        ?>
                                    </select></td>
                                    <td width="20%" align="right"><?php echo $bodytype.' : ';?></td>
                                    <td width="25%" align="left"><select name="slBodyType"><option value="0">- - <?php echo $selectall;?> - -</option>
										<?php
                                        $sel = isset($_GET['b'])?$_GET['b']:0;
                                        $sql = 'select BodyTypeID as Id, '.$_SESSION['lang'].'BodyType as LName from '.$table_prefix.'bodytypes order by TopSorted desc, LName asc';
                                        dropdownlist($sql, $sel);
                                        ?>
                                    </select></td>
                                </tr>
                                <tr>
                                	<td width="25%" align="right"><?php echo $smoking.' : ';?></td>
                                    <td width="20%" align="left"><select name="slSmoking"><option value="0">- - <?php echo $selectall;?> - -</option>
										<?php
                                        $sel = isset($_GET['sm'])?$_GET['sm']:0;
                                        $sql = 'select SmokingID as Id, '.$_SESSION['lang'].'Smoking as LName from '.$table_prefix.'smoking order by TopSorted desc, LName asc';
                                        dropdownlist($sql, $sel);
                                        ?>
                                    </select></td>
                                    <td width="20%" align="right"><?php echo $drinking.' : ';?></td>
                                    <td width="28%" align="left"><select name="slDrinking"><option value="0">- - <?php echo $selectall;?> - -</option>
										<?php
                                        $sel = isset($_GET['dr'])?$_GET['dr']:0;
                                        $sql = 'select DrinkingID as Id, '.$_SESSION['lang'].'Drinking as LName from '.$table_prefix.'drinking order by TopSorted desc, LName asc';
                                        dropdownlist($sql, $sel);
                                        ?>
                                    </select></td>
                                </tr>
                                <tr>
                                	<td width="25%" align="right"><?php echo $education.' : ';?></td>
                                    <td width="20%" align="left"><select name="slEducation"><option value="0">- - <?php echo $selectall;?> - -</option>
										<?php
                                        $sel = isset($_GET['ed'])?$_GET['ed']:0;
                                        $sql = 'select EducationID as Id, '.$_SESSION['lang'].'Education as LName from '.$table_prefix.'educations order by TopSorted desc, LName asc';
                                        dropdownlist($sql, $sel);
                                        ?>
                                    </select></td>
                                    <td width="20%" align="right"><?php echo $religion.' : ';?></td>
                                    <td width="25%" align="left"><select name="slReligion"><option value="0">- - <?php echo $selectall;?> - -</option>
										<?php
                                        $sel = isset($_GET['r'])?$_GET['r']:0;
                                        $sql = 'select ReligionID as Id, '.$_SESSION['lang'].'Religion as LName from '.$table_prefix.'religions order by TopSorted desc, LName asc';
                                        dropdownlist($sql, $sel);
                                        ?>
                                    </select></td>
                                </tr>
                                <tr>
                                	<td width="25%" align="right"><?php echo $havechild.' : ';?></td>
                                    <td width="20%" align="left"><select name="rdhave"><option value="0">- - <?php echo $selectall;?> - -</option>
                                    	<option value="2"><?php echo $yes;?></option><option value="3"><?php echo $not;?></option>
                                    </select></td>
                                    <td width="20%" align="right"><?php echo $wantchild.' : ';?></td>
                                    <td width="25%" align="left"><select name="rdwant"><option value="0">- - <?php echo $selectall;?> - -</option>
                                    	<option value="2"><?php echo $yes;?></option><option value="3"><?php echo $notwant;?></option>
                                    </select></td>
                                </tr>
                            </table>
                        </span><input type="hidden" id="typesearch" name="typesearch" value="<?php echo intval($_GET['t']);?>" />
                        <p align="center"><input type="submit" value="<?php echo $searchfprofile;?>" class="massbutton" name="smsearch" /></p>
                        </form>
                    </div>
                <p class="linespace"><br />&nbsp;</p><br />&nbsp;
            </div>
            <p class="linespace">&nbsp;</p>
       </div>
<?php
require_once 'includes/footer.php';
?>