<?php
require_once "includes/config.php";
if(isset($_GET['val']) && !empty($_GET['val'])){
	if(trim($_GET['val'])=='vn' || trim($_GET['val'])=='en'){
		if($_GET['val']=='vn')
			$_SESSION['lang'] = 'L2';
		if(trim($_GET['val'])=='en')
			$_SESSION['lang'] = 'L1';
		header('Location: '.urldecode($_GET['rt']));
		exit();
		}
	else{
		header('Location: '.$base_url);
		exit();
		}
	}
else{
	header('Location: '.$base_url);
	exit();
	}